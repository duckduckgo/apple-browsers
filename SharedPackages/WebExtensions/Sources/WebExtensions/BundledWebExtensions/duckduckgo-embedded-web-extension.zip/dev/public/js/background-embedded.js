"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __esm = (fn, res) => function __init() {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  };
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // node_modules/webextension-polyfill/dist/browser-polyfill.js
  var require_browser_polyfill = __commonJS({
    "node_modules/webextension-polyfill/dist/browser-polyfill.js"(exports2, module2) {
      (function(global2, factory) {
        if (typeof define === "function" && define.amd) {
          define("webextension-polyfill", ["module"], factory);
        } else if (typeof exports2 !== "undefined") {
          factory(module2);
        } else {
          var mod = {
            exports: {}
          };
          factory(mod);
          global2.browser = mod.exports;
        }
      })(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : exports2, function(module3) {
        "use strict";
        if (!(globalThis.chrome && globalThis.chrome.runtime && globalThis.chrome.runtime.id)) {
          throw new Error("This script should only be loaded in a browser extension.");
        }
        if (!(globalThis.browser && globalThis.browser.runtime && globalThis.browser.runtime.id)) {
          const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received.";
          const wrapAPIs = (extensionAPIs) => {
            const apiMetadata = {
              "alarms": {
                "clear": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "clearAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "get": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "bookmarks": {
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getChildren": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getRecent": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getSubTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTree": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "browserAction": {
                "disable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "enable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "getBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "openPopup": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "browsingData": {
                "remove": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "removeCache": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCookies": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeDownloads": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFormData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeHistory": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeLocalStorage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePasswords": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePluginData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "settings": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "commands": {
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "contextMenus": {
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "cookies": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAllCookieStores": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "set": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "devtools": {
                "inspectedWindow": {
                  "eval": {
                    "minArgs": 1,
                    "maxArgs": 2,
                    "singleCallbackArg": false
                  }
                },
                "panels": {
                  "create": {
                    "minArgs": 3,
                    "maxArgs": 3,
                    "singleCallbackArg": true
                  },
                  "elements": {
                    "createSidebarPane": {
                      "minArgs": 1,
                      "maxArgs": 1
                    }
                  }
                }
              },
              "downloads": {
                "cancel": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "download": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "erase": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFileIcon": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "open": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "pause": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFile": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "resume": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "extension": {
                "isAllowedFileSchemeAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "isAllowedIncognitoAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "history": {
                "addUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "deleteRange": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getVisits": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "i18n": {
                "detectLanguage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAcceptLanguages": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "identity": {
                "launchWebAuthFlow": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "idle": {
                "queryState": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "management": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getSelf": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setEnabled": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "uninstallSelf": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "notifications": {
                "clear": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPermissionLevel": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "pageAction": {
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "hide": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "permissions": {
                "contains": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "request": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "runtime": {
                "getBackgroundPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPlatformInfo": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "openOptionsPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "requestUpdateCheck": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "sendMessage": {
                  "minArgs": 1,
                  "maxArgs": 3
                },
                "sendNativeMessage": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "setUninstallURL": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "sessions": {
                "getDevices": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getRecentlyClosed": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "restore": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "storage": {
                "local": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                },
                "managed": {
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  }
                },
                "sync": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                }
              },
              "tabs": {
                "captureVisibleTab": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "detectLanguage": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "discard": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "duplicate": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "executeScript": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getZoom": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getZoomSettings": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goBack": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goForward": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "highlight": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "insertCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "query": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "reload": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "sendMessage": {
                  "minArgs": 2,
                  "maxArgs": 3
                },
                "setZoom": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "setZoomSettings": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "update": {
                  "minArgs": 1,
                  "maxArgs": 2
                }
              },
              "topSites": {
                "get": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "webNavigation": {
                "getAllFrames": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFrame": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "webRequest": {
                "handlerBehaviorChanged": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "windows": {
                "create": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getLastFocused": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              }
            };
            if (Object.keys(apiMetadata).length === 0) {
              throw new Error("api-metadata.json has not been included in browser-polyfill");
            }
            class DefaultWeakMap extends WeakMap {
              constructor(createItem, items = void 0) {
                super(items);
                this.createItem = createItem;
              }
              get(key) {
                if (!this.has(key)) {
                  this.set(key, this.createItem(key));
                }
                return super.get(key);
              }
            }
            const isThenable = (value) => {
              return value && typeof value === "object" && typeof value.then === "function";
            };
            const makeCallback = (promise, metadata) => {
              return (...callbackArgs) => {
                if (extensionAPIs.runtime.lastError) {
                  promise.reject(new Error(extensionAPIs.runtime.lastError.message));
                } else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) {
                  promise.resolve(callbackArgs[0]);
                } else {
                  promise.resolve(callbackArgs);
                }
              };
            };
            const pluralizeArguments = (numArgs) => numArgs == 1 ? "argument" : "arguments";
            const wrapAsyncFunction = (name, metadata) => {
              return function asyncFunctionWrapper(target, ...args) {
                if (args.length < metadata.minArgs) {
                  throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
                }
                if (args.length > metadata.maxArgs) {
                  throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
                }
                return new Promise((resolve, reject) => {
                  if (metadata.fallbackToNoCallback) {
                    try {
                      target[name](...args, makeCallback({
                        resolve,
                        reject
                      }, metadata));
                    } catch (cbError) {
                      console.warn(`${name} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `, cbError);
                      target[name](...args);
                      metadata.fallbackToNoCallback = false;
                      metadata.noCallback = true;
                      resolve();
                    }
                  } else if (metadata.noCallback) {
                    target[name](...args);
                    resolve();
                  } else {
                    target[name](...args, makeCallback({
                      resolve,
                      reject
                    }, metadata));
                  }
                });
              };
            };
            const wrapMethod = (target, method2, wrapper) => {
              return new Proxy(method2, {
                apply(targetMethod, thisObj, args) {
                  return wrapper.call(thisObj, target, ...args);
                }
              });
            };
            let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);
            const wrapObject = (target, wrappers = {}, metadata = {}) => {
              let cache = /* @__PURE__ */ Object.create(null);
              let handlers = {
                has(proxyTarget2, prop) {
                  return prop in target || prop in cache;
                },
                get(proxyTarget2, prop, receiver) {
                  if (prop in cache) {
                    return cache[prop];
                  }
                  if (!(prop in target)) {
                    return void 0;
                  }
                  let value = target[prop];
                  if (typeof value === "function") {
                    if (typeof wrappers[prop] === "function") {
                      value = wrapMethod(target, target[prop], wrappers[prop]);
                    } else if (hasOwnProperty(metadata, prop)) {
                      let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                      value = wrapMethod(target, target[prop], wrapper);
                    } else {
                      value = value.bind(target);
                    }
                  } else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) {
                    value = wrapObject(value, wrappers[prop], metadata[prop]);
                  } else if (hasOwnProperty(metadata, "*")) {
                    value = wrapObject(value, wrappers[prop], metadata["*"]);
                  } else {
                    Object.defineProperty(cache, prop, {
                      configurable: true,
                      enumerable: true,
                      get() {
                        return target[prop];
                      },
                      set(value2) {
                        target[prop] = value2;
                      }
                    });
                    return value;
                  }
                  cache[prop] = value;
                  return value;
                },
                set(proxyTarget2, prop, value, receiver) {
                  if (prop in cache) {
                    cache[prop] = value;
                  } else {
                    target[prop] = value;
                  }
                  return true;
                },
                defineProperty(proxyTarget2, prop, desc) {
                  return Reflect.defineProperty(cache, prop, desc);
                },
                deleteProperty(proxyTarget2, prop) {
                  return Reflect.deleteProperty(cache, prop);
                }
              };
              let proxyTarget = Object.create(target);
              return new Proxy(proxyTarget, handlers);
            };
            const wrapEvent = (wrapperMap) => ({
              addListener(target, listener, ...args) {
                target.addListener(wrapperMap.get(listener), ...args);
              },
              hasListener(target, listener) {
                return target.hasListener(wrapperMap.get(listener));
              },
              removeListener(target, listener) {
                target.removeListener(wrapperMap.get(listener));
              }
            });
            const onRequestFinishedWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onRequestFinished(req) {
                const wrappedReq = wrapObject(req, {}, {
                  getContent: {
                    minArgs: 0,
                    maxArgs: 0
                  }
                });
                listener(wrappedReq);
              };
            });
            const onMessageWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onMessage(message, sender, sendResponse) {
                let didCallSendResponse = false;
                let wrappedSendResponse;
                let sendResponsePromise = new Promise((resolve) => {
                  wrappedSendResponse = function(response) {
                    didCallSendResponse = true;
                    resolve(response);
                  };
                });
                let result;
                try {
                  result = listener(message, sender, wrappedSendResponse);
                } catch (err) {
                  result = Promise.reject(err);
                }
                const isResultThenable = result !== true && isThenable(result);
                if (result !== true && !isResultThenable && !didCallSendResponse) {
                  return false;
                }
                const sendPromisedResult = (promise) => {
                  promise.then((msg) => {
                    sendResponse(msg);
                  }, (error) => {
                    let message2;
                    if (error && (error instanceof Error || typeof error.message === "string")) {
                      message2 = error.message;
                    } else {
                      message2 = "An unexpected error occurred";
                    }
                    sendResponse({
                      __mozWebExtensionPolyfillReject__: true,
                      message: message2
                    });
                  }).catch((err) => {
                    console.error("Failed to send onMessage rejected reply", err);
                  });
                };
                if (isResultThenable) {
                  sendPromisedResult(result);
                } else {
                  sendPromisedResult(sendResponsePromise);
                }
                return true;
              };
            });
            const wrappedSendMessageCallback = ({
              reject,
              resolve
            }, reply) => {
              if (extensionAPIs.runtime.lastError) {
                if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) {
                  resolve();
                } else {
                  reject(new Error(extensionAPIs.runtime.lastError.message));
                }
              } else if (reply && reply.__mozWebExtensionPolyfillReject__) {
                reject(new Error(reply.message));
              } else {
                resolve(reply);
              }
            };
            const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
              if (args.length < metadata.minArgs) {
                throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
              }
              if (args.length > metadata.maxArgs) {
                throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
              }
              return new Promise((resolve, reject) => {
                const wrappedCb = wrappedSendMessageCallback.bind(null, {
                  resolve,
                  reject
                });
                args.push(wrappedCb);
                apiNamespaceObj.sendMessage(...args);
              });
            };
            const staticWrappers = {
              devtools: {
                network: {
                  onRequestFinished: wrapEvent(onRequestFinishedWrappers)
                }
              },
              runtime: {
                onMessage: wrapEvent(onMessageWrappers),
                onMessageExternal: wrapEvent(onMessageWrappers),
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 1,
                  maxArgs: 3
                })
              },
              tabs: {
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 2,
                  maxArgs: 3
                })
              }
            };
            const settingMetadata = {
              clear: {
                minArgs: 1,
                maxArgs: 1
              },
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              set: {
                minArgs: 1,
                maxArgs: 1
              }
            };
            apiMetadata.privacy = {
              network: {
                "*": settingMetadata
              },
              services: {
                "*": settingMetadata
              },
              websites: {
                "*": settingMetadata
              }
            };
            return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
          };
          module3.exports = wrapAPIs(chrome);
        } else {
          module3.exports = globalThis.browser;
        }
      });
    }
  });

  // shared/js/background/wrapper.js
  var wrapper_exports = {};
  __export(wrapper_exports, {
    changeTabURL: () => changeTabURL,
    createAlarm: () => createAlarm,
    executeScript: () => executeScript,
    getDDGTabUrls: () => getDDGTabUrls,
    getExtensionId: () => getExtensionId,
    getExtensionURL: () => getExtensionURL,
    getExtensionVersion: () => getExtensionVersion,
    getFromManagedStorage: () => getFromManagedStorage,
    getFromSessionStorage: () => getFromSessionStorage,
    getFromStorage: () => getFromStorage,
    getManifestVersion: () => getManifestVersion,
    insertCSS: () => insertCSS,
    mergeSavedSettings: () => mergeSavedSettings,
    normalizeTabData: () => normalizeTabData,
    openExtensionPage: () => openExtensionPage,
    removeFromSessionStorage: () => removeFromSessionStorage,
    sessionStorageFallback: () => sessionStorageFallback,
    setActionIcon: () => setActionIcon,
    setToSessionStorage: () => setToSessionStorage,
    setUninstallURL: () => setUninstallURL,
    syncToStorage: () => syncToStorage
  });
  function getExtensionURL(path) {
    return import_webextension_polyfill2.default.runtime.getURL(path);
  }
  function getExtensionVersion() {
    const manifest = import_webextension_polyfill2.default.runtime.getManifest();
    return manifest.version;
  }
  function openExtensionPage(path) {
    import_webextension_polyfill2.default.tabs.create({ url: getExtensionURL(path) });
  }
  async function setActionIcon(iconPath, tabId) {
    if (typeof import_webextension_polyfill2.default.action === "undefined") {
      return import_webextension_polyfill2.default.browserAction.setIcon({ path: iconPath, tabId });
    }
    return import_webextension_polyfill2.default.action.setIcon({ path: iconPath, tabId });
  }
  function getManifestVersion() {
    const manifest = import_webextension_polyfill2.default.runtime.getManifest();
    return manifest.manifest_version;
  }
  function syncToStorage(data) {
    return import_webextension_polyfill2.default.storage.local.set(data);
  }
  async function getFromStorage(key, cb) {
    const result = await import_webextension_polyfill2.default.storage.local.get(key);
    return result[key];
  }
  async function getFromManagedStorage(keys, cb) {
    try {
      return await import_webextension_polyfill2.default.storage.managed.get(keys);
    } catch (e) {
      console.log("get managed failed", e);
    }
    return {};
  }
  function getExtensionId() {
    return import_webextension_polyfill2.default.runtime.id;
  }
  function normalizeTabData(tabData) {
    const tabId = "tabId" in tabData ? tabData.tabId : tabData.id;
    const url = tabData.url;
    const status = "status" in tabData ? tabData.status : null;
    const requestId = "requestId" in tabData ? tabData.requestId : void 0;
    return {
      tabId,
      url,
      requestId,
      status
    };
  }
  function mergeSavedSettings(settings3, results) {
    return Object.assign(settings3, results);
  }
  async function getDDGTabUrls() {
    const tabs = await import_webextension_polyfill2.default.tabs.query({ url: "https://*.duckduckgo.com/*" }) || [];
    return tabs.map((tab) => tab.url);
  }
  function setUninstallURL(url) {
    import_webextension_polyfill2.default.runtime.setUninstallURL(url);
  }
  function changeTabURL(tabId, url) {
    return import_webextension_polyfill2.default.tabs.update(tabId, { url });
  }
  function convertScriptingAPIOptionsForTabsAPI(options) {
    if (typeof options !== "object") {
      throw new Error("Missing/invalid options Object.");
    }
    if (typeof options.file !== "undefined" || typeof options.frameId !== "undefined" || typeof options.runAt !== "undefined" || typeof options.allFrames !== "undefined" || typeof options.code !== "undefined") {
      throw new Error("Please provide options compatible with the (MV3) scripting API, instead of the (MV2) tabs API.");
    }
    if (typeof options.world !== "undefined") {
      throw new Error("World targetting not supported by MV2.");
    }
    const { allFrames, frameIds, tabId } = options.target;
    delete options.target;
    if (Array.isArray(frameIds) && frameIds.length > 0) {
      if (frameIds.length > 1) {
        throw new Error("Targetting multiple frames by ID not supported by MV2.");
      }
      options.frameId = frameIds[0];
    }
    if (typeof options.files !== "undefined") {
      if (Array.isArray(options.files) && options.files.length > 0) {
        if (options.files.length > 1) {
          throw new Error("Inserting multiple stylesheets/scripts in one go not supported by MV2.");
        }
        options.file = options.files[0];
      }
      delete options.files;
    }
    if (typeof allFrames !== "undefined") {
      options.allFrames = allFrames;
    }
    if (typeof options.injectImmediately !== "undefined") {
      if (options.injectImmediately) {
        options.runAt = "document_start";
      }
      delete options.injectImmediately;
    }
    let stringifiedArgs = "";
    if (typeof options.args !== "undefined") {
      if (Array.isArray(options.args)) {
        stringifiedArgs = "..." + JSON.stringify(options.args);
      }
      delete options.args;
    }
    if (typeof options.func !== "undefined") {
      if (typeof options.func === "function") {
        options.code = "(" + options.func.toString() + ")(" + stringifiedArgs + ")";
      }
      delete options.func;
    }
    return [tabId, options];
  }
  async function executeScript(options) {
    if (typeof import_webextension_polyfill2.default.scripting === "undefined") {
      return await import_webextension_polyfill2.default.tabs.executeScript(
        ...convertScriptingAPIOptionsForTabsAPI(options)
      );
    }
    return await import_webextension_polyfill2.default.scripting.executeScript(options);
  }
  async function insertCSS(options) {
    if (typeof import_webextension_polyfill2.default.scripting === "undefined") {
      return await import_webextension_polyfill2.default.tabs.insertCSS(
        ...convertScriptingAPIOptionsForTabsAPI(options)
      );
    }
    return await import_webextension_polyfill2.default.scripting.insertCSS(options);
  }
  async function setToSessionStorage(key, data) {
    if (typeof key !== "string") {
      throw new Error("Invalid storage key, string expected.");
    }
    if (sessionStorageSupported) {
      return await import_webextension_polyfill2.default.storage.session.set({ [key]: data });
    }
    sessionStorageFallback.set(key, data);
  }
  async function getFromSessionStorage(key) {
    if (typeof key !== "string") {
      throw new Error("Invalid storage key, string expected.");
    }
    if (sessionStorageSupported) {
      const result = await import_webextension_polyfill2.default.storage.session.get([key]);
      return result[key];
    }
    return sessionStorageFallback.get(key);
  }
  async function removeFromSessionStorage(key) {
    if (typeof key !== "string") {
      throw new Error("Invalid storage key, string expected.");
    }
    if (sessionStorageSupported) {
      return await import_webextension_polyfill2.default.storage.session.remove(key);
    }
    return sessionStorageFallback.delete(key);
  }
  async function createAlarm(name, alarmInfo) {
    const existingAlarm = await import_webextension_polyfill2.default.alarms.get(name);
    if (!existingAlarm) {
      return await import_webextension_polyfill2.default.alarms.create(name, alarmInfo);
    }
  }
  var import_webextension_polyfill2, sessionStorageSupported, sessionStorageFallback;
  var init_wrapper = __esm({
    "shared/js/background/wrapper.js"() {
      "use strict";
      import_webextension_polyfill2 = __toESM(require_browser_polyfill());
      sessionStorageSupported = typeof import_webextension_polyfill2.default.storage.session !== "undefined";
      sessionStorageFallback = sessionStorageSupported ? null : /* @__PURE__ */ new Map();
    }
  });

  // shared/data/defaultSettings.js
  var require_defaultSettings = __commonJS({
    "shared/data/defaultSettings.js"(exports2, module2) {
      "use strict";
      module2.exports = {
        httpsEverywhereEnabled: true,
        embeddedTweetsEnabled: false,
        GPC: true,
        youtubePreviewsEnabled: false,
        atb: null,
        set_atb: null,
        "config-etag": null,
        "httpsUpgradeBloomFilter-etag": null,
        "httpsDontUpgradeBloomFilters-etag": null,
        "httpsUpgradeList-etag": null,
        "httpsDontUpgradeList-etag": null,
        hasSeenPostInstall: false,
        extiSent: false,
        "tds-etag": null,
        lastTdsUpdate: 0,
        fireButtonClearHistoryEnabled: true,
        fireButtonTabClearEnabled: true
      };
    }
  });

  // shared/js/background/settings.js
  var require_settings = __commonJS({
    "shared/js/background/settings.js"(exports2, module2) {
      "use strict";
      var defaultSettings = require_defaultSettings();
      var browserWrapper = (init_wrapper(), __toCommonJS(wrapper_exports));
      var onSettingUpdate = new EventTarget();
      if (typeof CustomEvent === "undefined") globalThis.CustomEvent = Event;
      var MANAGED_SETTINGS = ["hasSeenPostInstall"];
      var settings3 = {};
      var isReady = false;
      var _ready = init().then(() => {
        isReady = true;
        console.log("Settings are loaded");
      });
      async function init() {
        buildSettingsFromDefaults();
        await buildSettingsFromManagedStorage();
        await buildSettingsFromLocalStorage();
      }
      function ready() {
        return _ready;
      }
      function checkForLegacyKeys() {
        const legacyKeys = {
          // Keys to migrate
          whitelisted: "allowlisted",
          whitelistOptIn: "allowlistOptIn",
          // Keys to remove
          advanced_options: null,
          clickToLoadClicks: null,
          cookieExcludeList: null,
          dev: null,
          ducky: null,
          extensionIsEnabled: null,
          failedUpgrades: null,
          last_search: null,
          lastsearch_enabled: null,
          meanings: null,
          safesearch: null,
          socialBlockingIsEnabled: null,
          totalUpgrades: null,
          trackerBlockingEnabled: null,
          use_post: null,
          version: null,
          zeroclick_google_right: null,
          "surrogates-etag": null,
          "brokenSiteList-etag": null,
          "surrogateList-etag": null,
          "trackersWhitelist-etag": null,
          "trackersWhitelistTemporary-etag": null
        };
        let syncNeeded = false;
        for (const legacyKey in legacyKeys) {
          const key = legacyKeys[legacyKey];
          if (!(legacyKey in settings3)) {
            continue;
          }
          syncNeeded = true;
          const legacyValue = settings3[legacyKey];
          if (key && legacyValue) {
            settings3[key] = legacyValue;
          }
          delete settings3[legacyKey];
        }
        if (syncNeeded) {
          syncSettingTolocalStorage();
        }
      }
      async function buildSettingsFromLocalStorage() {
        const results = await browserWrapper.getFromStorage(["settings"]);
        if (!results) return;
        settings3 = browserWrapper.mergeSavedSettings(settings3, results);
        checkForLegacyKeys();
      }
      async function buildSettingsFromManagedStorage() {
        const results = await browserWrapper.getFromManagedStorage(MANAGED_SETTINGS);
        settings3 = browserWrapper.mergeSavedSettings(settings3, results);
      }
      function buildSettingsFromDefaults() {
        settings3 = Object.assign({}, defaultSettings);
      }
      function syncSettingTolocalStorage() {
        return browserWrapper.syncToStorage({ settings: settings3 });
      }
      function getSetting(name) {
        if (!isReady) {
          console.warn(`Settings: getSetting() Settings not loaded: ${name}`);
          return;
        }
        if (name === "all") name = null;
        if (name) {
          return settings3[name];
        } else {
          return settings3;
        }
      }
      function updateSetting(name, value) {
        if (!isReady) {
          console.warn(`Settings: updateSetting() Setting not loaded: ${name}`);
          return;
        }
        settings3[name] = value;
        syncSettingTolocalStorage().then(() => {
          onSettingUpdate.dispatchEvent(new CustomEvent(name, { detail: value }));
        });
      }
      function incrementNumericSetting(name, increment = 1) {
        if (!isReady) {
          console.warn("Settings: incrementNumericSetting() Setting not loaded:", name);
          return;
        }
        let value = settings3[name];
        if (typeof value !== "number" || isNaN(value)) {
          value = 0;
        }
        updateSetting(name, value + increment);
      }
      function removeSetting(name) {
        if (!isReady) {
          console.warn(`Settings: removeSetting() Setting not loaded: ${name}`);
          return;
        }
        if (settings3[name]) {
          delete settings3[name];
          syncSettingTolocalStorage();
        }
      }
      function logSettings() {
        browserWrapper.getFromStorage(["settings"]).then((s) => {
          console.log(s.settings);
        });
      }
      module2.exports = {
        getSetting,
        updateSetting,
        incrementNumericSetting,
        removeSetting,
        logSettings,
        ready,
        onSettingUpdate
      };
    }
  });

  // shared/js/shared-utils/parse-user-agent-string.js
  var require_parse_user_agent_string = __commonJS({
    "shared/js/shared-utils/parse-user-agent-string.js"(exports2, module2) {
      "use strict";
      module2.exports = (uaString) => {
        if (!globalThis.navigator) return {};
        if (!uaString) uaString = globalThis.navigator.userAgent;
        let browser9;
        let version;
        try {
          let parsedUaParts = uaString.match(/(Firefox|Chrome|Edg)\/([0-9]+)/);
          const isEdge = /(Edge?)\/([0-9]+)/;
          const isOpera = /(OPR)\/([0-9]+)/;
          if (uaString.match(isEdge)) {
            parsedUaParts = uaString.match(isEdge);
          } else if (uaString.match(isOpera)) {
            parsedUaParts = uaString.match(isOpera);
            parsedUaParts[1] = "Opera";
          }
          browser9 = parsedUaParts[1];
          version = parsedUaParts[2];
          if (globalThis.navigator.brave) {
            browser9 = "Brave";
          }
        } catch (e) {
          browser9 = version = "";
        }
        let os = "o";
        if (globalThis.navigator.userAgent.indexOf("Windows") !== -1) os = "w";
        if (globalThis.navigator.userAgent.indexOf("Mac") !== -1) os = "m";
        if (globalThis.navigator.userAgent.indexOf("Linux") !== -1) os = "l";
        return {
          os,
          browser: browser9,
          version
        };
      };
    }
  });

  // shared/js/shared-utils/sha1.js
  var require_sha1 = __commonJS({
    "shared/js/shared-utils/sha1.js"(exports, module) {
      "use strict";
      (function() {
        "use strict";
        var root = typeof window === "object" ? window : {};
        var NODE_JS = !root.JS_SHA1_NO_NODE_JS && typeof process === "object" && process.versions && process.versions.node;
        if (NODE_JS) {
          root = global;
        }
        var COMMON_JS = !root.JS_SHA1_NO_COMMON_JS && typeof module === "object" && module.exports;
        var AMD = typeof define === "function" && define.amd;
        var HEX_CHARS = "0123456789abcdef".split("");
        var EXTRA = [-2147483648, 8388608, 32768, 128];
        var SHIFT = [24, 16, 8, 0];
        var OUTPUT_TYPES = ["hex", "array", "digest", "arrayBuffer"];
        var blocks = [];
        var createOutputMethod = function(outputType) {
          return function(message) {
            return new Sha1(true).update(message)[outputType]();
          };
        };
        var createMethod = function() {
          var method2 = createOutputMethod("hex");
          if (NODE_JS) {
            method2 = nodeWrap(method2);
          }
          method2.create = function() {
            return new Sha1();
          };
          method2.update = function(message) {
            return method2.create().update(message);
          };
          for (var i = 0; i < OUTPUT_TYPES.length; ++i) {
            var type = OUTPUT_TYPES[i];
            method2[type] = createOutputMethod(type);
          }
          return method2;
        };
        var nodeWrap = function(method) {
          var crypto = eval("require('crypto')");
          var Buffer = eval("require('buffer').Buffer");
          var nodeMethod = function(message) {
            if (typeof message === "string") {
              return crypto.createHash("sha1").update(message, "utf8").digest("hex");
            } else if (message.constructor === ArrayBuffer) {
              message = new Uint8Array(message);
            } else if (message.length === void 0) {
              return method(message);
            }
            return crypto.createHash("sha1").update(new Buffer(message)).digest("hex");
          };
          return nodeMethod;
        };
        function Sha1(sharedMemory) {
          if (sharedMemory) {
            blocks[0] = blocks[16] = blocks[1] = blocks[2] = blocks[3] = blocks[4] = blocks[5] = blocks[6] = blocks[7] = blocks[8] = blocks[9] = blocks[10] = blocks[11] = blocks[12] = blocks[13] = blocks[14] = blocks[15] = 0;
            this.blocks = blocks;
          } else {
            this.blocks = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
          }
          this.h0 = 1732584193;
          this.h1 = 4023233417;
          this.h2 = 2562383102;
          this.h3 = 271733878;
          this.h4 = 3285377520;
          this.block = this.start = this.bytes = this.hBytes = 0;
          this.finalized = this.hashed = false;
          this.first = true;
        }
        Sha1.prototype.update = function(message) {
          if (this.finalized) {
            return;
          }
          var notString = typeof message !== "string";
          if (notString && message.constructor === root.ArrayBuffer) {
            message = new Uint8Array(message);
          }
          var code, index = 0, i, length = message.length || 0, blocks2 = this.blocks;
          while (index < length) {
            if (this.hashed) {
              this.hashed = false;
              blocks2[0] = this.block;
              blocks2[16] = blocks2[1] = blocks2[2] = blocks2[3] = blocks2[4] = blocks2[5] = blocks2[6] = blocks2[7] = blocks2[8] = blocks2[9] = blocks2[10] = blocks2[11] = blocks2[12] = blocks2[13] = blocks2[14] = blocks2[15] = 0;
            }
            if (notString) {
              for (i = this.start; index < length && i < 64; ++index) {
                blocks2[i >> 2] |= message[index] << SHIFT[i++ & 3];
              }
            } else {
              for (i = this.start; index < length && i < 64; ++index) {
                code = message.charCodeAt(index);
                if (code < 128) {
                  blocks2[i >> 2] |= code << SHIFT[i++ & 3];
                } else if (code < 2048) {
                  blocks2[i >> 2] |= (192 | code >> 6) << SHIFT[i++ & 3];
                  blocks2[i >> 2] |= (128 | code & 63) << SHIFT[i++ & 3];
                } else if (code < 55296 || code >= 57344) {
                  blocks2[i >> 2] |= (224 | code >> 12) << SHIFT[i++ & 3];
                  blocks2[i >> 2] |= (128 | code >> 6 & 63) << SHIFT[i++ & 3];
                  blocks2[i >> 2] |= (128 | code & 63) << SHIFT[i++ & 3];
                } else {
                  code = 65536 + ((code & 1023) << 10 | message.charCodeAt(++index) & 1023);
                  blocks2[i >> 2] |= (240 | code >> 18) << SHIFT[i++ & 3];
                  blocks2[i >> 2] |= (128 | code >> 12 & 63) << SHIFT[i++ & 3];
                  blocks2[i >> 2] |= (128 | code >> 6 & 63) << SHIFT[i++ & 3];
                  blocks2[i >> 2] |= (128 | code & 63) << SHIFT[i++ & 3];
                }
              }
            }
            this.lastByteIndex = i;
            this.bytes += i - this.start;
            if (i >= 64) {
              this.block = blocks2[16];
              this.start = i - 64;
              this.hash();
              this.hashed = true;
            } else {
              this.start = i;
            }
          }
          if (this.bytes > 4294967295) {
            this.hBytes += this.bytes / 4294967296 << 0;
            this.bytes = this.bytes % 4294967296;
          }
          return this;
        };
        Sha1.prototype.finalize = function() {
          if (this.finalized) {
            return;
          }
          this.finalized = true;
          var blocks2 = this.blocks, i = this.lastByteIndex;
          blocks2[16] = this.block;
          blocks2[i >> 2] |= EXTRA[i & 3];
          this.block = blocks2[16];
          if (i >= 56) {
            if (!this.hashed) {
              this.hash();
            }
            blocks2[0] = this.block;
            blocks2[16] = blocks2[1] = blocks2[2] = blocks2[3] = blocks2[4] = blocks2[5] = blocks2[6] = blocks2[7] = blocks2[8] = blocks2[9] = blocks2[10] = blocks2[11] = blocks2[12] = blocks2[13] = blocks2[14] = blocks2[15] = 0;
          }
          blocks2[14] = this.hBytes << 3 | this.bytes >>> 29;
          blocks2[15] = this.bytes << 3;
          this.hash();
        };
        Sha1.prototype.hash = function() {
          var a = this.h0, b = this.h1, c = this.h2, d = this.h3, e = this.h4;
          var f, j, t, blocks2 = this.blocks;
          for (j = 16; j < 80; ++j) {
            t = blocks2[j - 3] ^ blocks2[j - 8] ^ blocks2[j - 14] ^ blocks2[j - 16];
            blocks2[j] = t << 1 | t >>> 31;
          }
          for (j = 0; j < 20; j += 5) {
            f = b & c | ~b & d;
            t = a << 5 | a >>> 27;
            e = t + f + e + 1518500249 + blocks2[j] << 0;
            b = b << 30 | b >>> 2;
            f = a & b | ~a & c;
            t = e << 5 | e >>> 27;
            d = t + f + d + 1518500249 + blocks2[j + 1] << 0;
            a = a << 30 | a >>> 2;
            f = e & a | ~e & b;
            t = d << 5 | d >>> 27;
            c = t + f + c + 1518500249 + blocks2[j + 2] << 0;
            e = e << 30 | e >>> 2;
            f = d & e | ~d & a;
            t = c << 5 | c >>> 27;
            b = t + f + b + 1518500249 + blocks2[j + 3] << 0;
            d = d << 30 | d >>> 2;
            f = c & d | ~c & e;
            t = b << 5 | b >>> 27;
            a = t + f + a + 1518500249 + blocks2[j + 4] << 0;
            c = c << 30 | c >>> 2;
          }
          for (; j < 40; j += 5) {
            f = b ^ c ^ d;
            t = a << 5 | a >>> 27;
            e = t + f + e + 1859775393 + blocks2[j] << 0;
            b = b << 30 | b >>> 2;
            f = a ^ b ^ c;
            t = e << 5 | e >>> 27;
            d = t + f + d + 1859775393 + blocks2[j + 1] << 0;
            a = a << 30 | a >>> 2;
            f = e ^ a ^ b;
            t = d << 5 | d >>> 27;
            c = t + f + c + 1859775393 + blocks2[j + 2] << 0;
            e = e << 30 | e >>> 2;
            f = d ^ e ^ a;
            t = c << 5 | c >>> 27;
            b = t + f + b + 1859775393 + blocks2[j + 3] << 0;
            d = d << 30 | d >>> 2;
            f = c ^ d ^ e;
            t = b << 5 | b >>> 27;
            a = t + f + a + 1859775393 + blocks2[j + 4] << 0;
            c = c << 30 | c >>> 2;
          }
          for (; j < 60; j += 5) {
            f = b & c | b & d | c & d;
            t = a << 5 | a >>> 27;
            e = t + f + e - 1894007588 + blocks2[j] << 0;
            b = b << 30 | b >>> 2;
            f = a & b | a & c | b & c;
            t = e << 5 | e >>> 27;
            d = t + f + d - 1894007588 + blocks2[j + 1] << 0;
            a = a << 30 | a >>> 2;
            f = e & a | e & b | a & b;
            t = d << 5 | d >>> 27;
            c = t + f + c - 1894007588 + blocks2[j + 2] << 0;
            e = e << 30 | e >>> 2;
            f = d & e | d & a | e & a;
            t = c << 5 | c >>> 27;
            b = t + f + b - 1894007588 + blocks2[j + 3] << 0;
            d = d << 30 | d >>> 2;
            f = c & d | c & e | d & e;
            t = b << 5 | b >>> 27;
            a = t + f + a - 1894007588 + blocks2[j + 4] << 0;
            c = c << 30 | c >>> 2;
          }
          for (; j < 80; j += 5) {
            f = b ^ c ^ d;
            t = a << 5 | a >>> 27;
            e = t + f + e - 899497514 + blocks2[j] << 0;
            b = b << 30 | b >>> 2;
            f = a ^ b ^ c;
            t = e << 5 | e >>> 27;
            d = t + f + d - 899497514 + blocks2[j + 1] << 0;
            a = a << 30 | a >>> 2;
            f = e ^ a ^ b;
            t = d << 5 | d >>> 27;
            c = t + f + c - 899497514 + blocks2[j + 2] << 0;
            e = e << 30 | e >>> 2;
            f = d ^ e ^ a;
            t = c << 5 | c >>> 27;
            b = t + f + b - 899497514 + blocks2[j + 3] << 0;
            d = d << 30 | d >>> 2;
            f = c ^ d ^ e;
            t = b << 5 | b >>> 27;
            a = t + f + a - 899497514 + blocks2[j + 4] << 0;
            c = c << 30 | c >>> 2;
          }
          this.h0 = this.h0 + a << 0;
          this.h1 = this.h1 + b << 0;
          this.h2 = this.h2 + c << 0;
          this.h3 = this.h3 + d << 0;
          this.h4 = this.h4 + e << 0;
        };
        Sha1.prototype.hex = function() {
          this.finalize();
          var h0 = this.h0, h1 = this.h1, h2 = this.h2, h3 = this.h3, h4 = this.h4;
          return HEX_CHARS[h0 >> 28 & 15] + HEX_CHARS[h0 >> 24 & 15] + HEX_CHARS[h0 >> 20 & 15] + HEX_CHARS[h0 >> 16 & 15] + HEX_CHARS[h0 >> 12 & 15] + HEX_CHARS[h0 >> 8 & 15] + HEX_CHARS[h0 >> 4 & 15] + HEX_CHARS[h0 & 15] + HEX_CHARS[h1 >> 28 & 15] + HEX_CHARS[h1 >> 24 & 15] + HEX_CHARS[h1 >> 20 & 15] + HEX_CHARS[h1 >> 16 & 15] + HEX_CHARS[h1 >> 12 & 15] + HEX_CHARS[h1 >> 8 & 15] + HEX_CHARS[h1 >> 4 & 15] + HEX_CHARS[h1 & 15] + HEX_CHARS[h2 >> 28 & 15] + HEX_CHARS[h2 >> 24 & 15] + HEX_CHARS[h2 >> 20 & 15] + HEX_CHARS[h2 >> 16 & 15] + HEX_CHARS[h2 >> 12 & 15] + HEX_CHARS[h2 >> 8 & 15] + HEX_CHARS[h2 >> 4 & 15] + HEX_CHARS[h2 & 15] + HEX_CHARS[h3 >> 28 & 15] + HEX_CHARS[h3 >> 24 & 15] + HEX_CHARS[h3 >> 20 & 15] + HEX_CHARS[h3 >> 16 & 15] + HEX_CHARS[h3 >> 12 & 15] + HEX_CHARS[h3 >> 8 & 15] + HEX_CHARS[h3 >> 4 & 15] + HEX_CHARS[h3 & 15] + HEX_CHARS[h4 >> 28 & 15] + HEX_CHARS[h4 >> 24 & 15] + HEX_CHARS[h4 >> 20 & 15] + HEX_CHARS[h4 >> 16 & 15] + HEX_CHARS[h4 >> 12 & 15] + HEX_CHARS[h4 >> 8 & 15] + HEX_CHARS[h4 >> 4 & 15] + HEX_CHARS[h4 & 15];
        };
        Sha1.prototype.toString = Sha1.prototype.hex;
        Sha1.prototype.digest = function() {
          this.finalize();
          var h0 = this.h0, h1 = this.h1, h2 = this.h2, h3 = this.h3, h4 = this.h4;
          return [
            h0 >> 24 & 255,
            h0 >> 16 & 255,
            h0 >> 8 & 255,
            h0 & 255,
            h1 >> 24 & 255,
            h1 >> 16 & 255,
            h1 >> 8 & 255,
            h1 & 255,
            h2 >> 24 & 255,
            h2 >> 16 & 255,
            h2 >> 8 & 255,
            h2 & 255,
            h3 >> 24 & 255,
            h3 >> 16 & 255,
            h3 >> 8 & 255,
            h3 & 255,
            h4 >> 24 & 255,
            h4 >> 16 & 255,
            h4 >> 8 & 255,
            h4 & 255
          ];
        };
        Sha1.prototype.array = Sha1.prototype.digest;
        Sha1.prototype.arrayBuffer = function() {
          this.finalize();
          var buffer = new ArrayBuffer(20);
          var dataView = new DataView(buffer);
          dataView.setUint32(0, this.h0);
          dataView.setUint32(4, this.h1);
          dataView.setUint32(8, this.h2);
          dataView.setUint32(12, this.h3);
          dataView.setUint32(16, this.h4);
          return buffer;
        };
        var exports = createMethod();
        if (COMMON_JS) {
          module.exports = exports;
        } else {
          root.sha1 = exports;
          if (AMD) {
            define(function() {
              return exports;
            });
          }
        }
      })();
    }
  });

  // shared/js/background/background-embedded.js
  var import_webextension_polyfill8 = __toESM(require_browser_polyfill());

  // node_modules/@duckduckgo/autoconsent/dist/autoconsent.esm.js
  var _Tools = class _Tools2 {
    static setBase(base) {
      _Tools2.base = base;
    }
    static findElement(options, parent = null, multiple = false) {
      let possibleTargets = null;
      if (parent != null) {
        possibleTargets = Array.from(parent.querySelectorAll(options.selector));
      } else {
        if (_Tools2.base != null) {
          possibleTargets = Array.from(
            _Tools2.base.querySelectorAll(options.selector)
          );
        } else {
          possibleTargets = Array.from(
            document.querySelectorAll(options.selector)
          );
        }
      }
      if (options.textFilter != null) {
        possibleTargets = possibleTargets.filter((possibleTarget) => {
          const textContent = possibleTarget.textContent.toLowerCase();
          if (Array.isArray(options.textFilter)) {
            let foundText = false;
            for (const text of options.textFilter) {
              if (textContent.indexOf(text.toLowerCase()) !== -1) {
                foundText = true;
                break;
              }
            }
            return foundText;
          } else if (options.textFilter != null) {
            return textContent.indexOf(options.textFilter.toLowerCase()) !== -1;
          }
          return false;
        });
      }
      if (options.styleFilters != null) {
        possibleTargets = possibleTargets.filter((possibleTarget) => {
          const styles = window.getComputedStyle(possibleTarget);
          let keep = true;
          for (const styleFilter of options.styleFilters) {
            const option = styles[styleFilter.option];
            if (styleFilter.negated) {
              keep = keep && option !== styleFilter.value;
            } else {
              keep = keep && option === styleFilter.value;
            }
          }
          return keep;
        });
      }
      if (options.displayFilter != null) {
        possibleTargets = possibleTargets.filter((possibleTarget) => {
          if (options.displayFilter) {
            return possibleTarget.offsetHeight !== 0;
          } else {
            return possibleTarget.offsetHeight === 0;
          }
        });
      }
      if (options.iframeFilter != null) {
        possibleTargets = possibleTargets.filter(() => {
          if (options.iframeFilter) {
            return window.location !== window.parent.location;
          } else {
            return window.location === window.parent.location;
          }
        });
      }
      if (options.childFilter != null) {
        possibleTargets = possibleTargets.filter((possibleTarget) => {
          const oldBase = _Tools2.base;
          _Tools2.setBase(possibleTarget);
          const childResults = _Tools2.find(options.childFilter);
          _Tools2.setBase(oldBase);
          return childResults.target != null;
        });
      }
      if (multiple) {
        return possibleTargets;
      } else {
        if (possibleTargets.length > 1) {
          console.warn(
            "Multiple possible targets: ",
            possibleTargets,
            options,
            parent
          );
        }
        return possibleTargets[0];
      }
    }
    static find(options, multiple = false) {
      const results = [];
      if (options.parent != null) {
        const parent = _Tools2.findElement(options.parent, null, multiple);
        if (parent != null) {
          if (parent instanceof Array) {
            parent.forEach((p) => {
              const targets = _Tools2.findElement(options.target, p, multiple);
              if (targets instanceof Array) {
                targets.forEach((target) => {
                  results.push({
                    parent: p,
                    target
                  });
                });
              } else {
                results.push({
                  parent: p,
                  target: targets
                });
              }
            });
            return results;
          } else {
            const targets = _Tools2.findElement(options.target, parent, multiple);
            if (targets instanceof Array) {
              targets.forEach((target) => {
                results.push({
                  parent,
                  target
                });
              });
            } else {
              results.push({
                parent,
                target: targets
              });
            }
          }
        }
      } else {
        const targets = _Tools2.findElement(options.target, null, multiple);
        if (targets instanceof Array) {
          targets.forEach((target) => {
            results.push({
              parent: null,
              target
            });
          });
        } else {
          results.push({
            parent: null,
            target: targets
          });
        }
      }
      if (results.length === 0) {
        results.push({
          parent: null,
          target: null
        });
      }
      if (multiple) {
        return results;
      } else {
        if (results.length !== 1) {
          console.warn(
            "Multiple results found, even though multiple false",
            results
          );
        }
        return results[0];
      }
    }
  };
  _Tools.base = null;
  var snippets = {
    // code-based rules
    EVAL_0: () => console.log(1),
    EVAL_CONSENTMANAGER_1: () => window.__cmp && typeof __cmp("getCMPData") === "object",
    EVAL_CONSENTMANAGER_2: () => !__cmp("consentStatus").userChoiceExists,
    EVAL_CONSENTMANAGER_3: () => __cmp("setConsent", 0),
    EVAL_CONSENTMANAGER_4: () => __cmp("setConsent", 1),
    EVAL_CONSENTMANAGER_5: () => __cmp("consentStatus").userChoiceExists,
    EVAL_COOKIEBOT_1: () => !!window.Cookiebot,
    EVAL_COOKIEBOT_2: () => !window.Cookiebot.hasResponse && window.Cookiebot.dialog?.visible === true,
    EVAL_COOKIEBOT_3: () => window.Cookiebot.withdraw() || true,
    EVAL_COOKIEBOT_4: () => window.Cookiebot.hide() || true,
    EVAL_COOKIEBOT_5: () => window.Cookiebot.declined === true,
    EVAL_KLARO_1: () => {
      const config = globalThis.klaroConfig || globalThis.klaro?.getManager && globalThis.klaro.getManager().config;
      if (!config) {
        return true;
      }
      const optionalServices = (config.services || config.apps).filter((s) => !s.required).map((s) => s.name);
      if (klaro && klaro.getManager) {
        const manager = klaro.getManager();
        return optionalServices.every((name) => !manager.consents[name]);
      } else if (klaroConfig && klaroConfig.storageMethod === "cookie") {
        const cookieName = klaroConfig.cookieName || klaroConfig.storageName;
        const consents = JSON.parse(
          decodeURIComponent(
            document.cookie.split(";").find((c) => c.trim().startsWith(cookieName)).split("=")[1]
          )
        );
        return Object.keys(consents).filter((k) => optionalServices.includes(k)).every((k) => consents[k] === false);
      }
    },
    EVAL_KLARO_OPEN_POPUP: () => {
      klaro.show(void 0, true);
    },
    EVAL_KLARO_TRY_API_OPT_OUT: () => {
      if (window.klaro && typeof klaro.show === "function" && typeof klaro.getManager === "function") {
        try {
          klaro.getManager().changeAll(false);
          klaro.getManager().saveAndApplyConsents();
          return true;
        } catch (e) {
          console.warn(e);
          return false;
        }
      }
      return false;
    },
    EVAL_ONETRUST_1: () => window.OnetrustActiveGroups.split(",").filter((s) => s.length > 0).length <= 1,
    EVAL_TRUSTARC_TOP: () => window && window.truste && window.truste.eu.bindMap.prefCookie === "0",
    EVAL_TRUSTARC_FRAME_TEST: () => window && window.QueryString && window.QueryString.preferences === "0",
    EVAL_TRUSTARC_FRAME_GTM: () => window && window.QueryString && window.QueryString.gtm === "1",
    // declarative rules
    EVAL_ADOPT_TEST: () => !!localStorage.getItem("adoptConsentMode"),
    EVAL_ADULTFRIENDFINDER_TEST: () => !!localStorage.getItem("cookieConsent"),
    EVAL_BAHN_TEST: () => utag.gdpr.getSelectedCategories().length === 1,
    EVAL_BIGCOMMERCE_CONSENT_MANAGER_DETECT: () => !!(window.consentManager && window.consentManager.version),
    EVAL_BORLABS_0: () => !JSON.parse(
      decodeURIComponent(
        document.cookie.split(";").find((c) => c.indexOf("borlabs-cookie") !== -1).split("=", 2)[1]
      )
    ).consents.statistics,
    EVAL_CC_BANNER2_0: () => !!document.cookie.match(/sncc=[^;]+D%3Dtrue/),
    EVAL_COINBASE_0: () => JSON.parse(decodeURIComponent(document.cookie.match(/cm_(eu|default)_preferences=([0-9a-zA-Z\\{\\}\\[\\]%:]*);?/)[2])).consent.length <= 1,
    EVAL_COOKIE_LAW_INFO_0: () => {
      if (CLI.disableAllCookies) CLI.disableAllCookies();
      if (CLI.reject_close) CLI.reject_close();
      document.body.classList.remove("cli-barmodal-open");
      return true;
    },
    EVAL_COOKIE_LAW_INFO_DETECT: () => !!window.CLI,
    EVAL_COOKIE_MANAGER_POPUP_0: () => JSON.parse(
      document.cookie.split(";").find((c) => c.trim().startsWith("CookieLevel")).split("=")[1]
    ).social === false,
    EVAL_COOKIEALERT_0: () => document.querySelector("body").removeAttribute("style") || true,
    EVAL_COOKIEALERT_1: () => document.querySelector("body").removeAttribute("style") || true,
    EVAL_COOKIEALERT_2: () => window.CookieConsent.declined === true,
    EVAL_COOKIEFIRST_0: () => ((o) => o.performance === false && o.functional === false && o.advertising === false)(
      JSON.parse(
        decodeURIComponent(
          document.cookie.split(";").find((c) => c.indexOf("cookiefirst") !== -1).trim()
        ).split("=")[1]
      )
    ),
    EVAL_COOKIEFIRST_1: () => document.querySelectorAll("button[data-cookiefirst-accent-color=true][role=checkbox]:not([disabled])").forEach((i) => i.getAttribute("aria-checked") === "true" && i.click()) || true,
    EVAL_COOKIEINFORMATION_0: () => CookieInformation.declineAllCategories() || true,
    EVAL_COOKIEINFORMATION_1: () => CookieInformation.submitAllCategories() || true,
    EVAL_ETSY_0: () => document.querySelectorAll(".gdpr-overlay-body input").forEach((toggle) => {
      toggle.checked = false;
    }) || true,
    EVAL_ETSY_1: () => document.querySelector(".gdpr-overlay-view button[data-wt-overlay-close]").click() || true,
    EVAL_EZOIC_0: () => ezCMP.handleAcceptAllClick(),
    EVAL_FIDES_DETECT_POPUP: () => window.Fides?.initialized,
    EVAL_GDPR_LEGAL_COOKIE_DETECT_CMP: () => !!window.GDPR_LC,
    EVAL_GDPR_LEGAL_COOKIE_TEST: () => !!window.GDPR_LC?.userConsentSetting,
    EVAL_IUBENDA_0: () => document.querySelectorAll(".purposes-item input[type=checkbox]:not([disabled])").forEach((x) => {
      if (x.checked) x.click();
    }) || true,
    EVAL_IUBENDA_1: () => !!document.cookie.match(/_iub_cs-\d+=/),
    EVAL_MEDIAVINE_0: () => document.querySelectorAll('[data-name="mediavine-gdpr-cmp"] input[type=checkbox]').forEach((x) => x.checked && x.click()) || true,
    EVAL_MICROSOFT_0: () => Array.from(document.querySelectorAll("div > button")).filter((el) => el.innerText.match("Reject|Ablehnen"))[0].click() || true,
    EVAL_MICROSOFT_1: () => Array.from(document.querySelectorAll("div > button")).filter((el) => el.innerText.match("Accept|Annehmen"))[0].click() || true,
    EVAL_MICROSOFT_2: () => !!document.cookie.match("MSCC|GHCC"),
    EVAL_MOOVE_0: () => document.querySelectorAll("#moove_gdpr_cookie_modal input").forEach((i) => {
      if (!i.disabled) i.checked = i.name === "moove_gdpr_strict_cookies" || i.id === "moove_gdpr_strict_cookies";
    }) || true,
    EVAL_NHNIEUWS_TEST: () => !!localStorage.getItem("psh:cookies-seen"),
    EVAL_OSANO_DETECT: () => !!window.Osano?.cm?.dialogOpen,
    EVAL_PANDECTES_TEST: () => document.cookie.includes("_pandectes_gdpr=") && JSON.parse(
      atob(
        document.cookie.split(";").find((s) => s.trim().startsWith("_pandectes_gdpr")).split("=")[1]
      )
    ).status === "deny",
    EVAL_POVR_GOBACK: () => window.history.back() || true,
    EVAL_PUBTECH_0: () => document.cookie.includes("euconsent-v2") && (document.cookie.match(/.YAAAAAAAAAAA/) || document.cookie.match(/.aAAAAAAAAAAA/) || document.cookie.match(/.YAAACFgAAAAA/)),
    EVAL_REMARKABLE_TEST: () => !!localStorage.getItem("rmCookieConsent"),
    EVAL_SHOPIFY_TEST: () => document.cookie.includes("gdpr_cookie_consent=0") || document.cookie.includes("_tracking_consent=") && JSON.parse(
      decodeURIComponent(
        document.cookie.split(";").find((s) => s.trim().startsWith("_tracking_consent")).split("=")[1]
      )
    ).purposes.a === false,
    EVAL_SKYSCANNER_TEST: () => document.cookie.match(/gdpr=[^;]*adverts:::false/) && !document.cookie.match(/gdpr=[^;]*init:::true/),
    EVAL_SIRDATA_UNBLOCK_SCROLL: () => {
      document.documentElement.classList.forEach((cls) => {
        if (cls.startsWith("sd-cmp-")) document.documentElement.classList.remove(cls);
      });
      return true;
    },
    EVAL_STEAMPOWERED_0: () => JSON.parse(
      decodeURIComponent(
        document.cookie.split(";").find((s) => s.trim().startsWith("cookieSettings")).split("=")[1]
      )
    ).preference_state === 2,
    EVAL_TAKEALOT_0: () => document.body.classList.remove("freeze") || (document.body.style = "") || true,
    EVAL_TARTEAUCITRON_0: () => tarteaucitron.userInterface.respondAll(false) || true,
    EVAL_TARTEAUCITRON_1: () => tarteaucitron.userInterface.respondAll(true) || true,
    EVAL_TARTEAUCITRON_2: () => document.cookie.match(/tarteaucitron=[^;]*/)?.[0].includes("false"),
    EVAL_TEALIUM_0: () => typeof window.utag !== "undefined" && typeof utag.gdpr === "object",
    EVAL_TEALIUM_1: () => utag.gdpr.setConsentValue(false) || true,
    EVAL_TEALIUM_DONOTSELL: () => utag.gdpr.dns?.setDnsState(false) || true,
    EVAL_TEALIUM_2: () => utag.gdpr.setConsentValue(true) || true,
    EVAL_TEALIUM_3: () => utag.gdpr.getConsentState() !== 1,
    EVAL_TEALIUM_DONOTSELL_CHECK: () => utag.gdpr.dns?.getDnsState() !== 1,
    EVAL_TESTCMP_STEP: () => !!document.querySelector("#reject-all"),
    EVAL_TESTCMP_0: () => window.results.results[0] === "button_clicked",
    EVAL_TESTCMP_COSMETIC_0: () => window.results.results[0] === "banner_hidden",
    EVAL_THEFREEDICTIONARY_0: () => cmpUi.showPurposes() || cmpUi.rejectAll() || true,
    EVAL_THEFREEDICTIONARY_1: () => cmpUi.allowAll() || true,
    EVAL_USERCENTRICS_API_0: () => typeof UC_UI === "object",
    EVAL_USERCENTRICS_API_1: () => !!UC_UI.closeCMP(),
    EVAL_USERCENTRICS_API_2: () => !!UC_UI.denyAllConsents(),
    EVAL_USERCENTRICS_API_3: () => !!UC_UI.acceptAllConsents(),
    EVAL_USERCENTRICS_API_4: () => !!UC_UI.closeCMP(),
    EVAL_USERCENTRICS_API_5: () => UC_UI.areAllConsentsAccepted() === true,
    EVAL_USERCENTRICS_API_6: () => UC_UI.areAllConsentsAccepted() === false,
    EVAL_USERCENTRICS_BUTTON_0: () => JSON.parse(localStorage.getItem("usercentrics")).consents.every((c) => c.isEssential || !c.consentStatus),
    EVAL_WAITROSE_0: () => Array.from(document.querySelectorAll("label[id$=cookies-deny-label]")).forEach((e) => e.click()) || true
  };
  var REJECT_PATTERNS_ENGLISH = [
    // e.g. "i reject cookies", "reject all", "reject all cookies", "reject cookies", "deny all", "deny all cookies", "refuse", "refuse all", "refuse cookies", "refuse all cookies", "deny", "reject all and close", "deny all and close", "reject non-essential cookies", "reject all non-essential cookies and continue", "reject optional cookies", "reject additional cookies", "reject targeting cookies", "reject marketing cookies", "reject analytics cookies", "reject tracking cookies", "reject advertising cookies", "reject all and close", "deny all and close"
    // note that "reject and subscribe" and "reject and pay" are excluded
    /^\s*(i)?\s*(reject|deny|refuse|decline|disable)\s*(all)?\s*(non-essential|optional|additional|targeting|analytics|marketing|unrequired|non-necessary|extra|tracking|advertising)?\s*(cookies)?\s*$/is,
    // e.g. "i do not accept", "i do not accept cookies", "do not accept", "do not accept cookies"
    /^\s*(i)?\s*do\s+not\s+accept\s*(cookies)?\s*$/is,
    // e.g. "continue without accepting", "continue without agreeing", "continue without agreeing →"
    /^\s*(continue|proceed|continue\s+browsing)\s+without\s+(accepting|agreeing|consent|cookies|tracking)(\s*→)?\s*$/is,
    // e.g. "strictly necessary cookies only", "essential cookies only", "required only", "use necessary cookies only", "essentials only"
    // note that "only" is required
    /^\s*(use|accept|allow|continue\s+with)?\s*(strictly)?\s*(necessary|essentials?|required)?\s*(cookies)?\s*only\s*$/is,
    // e.g. "allow essential cookies", "allow necessary", "allow essentials", "allow essentials only"
    // note that "essential" is required
    /^\s*(use|accept|allow|continue\s+with)?\s*(strictly)?\s*(necessary|essentials?|required)\s*(cookies)?\s*$/is,
    // e.g. "accept only essential cookies", "use only necessary cookies", "allow only essential", "only essentials", "continue with only essential cookies"
    // note that "only" is required
    /^\s*(use|accept|allow|continue\s+with)?\s*only\s*(strictly)?\s*(necessary|essentials?|required)?\s*(cookies)?\s*$/is,
    // e.g. "do not sell or share my personal information", "do not sell my personal information"
    // often used in CCPA
    /^\s*do\s+not\s+sell(\s+or\s+share)?\s*my\s*personal\s*information\s*$/is
    // These are impactful, but look error-prone
    // // e.g. "disagree"
    // /^\s*(i)?\s*disagree\s*(and\s+close)?\s*$/i,
    // // e.g. "i do not agree"
    // /^\s*(i\s+)?do\s+not\s+agree\s*$/i,
  ];
  var REJECT_PATTERNS_DUTCH = [
    "weigeren",
    "alles afwijzen",
    "alleen noodzakelijke cookies",
    "afwijzen",
    "alles weigeren",
    "cookies weigeren",
    "alleen noodzakelijk",
    "weiger",
    "weiger cookies",
    "doorgaan zonder te accepteren",
    "alleen functionele cookies",
    "alleen functioneel",
    "alleen noodzakelijke",
    "alleen essenti\xEBle cookies",
    "functioneel",
    "alle cookies verwerpen",
    "doorgaan zonder akkoord te gaan",
    "weiger alles",
    "nee, bedankt",
    "alle cookies weigeren",
    "weiger alle cookies",
    "alleen noodzakelijke cookies accepteren",
    "alleen strikt noodzakelijk",
    "ik weiger",
    "optionele cookies weigeren",
    "alle weigeren",
    "accepteer alleen noodzakelijke cookies",
    "alleen functionele cookies accepteren",
    "enkel noodzakelijke cookies",
    "niet accepteren",
    "weiger niet-essenti\xEBle cookies",
    "weiger niet-noodzakelijke cookies",
    "wijs alles af",
    "alle cookies afwijzen",
    "alleen vereiste cookies",
    "cookies afwijzen",
    "doorgaan zonder accepteren",
    "hier weigeren",
    "weiger alle",
    "aanvaard enkel essenti\xEBle cookies",
    "aanvullende cookies weigeren",
    "accepteren weigeren",
    "alle afwijzen",
    "alle niet functionele afwijzen",
    "alle optionele weigeren",
    "alleen noodzakelijke accepteren",
    "alleen strikt noodzakelijke cookies",
    "allen afwijzen",
    "clear weigeren",
    "enkel functioneel",
    "enkel noodzakelijke cookies aanvaarden",
    "functioneel altijd actief",
    "nee, accepteer alleen de noodzakelijke",
    "nee, geen cookies a.u.b.",
    "nee, weiger cookies",
    "nee, weigeren",
    "niet-noodzakelijke cookies weigeren",
    "optioneel afwijzen",
    "tracking cookies weigeren",
    "weigeren cookies",
    "weigeren?",
    "weigeren.",
    "strikt noodzakelijk",
    "weiger optionele cookies",
    "noodzakelijke cookies",
    "essenti\xEBle cookies",
    "ga verder zonder aanvaarden",
    "doorgaan zonder cookies",
    "accepteer noodzakelijke cookies",
    "noodzakelijke",
    "indien je enkel technisch noodzakelijke cookies wenst te accepteren, klik dan hier",
    "weiger",
    "alleen de noodzakelijke cookies",
    "alleen noodzakelijk",
    "alleen verplichte cookies",
    "ik wil alleen minimale cookies",
    "doorgaan zonder te accepteren",
    "geen cookies toestaan",
    "liever geen cookies",
    "nee, geen persoonlijke cookies",
    "nee, liever geen cookies",
    "ga door zonder te accepteren",
    "verder zonder accepteren",
    "essenti\xEBle accepteren",
    "functionele cookies",
    "strikt noodzakelijke cookies",
    "alleen basic cookies",
    "alleen basiscookies",
    "alleen standaard cookies",
    "alle cookies verwerpen",
    "noodzakelijk",
    "noodzakelijk cookies accepteren",
    "noodzakelijke cookies accepteren",
    "accepteer alleen noodzakelijk",
    "enkel noodzakelijke toestaan",
    "enkel strikt noodzakelijke cookies",
    "ik wijs ze liever af",
    "ik weiger cookies",
    "ik weiger optionele cookies",
    "weiger alle cookies",
    "weiger alle niet-noodzakelijke cookies",
    "weiger alle onnodige cookies",
    "weiger alle optionele",
    "weiger alles",
    "weiger targeting en third party cookies."
  ];
  var REJECT_PATTERNS_FRENCH = [
    "continuer sans accepter",
    "tout refuser",
    "refuser",
    "refuser tous les cookies",
    "je refuse",
    "refuser tout",
    "tout rejeter",
    "refuser et continuer",
    "rejeter",
    "refuser les cookies",
    "cookies n\xE9cessaires uniquement",
    "seulement n\xE9cessaires",
    "rejeter tout",
    "refuser les cookies optionnels",
    "je d\xE9sactive les finalit\xE9s non essentielles",
    "refuser les cookies non n\xE9cessaires",
    "rejeter tous les cookies",
    "cookies essentiels uniquement",
    "n\xE9cessaires uniquement",
    "refuser les cookies non essentiels",
    "tout refuser et fermer",
    "tout refuser sauf les cookies techniques",
    "continuer sans accepter x",
    "je refuse lutilisation de cookies",
    "non merci, seulement des cookies techniques",
    "non, tout refuser",
    "refuser tous les cookies non n\xE9cessaires",
    "rejeter les cookies",
    "uniquement les essentiels",
    "refuser tous",
    "accepter uniquement les n\xE9cessaires",
    "allow anonymous analytics",
    "autoriser les cookies essentiels uniquement",
    "autoriser uniquement les n\xE9cessaires",
    "cookies essentiels seulement",
    "cookies n\xE9cessaires seulement",
    "cookies techniques uniquement",
    "je pr\xE9f\xE8re les rejeter",
    "je refuse :(",
    "je refuse les cookies",
    "je refuse tous les cookies",
    "je refuse tout",
    "ne pas accepter",
    "non, accepter les n\xE9cessaires uniquement",
    "refuser (sauf cookies n\xE9cessaires)",
    "refuser ce cookie",
    "refuser les coockies",
    "refuser les cookies facultatifs",
    "refuser tout, sauf les cookies techniques",
    "refuser toutes",
    "refuser toutes les options",
    "rejeter la banni\xE8re",
    "rejeter les cookies non essentiels",
    "rejeter les cookies optionnels",
    "rejeter tous les non fonctionnels",
    "rejeter tout optionnel",
    "tout refuser, sauf les cookies techniques",
    "uniquement n\xE9cessaires",
    "x continuer sans accepter",
    "strictement n\xE9cessaires",
    "utiliser uniquement les cookies n\xE9cessaires",
    "cookies n\xE9cessaires",
    "accepter uniquement les cookies essentiels",
    "accepter les cookies n\xE9cessaires",
    "uniquement les cookies n\xE9cessaires",
    "autoriser uniquement les cookies essentiels",
    "autoriser uniquement les cookies n\xE9cessaires",
    "si vous ne souhaitez pas accepter les cookies \xE0 lexception des cookies techniquement n\xE9cessaires, veuillez cliquer ici",
    "cookies strictement n\xE9cessaires",
    "accepter les cookies strictement n\xE9cessaires",
    "autoriser les cookies essentiels",
    "non, merci, uniquement les cookies n\xE9cessaires",
    "indispensable uniquement",
    "uniquement autoriser les cookies essentiels",
    "utiliser que les cookies n\xE9cessaires",
    "uniquement les sdk n\xE9cessaires",
    "uniquement n\xE9cessaire",
    "utiliser uniquement les cookies fonctionnels",
    "refus",
    "refusez",
    "naccepter que les cookies indispensables",
    "naccepter que les cookies n\xE9cessaires",
    "naccepter que les cookies techniques",
    "n\xE9cessaires seulement"
  ];
  var REJECT_PATTERNS_GERMAN = [
    "ablehnen",
    "alle ablehnen",
    "nur notwendige cookies",
    "nur essenzielle cookies akzeptieren",
    "nur notwendige cookies verwenden",
    "alles ablehnen",
    "nur notwendige",
    "alle cookies ablehnen",
    "weiter ohne einwilligung",
    "mit diesem button wird der dialog geschlossen. seine funktionalit\xE4t ist identisch mit der des buttons nur essenzielle cookies akzeptieren.",
    "cookies ablehnen",
    "optionale cookies ablehnen",
    "nur erforderliche cookies",
    "einwilligung ablehnen",
    "nur erforderliche",
    "nur notwendige cookies zulassen",
    "nur funktionale cookies akzeptieren",
    "nur notwendige cookies akzeptieren",
    "nur notwendige technologien",
    "verweigern",
    "webanalyse ablehnen",
    "weiter ohne zustimmung",
    "optionale ablehnen",
    "nur notwendige akzeptieren",
    "nur funktionale cookies",
    "mit diesem button wird der dialog geschlossen. seine funktionalit\xE4t ist identisch mit der des buttons ablehnen.",
    "nur notwendige cookies erlauben",
    "zustimmung verweigern",
    "nein, danke",
    "nur erforderliche cookies akzeptieren",
    "zus\xE4tzliche cookies ablehnen",
    "ablehnen und nur essenzielle cookies akzeptieren",
    "nicht erforderliche ablehnen",
    "nicht essenzielle cookies daten ablehnen",
    "nur technisch notwendige cookies",
    "nur technisch notwendige cookies akzeptieren",
    "ablehnen speichern",
    "alle funktionen ablehnen",
    "alle optionalen cookies ablehnen",
    "alles verweigern",
    "mit erforderlichen einstellungen fortfahren",
    "nicht notwendige ablehnen",
    "notwendige cookies akzeptieren",
    "nur erforderliche technologien",
    "nur essenzielle cookies",
    "nur essenzielle cookies erlauben",
    "technisch nicht notwendige cookies ablehnen",
    "tippen sie zum ablehnen bitte hier",
    "ablehnen deny",
    "fortfahren ohne zu akzeptieren",
    "nur erforderliche akzeptieren",
    "nur notwendige erlauben",
    "ablehnen ...nur technisch notwendige cookies verwendet werden",
    "ablehnen (au\xDFer notwendige cookies)",
    "ablehnen und fortfahren",
    "ablehnen und schlie\xDFen",
    "ablehnen: nur grundfunktionen",
    "akzeptieren nur notwendige cookies",
    "alle ablehnen (au\xDFer notwendige cookies)",
    "alle nicht essenziellen cookies ablehnen",
    "alle nicht notwendigen cookies ablehnen",
    "alle optionale ablehnen",
    "alle optionalen ablehnen",
    "alle verweigern",
    "analyse cookies ablehnen",
    "cookie einstellungenablehnen",
    "erforderliche cookies akzeptieren",
    "erforderliche cookies zulassen",
    "externe inhalte ablehnen",
    "mit diesem button wird der dialog geschlossen. seine funktionalit\xE4t ist identisch mit der des buttons ablehnen und nur essenzielle cookies akzeptieren.",
    "mit diesem button wird der dialog geschlossen. seine funktionalit\xE4t ist identisch mit der des buttons nicht-essenzielle cookies verweigern.",
    "mit diesem button wird der dialog geschlossen. seine funktionalit\xE4t ist identisch mit der des buttons nur essenzielle akzeptieren.",
    "mit erforderlichen cookies fortfahren",
    "mit notwendigen fortfahren",
    "nein, bitte nicht",
    "nein, ich stimme nicht zu",
    "nicht funktionale cookies ablehnen",
    "nicht notwendige cookies ablehnen",
    "nicht-essenzielle cookies ablehnen",
    "nicht-essenzielle cookies verweigern",
    "notwendige cookies zulassen",
    "nur erforderliche cookies erlauben",
    "nur erforderliche cookies setzen",
    "nur erforderliche cookies verwenden",
    "nur essenzielle akzeptieren",
    "nur notwendige cookies annehmen",
    "nur notwendige cookies speichern",
    "nur notwendige cookies verwenden.",
    "nur notwendige funktionscookies akzeptieren",
    "nur notwendigen cookies zustimmen",
    "nur notwendiges akzeptieren",
    "nur wesentliche cookies annehmen",
    "opt. cookies ablehnen",
    "optionale dienste ablehnen",
    "optionale tools ablehnen",
    "sie alle cookies ablehnen",
    "technisch notwendige annehmen",
    "nur essentielle cookies",
    "nur essentielle",
    "nur funktionale akzeptieren",
    "nur technisch notwendige akzeptieren",
    "nur technisch notwendige daten und cookies ...",
    "nur technisch notwendige zulassen",
    "nur wesentliche",
    "ohne einverst\xE4ndnis fortfahren",
    "ohne einwilligung",
    "ohne zustimmung fortfahren",
    "ohne zustimmung weiter",
    "weiter mit essentiellen cookies",
    "weiter ohne annahme",
    "weiter ohne statistische analyse-cookies",
    "weiter ohne statistische cookies",
    "wesentliche cookies",
    "fortfahren ohne zustimmung"
  ];
  var REJECT_PATTERNS_ITALIAN = [
    "rifiuta",
    "rifiuta cookies",
    "rifiuta i cookie",
    "rifiuta i cookies",
    "rifiuta tutti i cookie",
    "rifiuta tutti i cookies",
    "rifiuta cookie non necessari",
    "rifiuta i cookie non tecnici",
    "rifiuta non necessari",
    "rifiuta tutto",
    "rifiuta tutti",
    "rifiuta e chiudi",
    "chiudi rifiuta tutti i cookie",
    "chiudi e rifiuta tutti i cookie",
    "chiudi e rifiuta tutto",
    "nega",
    "nega tutti",
    "negare",
    "non accetto",
    "accetta solo i necessari",
    "usa solo i cookie necessari",
    "accetta solo necessari",
    "solo necessari",
    "continua senza accettare x",
    "continua senza accettare",
    "rifiutare",
    "rifiutare i cookie",
    "rifiutare tutti i cookie",
    "rifiutare tutti",
    "rifiutare e continuare",
    "installa solo i cookie strettamente necessari",
    "solo cookies tecnici",
    "accetta necessari",
    "solo cookie tecnici",
    "solo cookie necessari",
    "strettamente necessari",
    "tecnici",
    "accetta solo cookie di navigazione",
    "chiudi e prosegui solo con i cookies tecnici necessari",
    "consenti solo i cookie tecnici",
    "solo cookie essenziali",
    "blocca i cookie non essenziali",
    "accetta i cookie necessari",
    "accetta solo cookie tecnici",
    "accetta solo i cookie essenziali",
    "accetta solo i cookie necessari",
    "accetta solo i necessary",
    "accetta i cookie essenziali",
    "accetta cookie tecnici",
    "necessari",
    "usa solo i cookie tecnici",
    "usa solo i necessari",
    "rifiuto",
    "essenziali",
    "accetta cookie essenziali",
    "accetta cookie necessari",
    "accetta solo cookie essenziali",
    "accetta solo cookie necessari",
    "rifiuta cookie non necessari",
    "rifiuta cookie non essenziali",
    "rifiuta i cookie non necessari",
    "rifiuta i cookie non essenziali",
    "rifiuta tutti i cookie e chiudi",
    "rifiuta tutto e chiudi",
    "rifiuta tutti i cookie chiudi",
    "continuare senza accettare",
    "rifiutare cookies",
    "rifiutare i cookies",
    "rifiutare non necessari",
    "rifiutare tutto",
    "rifiutare e chiudere",
    "solo essenziali",
    "solo tecnici",
    "negare tutti"
  ];
  var REJECT_PATTERNS_BRAZILIAN_PORTUGUESE = [
    // (deny)
    /^\s*(rejeitar|recusar|desativar|bloquear|negar|não\s*aceito|não \s*aceitar)\s*$/is,
    // (proceed) (without accepting)
    /^\s*(continuar|prosseguir|seguir)\s*(sem\s*aceitar)\s*$/is,
    // (deny) (everything) (optional)
    /^\s*(rejeitar|recusar|desativar|bloquear|negar|não\s*aceito|não \s*aceitar)\s*(tudo|o)?\s*(opcional|(não[-\s](essencial|funcional|obrigatório|necessário)))?\s*$/is,
    // (deny) (all) (the) (optional) (cookies)
    /^\s*(rejeitar|recusar|desativar|bloquear|negar|não\s*aceito|não \s*aceitar)\s*(todos)?\s*(os)?\s*(cookies)?\s*(opcionais|(não[-\s](essenciais|funcionais|obrigatórios|necessários)))?\s*$/is,
    // (accept) (only) (the) (essential)
    /^\s*(aceitar|utilizar)?\s*(apenas|somente|só)?\s*(o)?\s*(essencial|funcional|obrigatório|necessário)\s*$/is,
    // (accept) (only) (the) (essential) (cookies)
    /^\s*(aceitar|utilizar)?\s*(apenas|somente|só)?\s*(os)?\s*(cookies)?\s*(essenciais|funcionais|obrigatórios|necessários)\s*$/is
  ];
  var REJECT_PATTERNS_SPANISH = [
    "rechazar",
    "rechazar todo",
    "rechazar todas",
    "denegar",
    "rechazar cookies",
    "rechazarlas todas",
    "no acepto",
    "rechazar todas las cookies",
    "rechazar y cerrar",
    "denegar todas",
    "solo necesarias",
    "rechazar cookies opcionales",
    "rechazar opcionales",
    "cookies estrictamente necesarias",
    "aceptar s\xF3lo necesarias",
    "denegar todo",
    "clear rechazar cookies",
    "configurar rechazar cookies",
    "denegar cookies",
    "rechazar y continuar",
    "rechazar las cookies",
    "clear rechazar",
    "denegar todas las cookies",
    "rechazar cookies no esenciales",
    "rechazarlas",
    "no, no acepto",
    "permitir s\xF3lo necesarias",
    "rechazar cookies adicionales",
    "rechazar cookies anal\xEDticas",
    "rechazar no necesarias",
    "rechazar opcional",
    "rechazar todo lo opcional",
    "solo cookies estrictamente necesarias",
    "solo esenciales",
    "x rechazar todas las cookies",
    "solo usar cookies necesarias",
    "solo cookies necesarias",
    "declinar",
    "aceptar solo las cookies esenciales",
    "necesarias",
    "aceptar cookies opcionales",
    "aceptar solo lo necesario",
    "solo funcionales",
    "declinar y cerrar",
    "d\xE9clin",
    "declina",
    "declinar consentimiento",
    "declinar todas",
    "solo las cookies necesarias",
    "nom\xE9s sutilitzen cookies quan \xE9s necessari",
    "no, s\xF3lo las estrictamente necesarias",
    "solo las necesarias",
    "acceptar nom\xE9s les necess\xE0ries",
    "acepta solo las necesarias",
    "aceptar solo lo esencial",
    "aceptar las obligatorias",
    "permitir solo cookies t\xE9cnicas",
    "cookies t\xE9cnicas",
    "permitir solo cookies t\xE9cnicas",
    "usar solo cookies t\xE9cnicas",
    "aceptar solo las esenciales"
  ];
  var REJECT_PATTERNS_SWEDISH = [
    "avvisa",
    "endast n\xF6dv\xE4ndiga",
    "avvisa alla",
    "endast n\xF6dv\xE4ndiga cookies",
    "neka",
    "neka alla",
    "avvisa allt",
    "avvisa alla cookies",
    "till\xE5t bara n\xF6dv\xE4ndiga cookies",
    "bara n\xF6dv\xE4ndiga",
    "bara n\xF6dv\xE4ndiga cookies",
    "till\xE5t bara n\xF6dv\xE4ndiga kakor",
    "endast n\xF6dv\xE4ndiga kakor",
    "till\xE5t endast n\xF6dv\xE4ndiga",
    "forts\xE4tt utan att acceptera",
    "godk\xE4nn endast n\xF6dv\xE4ndiga",
    "acceptera endast n\xF6dv\xE4ndiga",
    "avvisa cookies",
    "till\xE5t endast n\xF6dv\xE4ndiga kakor",
    "acceptera endast n\xF6dv\xE4ndiga cookies",
    "neka kakor",
    "bara n\xF6dv\xE4ndiga kakor",
    "neka alla cookies",
    "anv\xE4nd endast n\xF6dv\xE4ndiga",
    "avvisa alla utom n\xF6dv\xE4ndiga",
    "hantera eller avvisa",
    "neka alla utom n\xF6dv\xE4ndiga kakor",
    "neka och st\xE4ng",
    "till\xE5t bara n\xF6dv\xE4ndiga tj\xE4nster",
    "avvisa alla utom n\xF6dv\xE4ndiga kakor",
    "avvisa alla valfria",
    "godk\xE4nn bara n\xF6dv\xE4ndiga cookies",
    "acceptera endast n\xF6dv\xE4ndiga kakor",
    "anv\xE4nd endast n\xF6dv\xE4ndiga cookies",
    "avvisa alla kakor",
    "avvisa alla valm\xF6jligheter",
    "avvisa ej n\xF6dv\xE4ndiga",
    "avvisa icke-n\xF6dv\xE4ndiga",
    "f\xF6rneka",
    "godk\xE4nn bara n\xF6dv\xE4ndiga",
    "godk\xE4nn bara n\xF6dv\xE4ndiga kakor",
    "godk\xE4nn endast n\xF6dv\xE4ndiga cookies",
    "godk\xE4nn endast n\xF6dv\xE4ndiga kakor",
    "godta endast n\xF6dv\xE4ndiga",
    "jag godk\xE4nner bara n\xF6dv\xE4ndiga kakor",
    "nej, avvisa alla",
    "nej, bara n\xF6dv\xE4ndiga",
    "nej, bara n\xF6dv\xE4ndiga cookies",
    "neka alla utom n\xF6dv\xE4ndiga",
    "neka alla.",
    "neka cookies",
    "neka samtliga",
    "ok, endast n\xF6dv\xE4ndiga",
    "spara endast n\xF6dv\xE4ndiga",
    "st\xE4ng och avvisa",
    "till\xE5t bara n\xF6dv\xE4ndiga",
    "godk\xE4nn n\xF6dv\xE4ndiga kakor",
    "godk\xE4nn n\xF6dv\xE4ndiga",
    "acceptera n\xF6dv\xE4ndiga",
    "strikt n\xF6dv\xE4ndigt",
    "till\xE5t n\xF6dv\xE4ndiga",
    "n\xF6dv\xE4ndiga",
    "enbart n\xF6dv\xE4ndiga",
    "jag godk\xE4nner n\xF6dv\xE4ndiga kakor",
    "acceptera n\xF6dv\xE4ndiga kakor",
    "godk\xE4nn enbart n\xF6dv\xE4ndiga kakor",
    "godk\xE4nn n\xF6dv\xE4ndiga cookies",
    "om du inte vill acceptera andra cookies \xE4n de som \xE4r tekniskt n\xF6dv\xE4ndiga klickar du h\xE4r",
    "acceptera enbart n\xF6dv\xE4ndiga",
    "n\xF6dv\xE4ndiga cookies",
    "jag godk\xE4nner enbart att ni anv\xE4nder n\xF6dv\xE4ndiga cookies",
    "+ strikt n\xF6dv\xE4ndiga cookies",
    "anv\xE4nd enbart n\xF6dv\xE4ndiga cookies",
    "enbart n\xF6dv\xE4ndiga cookies",
    "godk\xE4nn n\xF6dv\xE4ndiga kakor st\xE4ng",
    "ok till n\xF6dv\xE4ndiga",
    "strikt n\xF6dv\xE4ndiga",
    "forts\xE4tt utan att godk\xE4nna",
    "avb\xF6j alla cookies",
    "jag accepterar endast grundl\xE4ggande kakor",
    "nej, jag avb\xF6jer",
    "till\xE5t inte cookies"
  ];
  var REJECT_PATTERNS = [
    ...REJECT_PATTERNS_ENGLISH,
    ...REJECT_PATTERNS_DUTCH,
    ...REJECT_PATTERNS_FRENCH,
    ...REJECT_PATTERNS_GERMAN,
    ...REJECT_PATTERNS_ITALIAN,
    ...REJECT_PATTERNS_BRAZILIAN_PORTUGUESE,
    ...REJECT_PATTERNS_SPANISH,
    ...REJECT_PATTERNS_SWEDISH
  ];
  var compactedRuleSteps = [
    ["exists", "e"],
    ["visible", "v"],
    ["waitForThenClick", "c"],
    ["click", "k"],
    ["waitFor", "w"],
    ["waitForVisible", "wv"],
    ["hide", "h"],
    ["cookieContains", "cc"]
  ];
  function clearUnusedStrings(ruleset, ignoreBeforeIndex = 0) {
    const { v, s, r } = ruleset;
    const usedStringIds = /* @__PURE__ */ new Set();
    function addStringIdsFromRuleSteps(steps) {
      steps.forEach((step) => {
        for (const [, shortKey] of compactedRuleSteps) {
          if (step[shortKey] !== void 0) {
            usedStringIds.add(step[shortKey]);
          }
        }
        if (step.if) {
          addStringIdsFromRuleSteps([step.if]);
        }
        if (step.then) {
          addStringIdsFromRuleSteps(step.then);
        }
        if (step.else) {
          addStringIdsFromRuleSteps(step.else);
        }
        if (step.any) {
          addStringIdsFromRuleSteps(step.any);
        }
      });
    }
    ruleset.r.forEach((rule) => {
      addStringIdsFromRuleSteps(rule[6]);
      addStringIdsFromRuleSteps(rule[7]);
      addStringIdsFromRuleSteps(rule[8]);
      addStringIdsFromRuleSteps(rule[9]);
      rule[5].forEach((id) => usedStringIds.add(id));
    });
    return {
      v,
      r,
      s: s.slice(0, Math.max(...usedStringIds) + 1).map((str, idx) => {
        if (idx < ignoreBeforeIndex || usedStringIds.has(idx)) {
          return str;
        }
        return "";
      })
    };
  }
  function shouldRunRuleInContext(rule, mainFrame, url) {
    const runContext = rule[4];
    if (mainFrame && runContext === 1) {
      return false;
    }
    if (!mainFrame && [20, 22, 10, 12].includes(runContext)) {
      return false;
    }
    const urlPattern = rule[3];
    if (urlPattern && urlPattern !== "" && url.match(urlPattern) === null) {
      return false;
    }
    return true;
  }
  function filterCompactRules(rules2, context) {
    const { v, s, r, index } = rules2;
    const { url, mainFrame } = context;
    const shouldRunInContext = (rule) => shouldRunRuleInContext(rule, mainFrame, url);
    if (!mainFrame) {
      const ruleset = {
        v,
        s: s.slice(0, index.frameStringEnd),
        r: r.slice(index.frameRuleRange[0], index.frameRuleRange[1]).filter(shouldRunInContext)
      };
      return clearUnusedStrings(ruleset);
    }
    const genericRules = r.slice(index.genericRuleRange[0], index.genericRuleRange[1]);
    const specificRules = r.slice(index.specificRuleRange[0], index.specificRuleRange[1]).filter(shouldRunInContext);
    if (specificRules.length > 0) {
      const ruleset = {
        v,
        s,
        r: [...genericRules, ...specificRules]
      };
      return clearUnusedStrings(ruleset);
    }
    return {
      v,
      s: s.slice(0, index.genericStringEnd),
      r: genericRules
    };
  }
  var _config;
  _config = /* @__PURE__ */ new WeakMap();

  // shared/js/background/components/cookie-prompt-management.js
  var import_webextension_polyfill3 = __toESM(require_browser_polyfill());

  // shared/js/background/components/mv3-content-script-injection.js
  var import_webextension_polyfill = __toESM(require_browser_polyfill());
  async function registerContentScripts(scripts) {
    const existingScripts = await import_webextension_polyfill.default.scripting.getRegisteredContentScripts();
    const duplicateIds = existingScripts.filter((s) => scripts.some((newScript) => newScript.id === s.id)).map((s) => s.id);
    if (duplicateIds.length > 0) {
      await unregisterContentScripts(duplicateIds);
    }
    await import_webextension_polyfill.default.scripting.registerContentScripts(scripts);
  }
  async function unregisterContentScripts(scriptIds) {
    await import_webextension_polyfill.default.scripting.unregisterContentScripts({ ids: scriptIds });
  }

  // shared/js/background/components/cookie-prompt-management.js
  init_wrapper();

  // shared/js/background/message-registry.js
  var messageHandlers = {};
  function registerMessageHandler(name, func) {
    messageHandlers[name] = func;
  }
  var message_registry_default = messageHandlers;

  // shared/js/background/components/cookie-prompt-management.js
  var logsConfig = {
    lifecycle: true,
    detectionsteps: false,
    errors: true,
    evals: false,
    messages: true,
    rulesteps: true,
    waits: true
  };
  var CookiePromptManagement = class _CookiePromptManagement {
    static SUMMARY_ALARM_NAME = "cpm-summary";
    static SUMMARY_DELAY_MINUTES = 2;
    /**
     *
     * @param {{
     *  cpmMessaging: CPMMessagingBase
     * }} opts
     */
    constructor({ cpmMessaging: cpmMessaging2 }) {
      this.cpmMessaging = cpmMessaging2;
      this.scheduleConfigRefresh();
      this._tabUrlsCache = /* @__PURE__ */ new Map();
      this._lastHandledCMP = /* @__PURE__ */ new Map();
      this._reloadLoopDetected = /* @__PURE__ */ new Set();
      registerContentScripts([
        {
          id: "cookie-prompt-management-script",
          js: ["public/js/content-scripts/cpm.js"],
          matches: ["<all_urls>"],
          runAt: "document_end",
          world: "ISOLATED",
          matchOriginAsFallback: true,
          allFrames: true
        }
      ]);
      this._stateQueue = Promise.resolve();
      this.getCpmState();
      import_webextension_polyfill3.default.alarms.onAlarm.addListener((alarm) => {
        this.cpmMessaging.logMessage(`alarm triggered: ${JSON.stringify(alarm)}`);
        if (alarm.name === _CookiePromptManagement.SUMMARY_ALARM_NAME) {
          this.sendSummaryPixel();
        }
      });
      import_webextension_polyfill3.default.runtime.onSuspend?.addListener(() => {
        this.sendSummaryPixel();
      });
      registerMessageHandler("autoconsent", (options, sender, req) => {
        console.log(`received autoconsent message: ${req.autoconsentPayload.type}`);
        return this.handleAutoConsentMessage(req.autoconsentPayload, sender).then(() => {
          console.log(`handled autoconsent message: ${req.autoconsentPayload.type}`);
        });
      });
    }
    scheduleConfigRefresh() {
      this.remoteConfigJson = this.cpmMessaging.refreshRemoteConfig().catch((e) => {
        return null;
      });
    }
    /**
     * @param {object} jsonCpmState
     * @returns {CpmState}
     */
    _deserializeCpmState(jsonCpmState) {
      return {
        sitesNotifiedCache: new Set(jsonCpmState.sitesNotifiedCache || []),
        detectionCache: {
          patterns: new Set(jsonCpmState.detectionCache?.patterns || []),
          both: new Set(jsonCpmState.detectionCache?.both || []),
          onlyRules: new Set(jsonCpmState.detectionCache?.onlyRules || [])
        },
        summaryEvents: structuredClone(jsonCpmState.summaryEvents || {})
      };
    }
    /**
     * @param {CpmState} cpmState
     * @returns {object}
     */
    _serializeCpmState(cpmState) {
      return {
        sitesNotifiedCache: Array.from(cpmState.sitesNotifiedCache),
        detectionCache: {
          patterns: Array.from(cpmState.detectionCache.patterns),
          both: Array.from(cpmState.detectionCache.both),
          onlyRules: Array.from(cpmState.detectionCache.onlyRules)
        },
        summaryEvents: structuredClone(cpmState.summaryEvents)
      };
    }
    /**
     * @returns {Promise<CpmState>}
     */
    async getCpmState() {
      if (!this._jsonCpmState) {
        this._jsonCpmState = await getFromSessionStorage("cpmState") || {
          sitesNotifiedCache: [],
          detectionCache: {
            patterns: [],
            both: [],
            onlyRules: []
          },
          summaryEvents: {}
        };
      }
      return this._deserializeCpmState(this._jsonCpmState);
    }
    checkHeuristicActionEnabled() {
      return this.cpmMessaging.checkSubfeatureEnabled("heuristicAction");
    }
    /**
     * @param {CpmState} newState
     */
    async updateCpmState(newState) {
      this._jsonCpmState = this._serializeCpmState(newState);
      try {
        await setToSessionStorage("cpmState", this._jsonCpmState);
      } catch (e) {
        this.cpmMessaging.logMessage(`error setting cpmState to session storage: ${e}`);
      }
    }
    /**
     * Atomically read-modify-write the CPM state.
     * All state mutations are serialized through this method to prevent race conditions
     * between parallel message handlers.
     *
     * IMPORTANT: The callback must NOT await other methods that call
     * modifyCpmState (e.g. firePixel), as that would deadlock the queue.
     * Non-awaited calls are fine -- they simply queue up after the current operation.
     *
     * @param {(state: CpmState) => void | Promise<void>} fn
     * @returns {Promise<void>}
     */
    modifyCpmState(fn) {
      const op = this._stateQueue.then(async () => {
        const state = await this.getCpmState();
        await fn(state);
        await this.updateCpmState(state);
      });
      this._stateQueue = op.catch((e) => {
        this.cpmMessaging.logMessage(`error in state queue: ${e}`);
      });
      return op;
    }
    /**
     * @param {number} tabId
     */
    clearReloadLoopState(tabId) {
      this._lastHandledCMP.delete(tabId);
      this._reloadLoopDetected.delete(tabId);
    }
    /**
     * @param {number} tabId
     * @param {string} url
     * @returns {URL}
     */
    updateTopUrl(tabId, url) {
      const oldTopUrl = this._tabUrlsCache.get(tabId) || new URL("about:blank");
      let newTopUrl = null;
      try {
        newTopUrl = new URL(url);
      } catch (e) {
        this.cpmMessaging.logMessage(`invalid top URL: ${url}: ${e}`);
        return oldTopUrl;
      }
      this.cpmMessaging.logMessage(`${tabId} Main frame navigated from ${oldTopUrl} to ${newTopUrl}`);
      if (oldTopUrl.host !== newTopUrl.host || oldTopUrl.pathname !== newTopUrl.pathname || oldTopUrl.protocol !== newTopUrl.protocol) {
        this.clearReloadLoopState(tabId);
      }
      this._tabUrlsCache.set(tabId, newTopUrl);
      return newTopUrl;
    }
    /**
     * @param {number} tabId
     * @param {string} cmp
     * @param {boolean} isCosmetic
     */
    rememberLastHandledCMP(tabId, cmp, isCosmetic) {
      if (isCosmetic) {
        console.log("cosmetic rule handled, not storing for reload loop detection", tabId, cmp);
        this.clearReloadLoopState(tabId);
        return;
      }
      const lastHandledCMP = this._lastHandledCMP.get(tabId);
      if (lastHandledCMP !== cmp) {
        console.log("last handled CMP is changed from", lastHandledCMP, "to", cmp, "clearing reload loop state", tabId);
        this.clearReloadLoopState(tabId);
      }
      console.log("recording popup handled: CMP", cmp, "on", this._tabUrlsCache.get(tabId), "tabId:", tabId);
      this._lastHandledCMP.set(tabId, cmp);
    }
    /**
     * @param {number} tabId
     * @param {string} cmp
     */
    detectReloadLoop(tabId, cmp) {
      const lastHandledCMP = this._lastHandledCMP.get(tabId);
      if (!this._reloadLoopDetected.has(tabId) && lastHandledCMP === cmp) {
        this.cpmMessaging.logMessage(`reload loop detected: ${cmp} on ${this._tabUrlsCache.get(tabId)} tabId: ${tabId}`);
        this._reloadLoopDetected.add(tabId);
        this.firePixel("error_reload-loop");
      }
    }
    /**
     *
     * @param {import('@duckduckgo/autoconsent').ContentScriptMessage} msg
     * @param {browser.Runtime.MessageSender} sender
     * @returns
     */
    async handleAutoConsentMessage(msg, sender) {
      const frameId = sender.frameId;
      if (!sender.tab || typeof frameId !== "number") {
        this.cpmMessaging.logMessage(`Invalid frameId ${frameId} or tab ${sender.tab}`);
        return;
      }
      const tabId = sender.tab.id;
      if (typeof tabId !== "number") {
        this.cpmMessaging.logMessage(`Invalid tabId ${tabId}`);
        return;
      }
      const isMainFrame = frameId === 0;
      const frameUrl = sender.url || sender.origin || "about:blank";
      const tabUrl = sender.tab.url || sender.tab.pendingUrl || "about:blank";
      let tabDomain = null;
      try {
        tabDomain = new URL(tabUrl).hostname;
      } catch (e) {
        this.cpmMessaging.logMessage(`error getting tab domain: ${e}`);
        return;
      }
      const remoteConfig = await this.remoteConfigJson;
      if (!remoteConfig) {
        this.cpmMessaging.logMessage("Remote config not ready, scheduling retry");
        this.scheduleConfigRefresh();
        return;
      }
      const autoconsentRemoteConfig = remoteConfig.features?.autoconsent;
      const autoconsentSettings = autoconsentRemoteConfig?.settings;
      console.log(
        "received autoconsent message",
        msg.type,
        msg,
        "sender:",
        sender,
        "autoconsentRemoteConfig:",
        autoconsentRemoteConfig
      );
      if (!autoconsentSettings) {
        this.cpmMessaging.logMessage(`autoconsentSettings not ready: ${autoconsentSettings}`);
        return;
      }
      const autoconsentFeatureEnabled = await this.cpmMessaging.checkAutoconsentSettingEnabled();
      if (!autoconsentFeatureEnabled) {
        this.cpmMessaging.logMessage("autoconsent setting not enabled");
        return;
      }
      const heuristicActionEnabled = await this.checkHeuristicActionEnabled();
      switch (msg.type) {
        case "init": {
          if (isMainFrame) {
            this.updateTopUrl(tabId, tabUrl);
            this.scheduleConfigRefresh();
          }
          const isEnabled = await this.cpmMessaging.checkAutoconsentEnabledForSite(tabUrl);
          if (!isEnabled) {
            this.cpmMessaging.logMessage(`autoconsent disabled for site: ${tabUrl}`);
            this.firePixel("disabled-for-site");
            return;
          }
          const visualTest = true;
          let autoAction = "optOut";
          if (this._reloadLoopDetected.has(tabId)) {
            this.cpmMessaging.logMessage(`reload loop detected, disabling autoAction: ${tabId}`);
            autoAction = null;
          }
          if (isMainFrame) {
            this.cpmMessaging.refreshDashboardState(tabId, tabUrl, {
              // keep "cookies managed" if we did it for this site since app launch
              consentManaged: (await this.getCpmState()).sitesNotifiedCache.has(tabDomain),
              cosmetic: null,
              optoutFailed: null,
              selftestFailed: null,
              consentReloadLoop: this._reloadLoopDetected.has(tabId),
              consentRule: this._lastHandledCMP.get(tabId) || null,
              consentHeuristicEnabled: heuristicActionEnabled
            });
            this.firePixel("init");
          }
          const autoconsentConfig = {
            enabled: isEnabled,
            autoAction,
            detectRetries: 20,
            isMainWorld: false,
            disabledCmps: autoconsentSettings.disabledCMPs || [],
            enablePrehide: true,
            prehideTimeout: 2e3,
            enableCosmeticRules: true,
            enableGeneratedRules: true,
            enableFilterList: false,
            enableHeuristicDetection: true,
            enableHeuristicAction: heuristicActionEnabled,
            visualTest,
            logs: logsConfig
          };
          const compactRuleList = autoconsentSettings.compactRuleList;
          const rules2 = {
            autoconsent: [],
            consentomatic: []
          };
          if (compactRuleList) {
            if (compactRuleList.index) {
              rules2.compact = filterCompactRules(
                /** @type {import('@duckduckgo/autoconsent').IndexedCMPRuleset} */
                compactRuleList,
                {
                  // use the frame URL here because rules are filtered by frame context
                  url: frameUrl,
                  mainFrame: isMainFrame
                }
              );
            } else {
              rules2.compact = compactRuleList;
            }
          }
          console.log("autoconsent config", autoconsentConfig);
          chrome.tabs.sendMessage(
            tabId,
            {
              type: "initResp",
              rules: rules2,
              config: autoconsentConfig
            },
            {
              frameId
            }
          );
          break;
        }
        case "cmpDetected": {
          break;
        }
        case "popupFound": {
          this.firePixel("popup-found");
          this.detectReloadLoop(tabId, msg.cmp);
          break;
        }
        case "optOutResult": {
          if (!msg.result) {
            this.firePixel("error_optout");
            this.cpmMessaging.refreshDashboardState(tabId, tabUrl, {
              consentManaged: true,
              cosmetic: null,
              optoutFailed: true,
              selftestFailed: null,
              consentReloadLoop: this._reloadLoopDetected.has(tabId),
              consentRule: msg.cmp,
              consentHeuristicEnabled: heuristicActionEnabled
            });
          } else {
          }
          break;
        }
        case "autoconsentDone": {
          this.rememberLastHandledCMP(tabId, msg.cmp, msg.isCosmetic);
          this.cpmMessaging.refreshDashboardState(tabId, tabUrl, {
            consentManaged: true,
            cosmetic: msg.isCosmetic,
            optoutFailed: false,
            selftestFailed: null,
            consentReloadLoop: this._reloadLoopDetected.has(tabId),
            consentRule: msg.cmp,
            consentHeuristicEnabled: heuristicActionEnabled
          });
          if (msg.cmp === "HEURISTIC") {
            this.firePixel("done_heuristic");
          } else {
            this.firePixel(msg.isCosmetic ? "done_cosmetic" : "done");
          }
          await this.modifyCpmState((cpmState) => {
            cpmState.sitesNotifiedCache.add(tabDomain);
          });
          this.cpmMessaging.showCpmAnimation(tabId, tabUrl, msg.isCosmetic);
          this.firePixel(msg.isCosmetic ? "animation-shown_cosmetic" : "animation-shown");
          this.cpmMessaging.notifyPopupHandled(tabId, msg);
          break;
        }
        case "report": {
          const state = msg.state || {};
          const detectedByPatterns = state.heuristicPatterns?.length > 0;
          const detectedBySnippets = state.heuristicSnippets?.length > 0;
          const detectedPopups = state.detectedPopups?.length > 0;
          const heuristicMatch = detectedByPatterns || detectedBySnippets;
          await this.modifyCpmState((cpmState) => {
            if (isMainFrame && heuristicMatch && !cpmState.detectionCache.patterns.has(msg.instanceId)) {
              cpmState.detectionCache.patterns.add(msg.instanceId);
              this.firePixel("detected-by-patterns");
            }
            if (isMainFrame && detectedPopups) {
              if (heuristicMatch && !cpmState.detectionCache.both.has(msg.instanceId)) {
                cpmState.detectionCache.both.add(msg.instanceId);
                this.firePixel("detected-by-both");
              } else if (!heuristicMatch && !cpmState.detectionCache.onlyRules.has(msg.instanceId)) {
                cpmState.detectionCache.onlyRules.add(msg.instanceId);
                this.firePixel("detected-only-rules");
              }
            }
          });
          break;
        }
        case "eval": {
          if (typeof msg.snippetId !== "undefined") {
            this.evalInTab(tabId, frameId, msg.snippetId).then(([result]) => {
              if (logsConfig.evals) {
                console.groupCollapsed(`eval result for ${frameUrl}`);
                console.log(msg.code, result.result);
                console.groupEnd();
              }
              chrome.tabs.sendMessage(
                tabId,
                {
                  id: msg.id,
                  type: "evalResp",
                  result: result.result
                },
                {
                  frameId
                }
              );
            });
          }
          break;
        }
        case "autoconsentError": {
          if (msg.details?.msg?.includes("Found multiple CMPs")) {
            this.firePixel("error_multiple-popups");
          }
          break;
        }
        case "visualDelay": {
          console.log("visualDelay", msg);
          break;
        }
        default:
          this.cpmMessaging.logMessage(`Unhandled autoconsent message type: ${msg.type}`);
          break;
      }
    }
    /**
     *
     * @param {number} tabId
     * @param {number} frameId
     * @param {keyof typeof evalSnippets} snippetId
     * @returns {Promise<chrome.scripting.InjectionResult<boolean>[]>}
     */
    async evalInTab(tabId, frameId, snippetId) {
      return chrome.scripting.executeScript({
        target: {
          tabId,
          frameIds: [frameId]
        },
        world: "MAIN",
        func: snippets[snippetId]
      });
    }
    async firePixel(eventName) {
      this.modifyCpmState((cpmState) => {
        cpmState.summaryEvents[eventName] = (cpmState.summaryEvents[eventName] || 0) + 1;
      });
      createAlarm(_CookiePromptManagement.SUMMARY_ALARM_NAME, {
        delayInMinutes: _CookiePromptManagement.SUMMARY_DELAY_MINUTES
      });
      const pixelName = `autoconsent_${eventName}`;
      this.cpmMessaging.sendPixel(pixelName, "daily", {
        consentHeuristicEnabled: await this.checkHeuristicActionEnabled() ? "1" : "0",
        fromExtension: "1"
      });
    }
    async sendSummaryPixel() {
      let summaryEvents = {};
      await this.modifyCpmState((cpmState) => {
        summaryEvents = structuredClone(cpmState.summaryEvents);
        cpmState.summaryEvents = {};
        cpmState.detectionCache.patterns.clear();
        cpmState.detectionCache.both.clear();
        cpmState.detectionCache.onlyRules.clear();
      });
      this.cpmMessaging.sendPixel("autoconsent_summary", "standard", {
        ...summaryEvents,
        consentHeuristicEnabled: await this.checkHeuristicActionEnabled() ? "1" : "0",
        fromExtension: "1"
      });
    }
  };

  // shared/js/background/components/cpm-embedded-messaging.js
  init_wrapper();
  var SUBFEATURE_CHECK_TTL = 30 * 1e3;
  var SETTING_CHECK_TTL = 10 * 1e3;
  var SITE_CHECK_TTL = 3 * 1e3;
  var MAX_CACHE_SIZE = 100;
  var CPMEmbeddedMessaging = class {
    /**
     * @param {NativeMessagingInterface} nativeMessaging
     */
    constructor(nativeMessaging2) {
      this.nativeMessaging = nativeMessaging2;
      this._cache = /* @__PURE__ */ new Map();
      this._queue = Promise.resolve();
      this._cachedConfig = null;
    }
    /**
     * Enqueue a notification message to be sent to the native app.
     * @param {string} method
     * @param {Record<string, any>} params
     */
    async _notify(method2, params) {
      const result = this._queue.then(() => {
        return this.nativeMessaging.notify(method2, params);
      }).catch((e) => {
        console.error("error in notification queue", e);
      });
      this._queue = result;
      await result;
    }
    /**
     * Enqueue a request to the native app and wait for a response,
     * blocking subsequent callers until the request is complete.
     * If cacheKey and ttl are provided, the result is cached and
     * returned immediately on subsequent calls within the TTL.
     * @param {string} method
     * @param {Record<string, any>} params
     * @param {string} [cacheKey]
     * @param {number} [ttl]
     * @returns {Promise<any>}
     */
    _request(method2, params, cacheKey, ttl) {
      const job = this._queue.then(async () => {
        if (cacheKey && ttl) {
          const cached = this._cache.get(cacheKey);
          if (cached && Date.now() - cached.time < ttl) {
            return cached.value;
          }
        }
        const result = await this.nativeMessaging.request(method2, params);
        if (cacheKey && ttl) {
          if (this._cache.size >= MAX_CACHE_SIZE) {
            const oldest = this._cache.keys().next().value;
            if (oldest !== void 0) this._cache.delete(oldest);
          }
          this._cache.set(cacheKey, { time: Date.now(), value: result });
        }
        return result;
      }).catch((e) => {
        console.error(`error in request queue for ${method2}`, e);
      });
      this._queue = job;
      return job;
    }
    async logMessage(message) {
      console.log(message);
      await this._notify("extensionLog", {
        message
      });
    }
    async refreshDashboardState(tabId, url, dashboardState) {
      await this._notify("refreshCpmDashboardState", {
        tabId,
        url,
        consentStatus: dashboardState
      });
    }
    async showCpmAnimation(tabId, topUrl, isCosmetic) {
      await this._notify("showCpmAnimation", {
        tabId,
        topUrl,
        isCosmetic
      });
    }
    async notifyPopupHandled(tabId, msg) {
      await this._notify("cookiePopupHandled", {
        tabId,
        msg
      });
    }
    async checkAutoconsentSettingEnabled() {
      const result = await this._request("isAutoconsentSettingEnabled", {}, "userSetting", SETTING_CHECK_TTL);
      return result?.enabled ?? false;
    }
    async checkAutoconsentEnabledForSite(url) {
      const result = await this._request("isFeatureEnabled", { featureName: "autoconsent", url }, `site:${url}`, SITE_CHECK_TTL);
      return result?.enabled ?? false;
    }
    async checkSubfeatureEnabled(subfeatureName) {
      const result = await this._request(
        "isSubFeatureEnabled",
        { featureName: "autoconsent", subfeatureName },
        `subfeature:${subfeatureName}`,
        SUBFEATURE_CHECK_TTL
      );
      return result?.enabled ?? false;
    }
    async sendPixel(pixelName, type, params) {
      await this._notify("sendPixel", {
        pixelName,
        type,
        params
      });
    }
    async refreshRemoteConfig() {
      const cachedConfig = this._cachedConfig || await getFromSessionStorage("config") || { version: "unknown" };
      const cachedConfigVersion = `${cachedConfig.version}`;
      console.log(`cachedConfig: ${JSON.stringify(cachedConfig)}`);
      try {
        console.log(`fetching config from native, cachedConfigVersion: ${cachedConfigVersion}`);
        const result = await this.nativeMessaging.request("getResourceIfNew", { name: "config", version: cachedConfigVersion });
        if (result.updated) {
          this._cachedConfig = result.data;
          try {
            await setToSessionStorage("config", this._cachedConfig);
          } catch (e) {
            this.logMessage(`error setting cached config to session storage: ${e}`);
          }
          return this._cachedConfig;
        }
        return cachedConfig;
      } catch (e) {
        this.logMessage(`error refreshing remote config: ${e}`);
        if (cachedConfigVersion !== "unknown") {
          return cachedConfig;
        }
        throw e;
      }
    }
  };

  // shared/js/background/components/message-router.js
  var import_webextension_polyfill5 = __toESM(require_browser_polyfill());
  init_wrapper();

  // shared/js/background/utils.js
  var import_webextension_polyfill4 = __toESM(require_browser_polyfill());
  init_wrapper();

  // shared/js/background/storage/tds.js
  var settings = require_settings();

  // shared/js/background/utils.js
  var import_settings = __toESM(require_settings());

  // node_modules/tldts-core/dist/es6/src/options.js
  function setDefaultsImpl({ allowIcannDomains = true, allowPrivateDomains = false, detectIp = true, extractHostname: extractHostname2 = true, mixedInputs = true, validHosts = null, validateHostname = true }) {
    return {
      allowIcannDomains,
      allowPrivateDomains,
      detectIp,
      extractHostname: extractHostname2,
      mixedInputs,
      validHosts,
      validateHostname
    };
  }
  var DEFAULT_OPTIONS = (
    /*@__INLINE__*/
    setDefaultsImpl({})
  );

  // node_modules/tldts-core/dist/es6/src/factory.js
  function getEmptyResult() {
    return {
      domain: null,
      domainWithoutSuffix: null,
      hostname: null,
      isIcann: null,
      isIp: null,
      isPrivate: null,
      publicSuffix: null,
      subdomain: null
    };
  }

  // node_modules/tldts/dist/es6/index.js
  var RESULT = getEmptyResult();

  // shared/js/background/utils.js
  var import_parse_user_agent_string = __toESM(require_parse_user_agent_string());
  var import_sha1 = __toESM(require_sha1());
  var browserInfo = (0, import_parse_user_agent_string.default)();
  function getBrowserName() {
    if (!browserInfo || !browserInfo.browser) return;
    let browserName = browserInfo.browser.toLowerCase();
    if (browserName === "firefox") browserName = "moz";
    return browserName;
  }
  var dayMultiplier = 24 * 60 * 60 * 1e3;

  // shared/js/background/popup-messaging.js
  var activePort = null;
  function getActivePort() {
    return activePort;
  }
  function setActivePort(port) {
    activePort = port;
  }

  // shared/js/background/components/message-router.js
  var MessageReceivedEvent = class extends CustomEvent {
    constructor(msg) {
      super("messageReceived", { detail: msg });
    }
    get messageType() {
      return this.detail.messageType;
    }
  };
  var MessageRouter = class extends EventTarget {
    constructor() {
      super();
      const browserName = getBrowserName();
      import_webextension_polyfill5.default.runtime.onConnect.addListener((port) => {
        if (port.name === "privacy-dashboard") {
          this.popupConnectionOpened(port);
        }
      });
      import_webextension_polyfill5.default.runtime.onMessage.addListener((req, sender) => {
        if (sender.id !== getExtensionId()) return;
        if (browserName === "chrome" && (req === "healthCheckRequest" || req === "rescheduleCounterMessagingRequest")) {
          req = { messageType: req };
        }
        const legacyMessageTypes = [
          "addUserData",
          "getUserData",
          "removeUserData",
          "getEmailProtectionCapabilities",
          "getAddresses",
          "refreshAlias",
          "debuggerMessage"
        ];
        for (const legacyMessageType of legacyMessageTypes) {
          if (legacyMessageType in req) {
            req.messageType = legacyMessageType;
            req.options = req[legacyMessageType];
          }
        }
        if (req.registeredTempAutofillContentScript) {
          req.messageType = "registeredContentScript";
        }
        if (req.messageType && req.messageType in message_registry_default) {
          this.dispatchEvent(new MessageReceivedEvent(req));
          return Promise.resolve(message_registry_default[req.messageType](req.options, sender, req));
        }
        console.error("Unrecognized message to background:", req, sender);
      });
    }
    /**
     * Set up the messaging connection with the popup UI.
     *
     * Note: If the ServiceWorker dies while there is an open connection, the popup
     *       will take care of re-opening the connection.
     *
     * @param {Port} port
     */
    popupConnectionOpened(port) {
      setActivePort(port);
      port.onDisconnect.addListener(() => {
        if (getActivePort() === port) {
          setActivePort(null);
        }
      });
      port.onMessage.addListener(async (message) => {
        const messageType = message?.messageType;
        if (!messageType || !(messageType in message_registry_default)) {
          console.error("Unrecognized message (privacy-dashboard -> background):", message);
          return;
        }
        this.dispatchEvent(new MessageReceivedEvent(message));
        const response = await message_registry_default[messageType](message?.options, port, message);
        if (typeof message?.id === "number") {
          port.postMessage({
            id: message.id,
            messageType: "response",
            options: response
          });
        }
      });
    }
  };

  // shared/js/background/devbuild-reloader.js
  var import_webextension_polyfill6 = __toESM(require_browser_polyfill());
  init_wrapper();
  function initReloader() {
    function createAlarmTimer() {
      createAlarm("checkBuildTime", { when: Date.now() + 5e3 });
    }
    import_webextension_polyfill6.default.alarms.onAlarm.addListener(async (alarmEvent) => {
      if (alarmEvent.name !== "checkBuildTime") {
        return;
      }
      let buildTime = null;
      try {
        const response = await fetch("/buildtime.txt", { cache: "no-store" });
        buildTime = await response.text();
      } catch (e) {
      }
      if (buildTime) {
        const previousBuildTime = await getFromSessionStorage("buildTime");
        if (!previousBuildTime) {
          await setToSessionStorage("buildTime", buildTime);
        } else if (buildTime !== previousBuildTime) {
          import_webextension_polyfill6.default.runtime.reload();
        }
      }
      createAlarmTimer();
    });
    createAlarmTimer();
  }

  // shared/js/background/components/native-messaging.js
  var import_webextension_polyfill7 = __toESM(require_browser_polyfill());
  var DEFAULT_NATIVE_APP_ID = "com.duckduckgo.macos.browser";
  var NativeMessaging = class {
    /**
     * @param {string} context
     * @param {string} featureName
     * @param {string} [appId]
     */
    constructor(context, featureName, appId = DEFAULT_NATIVE_APP_ID) {
      this._appId = appId;
      this._context = context;
      this._featureName = featureName;
    }
    /**
     * Send a fire-and-forget notification to the native app.
     *
     * @param {string} method - The method name to call on the native side
     * @param {Record<string, any>} [params] - Optional parameters to send
     */
    async notify(method2, params = {}) {
      const msg = (
        /** @type {NotificationMessage} */
        {
          context: this._context,
          featureName: this._featureName,
          method: method2,
          params
        }
      );
      console.log("[NativeMessaging] NOTIFY", `${this._context}.${this._featureName}.${method2}`, params);
      await import_webextension_polyfill7.default.runtime.sendNativeMessage(this._appId, msg).catch((e) => {
        console.error("[NativeMessaging] notification error:", e);
        throw e;
      });
    }
    /**
     * Send a request to the native app and wait for a response.
     *
     * @param {string} method - The method name to call on the native side
     * @param {Record<string, any>} [params] - Optional parameters to send
     * @returns {Promise<any>}
     */
    async request(method2, params = {}) {
      const id = crypto.randomUUID();
      const msg = (
        /** @type {RequestMessage} */
        {
          context: this._context,
          featureName: this._featureName,
          id,
          method: method2,
          params
        }
      );
      console.log("[NativeMessaging] REQUEST", `${this._context}.${this._featureName}.${method2}`, `id=${id}`, params);
      const response = (
        /** @type {MessageResponse} */
        await import_webextension_polyfill7.default.runtime.sendNativeMessage(this._appId, msg).catch((e) => {
          console.error("[NativeMessaging] error:", e);
          return {
            id,
            context: this._context,
            featureName: this._featureName,
            error: {
              message: `NativeMessaging request-response error: ${e}`
            }
          };
        })
      );
      console.log("[NativeMessaging] Received from native:", JSON.stringify(response));
      if (!response || typeof response !== "object") {
        throw new Error(`NativeMessaging: unexpected response type: ${typeof response}`);
      }
      if ("error" in response && response.error) {
        console.log("[NativeMessaging] RESPONSE ERROR", `id=${id}`, response.error);
        throw new Error(response.error.message || "Unknown error");
      }
      console.log("[NativeMessaging] RESPONSE OK", `id=${id}`, response.result);
      return response.result || {};
    }
    subscribe(_msg, _callback) {
      throw new Error("Subscriptions are not supported over Native Messaging API");
    }
  };

  // shared/js/background/background-embedded.js
  var nativeMessaging = new NativeMessaging("ddgInternalExtension", "autoconsent", "com.duckduckgo.macos.browser");
  globalThis.addEventListener("error", (event) => {
    nativeMessaging.notify("extensionException", {
      message: `Uncaught error: ${event.error?.message ?? event.message}`,
      stack: event.error?.stack
    }).catch((e) => {
    });
  });
  globalThis.addEventListener("unhandledrejection", (event) => {
    nativeMessaging.notify("extensionException", {
      message: `Unhandled promise rejection: ${event.reason}`,
      stack: event.reason?.stack
    }).catch((e) => {
    });
  });
  var cpmMessaging = new CPMEmbeddedMessaging(nativeMessaging);
  var messaging = new MessageRouter();
  var cpm = new CookiePromptManagement({
    cpmMessaging
  });
  var components = {
    messaging,
    cpm
  };
  Promise.all([
    import_webextension_polyfill8.default.scripting.getRegisteredContentScripts(),
    import_webextension_polyfill8.default.alarms.getAll(),
    // @ts-ignore - getBytesInUse is not available in the type
    import_webextension_polyfill8.default.storage.session.getBytesInUse(null)
  ]).then(([scripts, alarms, bytesInSessionStorage]) => {
    const quotaBytes = import_webextension_polyfill8.default.storage.session.QUOTA_BYTES;
    cpmMessaging.logMessage(
      `DuckDuckGo Embedded Extension loaded.
        Content scripts: ${JSON.stringify(scripts)}
        Alarms: ${JSON.stringify(alarms)}
        Current time: ${Date.now()}
        Bytes in session storage: ${bytesInSessionStorage} (Quota ${quotaBytes})
        `
    );
  });
  self.components = components;
  initReloader();
})();
/*
 * [js-sha1]{@link https://github.com/emn178/js-sha1}
 *
 * @version 0.6.0
 * @author Chen, Yi-Cyuan [emn178@gmail.com]
 * @copyright Chen, Yi-Cyuan 2014-2017
 * @license MIT
 */
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsibm9kZV9tb2R1bGVzL3dlYmV4dGVuc2lvbi1wb2x5ZmlsbC9kaXN0L2Jyb3dzZXItcG9seWZpbGwuanMiLCAic2hhcmVkL2pzL2JhY2tncm91bmQvd3JhcHBlci5qcyIsICJzaGFyZWQvZGF0YS9kZWZhdWx0U2V0dGluZ3MuanMiLCAic2hhcmVkL2pzL2JhY2tncm91bmQvc2V0dGluZ3MuanMiLCAic2hhcmVkL2pzL3NoYXJlZC11dGlscy9wYXJzZS11c2VyLWFnZW50LXN0cmluZy5qcyIsICJzaGFyZWQvanMvc2hhcmVkLXV0aWxzL3NoYTEuanMiLCAic2hhcmVkL2pzL2JhY2tncm91bmQvYmFja2dyb3VuZC1lbWJlZGRlZC5qcyIsICJub2RlX21vZHVsZXMvQGR1Y2tkdWNrZ28vYXV0b2NvbnNlbnQvZGlzdC9hdXRvY29uc2VudC5lc20uanMiLCAic2hhcmVkL2pzL2JhY2tncm91bmQvY29tcG9uZW50cy9jb29raWUtcHJvbXB0LW1hbmFnZW1lbnQuanMiLCAic2hhcmVkL2pzL2JhY2tncm91bmQvY29tcG9uZW50cy9tdjMtY29udGVudC1zY3JpcHQtaW5qZWN0aW9uLmpzIiwgInNoYXJlZC9qcy9iYWNrZ3JvdW5kL21lc3NhZ2UtcmVnaXN0cnkuanMiLCAic2hhcmVkL2pzL2JhY2tncm91bmQvY29tcG9uZW50cy9jcG0tZW1iZWRkZWQtbWVzc2FnaW5nLmpzIiwgInNoYXJlZC9qcy9iYWNrZ3JvdW5kL2NvbXBvbmVudHMvbWVzc2FnZS1yb3V0ZXIuanMiLCAic2hhcmVkL2pzL2JhY2tncm91bmQvdXRpbHMuanMiLCAic2hhcmVkL2pzL2JhY2tncm91bmQvc3RvcmFnZS90ZHMuanMiLCAibm9kZV9tb2R1bGVzL3RsZHRzLWNvcmUvc3JjL29wdGlvbnMudHMiLCAibm9kZV9tb2R1bGVzL3RsZHRzLWNvcmUvc3JjL2ZhY3RvcnkudHMiLCAibm9kZV9tb2R1bGVzL3RsZHRzL2luZGV4LnRzIiwgInNoYXJlZC9qcy9iYWNrZ3JvdW5kL3BvcHVwLW1lc3NhZ2luZy5qcyIsICJzaGFyZWQvanMvYmFja2dyb3VuZC9kZXZidWlsZC1yZWxvYWRlci5qcyIsICJzaGFyZWQvanMvYmFja2dyb3VuZC9jb21wb25lbnRzL25hdGl2ZS1tZXNzYWdpbmcuanMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbIi8qIHdlYmV4dGVuc2lvbi1wb2x5ZmlsbCAtIHYwLjEyLjAgLSBUdWUgTWF5IDE0IDIwMjQgMTg6MDE6MjkgKi9cbi8qIC0qLSBNb2RlOiBpbmRlbnQtdGFicy1tb2RlOiBuaWw7IGpzLWluZGVudC1sZXZlbDogMiAtKi0gKi9cbi8qIHZpbTogc2V0IHN0cz0yIHN3PTIgZXQgdHc9ODA6ICovXG4vKiBUaGlzIFNvdXJjZSBDb2RlIEZvcm0gaXMgc3ViamVjdCB0byB0aGUgdGVybXMgb2YgdGhlIE1vemlsbGEgUHVibGljXG4gKiBMaWNlbnNlLCB2LiAyLjAuIElmIGEgY29weSBvZiB0aGUgTVBMIHdhcyBub3QgZGlzdHJpYnV0ZWQgd2l0aCB0aGlzXG4gKiBmaWxlLCBZb3UgY2FuIG9idGFpbiBvbmUgYXQgaHR0cDovL21vemlsbGEub3JnL01QTC8yLjAvLiAqL1xuXCJ1c2Ugc3RyaWN0XCI7XG5cbmlmICghKGdsb2JhbFRoaXMuY2hyb21lICYmIGdsb2JhbFRoaXMuY2hyb21lLnJ1bnRpbWUgJiYgZ2xvYmFsVGhpcy5jaHJvbWUucnVudGltZS5pZCkpIHtcbiAgdGhyb3cgbmV3IEVycm9yKFwiVGhpcyBzY3JpcHQgc2hvdWxkIG9ubHkgYmUgbG9hZGVkIGluIGEgYnJvd3NlciBleHRlbnNpb24uXCIpO1xufVxuXG5pZiAoIShnbG9iYWxUaGlzLmJyb3dzZXIgJiYgZ2xvYmFsVGhpcy5icm93c2VyLnJ1bnRpbWUgJiYgZ2xvYmFsVGhpcy5icm93c2VyLnJ1bnRpbWUuaWQpKSB7XG4gIGNvbnN0IENIUk9NRV9TRU5EX01FU1NBR0VfQ0FMTEJBQ0tfTk9fUkVTUE9OU0VfTUVTU0FHRSA9IFwiVGhlIG1lc3NhZ2UgcG9ydCBjbG9zZWQgYmVmb3JlIGEgcmVzcG9uc2Ugd2FzIHJlY2VpdmVkLlwiO1xuXG4gIC8vIFdyYXBwaW5nIHRoZSBidWxrIG9mIHRoaXMgcG9seWZpbGwgaW4gYSBvbmUtdGltZS11c2UgZnVuY3Rpb24gaXMgYSBtaW5vclxuICAvLyBvcHRpbWl6YXRpb24gZm9yIEZpcmVmb3guIFNpbmNlIFNwaWRlcm1vbmtleSBkb2VzIG5vdCBmdWxseSBwYXJzZSB0aGVcbiAgLy8gY29udGVudHMgb2YgYSBmdW5jdGlvbiB1bnRpbCB0aGUgZmlyc3QgdGltZSBpdCdzIGNhbGxlZCwgYW5kIHNpbmNlIGl0IHdpbGxcbiAgLy8gbmV2ZXIgYWN0dWFsbHkgbmVlZCB0byBiZSBjYWxsZWQsIHRoaXMgYWxsb3dzIHRoZSBwb2x5ZmlsbCB0byBiZSBpbmNsdWRlZFxuICAvLyBpbiBGaXJlZm94IG5lYXJseSBmb3IgZnJlZS5cbiAgY29uc3Qgd3JhcEFQSXMgPSBleHRlbnNpb25BUElzID0+IHtcbiAgICAvLyBOT1RFOiBhcGlNZXRhZGF0YSBpcyBhc3NvY2lhdGVkIHRvIHRoZSBjb250ZW50IG9mIHRoZSBhcGktbWV0YWRhdGEuanNvbiBmaWxlXG4gICAgLy8gYXQgYnVpbGQgdGltZSBieSByZXBsYWNpbmcgdGhlIGZvbGxvd2luZyBcImluY2x1ZGVcIiB3aXRoIHRoZSBjb250ZW50IG9mIHRoZVxuICAgIC8vIEpTT04gZmlsZS5cbiAgICBjb25zdCBhcGlNZXRhZGF0YSA9IHtcbiAgICAgIFwiYWxhcm1zXCI6IHtcbiAgICAgICAgXCJjbGVhclwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgfSxcbiAgICAgICAgXCJjbGVhckFsbFwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgfSxcbiAgICAgICAgXCJnZXRcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgIH0sXG4gICAgICAgIFwiZ2V0QWxsXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgXCJib29rbWFya3NcIjoge1xuICAgICAgICBcImNyZWF0ZVwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgfSxcbiAgICAgICAgXCJnZXRcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgIH0sXG4gICAgICAgIFwiZ2V0Q2hpbGRyZW5cIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgIH0sXG4gICAgICAgIFwiZ2V0UmVjZW50XCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICB9LFxuICAgICAgICBcImdldFN1YlRyZWVcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgIH0sXG4gICAgICAgIFwiZ2V0VHJlZVwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgfSxcbiAgICAgICAgXCJtb3ZlXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMixcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMlxuICAgICAgICB9LFxuICAgICAgICBcInJlbW92ZVwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgfSxcbiAgICAgICAgXCJyZW1vdmVUcmVlXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICB9LFxuICAgICAgICBcInNlYXJjaFwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgfSxcbiAgICAgICAgXCJ1cGRhdGVcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAyLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAyXG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICBcImJyb3dzZXJBY3Rpb25cIjoge1xuICAgICAgICBcImRpc2FibGVcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxLFxuICAgICAgICAgIFwiZmFsbGJhY2tUb05vQ2FsbGJhY2tcIjogdHJ1ZVxuICAgICAgICB9LFxuICAgICAgICBcImVuYWJsZVwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDEsXG4gICAgICAgICAgXCJmYWxsYmFja1RvTm9DYWxsYmFja1wiOiB0cnVlXG4gICAgICAgIH0sXG4gICAgICAgIFwiZ2V0QmFkZ2VCYWNrZ3JvdW5kQ29sb3JcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgIH0sXG4gICAgICAgIFwiZ2V0QmFkZ2VUZXh0XCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICB9LFxuICAgICAgICBcImdldFBvcHVwXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICB9LFxuICAgICAgICBcImdldFRpdGxlXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICB9LFxuICAgICAgICBcIm9wZW5Qb3B1cFwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgfSxcbiAgICAgICAgXCJzZXRCYWRnZUJhY2tncm91bmRDb2xvclwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDEsXG4gICAgICAgICAgXCJmYWxsYmFja1RvTm9DYWxsYmFja1wiOiB0cnVlXG4gICAgICAgIH0sXG4gICAgICAgIFwic2V0QmFkZ2VUZXh0XCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMSxcbiAgICAgICAgICBcImZhbGxiYWNrVG9Ob0NhbGxiYWNrXCI6IHRydWVcbiAgICAgICAgfSxcbiAgICAgICAgXCJzZXRJY29uXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICB9LFxuICAgICAgICBcInNldFBvcHVwXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMSxcbiAgICAgICAgICBcImZhbGxiYWNrVG9Ob0NhbGxiYWNrXCI6IHRydWVcbiAgICAgICAgfSxcbiAgICAgICAgXCJzZXRUaXRsZVwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDEsXG4gICAgICAgICAgXCJmYWxsYmFja1RvTm9DYWxsYmFja1wiOiB0cnVlXG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICBcImJyb3dzaW5nRGF0YVwiOiB7XG4gICAgICAgIFwicmVtb3ZlXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMixcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMlxuICAgICAgICB9LFxuICAgICAgICBcInJlbW92ZUNhY2hlXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICB9LFxuICAgICAgICBcInJlbW92ZUNvb2tpZXNcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgIH0sXG4gICAgICAgIFwicmVtb3ZlRG93bmxvYWRzXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICB9LFxuICAgICAgICBcInJlbW92ZUZvcm1EYXRhXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICB9LFxuICAgICAgICBcInJlbW92ZUhpc3RvcnlcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgIH0sXG4gICAgICAgIFwicmVtb3ZlTG9jYWxTdG9yYWdlXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICB9LFxuICAgICAgICBcInJlbW92ZVBhc3N3b3Jkc1wiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgfSxcbiAgICAgICAgXCJyZW1vdmVQbHVnaW5EYXRhXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICB9LFxuICAgICAgICBcInNldHRpbmdzXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgXCJjb21tYW5kc1wiOiB7XG4gICAgICAgIFwiZ2V0QWxsXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgXCJjb250ZXh0TWVudXNcIjoge1xuICAgICAgICBcInJlbW92ZVwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgfSxcbiAgICAgICAgXCJyZW1vdmVBbGxcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgIH0sXG4gICAgICAgIFwidXBkYXRlXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMixcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMlxuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgXCJjb29raWVzXCI6IHtcbiAgICAgICAgXCJnZXRcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgIH0sXG4gICAgICAgIFwiZ2V0QWxsXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICB9LFxuICAgICAgICBcImdldEFsbENvb2tpZVN0b3Jlc1wiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgfSxcbiAgICAgICAgXCJyZW1vdmVcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgIH0sXG4gICAgICAgIFwic2V0XCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgXCJkZXZ0b29sc1wiOiB7XG4gICAgICAgIFwiaW5zcGVjdGVkV2luZG93XCI6IHtcbiAgICAgICAgICBcImV2YWxcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMixcbiAgICAgICAgICAgIFwic2luZ2xlQ2FsbGJhY2tBcmdcIjogZmFsc2VcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIFwicGFuZWxzXCI6IHtcbiAgICAgICAgICBcImNyZWF0ZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMyxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAzLFxuICAgICAgICAgICAgXCJzaW5nbGVDYWxsYmFja0FyZ1wiOiB0cnVlXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImVsZW1lbnRzXCI6IHtcbiAgICAgICAgICAgIFwiY3JlYXRlU2lkZWJhclBhbmVcIjoge1xuICAgICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICBcImRvd25sb2Fkc1wiOiB7XG4gICAgICAgIFwiY2FuY2VsXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICB9LFxuICAgICAgICBcImRvd25sb2FkXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICB9LFxuICAgICAgICBcImVyYXNlXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICB9LFxuICAgICAgICBcImdldEZpbGVJY29uXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMlxuICAgICAgICB9LFxuICAgICAgICBcIm9wZW5cIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxLFxuICAgICAgICAgIFwiZmFsbGJhY2tUb05vQ2FsbGJhY2tcIjogdHJ1ZVxuICAgICAgICB9LFxuICAgICAgICBcInBhdXNlXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICB9LFxuICAgICAgICBcInJlbW92ZUZpbGVcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgIH0sXG4gICAgICAgIFwicmVzdW1lXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICB9LFxuICAgICAgICBcInNlYXJjaFwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgfSxcbiAgICAgICAgXCJzaG93XCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMSxcbiAgICAgICAgICBcImZhbGxiYWNrVG9Ob0NhbGxiYWNrXCI6IHRydWVcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIFwiZXh0ZW5zaW9uXCI6IHtcbiAgICAgICAgXCJpc0FsbG93ZWRGaWxlU2NoZW1lQWNjZXNzXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICB9LFxuICAgICAgICBcImlzQWxsb3dlZEluY29nbml0b0FjY2Vzc1wiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIFwiaGlzdG9yeVwiOiB7XG4gICAgICAgIFwiYWRkVXJsXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICB9LFxuICAgICAgICBcImRlbGV0ZUFsbFwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgfSxcbiAgICAgICAgXCJkZWxldGVSYW5nZVwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgfSxcbiAgICAgICAgXCJkZWxldGVVcmxcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgIH0sXG4gICAgICAgIFwiZ2V0VmlzaXRzXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICB9LFxuICAgICAgICBcInNlYXJjaFwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIFwiaTE4blwiOiB7XG4gICAgICAgIFwiZGV0ZWN0TGFuZ3VhZ2VcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgIH0sXG4gICAgICAgIFwiZ2V0QWNjZXB0TGFuZ3VhZ2VzXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgXCJpZGVudGl0eVwiOiB7XG4gICAgICAgIFwibGF1bmNoV2ViQXV0aEZsb3dcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICBcImlkbGVcIjoge1xuICAgICAgICBcInF1ZXJ5U3RhdGVcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICBcIm1hbmFnZW1lbnRcIjoge1xuICAgICAgICBcImdldFwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgfSxcbiAgICAgICAgXCJnZXRBbGxcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgIH0sXG4gICAgICAgIFwiZ2V0U2VsZlwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgfSxcbiAgICAgICAgXCJzZXRFbmFibGVkXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMixcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMlxuICAgICAgICB9LFxuICAgICAgICBcInVuaW5zdGFsbFNlbGZcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICBcIm5vdGlmaWNhdGlvbnNcIjoge1xuICAgICAgICBcImNsZWFyXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICB9LFxuICAgICAgICBcImNyZWF0ZVwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDJcbiAgICAgICAgfSxcbiAgICAgICAgXCJnZXRBbGxcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgIH0sXG4gICAgICAgIFwiZ2V0UGVybWlzc2lvbkxldmVsXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICB9LFxuICAgICAgICBcInVwZGF0ZVwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDIsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDJcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIFwicGFnZUFjdGlvblwiOiB7XG4gICAgICAgIFwiZ2V0UG9wdXBcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgIH0sXG4gICAgICAgIFwiZ2V0VGl0bGVcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgIH0sXG4gICAgICAgIFwiaGlkZVwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDEsXG4gICAgICAgICAgXCJmYWxsYmFja1RvTm9DYWxsYmFja1wiOiB0cnVlXG4gICAgICAgIH0sXG4gICAgICAgIFwic2V0SWNvblwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgfSxcbiAgICAgICAgXCJzZXRQb3B1cFwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDEsXG4gICAgICAgICAgXCJmYWxsYmFja1RvTm9DYWxsYmFja1wiOiB0cnVlXG4gICAgICAgIH0sXG4gICAgICAgIFwic2V0VGl0bGVcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxLFxuICAgICAgICAgIFwiZmFsbGJhY2tUb05vQ2FsbGJhY2tcIjogdHJ1ZVxuICAgICAgICB9LFxuICAgICAgICBcInNob3dcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxLFxuICAgICAgICAgIFwiZmFsbGJhY2tUb05vQ2FsbGJhY2tcIjogdHJ1ZVxuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgXCJwZXJtaXNzaW9uc1wiOiB7XG4gICAgICAgIFwiY29udGFpbnNcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgIH0sXG4gICAgICAgIFwiZ2V0QWxsXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICB9LFxuICAgICAgICBcInJlbW92ZVwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgfSxcbiAgICAgICAgXCJyZXF1ZXN0XCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgXCJydW50aW1lXCI6IHtcbiAgICAgICAgXCJnZXRCYWNrZ3JvdW5kUGFnZVwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgfSxcbiAgICAgICAgXCJnZXRQbGF0Zm9ybUluZm9cIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgIH0sXG4gICAgICAgIFwib3Blbk9wdGlvbnNQYWdlXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICB9LFxuICAgICAgICBcInJlcXVlc3RVcGRhdGVDaGVja1wiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgfSxcbiAgICAgICAgXCJzZW5kTWVzc2FnZVwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDNcbiAgICAgICAgfSxcbiAgICAgICAgXCJzZW5kTmF0aXZlTWVzc2FnZVwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDIsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDJcbiAgICAgICAgfSxcbiAgICAgICAgXCJzZXRVbmluc3RhbGxVUkxcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICBcInNlc3Npb25zXCI6IHtcbiAgICAgICAgXCJnZXREZXZpY2VzXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICB9LFxuICAgICAgICBcImdldFJlY2VudGx5Q2xvc2VkXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICB9LFxuICAgICAgICBcInJlc3RvcmVcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICBcInN0b3JhZ2VcIjoge1xuICAgICAgICBcImxvY2FsXCI6IHtcbiAgICAgICAgICBcImNsZWFyXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0XCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0Qnl0ZXNJblVzZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInJlbW92ZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInNldFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBcIm1hbmFnZWRcIjoge1xuICAgICAgICAgIFwiZ2V0XCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0Qnl0ZXNJblVzZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBcInN5bmNcIjoge1xuICAgICAgICAgIFwiY2xlYXJcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRCeXRlc0luVXNlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwicmVtb3ZlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwic2V0XCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICBcInRhYnNcIjoge1xuICAgICAgICBcImNhcHR1cmVWaXNpYmxlVGFiXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMlxuICAgICAgICB9LFxuICAgICAgICBcImNyZWF0ZVwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgfSxcbiAgICAgICAgXCJkZXRlY3RMYW5ndWFnZVwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgfSxcbiAgICAgICAgXCJkaXNjYXJkXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICB9LFxuICAgICAgICBcImR1cGxpY2F0ZVwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgfSxcbiAgICAgICAgXCJleGVjdXRlU2NyaXB0XCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMlxuICAgICAgICB9LFxuICAgICAgICBcImdldFwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgfSxcbiAgICAgICAgXCJnZXRDdXJyZW50XCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICB9LFxuICAgICAgICBcImdldFpvb21cIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgIH0sXG4gICAgICAgIFwiZ2V0Wm9vbVNldHRpbmdzXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICB9LFxuICAgICAgICBcImdvQmFja1wiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgfSxcbiAgICAgICAgXCJnb0ZvcndhcmRcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgIH0sXG4gICAgICAgIFwiaGlnaGxpZ2h0XCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICB9LFxuICAgICAgICBcImluc2VydENTU1wiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDJcbiAgICAgICAgfSxcbiAgICAgICAgXCJtb3ZlXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMixcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMlxuICAgICAgICB9LFxuICAgICAgICBcInF1ZXJ5XCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICB9LFxuICAgICAgICBcInJlbG9hZFwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDJcbiAgICAgICAgfSxcbiAgICAgICAgXCJyZW1vdmVcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgIH0sXG4gICAgICAgIFwicmVtb3ZlQ1NTXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMlxuICAgICAgICB9LFxuICAgICAgICBcInNlbmRNZXNzYWdlXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMixcbiAgICAgICAgICBcIm1heEFyZ3NcIjogM1xuICAgICAgICB9LFxuICAgICAgICBcInNldFpvb21cIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAyXG4gICAgICAgIH0sXG4gICAgICAgIFwic2V0Wm9vbVNldHRpbmdzXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMlxuICAgICAgICB9LFxuICAgICAgICBcInVwZGF0ZVwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDJcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIFwidG9wU2l0ZXNcIjoge1xuICAgICAgICBcImdldFwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIFwid2ViTmF2aWdhdGlvblwiOiB7XG4gICAgICAgIFwiZ2V0QWxsRnJhbWVzXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICB9LFxuICAgICAgICBcImdldEZyYW1lXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgXCJ3ZWJSZXF1ZXN0XCI6IHtcbiAgICAgICAgXCJoYW5kbGVyQmVoYXZpb3JDaGFuZ2VkXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgXCJ3aW5kb3dzXCI6IHtcbiAgICAgICAgXCJjcmVhdGVcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgIH0sXG4gICAgICAgIFwiZ2V0XCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMlxuICAgICAgICB9LFxuICAgICAgICBcImdldEFsbFwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgfSxcbiAgICAgICAgXCJnZXRDdXJyZW50XCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICB9LFxuICAgICAgICBcImdldExhc3RGb2N1c2VkXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICB9LFxuICAgICAgICBcInJlbW92ZVwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgfSxcbiAgICAgICAgXCJ1cGRhdGVcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAyLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAyXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9O1xuXG4gICAgaWYgKE9iamVjdC5rZXlzKGFwaU1ldGFkYXRhKS5sZW5ndGggPT09IDApIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcImFwaS1tZXRhZGF0YS5qc29uIGhhcyBub3QgYmVlbiBpbmNsdWRlZCBpbiBicm93c2VyLXBvbHlmaWxsXCIpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEEgV2Vha01hcCBzdWJjbGFzcyB3aGljaCBjcmVhdGVzIGFuZCBzdG9yZXMgYSB2YWx1ZSBmb3IgYW55IGtleSB3aGljaCBkb2VzXG4gICAgICogbm90IGV4aXN0IHdoZW4gYWNjZXNzZWQsIGJ1dCBiZWhhdmVzIGV4YWN0bHkgYXMgYW4gb3JkaW5hcnkgV2Vha01hcFxuICAgICAqIG90aGVyd2lzZS5cbiAgICAgKlxuICAgICAqIEBwYXJhbSB7ZnVuY3Rpb259IGNyZWF0ZUl0ZW1cbiAgICAgKiAgICAgICAgQSBmdW5jdGlvbiB3aGljaCB3aWxsIGJlIGNhbGxlZCBpbiBvcmRlciB0byBjcmVhdGUgdGhlIHZhbHVlIGZvciBhbnlcbiAgICAgKiAgICAgICAga2V5IHdoaWNoIGRvZXMgbm90IGV4aXN0LCB0aGUgZmlyc3QgdGltZSBpdCBpcyBhY2Nlc3NlZC4gVGhlXG4gICAgICogICAgICAgIGZ1bmN0aW9uIHJlY2VpdmVzLCBhcyBpdHMgb25seSBhcmd1bWVudCwgdGhlIGtleSBiZWluZyBjcmVhdGVkLlxuICAgICAqL1xuICAgIGNsYXNzIERlZmF1bHRXZWFrTWFwIGV4dGVuZHMgV2Vha01hcCB7XG4gICAgICBjb25zdHJ1Y3RvcihjcmVhdGVJdGVtLCBpdGVtcyA9IHVuZGVmaW5lZCkge1xuICAgICAgICBzdXBlcihpdGVtcyk7XG4gICAgICAgIHRoaXMuY3JlYXRlSXRlbSA9IGNyZWF0ZUl0ZW07XG4gICAgICB9XG5cbiAgICAgIGdldChrZXkpIHtcbiAgICAgICAgaWYgKCF0aGlzLmhhcyhrZXkpKSB7XG4gICAgICAgICAgdGhpcy5zZXQoa2V5LCB0aGlzLmNyZWF0ZUl0ZW0oa2V5KSk7XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gc3VwZXIuZ2V0KGtleSk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogUmV0dXJucyB0cnVlIGlmIHRoZSBnaXZlbiBvYmplY3QgaXMgYW4gb2JqZWN0IHdpdGggYSBgdGhlbmAgbWV0aG9kLCBhbmQgY2FuXG4gICAgICogdGhlcmVmb3JlIGJlIGFzc3VtZWQgdG8gYmVoYXZlIGFzIGEgUHJvbWlzZS5cbiAgICAgKlxuICAgICAqIEBwYXJhbSB7Kn0gdmFsdWUgVGhlIHZhbHVlIHRvIHRlc3QuXG4gICAgICogQHJldHVybnMge2Jvb2xlYW59IFRydWUgaWYgdGhlIHZhbHVlIGlzIHRoZW5hYmxlLlxuICAgICAqL1xuICAgIGNvbnN0IGlzVGhlbmFibGUgPSB2YWx1ZSA9PiB7XG4gICAgICByZXR1cm4gdmFsdWUgJiYgdHlwZW9mIHZhbHVlID09PSBcIm9iamVjdFwiICYmIHR5cGVvZiB2YWx1ZS50aGVuID09PSBcImZ1bmN0aW9uXCI7XG4gICAgfTtcblxuICAgIC8qKlxuICAgICAqIENyZWF0ZXMgYW5kIHJldHVybnMgYSBmdW5jdGlvbiB3aGljaCwgd2hlbiBjYWxsZWQsIHdpbGwgcmVzb2x2ZSBvciByZWplY3RcbiAgICAgKiB0aGUgZ2l2ZW4gcHJvbWlzZSBiYXNlZCBvbiBob3cgaXQgaXMgY2FsbGVkOlxuICAgICAqXG4gICAgICogLSBJZiwgd2hlbiBjYWxsZWQsIGBjaHJvbWUucnVudGltZS5sYXN0RXJyb3JgIGNvbnRhaW5zIGEgbm9uLW51bGwgb2JqZWN0LFxuICAgICAqICAgdGhlIHByb21pc2UgaXMgcmVqZWN0ZWQgd2l0aCB0aGF0IHZhbHVlLlxuICAgICAqIC0gSWYgdGhlIGZ1bmN0aW9uIGlzIGNhbGxlZCB3aXRoIGV4YWN0bHkgb25lIGFyZ3VtZW50LCB0aGUgcHJvbWlzZSBpc1xuICAgICAqICAgcmVzb2x2ZWQgdG8gdGhhdCB2YWx1ZS5cbiAgICAgKiAtIE90aGVyd2lzZSwgdGhlIHByb21pc2UgaXMgcmVzb2x2ZWQgdG8gYW4gYXJyYXkgY29udGFpbmluZyBhbGwgb2YgdGhlXG4gICAgICogICBmdW5jdGlvbidzIGFyZ3VtZW50cy5cbiAgICAgKlxuICAgICAqIEBwYXJhbSB7b2JqZWN0fSBwcm9taXNlXG4gICAgICogICAgICAgIEFuIG9iamVjdCBjb250YWluaW5nIHRoZSByZXNvbHV0aW9uIGFuZCByZWplY3Rpb24gZnVuY3Rpb25zIG9mIGFcbiAgICAgKiAgICAgICAgcHJvbWlzZS5cbiAgICAgKiBAcGFyYW0ge2Z1bmN0aW9ufSBwcm9taXNlLnJlc29sdmVcbiAgICAgKiAgICAgICAgVGhlIHByb21pc2UncyByZXNvbHV0aW9uIGZ1bmN0aW9uLlxuICAgICAqIEBwYXJhbSB7ZnVuY3Rpb259IHByb21pc2UucmVqZWN0XG4gICAgICogICAgICAgIFRoZSBwcm9taXNlJ3MgcmVqZWN0aW9uIGZ1bmN0aW9uLlxuICAgICAqIEBwYXJhbSB7b2JqZWN0fSBtZXRhZGF0YVxuICAgICAqICAgICAgICBNZXRhZGF0YSBhYm91dCB0aGUgd3JhcHBlZCBtZXRob2Qgd2hpY2ggaGFzIGNyZWF0ZWQgdGhlIGNhbGxiYWNrLlxuICAgICAqIEBwYXJhbSB7Ym9vbGVhbn0gbWV0YWRhdGEuc2luZ2xlQ2FsbGJhY2tBcmdcbiAgICAgKiAgICAgICAgV2hldGhlciBvciBub3QgdGhlIHByb21pc2UgaXMgcmVzb2x2ZWQgd2l0aCBvbmx5IHRoZSBmaXJzdFxuICAgICAqICAgICAgICBhcmd1bWVudCBvZiB0aGUgY2FsbGJhY2ssIGFsdGVybmF0aXZlbHkgYW4gYXJyYXkgb2YgYWxsIHRoZVxuICAgICAqICAgICAgICBjYWxsYmFjayBhcmd1bWVudHMgaXMgcmVzb2x2ZWQuIEJ5IGRlZmF1bHQsIGlmIHRoZSBjYWxsYmFja1xuICAgICAqICAgICAgICBmdW5jdGlvbiBpcyBpbnZva2VkIHdpdGggb25seSBhIHNpbmdsZSBhcmd1bWVudCwgdGhhdCB3aWxsIGJlXG4gICAgICogICAgICAgIHJlc29sdmVkIHRvIHRoZSBwcm9taXNlLCB3aGlsZSBhbGwgYXJndW1lbnRzIHdpbGwgYmUgcmVzb2x2ZWQgYXNcbiAgICAgKiAgICAgICAgYW4gYXJyYXkgaWYgbXVsdGlwbGUgYXJlIGdpdmVuLlxuICAgICAqXG4gICAgICogQHJldHVybnMge2Z1bmN0aW9ufVxuICAgICAqICAgICAgICBUaGUgZ2VuZXJhdGVkIGNhbGxiYWNrIGZ1bmN0aW9uLlxuICAgICAqL1xuICAgIGNvbnN0IG1ha2VDYWxsYmFjayA9IChwcm9taXNlLCBtZXRhZGF0YSkgPT4ge1xuICAgICAgcmV0dXJuICguLi5jYWxsYmFja0FyZ3MpID0+IHtcbiAgICAgICAgaWYgKGV4dGVuc2lvbkFQSXMucnVudGltZS5sYXN0RXJyb3IpIHtcbiAgICAgICAgICBwcm9taXNlLnJlamVjdChuZXcgRXJyb3IoZXh0ZW5zaW9uQVBJcy5ydW50aW1lLmxhc3RFcnJvci5tZXNzYWdlKSk7XG4gICAgICAgIH0gZWxzZSBpZiAobWV0YWRhdGEuc2luZ2xlQ2FsbGJhY2tBcmcgfHxcbiAgICAgICAgICAgICAgICAgICAoY2FsbGJhY2tBcmdzLmxlbmd0aCA8PSAxICYmIG1ldGFkYXRhLnNpbmdsZUNhbGxiYWNrQXJnICE9PSBmYWxzZSkpIHtcbiAgICAgICAgICBwcm9taXNlLnJlc29sdmUoY2FsbGJhY2tBcmdzWzBdKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBwcm9taXNlLnJlc29sdmUoY2FsbGJhY2tBcmdzKTtcbiAgICAgICAgfVxuICAgICAgfTtcbiAgICB9O1xuXG4gICAgY29uc3QgcGx1cmFsaXplQXJndW1lbnRzID0gKG51bUFyZ3MpID0+IG51bUFyZ3MgPT0gMSA/IFwiYXJndW1lbnRcIiA6IFwiYXJndW1lbnRzXCI7XG5cbiAgICAvKipcbiAgICAgKiBDcmVhdGVzIGEgd3JhcHBlciBmdW5jdGlvbiBmb3IgYSBtZXRob2Qgd2l0aCB0aGUgZ2l2ZW4gbmFtZSBhbmQgbWV0YWRhdGEuXG4gICAgICpcbiAgICAgKiBAcGFyYW0ge3N0cmluZ30gbmFtZVxuICAgICAqICAgICAgICBUaGUgbmFtZSBvZiB0aGUgbWV0aG9kIHdoaWNoIGlzIGJlaW5nIHdyYXBwZWQuXG4gICAgICogQHBhcmFtIHtvYmplY3R9IG1ldGFkYXRhXG4gICAgICogICAgICAgIE1ldGFkYXRhIGFib3V0IHRoZSBtZXRob2QgYmVpbmcgd3JhcHBlZC5cbiAgICAgKiBAcGFyYW0ge2ludGVnZXJ9IG1ldGFkYXRhLm1pbkFyZ3NcbiAgICAgKiAgICAgICAgVGhlIG1pbmltdW0gbnVtYmVyIG9mIGFyZ3VtZW50cyB3aGljaCBtdXN0IGJlIHBhc3NlZCB0byB0aGVcbiAgICAgKiAgICAgICAgZnVuY3Rpb24uIElmIGNhbGxlZCB3aXRoIGZld2VyIHRoYW4gdGhpcyBudW1iZXIgb2YgYXJndW1lbnRzLCB0aGVcbiAgICAgKiAgICAgICAgd3JhcHBlciB3aWxsIHJhaXNlIGFuIGV4Y2VwdGlvbi5cbiAgICAgKiBAcGFyYW0ge2ludGVnZXJ9IG1ldGFkYXRhLm1heEFyZ3NcbiAgICAgKiAgICAgICAgVGhlIG1heGltdW0gbnVtYmVyIG9mIGFyZ3VtZW50cyB3aGljaCBtYXkgYmUgcGFzc2VkIHRvIHRoZVxuICAgICAqICAgICAgICBmdW5jdGlvbi4gSWYgY2FsbGVkIHdpdGggbW9yZSB0aGFuIHRoaXMgbnVtYmVyIG9mIGFyZ3VtZW50cywgdGhlXG4gICAgICogICAgICAgIHdyYXBwZXIgd2lsbCByYWlzZSBhbiBleGNlcHRpb24uXG4gICAgICogQHBhcmFtIHtib29sZWFufSBtZXRhZGF0YS5zaW5nbGVDYWxsYmFja0FyZ1xuICAgICAqICAgICAgICBXaGV0aGVyIG9yIG5vdCB0aGUgcHJvbWlzZSBpcyByZXNvbHZlZCB3aXRoIG9ubHkgdGhlIGZpcnN0XG4gICAgICogICAgICAgIGFyZ3VtZW50IG9mIHRoZSBjYWxsYmFjaywgYWx0ZXJuYXRpdmVseSBhbiBhcnJheSBvZiBhbGwgdGhlXG4gICAgICogICAgICAgIGNhbGxiYWNrIGFyZ3VtZW50cyBpcyByZXNvbHZlZC4gQnkgZGVmYXVsdCwgaWYgdGhlIGNhbGxiYWNrXG4gICAgICogICAgICAgIGZ1bmN0aW9uIGlzIGludm9rZWQgd2l0aCBvbmx5IGEgc2luZ2xlIGFyZ3VtZW50LCB0aGF0IHdpbGwgYmVcbiAgICAgKiAgICAgICAgcmVzb2x2ZWQgdG8gdGhlIHByb21pc2UsIHdoaWxlIGFsbCBhcmd1bWVudHMgd2lsbCBiZSByZXNvbHZlZCBhc1xuICAgICAqICAgICAgICBhbiBhcnJheSBpZiBtdWx0aXBsZSBhcmUgZ2l2ZW4uXG4gICAgICpcbiAgICAgKiBAcmV0dXJucyB7ZnVuY3Rpb24ob2JqZWN0LCAuLi4qKX1cbiAgICAgKiAgICAgICBUaGUgZ2VuZXJhdGVkIHdyYXBwZXIgZnVuY3Rpb24uXG4gICAgICovXG4gICAgY29uc3Qgd3JhcEFzeW5jRnVuY3Rpb24gPSAobmFtZSwgbWV0YWRhdGEpID0+IHtcbiAgICAgIHJldHVybiBmdW5jdGlvbiBhc3luY0Z1bmN0aW9uV3JhcHBlcih0YXJnZXQsIC4uLmFyZ3MpIHtcbiAgICAgICAgaWYgKGFyZ3MubGVuZ3RoIDwgbWV0YWRhdGEubWluQXJncykge1xuICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgRXhwZWN0ZWQgYXQgbGVhc3QgJHttZXRhZGF0YS5taW5BcmdzfSAke3BsdXJhbGl6ZUFyZ3VtZW50cyhtZXRhZGF0YS5taW5BcmdzKX0gZm9yICR7bmFtZX0oKSwgZ290ICR7YXJncy5sZW5ndGh9YCk7XG4gICAgICAgIH1cblxuICAgICAgICBpZiAoYXJncy5sZW5ndGggPiBtZXRhZGF0YS5tYXhBcmdzKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBFeHBlY3RlZCBhdCBtb3N0ICR7bWV0YWRhdGEubWF4QXJnc30gJHtwbHVyYWxpemVBcmd1bWVudHMobWV0YWRhdGEubWF4QXJncyl9IGZvciAke25hbWV9KCksIGdvdCAke2FyZ3MubGVuZ3RofWApO1xuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgICAgICBpZiAobWV0YWRhdGEuZmFsbGJhY2tUb05vQ2FsbGJhY2spIHtcbiAgICAgICAgICAgIC8vIFRoaXMgQVBJIG1ldGhvZCBoYXMgY3VycmVudGx5IG5vIGNhbGxiYWNrIG9uIENocm9tZSwgYnV0IGl0IHJldHVybiBhIHByb21pc2Ugb24gRmlyZWZveCxcbiAgICAgICAgICAgIC8vIGFuZCBzbyB0aGUgcG9seWZpbGwgd2lsbCB0cnkgdG8gY2FsbCBpdCB3aXRoIGEgY2FsbGJhY2sgZmlyc3QsIGFuZCBpdCB3aWxsIGZhbGxiYWNrXG4gICAgICAgICAgICAvLyB0byBub3QgcGFzc2luZyB0aGUgY2FsbGJhY2sgaWYgdGhlIGZpcnN0IGNhbGwgZmFpbHMuXG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICB0YXJnZXRbbmFtZV0oLi4uYXJncywgbWFrZUNhbGxiYWNrKHtyZXNvbHZlLCByZWplY3R9LCBtZXRhZGF0YSkpO1xuICAgICAgICAgICAgfSBjYXRjaCAoY2JFcnJvcikge1xuICAgICAgICAgICAgICBjb25zb2xlLndhcm4oYCR7bmFtZX0gQVBJIG1ldGhvZCBkb2Vzbid0IHNlZW0gdG8gc3VwcG9ydCB0aGUgY2FsbGJhY2sgcGFyYW1ldGVyLCBgICtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiZmFsbGluZyBiYWNrIHRvIGNhbGwgaXQgd2l0aG91dCBhIGNhbGxiYWNrOiBcIiwgY2JFcnJvcik7XG5cbiAgICAgICAgICAgICAgdGFyZ2V0W25hbWVdKC4uLmFyZ3MpO1xuXG4gICAgICAgICAgICAgIC8vIFVwZGF0ZSB0aGUgQVBJIG1ldGhvZCBtZXRhZGF0YSwgc28gdGhhdCB0aGUgbmV4dCBBUEkgY2FsbHMgd2lsbCBub3QgdHJ5IHRvXG4gICAgICAgICAgICAgIC8vIHVzZSB0aGUgdW5zdXBwb3J0ZWQgY2FsbGJhY2sgYW55bW9yZS5cbiAgICAgICAgICAgICAgbWV0YWRhdGEuZmFsbGJhY2tUb05vQ2FsbGJhY2sgPSBmYWxzZTtcbiAgICAgICAgICAgICAgbWV0YWRhdGEubm9DYWxsYmFjayA9IHRydWU7XG5cbiAgICAgICAgICAgICAgcmVzb2x2ZSgpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH0gZWxzZSBpZiAobWV0YWRhdGEubm9DYWxsYmFjaykge1xuICAgICAgICAgICAgdGFyZ2V0W25hbWVdKC4uLmFyZ3MpO1xuICAgICAgICAgICAgcmVzb2x2ZSgpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0YXJnZXRbbmFtZV0oLi4uYXJncywgbWFrZUNhbGxiYWNrKHtyZXNvbHZlLCByZWplY3R9LCBtZXRhZGF0YSkpO1xuICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICB9O1xuICAgIH07XG5cbiAgICAvKipcbiAgICAgKiBXcmFwcyBhbiBleGlzdGluZyBtZXRob2Qgb2YgdGhlIHRhcmdldCBvYmplY3QsIHNvIHRoYXQgY2FsbHMgdG8gaXQgYXJlXG4gICAgICogaW50ZXJjZXB0ZWQgYnkgdGhlIGdpdmVuIHdyYXBwZXIgZnVuY3Rpb24uIFRoZSB3cmFwcGVyIGZ1bmN0aW9uIHJlY2VpdmVzLFxuICAgICAqIGFzIGl0cyBmaXJzdCBhcmd1bWVudCwgdGhlIG9yaWdpbmFsIGB0YXJnZXRgIG9iamVjdCwgZm9sbG93ZWQgYnkgZWFjaCBvZlxuICAgICAqIHRoZSBhcmd1bWVudHMgcGFzc2VkIHRvIHRoZSBvcmlnaW5hbCBtZXRob2QuXG4gICAgICpcbiAgICAgKiBAcGFyYW0ge29iamVjdH0gdGFyZ2V0XG4gICAgICogICAgICAgIFRoZSBvcmlnaW5hbCB0YXJnZXQgb2JqZWN0IHRoYXQgdGhlIHdyYXBwZWQgbWV0aG9kIGJlbG9uZ3MgdG8uXG4gICAgICogQHBhcmFtIHtmdW5jdGlvbn0gbWV0aG9kXG4gICAgICogICAgICAgIFRoZSBtZXRob2QgYmVpbmcgd3JhcHBlZC4gVGhpcyBpcyB1c2VkIGFzIHRoZSB0YXJnZXQgb2YgdGhlIFByb3h5XG4gICAgICogICAgICAgIG9iamVjdCB3aGljaCBpcyBjcmVhdGVkIHRvIHdyYXAgdGhlIG1ldGhvZC5cbiAgICAgKiBAcGFyYW0ge2Z1bmN0aW9ufSB3cmFwcGVyXG4gICAgICogICAgICAgIFRoZSB3cmFwcGVyIGZ1bmN0aW9uIHdoaWNoIGlzIGNhbGxlZCBpbiBwbGFjZSBvZiBhIGRpcmVjdCBpbnZvY2F0aW9uXG4gICAgICogICAgICAgIG9mIHRoZSB3cmFwcGVkIG1ldGhvZC5cbiAgICAgKlxuICAgICAqIEByZXR1cm5zIHtQcm94eTxmdW5jdGlvbj59XG4gICAgICogICAgICAgIEEgUHJveHkgb2JqZWN0IGZvciB0aGUgZ2l2ZW4gbWV0aG9kLCB3aGljaCBpbnZva2VzIHRoZSBnaXZlbiB3cmFwcGVyXG4gICAgICogICAgICAgIG1ldGhvZCBpbiBpdHMgcGxhY2UuXG4gICAgICovXG4gICAgY29uc3Qgd3JhcE1ldGhvZCA9ICh0YXJnZXQsIG1ldGhvZCwgd3JhcHBlcikgPT4ge1xuICAgICAgcmV0dXJuIG5ldyBQcm94eShtZXRob2QsIHtcbiAgICAgICAgYXBwbHkodGFyZ2V0TWV0aG9kLCB0aGlzT2JqLCBhcmdzKSB7XG4gICAgICAgICAgcmV0dXJuIHdyYXBwZXIuY2FsbCh0aGlzT2JqLCB0YXJnZXQsIC4uLmFyZ3MpO1xuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfTtcblxuICAgIGxldCBoYXNPd25Qcm9wZXJ0eSA9IEZ1bmN0aW9uLmNhbGwuYmluZChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5KTtcblxuICAgIC8qKlxuICAgICAqIFdyYXBzIGFuIG9iamVjdCBpbiBhIFByb3h5IHdoaWNoIGludGVyY2VwdHMgYW5kIHdyYXBzIGNlcnRhaW4gbWV0aG9kc1xuICAgICAqIGJhc2VkIG9uIHRoZSBnaXZlbiBgd3JhcHBlcnNgIGFuZCBgbWV0YWRhdGFgIG9iamVjdHMuXG4gICAgICpcbiAgICAgKiBAcGFyYW0ge29iamVjdH0gdGFyZ2V0XG4gICAgICogICAgICAgIFRoZSB0YXJnZXQgb2JqZWN0IHRvIHdyYXAuXG4gICAgICpcbiAgICAgKiBAcGFyYW0ge29iamVjdH0gW3dyYXBwZXJzID0ge31dXG4gICAgICogICAgICAgIEFuIG9iamVjdCB0cmVlIGNvbnRhaW5pbmcgd3JhcHBlciBmdW5jdGlvbnMgZm9yIHNwZWNpYWwgY2FzZXMuIEFueVxuICAgICAqICAgICAgICBmdW5jdGlvbiBwcmVzZW50IGluIHRoaXMgb2JqZWN0IHRyZWUgaXMgY2FsbGVkIGluIHBsYWNlIG9mIHRoZVxuICAgICAqICAgICAgICBtZXRob2QgaW4gdGhlIHNhbWUgbG9jYXRpb24gaW4gdGhlIGB0YXJnZXRgIG9iamVjdCB0cmVlLiBUaGVzZVxuICAgICAqICAgICAgICB3cmFwcGVyIG1ldGhvZHMgYXJlIGludm9rZWQgYXMgZGVzY3JpYmVkIGluIHtAc2VlIHdyYXBNZXRob2R9LlxuICAgICAqXG4gICAgICogQHBhcmFtIHtvYmplY3R9IFttZXRhZGF0YSA9IHt9XVxuICAgICAqICAgICAgICBBbiBvYmplY3QgdHJlZSBjb250YWluaW5nIG1ldGFkYXRhIHVzZWQgdG8gYXV0b21hdGljYWxseSBnZW5lcmF0ZVxuICAgICAqICAgICAgICBQcm9taXNlLWJhc2VkIHdyYXBwZXIgZnVuY3Rpb25zIGZvciBhc3luY2hyb25vdXMuIEFueSBmdW5jdGlvbiBpblxuICAgICAqICAgICAgICB0aGUgYHRhcmdldGAgb2JqZWN0IHRyZWUgd2hpY2ggaGFzIGEgY29ycmVzcG9uZGluZyBtZXRhZGF0YSBvYmplY3RcbiAgICAgKiAgICAgICAgaW4gdGhlIHNhbWUgbG9jYXRpb24gaW4gdGhlIGBtZXRhZGF0YWAgdHJlZSBpcyByZXBsYWNlZCB3aXRoIGFuXG4gICAgICogICAgICAgIGF1dG9tYXRpY2FsbHktZ2VuZXJhdGVkIHdyYXBwZXIgZnVuY3Rpb24sIGFzIGRlc2NyaWJlZCBpblxuICAgICAqICAgICAgICB7QHNlZSB3cmFwQXN5bmNGdW5jdGlvbn1cbiAgICAgKlxuICAgICAqIEByZXR1cm5zIHtQcm94eTxvYmplY3Q+fVxuICAgICAqL1xuICAgIGNvbnN0IHdyYXBPYmplY3QgPSAodGFyZ2V0LCB3cmFwcGVycyA9IHt9LCBtZXRhZGF0YSA9IHt9KSA9PiB7XG4gICAgICBsZXQgY2FjaGUgPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuICAgICAgbGV0IGhhbmRsZXJzID0ge1xuICAgICAgICBoYXMocHJveHlUYXJnZXQsIHByb3ApIHtcbiAgICAgICAgICByZXR1cm4gcHJvcCBpbiB0YXJnZXQgfHwgcHJvcCBpbiBjYWNoZTtcbiAgICAgICAgfSxcblxuICAgICAgICBnZXQocHJveHlUYXJnZXQsIHByb3AsIHJlY2VpdmVyKSB7XG4gICAgICAgICAgaWYgKHByb3AgaW4gY2FjaGUpIHtcbiAgICAgICAgICAgIHJldHVybiBjYWNoZVtwcm9wXTtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICBpZiAoIShwcm9wIGluIHRhcmdldCkpIHtcbiAgICAgICAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgbGV0IHZhbHVlID0gdGFyZ2V0W3Byb3BdO1xuXG4gICAgICAgICAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gXCJmdW5jdGlvblwiKSB7XG4gICAgICAgICAgICAvLyBUaGlzIGlzIGEgbWV0aG9kIG9uIHRoZSB1bmRlcmx5aW5nIG9iamVjdC4gQ2hlY2sgaWYgd2UgbmVlZCB0byBkb1xuICAgICAgICAgICAgLy8gYW55IHdyYXBwaW5nLlxuXG4gICAgICAgICAgICBpZiAodHlwZW9mIHdyYXBwZXJzW3Byb3BdID09PSBcImZ1bmN0aW9uXCIpIHtcbiAgICAgICAgICAgICAgLy8gV2UgaGF2ZSBhIHNwZWNpYWwtY2FzZSB3cmFwcGVyIGZvciB0aGlzIG1ldGhvZC5cbiAgICAgICAgICAgICAgdmFsdWUgPSB3cmFwTWV0aG9kKHRhcmdldCwgdGFyZ2V0W3Byb3BdLCB3cmFwcGVyc1twcm9wXSk7XG4gICAgICAgICAgICB9IGVsc2UgaWYgKGhhc093blByb3BlcnR5KG1ldGFkYXRhLCBwcm9wKSkge1xuICAgICAgICAgICAgICAvLyBUaGlzIGlzIGFuIGFzeW5jIG1ldGhvZCB0aGF0IHdlIGhhdmUgbWV0YWRhdGEgZm9yLiBDcmVhdGUgYVxuICAgICAgICAgICAgICAvLyBQcm9taXNlIHdyYXBwZXIgZm9yIGl0LlxuICAgICAgICAgICAgICBsZXQgd3JhcHBlciA9IHdyYXBBc3luY0Z1bmN0aW9uKHByb3AsIG1ldGFkYXRhW3Byb3BdKTtcbiAgICAgICAgICAgICAgdmFsdWUgPSB3cmFwTWV0aG9kKHRhcmdldCwgdGFyZ2V0W3Byb3BdLCB3cmFwcGVyKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgIC8vIFRoaXMgaXMgYSBtZXRob2QgdGhhdCB3ZSBkb24ndCBrbm93IG9yIGNhcmUgYWJvdXQuIFJldHVybiB0aGVcbiAgICAgICAgICAgICAgLy8gb3JpZ2luYWwgbWV0aG9kLCBib3VuZCB0byB0aGUgdW5kZXJseWluZyBvYmplY3QuXG4gICAgICAgICAgICAgIHZhbHVlID0gdmFsdWUuYmluZCh0YXJnZXQpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH0gZWxzZSBpZiAodHlwZW9mIHZhbHVlID09PSBcIm9iamVjdFwiICYmIHZhbHVlICE9PSBudWxsICYmXG4gICAgICAgICAgICAgICAgICAgICAoaGFzT3duUHJvcGVydHkod3JhcHBlcnMsIHByb3ApIHx8XG4gICAgICAgICAgICAgICAgICAgICAgaGFzT3duUHJvcGVydHkobWV0YWRhdGEsIHByb3ApKSkge1xuICAgICAgICAgICAgLy8gVGhpcyBpcyBhbiBvYmplY3QgdGhhdCB3ZSBuZWVkIHRvIGRvIHNvbWUgd3JhcHBpbmcgZm9yIHRoZSBjaGlsZHJlblxuICAgICAgICAgICAgLy8gb2YuIENyZWF0ZSBhIHN1Yi1vYmplY3Qgd3JhcHBlciBmb3IgaXQgd2l0aCB0aGUgYXBwcm9wcmlhdGUgY2hpbGRcbiAgICAgICAgICAgIC8vIG1ldGFkYXRhLlxuICAgICAgICAgICAgdmFsdWUgPSB3cmFwT2JqZWN0KHZhbHVlLCB3cmFwcGVyc1twcm9wXSwgbWV0YWRhdGFbcHJvcF0pO1xuICAgICAgICAgIH0gZWxzZSBpZiAoaGFzT3duUHJvcGVydHkobWV0YWRhdGEsIFwiKlwiKSkge1xuICAgICAgICAgICAgLy8gV3JhcCBhbGwgcHJvcGVydGllcyBpbiAqIG5hbWVzcGFjZS5cbiAgICAgICAgICAgIHZhbHVlID0gd3JhcE9iamVjdCh2YWx1ZSwgd3JhcHBlcnNbcHJvcF0sIG1ldGFkYXRhW1wiKlwiXSk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIC8vIFdlIGRvbid0IG5lZWQgdG8gZG8gYW55IHdyYXBwaW5nIGZvciB0aGlzIHByb3BlcnR5LFxuICAgICAgICAgICAgLy8gc28ganVzdCBmb3J3YXJkIGFsbCBhY2Nlc3MgdG8gdGhlIHVuZGVybHlpbmcgb2JqZWN0LlxuICAgICAgICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KGNhY2hlLCBwcm9wLCB7XG4gICAgICAgICAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZSxcbiAgICAgICAgICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgICAgICAgICAgZ2V0KCkge1xuICAgICAgICAgICAgICAgIHJldHVybiB0YXJnZXRbcHJvcF07XG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIHNldCh2YWx1ZSkge1xuICAgICAgICAgICAgICAgIHRhcmdldFtwcm9wXSA9IHZhbHVlO1xuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgIHJldHVybiB2YWx1ZTtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICBjYWNoZVtwcm9wXSA9IHZhbHVlO1xuICAgICAgICAgIHJldHVybiB2YWx1ZTtcbiAgICAgICAgfSxcblxuICAgICAgICBzZXQocHJveHlUYXJnZXQsIHByb3AsIHZhbHVlLCByZWNlaXZlcikge1xuICAgICAgICAgIGlmIChwcm9wIGluIGNhY2hlKSB7XG4gICAgICAgICAgICBjYWNoZVtwcm9wXSA9IHZhbHVlO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0YXJnZXRbcHJvcF0gPSB2YWx1ZTtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIH0sXG5cbiAgICAgICAgZGVmaW5lUHJvcGVydHkocHJveHlUYXJnZXQsIHByb3AsIGRlc2MpIHtcbiAgICAgICAgICByZXR1cm4gUmVmbGVjdC5kZWZpbmVQcm9wZXJ0eShjYWNoZSwgcHJvcCwgZGVzYyk7XG4gICAgICAgIH0sXG5cbiAgICAgICAgZGVsZXRlUHJvcGVydHkocHJveHlUYXJnZXQsIHByb3ApIHtcbiAgICAgICAgICByZXR1cm4gUmVmbGVjdC5kZWxldGVQcm9wZXJ0eShjYWNoZSwgcHJvcCk7XG4gICAgICAgIH0sXG4gICAgICB9O1xuXG4gICAgICAvLyBQZXIgY29udHJhY3Qgb2YgdGhlIFByb3h5IEFQSSwgdGhlIFwiZ2V0XCIgcHJveHkgaGFuZGxlciBtdXN0IHJldHVybiB0aGVcbiAgICAgIC8vIG9yaWdpbmFsIHZhbHVlIG9mIHRoZSB0YXJnZXQgaWYgdGhhdCB2YWx1ZSBpcyBkZWNsYXJlZCByZWFkLW9ubHkgYW5kXG4gICAgICAvLyBub24tY29uZmlndXJhYmxlLiBGb3IgdGhpcyByZWFzb24sIHdlIGNyZWF0ZSBhbiBvYmplY3Qgd2l0aCB0aGVcbiAgICAgIC8vIHByb3RvdHlwZSBzZXQgdG8gYHRhcmdldGAgaW5zdGVhZCBvZiB1c2luZyBgdGFyZ2V0YCBkaXJlY3RseS5cbiAgICAgIC8vIE90aGVyd2lzZSB3ZSBjYW5ub3QgcmV0dXJuIGEgY3VzdG9tIG9iamVjdCBmb3IgQVBJcyB0aGF0XG4gICAgICAvLyBhcmUgZGVjbGFyZWQgcmVhZC1vbmx5IGFuZCBub24tY29uZmlndXJhYmxlLCBzdWNoIGFzIGBjaHJvbWUuZGV2dG9vbHNgLlxuICAgICAgLy9cbiAgICAgIC8vIFRoZSBwcm94eSBoYW5kbGVycyB0aGVtc2VsdmVzIHdpbGwgc3RpbGwgdXNlIHRoZSBvcmlnaW5hbCBgdGFyZ2V0YFxuICAgICAgLy8gaW5zdGVhZCBvZiB0aGUgYHByb3h5VGFyZ2V0YCwgc28gdGhhdCB0aGUgbWV0aG9kcyBhbmQgcHJvcGVydGllcyBhcmVcbiAgICAgIC8vIGRlcmVmZXJlbmNlZCB2aWEgdGhlIG9yaWdpbmFsIHRhcmdldHMuXG4gICAgICBsZXQgcHJveHlUYXJnZXQgPSBPYmplY3QuY3JlYXRlKHRhcmdldCk7XG4gICAgICByZXR1cm4gbmV3IFByb3h5KHByb3h5VGFyZ2V0LCBoYW5kbGVycyk7XG4gICAgfTtcblxuICAgIC8qKlxuICAgICAqIENyZWF0ZXMgYSBzZXQgb2Ygd3JhcHBlciBmdW5jdGlvbnMgZm9yIGFuIGV2ZW50IG9iamVjdCwgd2hpY2ggaGFuZGxlc1xuICAgICAqIHdyYXBwaW5nIG9mIGxpc3RlbmVyIGZ1bmN0aW9ucyB0aGF0IHRob3NlIG1lc3NhZ2VzIGFyZSBwYXNzZWQuXG4gICAgICpcbiAgICAgKiBBIHNpbmdsZSB3cmFwcGVyIGlzIGNyZWF0ZWQgZm9yIGVhY2ggbGlzdGVuZXIgZnVuY3Rpb24sIGFuZCBzdG9yZWQgaW4gYVxuICAgICAqIG1hcC4gU3Vic2VxdWVudCBjYWxscyB0byBgYWRkTGlzdGVuZXJgLCBgaGFzTGlzdGVuZXJgLCBvciBgcmVtb3ZlTGlzdGVuZXJgXG4gICAgICogcmV0cmlldmUgdGhlIG9yaWdpbmFsIHdyYXBwZXIsIHNvIHRoYXQgIGF0dGVtcHRzIHRvIHJlbW92ZSBhXG4gICAgICogcHJldmlvdXNseS1hZGRlZCBsaXN0ZW5lciB3b3JrIGFzIGV4cGVjdGVkLlxuICAgICAqXG4gICAgICogQHBhcmFtIHtEZWZhdWx0V2Vha01hcDxmdW5jdGlvbiwgZnVuY3Rpb24+fSB3cmFwcGVyTWFwXG4gICAgICogICAgICAgIEEgRGVmYXVsdFdlYWtNYXAgb2JqZWN0IHdoaWNoIHdpbGwgY3JlYXRlIHRoZSBhcHByb3ByaWF0ZSB3cmFwcGVyXG4gICAgICogICAgICAgIGZvciBhIGdpdmVuIGxpc3RlbmVyIGZ1bmN0aW9uIHdoZW4gb25lIGRvZXMgbm90IGV4aXN0LCBhbmQgcmV0cmlldmVcbiAgICAgKiAgICAgICAgYW4gZXhpc3Rpbmcgb25lIHdoZW4gaXQgZG9lcy5cbiAgICAgKlxuICAgICAqIEByZXR1cm5zIHtvYmplY3R9XG4gICAgICovXG4gICAgY29uc3Qgd3JhcEV2ZW50ID0gd3JhcHBlck1hcCA9PiAoe1xuICAgICAgYWRkTGlzdGVuZXIodGFyZ2V0LCBsaXN0ZW5lciwgLi4uYXJncykge1xuICAgICAgICB0YXJnZXQuYWRkTGlzdGVuZXIod3JhcHBlck1hcC5nZXQobGlzdGVuZXIpLCAuLi5hcmdzKTtcbiAgICAgIH0sXG5cbiAgICAgIGhhc0xpc3RlbmVyKHRhcmdldCwgbGlzdGVuZXIpIHtcbiAgICAgICAgcmV0dXJuIHRhcmdldC5oYXNMaXN0ZW5lcih3cmFwcGVyTWFwLmdldChsaXN0ZW5lcikpO1xuICAgICAgfSxcblxuICAgICAgcmVtb3ZlTGlzdGVuZXIodGFyZ2V0LCBsaXN0ZW5lcikge1xuICAgICAgICB0YXJnZXQucmVtb3ZlTGlzdGVuZXIod3JhcHBlck1hcC5nZXQobGlzdGVuZXIpKTtcbiAgICAgIH0sXG4gICAgfSk7XG5cbiAgICBjb25zdCBvblJlcXVlc3RGaW5pc2hlZFdyYXBwZXJzID0gbmV3IERlZmF1bHRXZWFrTWFwKGxpc3RlbmVyID0+IHtcbiAgICAgIGlmICh0eXBlb2YgbGlzdGVuZXIgIT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgICByZXR1cm4gbGlzdGVuZXI7XG4gICAgICB9XG5cbiAgICAgIC8qKlxuICAgICAgICogV3JhcHMgYW4gb25SZXF1ZXN0RmluaXNoZWQgbGlzdGVuZXIgZnVuY3Rpb24gc28gdGhhdCBpdCB3aWxsIHJldHVybiBhXG4gICAgICAgKiBgZ2V0Q29udGVudCgpYCBwcm9wZXJ0eSB3aGljaCByZXR1cm5zIGEgYFByb21pc2VgIHJhdGhlciB0aGFuIHVzaW5nIGFcbiAgICAgICAqIGNhbGxiYWNrIEFQSS5cbiAgICAgICAqXG4gICAgICAgKiBAcGFyYW0ge29iamVjdH0gcmVxXG4gICAgICAgKiAgICAgICAgVGhlIEhBUiBlbnRyeSBvYmplY3QgcmVwcmVzZW50aW5nIHRoZSBuZXR3b3JrIHJlcXVlc3QuXG4gICAgICAgKi9cbiAgICAgIHJldHVybiBmdW5jdGlvbiBvblJlcXVlc3RGaW5pc2hlZChyZXEpIHtcbiAgICAgICAgY29uc3Qgd3JhcHBlZFJlcSA9IHdyYXBPYmplY3QocmVxLCB7fSAvKiB3cmFwcGVycyAqLywge1xuICAgICAgICAgIGdldENvbnRlbnQ6IHtcbiAgICAgICAgICAgIG1pbkFyZ3M6IDAsXG4gICAgICAgICAgICBtYXhBcmdzOiAwLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgICBsaXN0ZW5lcih3cmFwcGVkUmVxKTtcbiAgICAgIH07XG4gICAgfSk7XG5cbiAgICBjb25zdCBvbk1lc3NhZ2VXcmFwcGVycyA9IG5ldyBEZWZhdWx0V2Vha01hcChsaXN0ZW5lciA9PiB7XG4gICAgICBpZiAodHlwZW9mIGxpc3RlbmVyICE9PSBcImZ1bmN0aW9uXCIpIHtcbiAgICAgICAgcmV0dXJuIGxpc3RlbmVyO1xuICAgICAgfVxuXG4gICAgICAvKipcbiAgICAgICAqIFdyYXBzIGEgbWVzc2FnZSBsaXN0ZW5lciBmdW5jdGlvbiBzbyB0aGF0IGl0IG1heSBzZW5kIHJlc3BvbnNlcyBiYXNlZCBvblxuICAgICAgICogaXRzIHJldHVybiB2YWx1ZSwgcmF0aGVyIHRoYW4gYnkgcmV0dXJuaW5nIGEgc2VudGluZWwgdmFsdWUgYW5kIGNhbGxpbmcgYVxuICAgICAgICogY2FsbGJhY2suIElmIHRoZSBsaXN0ZW5lciBmdW5jdGlvbiByZXR1cm5zIGEgUHJvbWlzZSwgdGhlIHJlc3BvbnNlIGlzXG4gICAgICAgKiBzZW50IHdoZW4gdGhlIHByb21pc2UgZWl0aGVyIHJlc29sdmVzIG9yIHJlamVjdHMuXG4gICAgICAgKlxuICAgICAgICogQHBhcmFtIHsqfSBtZXNzYWdlXG4gICAgICAgKiAgICAgICAgVGhlIG1lc3NhZ2Ugc2VudCBieSB0aGUgb3RoZXIgZW5kIG9mIHRoZSBjaGFubmVsLlxuICAgICAgICogQHBhcmFtIHtvYmplY3R9IHNlbmRlclxuICAgICAgICogICAgICAgIERldGFpbHMgYWJvdXQgdGhlIHNlbmRlciBvZiB0aGUgbWVzc2FnZS5cbiAgICAgICAqIEBwYXJhbSB7ZnVuY3Rpb24oKil9IHNlbmRSZXNwb25zZVxuICAgICAgICogICAgICAgIEEgY2FsbGJhY2sgd2hpY2gsIHdoZW4gY2FsbGVkIHdpdGggYW4gYXJiaXRyYXJ5IGFyZ3VtZW50LCBzZW5kc1xuICAgICAgICogICAgICAgIHRoYXQgdmFsdWUgYXMgYSByZXNwb25zZS5cbiAgICAgICAqIEByZXR1cm5zIHtib29sZWFufVxuICAgICAgICogICAgICAgIFRydWUgaWYgdGhlIHdyYXBwZWQgbGlzdGVuZXIgcmV0dXJuZWQgYSBQcm9taXNlLCB3aGljaCB3aWxsIGxhdGVyXG4gICAgICAgKiAgICAgICAgeWllbGQgYSByZXNwb25zZS4gRmFsc2Ugb3RoZXJ3aXNlLlxuICAgICAgICovXG4gICAgICByZXR1cm4gZnVuY3Rpb24gb25NZXNzYWdlKG1lc3NhZ2UsIHNlbmRlciwgc2VuZFJlc3BvbnNlKSB7XG4gICAgICAgIGxldCBkaWRDYWxsU2VuZFJlc3BvbnNlID0gZmFsc2U7XG5cbiAgICAgICAgbGV0IHdyYXBwZWRTZW5kUmVzcG9uc2U7XG4gICAgICAgIGxldCBzZW5kUmVzcG9uc2VQcm9taXNlID0gbmV3IFByb21pc2UocmVzb2x2ZSA9PiB7XG4gICAgICAgICAgd3JhcHBlZFNlbmRSZXNwb25zZSA9IGZ1bmN0aW9uKHJlc3BvbnNlKSB7XG4gICAgICAgICAgICBkaWRDYWxsU2VuZFJlc3BvbnNlID0gdHJ1ZTtcbiAgICAgICAgICAgIHJlc29sdmUocmVzcG9uc2UpO1xuICAgICAgICAgIH07XG4gICAgICAgIH0pO1xuXG4gICAgICAgIGxldCByZXN1bHQ7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgcmVzdWx0ID0gbGlzdGVuZXIobWVzc2FnZSwgc2VuZGVyLCB3cmFwcGVkU2VuZFJlc3BvbnNlKTtcbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgcmVzdWx0ID0gUHJvbWlzZS5yZWplY3QoZXJyKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IGlzUmVzdWx0VGhlbmFibGUgPSByZXN1bHQgIT09IHRydWUgJiYgaXNUaGVuYWJsZShyZXN1bHQpO1xuXG4gICAgICAgIC8vIElmIHRoZSBsaXN0ZW5lciBkaWRuJ3QgcmV0dXJuZWQgdHJ1ZSBvciBhIFByb21pc2UsIG9yIGNhbGxlZFxuICAgICAgICAvLyB3cmFwcGVkU2VuZFJlc3BvbnNlIHN5bmNocm9ub3VzbHksIHdlIGNhbiBleGl0IGVhcmxpZXJcbiAgICAgICAgLy8gYmVjYXVzZSB0aGVyZSB3aWxsIGJlIG5vIHJlc3BvbnNlIHNlbnQgZnJvbSB0aGlzIGxpc3RlbmVyLlxuICAgICAgICBpZiAocmVzdWx0ICE9PSB0cnVlICYmICFpc1Jlc3VsdFRoZW5hYmxlICYmICFkaWRDYWxsU2VuZFJlc3BvbnNlKSB7XG4gICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gQSBzbWFsbCBoZWxwZXIgdG8gc2VuZCB0aGUgbWVzc2FnZSBpZiB0aGUgcHJvbWlzZSByZXNvbHZlc1xuICAgICAgICAvLyBhbmQgYW4gZXJyb3IgaWYgdGhlIHByb21pc2UgcmVqZWN0cyAoYSB3cmFwcGVkIHNlbmRNZXNzYWdlIGhhc1xuICAgICAgICAvLyB0byB0cmFuc2xhdGUgdGhlIG1lc3NhZ2UgaW50byBhIHJlc29sdmVkIHByb21pc2Ugb3IgYSByZWplY3RlZFxuICAgICAgICAvLyBwcm9taXNlKS5cbiAgICAgICAgY29uc3Qgc2VuZFByb21pc2VkUmVzdWx0ID0gKHByb21pc2UpID0+IHtcbiAgICAgICAgICBwcm9taXNlLnRoZW4obXNnID0+IHtcbiAgICAgICAgICAgIC8vIHNlbmQgdGhlIG1lc3NhZ2UgdmFsdWUuXG4gICAgICAgICAgICBzZW5kUmVzcG9uc2UobXNnKTtcbiAgICAgICAgICB9LCBlcnJvciA9PiB7XG4gICAgICAgICAgICAvLyBTZW5kIGEgSlNPTiByZXByZXNlbnRhdGlvbiBvZiB0aGUgZXJyb3IgaWYgdGhlIHJlamVjdGVkIHZhbHVlXG4gICAgICAgICAgICAvLyBpcyBhbiBpbnN0YW5jZSBvZiBlcnJvciwgb3IgdGhlIG9iamVjdCBpdHNlbGYgb3RoZXJ3aXNlLlxuICAgICAgICAgICAgbGV0IG1lc3NhZ2U7XG4gICAgICAgICAgICBpZiAoZXJyb3IgJiYgKGVycm9yIGluc3RhbmNlb2YgRXJyb3IgfHxcbiAgICAgICAgICAgICAgICB0eXBlb2YgZXJyb3IubWVzc2FnZSA9PT0gXCJzdHJpbmdcIikpIHtcbiAgICAgICAgICAgICAgbWVzc2FnZSA9IGVycm9yLm1lc3NhZ2U7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICBtZXNzYWdlID0gXCJBbiB1bmV4cGVjdGVkIGVycm9yIG9jY3VycmVkXCI7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHNlbmRSZXNwb25zZSh7XG4gICAgICAgICAgICAgIF9fbW96V2ViRXh0ZW5zaW9uUG9seWZpbGxSZWplY3RfXzogdHJ1ZSxcbiAgICAgICAgICAgICAgbWVzc2FnZSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH0pLmNhdGNoKGVyciA9PiB7XG4gICAgICAgICAgICAvLyBQcmludCBhbiBlcnJvciBvbiB0aGUgY29uc29sZSBpZiB1bmFibGUgdG8gc2VuZCB0aGUgcmVzcG9uc2UuXG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKFwiRmFpbGVkIHRvIHNlbmQgb25NZXNzYWdlIHJlamVjdGVkIHJlcGx5XCIsIGVycik7XG4gICAgICAgICAgfSk7XG4gICAgICAgIH07XG5cbiAgICAgICAgLy8gSWYgdGhlIGxpc3RlbmVyIHJldHVybmVkIGEgUHJvbWlzZSwgc2VuZCB0aGUgcmVzb2x2ZWQgdmFsdWUgYXMgYVxuICAgICAgICAvLyByZXN1bHQsIG90aGVyd2lzZSB3YWl0IHRoZSBwcm9taXNlIHJlbGF0ZWQgdG8gdGhlIHdyYXBwZWRTZW5kUmVzcG9uc2VcbiAgICAgICAgLy8gY2FsbGJhY2sgdG8gcmVzb2x2ZSBhbmQgc2VuZCBpdCBhcyBhIHJlc3BvbnNlLlxuICAgICAgICBpZiAoaXNSZXN1bHRUaGVuYWJsZSkge1xuICAgICAgICAgIHNlbmRQcm9taXNlZFJlc3VsdChyZXN1bHQpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHNlbmRQcm9taXNlZFJlc3VsdChzZW5kUmVzcG9uc2VQcm9taXNlKTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIExldCBDaHJvbWUga25vdyB0aGF0IHRoZSBsaXN0ZW5lciBpcyByZXBseWluZy5cbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICB9O1xuICAgIH0pO1xuXG4gICAgY29uc3Qgd3JhcHBlZFNlbmRNZXNzYWdlQ2FsbGJhY2sgPSAoe3JlamVjdCwgcmVzb2x2ZX0sIHJlcGx5KSA9PiB7XG4gICAgICBpZiAoZXh0ZW5zaW9uQVBJcy5ydW50aW1lLmxhc3RFcnJvcikge1xuICAgICAgICAvLyBEZXRlY3Qgd2hlbiBub25lIG9mIHRoZSBsaXN0ZW5lcnMgcmVwbGllZCB0byB0aGUgc2VuZE1lc3NhZ2UgY2FsbCBhbmQgcmVzb2x2ZVxuICAgICAgICAvLyB0aGUgcHJvbWlzZSB0byB1bmRlZmluZWQgYXMgaW4gRmlyZWZveC5cbiAgICAgICAgLy8gU2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9tb3ppbGxhL3dlYmV4dGVuc2lvbi1wb2x5ZmlsbC9pc3N1ZXMvMTMwXG4gICAgICAgIGlmIChleHRlbnNpb25BUElzLnJ1bnRpbWUubGFzdEVycm9yLm1lc3NhZ2UgPT09IENIUk9NRV9TRU5EX01FU1NBR0VfQ0FMTEJBQ0tfTk9fUkVTUE9OU0VfTUVTU0FHRSkge1xuICAgICAgICAgIHJlc29sdmUoKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICByZWplY3QobmV3IEVycm9yKGV4dGVuc2lvbkFQSXMucnVudGltZS5sYXN0RXJyb3IubWVzc2FnZSkpO1xuICAgICAgICB9XG4gICAgICB9IGVsc2UgaWYgKHJlcGx5ICYmIHJlcGx5Ll9fbW96V2ViRXh0ZW5zaW9uUG9seWZpbGxSZWplY3RfXykge1xuICAgICAgICAvLyBDb252ZXJ0IGJhY2sgdGhlIEpTT04gcmVwcmVzZW50YXRpb24gb2YgdGhlIGVycm9yIGludG9cbiAgICAgICAgLy8gYW4gRXJyb3IgaW5zdGFuY2UuXG4gICAgICAgIHJlamVjdChuZXcgRXJyb3IocmVwbHkubWVzc2FnZSkpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmVzb2x2ZShyZXBseSk7XG4gICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IHdyYXBwZWRTZW5kTWVzc2FnZSA9IChuYW1lLCBtZXRhZGF0YSwgYXBpTmFtZXNwYWNlT2JqLCAuLi5hcmdzKSA9PiB7XG4gICAgICBpZiAoYXJncy5sZW5ndGggPCBtZXRhZGF0YS5taW5BcmdzKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihgRXhwZWN0ZWQgYXQgbGVhc3QgJHttZXRhZGF0YS5taW5BcmdzfSAke3BsdXJhbGl6ZUFyZ3VtZW50cyhtZXRhZGF0YS5taW5BcmdzKX0gZm9yICR7bmFtZX0oKSwgZ290ICR7YXJncy5sZW5ndGh9YCk7XG4gICAgICB9XG5cbiAgICAgIGlmIChhcmdzLmxlbmd0aCA+IG1ldGFkYXRhLm1heEFyZ3MpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBFeHBlY3RlZCBhdCBtb3N0ICR7bWV0YWRhdGEubWF4QXJnc30gJHtwbHVyYWxpemVBcmd1bWVudHMobWV0YWRhdGEubWF4QXJncyl9IGZvciAke25hbWV9KCksIGdvdCAke2FyZ3MubGVuZ3RofWApO1xuICAgICAgfVxuXG4gICAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgICBjb25zdCB3cmFwcGVkQ2IgPSB3cmFwcGVkU2VuZE1lc3NhZ2VDYWxsYmFjay5iaW5kKG51bGwsIHtyZXNvbHZlLCByZWplY3R9KTtcbiAgICAgICAgYXJncy5wdXNoKHdyYXBwZWRDYik7XG4gICAgICAgIGFwaU5hbWVzcGFjZU9iai5zZW5kTWVzc2FnZSguLi5hcmdzKTtcbiAgICAgIH0pO1xuICAgIH07XG5cbiAgICBjb25zdCBzdGF0aWNXcmFwcGVycyA9IHtcbiAgICAgIGRldnRvb2xzOiB7XG4gICAgICAgIG5ldHdvcms6IHtcbiAgICAgICAgICBvblJlcXVlc3RGaW5pc2hlZDogd3JhcEV2ZW50KG9uUmVxdWVzdEZpbmlzaGVkV3JhcHBlcnMpLFxuICAgICAgICB9LFxuICAgICAgfSxcbiAgICAgIHJ1bnRpbWU6IHtcbiAgICAgICAgb25NZXNzYWdlOiB3cmFwRXZlbnQob25NZXNzYWdlV3JhcHBlcnMpLFxuICAgICAgICBvbk1lc3NhZ2VFeHRlcm5hbDogd3JhcEV2ZW50KG9uTWVzc2FnZVdyYXBwZXJzKSxcbiAgICAgICAgc2VuZE1lc3NhZ2U6IHdyYXBwZWRTZW5kTWVzc2FnZS5iaW5kKG51bGwsIFwic2VuZE1lc3NhZ2VcIiwge21pbkFyZ3M6IDEsIG1heEFyZ3M6IDN9KSxcbiAgICAgIH0sXG4gICAgICB0YWJzOiB7XG4gICAgICAgIHNlbmRNZXNzYWdlOiB3cmFwcGVkU2VuZE1lc3NhZ2UuYmluZChudWxsLCBcInNlbmRNZXNzYWdlXCIsIHttaW5BcmdzOiAyLCBtYXhBcmdzOiAzfSksXG4gICAgICB9LFxuICAgIH07XG4gICAgY29uc3Qgc2V0dGluZ01ldGFkYXRhID0ge1xuICAgICAgY2xlYXI6IHttaW5BcmdzOiAxLCBtYXhBcmdzOiAxfSxcbiAgICAgIGdldDoge21pbkFyZ3M6IDEsIG1heEFyZ3M6IDF9LFxuICAgICAgc2V0OiB7bWluQXJnczogMSwgbWF4QXJnczogMX0sXG4gICAgfTtcbiAgICBhcGlNZXRhZGF0YS5wcml2YWN5ID0ge1xuICAgICAgbmV0d29yazoge1wiKlwiOiBzZXR0aW5nTWV0YWRhdGF9LFxuICAgICAgc2VydmljZXM6IHtcIipcIjogc2V0dGluZ01ldGFkYXRhfSxcbiAgICAgIHdlYnNpdGVzOiB7XCIqXCI6IHNldHRpbmdNZXRhZGF0YX0sXG4gICAgfTtcblxuICAgIHJldHVybiB3cmFwT2JqZWN0KGV4dGVuc2lvbkFQSXMsIHN0YXRpY1dyYXBwZXJzLCBhcGlNZXRhZGF0YSk7XG4gIH07XG5cbiAgLy8gVGhlIGJ1aWxkIHByb2Nlc3MgYWRkcyBhIFVNRCB3cmFwcGVyIGFyb3VuZCB0aGlzIGZpbGUsIHdoaWNoIG1ha2VzIHRoZVxuICAvLyBgbW9kdWxlYCB2YXJpYWJsZSBhdmFpbGFibGUuXG4gIG1vZHVsZS5leHBvcnRzID0gd3JhcEFQSXMoY2hyb21lKTtcbn0gZWxzZSB7XG4gIG1vZHVsZS5leHBvcnRzID0gZ2xvYmFsVGhpcy5icm93c2VyO1xufVxuIiwgImltcG9ydCBicm93c2VyIGZyb20gJ3dlYmV4dGVuc2lvbi1wb2x5ZmlsbCc7XG5cbmV4cG9ydCBmdW5jdGlvbiBnZXRFeHRlbnNpb25VUkwocGF0aCkge1xuICAgIHJldHVybiBicm93c2VyLnJ1bnRpbWUuZ2V0VVJMKHBhdGgpO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gZ2V0RXh0ZW5zaW9uVmVyc2lvbigpIHtcbiAgICBjb25zdCBtYW5pZmVzdCA9IGJyb3dzZXIucnVudGltZS5nZXRNYW5pZmVzdCgpO1xuICAgIHJldHVybiBtYW5pZmVzdC52ZXJzaW9uO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gb3BlbkV4dGVuc2lvblBhZ2UocGF0aCkge1xuICAgIGJyb3dzZXIudGFicy5jcmVhdGUoeyB1cmw6IGdldEV4dGVuc2lvblVSTChwYXRoKSB9KTtcbn1cblxuLyoqXG4gKiBAcGFyYW0ge3N0cmluZ30gaWNvblBhdGhcbiAqIEBwYXJhbSB7bnVtYmVyfSB0YWJJZFxuICogQHJldHVybnMge1Byb21pc2U8dm9pZD59XG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRBY3Rpb25JY29uKGljb25QYXRoLCB0YWJJZCkge1xuICAgIGlmICh0eXBlb2YgYnJvd3Nlci5hY3Rpb24gPT09ICd1bmRlZmluZWQnKSB7XG4gICAgICAgIHJldHVybiBicm93c2VyLmJyb3dzZXJBY3Rpb24uc2V0SWNvbih7IHBhdGg6IGljb25QYXRoLCB0YWJJZCB9KTtcbiAgICB9XG4gICAgcmV0dXJuIGJyb3dzZXIuYWN0aW9uLnNldEljb24oeyBwYXRoOiBpY29uUGF0aCwgdGFiSWQgfSk7XG59XG5leHBvcnQgZnVuY3Rpb24gZ2V0TWFuaWZlc3RWZXJzaW9uKCkge1xuICAgIGNvbnN0IG1hbmlmZXN0ID0gYnJvd3Nlci5ydW50aW1lLmdldE1hbmlmZXN0KCk7XG4gICAgcmV0dXJuIG1hbmlmZXN0Lm1hbmlmZXN0X3ZlcnNpb247XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBzeW5jVG9TdG9yYWdlKGRhdGEpIHtcbiAgICByZXR1cm4gYnJvd3Nlci5zdG9yYWdlLmxvY2FsLnNldChkYXRhKTtcbn1cblxuLy8gQHRzLWlnbm9yZVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEZyb21TdG9yYWdlKGtleSwgY2IpIHtcbiAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuZ2V0KGtleSk7XG4gICAgcmV0dXJuIHJlc3VsdFtrZXldO1xufVxuXG4vLyBAdHMtaWdub3JlXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0RnJvbU1hbmFnZWRTdG9yYWdlKGtleXMsIGNiKSB7XG4gICAgdHJ5IHtcbiAgICAgICAgcmV0dXJuIGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5tYW5hZ2VkLmdldChrZXlzKTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKCdnZXQgbWFuYWdlZCBmYWlsZWQnLCBlKTtcbiAgICB9XG4gICAgcmV0dXJuIHt9O1xufVxuXG5leHBvcnQgZnVuY3Rpb24gZ2V0RXh0ZW5zaW9uSWQoKSB7XG4gICAgcmV0dXJuIGJyb3dzZXIucnVudGltZS5pZDtcbn1cblxuLyoqXG4gKiBAcGFyYW0ge2Jyb3dzZXIuV2ViUmVxdWVzdC5PbkJlZm9yZVJlZGlyZWN0RGV0YWlsc1R5cGUgfCBicm93c2VyLlRhYnMuVGFiIHwgYnJvd3Nlci5UYWJzLk9uVXBkYXRlZENoYW5nZUluZm9UeXBlfSB0YWJEYXRhXG4gKiBAcmV0dXJucyB7e3RhYklkOiBudW1iZXIsIHVybDogc3RyaW5nIHwgdW5kZWZpbmVkLCByZXF1ZXN0SWQ/OiBzdHJpbmcsIHN0YXR1czogc3RyaW5nIHwgbnVsbCB8IHVuZGVmaW5lZH19XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBub3JtYWxpemVUYWJEYXRhKHRhYkRhdGEpIHtcbiAgICAvLyBAdHMtZXhwZWN0LWVycm9yIC0gaWQgZG9lc24ndCBleGlzdCBvblVwZGF0ZWRDaGFuZ2VJbmZvVHlwZSBidXQgd2UgcmVjdGlmeSBpbiBvbkNyZWF0ZU9yVXBkYXRlVGFiXG4gICAgY29uc3QgdGFiSWQgPSAndGFiSWQnIGluIHRhYkRhdGEgPyB0YWJEYXRhLnRhYklkIDogdGFiRGF0YS5pZDtcbiAgICBjb25zdCB1cmwgPSB0YWJEYXRhLnVybDtcbiAgICBjb25zdCBzdGF0dXMgPSAnc3RhdHVzJyBpbiB0YWJEYXRhID8gdGFiRGF0YS5zdGF0dXMgOiBudWxsO1xuICAgIGNvbnN0IHJlcXVlc3RJZCA9ICdyZXF1ZXN0SWQnIGluIHRhYkRhdGEgPyB0YWJEYXRhLnJlcXVlc3RJZCA6IHVuZGVmaW5lZDtcbiAgICByZXR1cm4ge1xuICAgICAgICB0YWJJZCxcbiAgICAgICAgdXJsLFxuICAgICAgICByZXF1ZXN0SWQsXG4gICAgICAgIHN0YXR1cyxcbiAgICB9O1xufVxuXG5leHBvcnQgZnVuY3Rpb24gbWVyZ2VTYXZlZFNldHRpbmdzKHNldHRpbmdzLCByZXN1bHRzKSB7XG4gICAgcmV0dXJuIE9iamVjdC5hc3NpZ24oc2V0dGluZ3MsIHJlc3VsdHMpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0RERHVGFiVXJscygpIHtcbiAgICBjb25zdCB0YWJzID0gKGF3YWl0IGJyb3dzZXIudGFicy5xdWVyeSh7IHVybDogJ2h0dHBzOi8vKi5kdWNrZHVja2dvLmNvbS8qJyB9KSkgfHwgW107XG4gICAgcmV0dXJuIHRhYnMubWFwKCh0YWIpID0+IHRhYi51cmwpO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gc2V0VW5pbnN0YWxsVVJMKHVybCkge1xuICAgIGJyb3dzZXIucnVudGltZS5zZXRVbmluc3RhbGxVUkwodXJsKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGNoYW5nZVRhYlVSTCh0YWJJZCwgdXJsKSB7XG4gICAgcmV0dXJuIGJyb3dzZXIudGFicy51cGRhdGUodGFiSWQsIHsgdXJsIH0pO1xufVxuXG5mdW5jdGlvbiBjb252ZXJ0U2NyaXB0aW5nQVBJT3B0aW9uc0ZvclRhYnNBUEkob3B0aW9ucykge1xuICAgIGlmICh0eXBlb2Ygb3B0aW9ucyAhPT0gJ29iamVjdCcpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdNaXNzaW5nL2ludmFsaWQgb3B0aW9ucyBPYmplY3QuJyk7XG4gICAgfVxuXG4gICAgaWYgKFxuICAgICAgICB0eXBlb2Ygb3B0aW9ucy5maWxlICE9PSAndW5kZWZpbmVkJyB8fFxuICAgICAgICB0eXBlb2Ygb3B0aW9ucy5mcmFtZUlkICE9PSAndW5kZWZpbmVkJyB8fFxuICAgICAgICB0eXBlb2Ygb3B0aW9ucy5ydW5BdCAhPT0gJ3VuZGVmaW5lZCcgfHxcbiAgICAgICAgdHlwZW9mIG9wdGlvbnMuYWxsRnJhbWVzICE9PSAndW5kZWZpbmVkJyB8fFxuICAgICAgICB0eXBlb2Ygb3B0aW9ucy5jb2RlICE9PSAndW5kZWZpbmVkJ1xuICAgICkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1BsZWFzZSBwcm92aWRlIG9wdGlvbnMgY29tcGF0aWJsZSB3aXRoIHRoZSAoTVYzKSBzY3JpcHRpbmcgQVBJLCAnICsgJ2luc3RlYWQgb2YgdGhlIChNVjIpIHRhYnMgQVBJLicpO1xuICAgIH1cblxuICAgIGlmICh0eXBlb2Ygb3B0aW9ucy53b3JsZCAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdXb3JsZCB0YXJnZXR0aW5nIG5vdCBzdXBwb3J0ZWQgYnkgTVYyLicpO1xuICAgIH1cblxuICAgIGNvbnN0IHsgYWxsRnJhbWVzLCBmcmFtZUlkcywgdGFiSWQgfSA9IG9wdGlvbnMudGFyZ2V0O1xuICAgIGRlbGV0ZSBvcHRpb25zLnRhcmdldDtcblxuICAgIGlmIChBcnJheS5pc0FycmF5KGZyYW1lSWRzKSAmJiBmcmFtZUlkcy5sZW5ndGggPiAwKSB7XG4gICAgICAgIGlmIChmcmFtZUlkcy5sZW5ndGggPiAxKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1RhcmdldHRpbmcgbXVsdGlwbGUgZnJhbWVzIGJ5IElEIG5vdCBzdXBwb3J0ZWQgYnkgTVYyLicpO1xuICAgICAgICB9XG5cbiAgICAgICAgb3B0aW9ucy5mcmFtZUlkID0gZnJhbWVJZHNbMF07XG4gICAgfVxuXG4gICAgaWYgKHR5cGVvZiBvcHRpb25zLmZpbGVzICE9PSAndW5kZWZpbmVkJykge1xuICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShvcHRpb25zLmZpbGVzKSAmJiBvcHRpb25zLmZpbGVzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgIGlmIChvcHRpb25zLmZpbGVzLmxlbmd0aCA+IDEpIHtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0luc2VydGluZyBtdWx0aXBsZSBzdHlsZXNoZWV0cy9zY3JpcHRzIGluIG9uZSBnbyBub3Qgc3VwcG9ydGVkIGJ5IE1WMi4nKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIG9wdGlvbnMuZmlsZSA9IG9wdGlvbnMuZmlsZXNbMF07XG4gICAgICAgIH1cbiAgICAgICAgZGVsZXRlIG9wdGlvbnMuZmlsZXM7XG4gICAgfVxuXG4gICAgaWYgKHR5cGVvZiBhbGxGcmFtZXMgIT09ICd1bmRlZmluZWQnKSB7XG4gICAgICAgIG9wdGlvbnMuYWxsRnJhbWVzID0gYWxsRnJhbWVzO1xuICAgIH1cblxuICAgIGlmICh0eXBlb2Ygb3B0aW9ucy5pbmplY3RJbW1lZGlhdGVseSAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgICAgaWYgKG9wdGlvbnMuaW5qZWN0SW1tZWRpYXRlbHkpIHtcbiAgICAgICAgICAgIG9wdGlvbnMucnVuQXQgPSAnZG9jdW1lbnRfc3RhcnQnO1xuICAgICAgICB9XG4gICAgICAgIGRlbGV0ZSBvcHRpb25zLmluamVjdEltbWVkaWF0ZWx5O1xuICAgIH1cblxuICAgIGxldCBzdHJpbmdpZmllZEFyZ3MgPSAnJztcbiAgICBpZiAodHlwZW9mIG9wdGlvbnMuYXJncyAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkob3B0aW9ucy5hcmdzKSkge1xuICAgICAgICAgICAgc3RyaW5naWZpZWRBcmdzID0gJy4uLicgKyBKU09OLnN0cmluZ2lmeShvcHRpb25zLmFyZ3MpO1xuICAgICAgICB9XG4gICAgICAgIGRlbGV0ZSBvcHRpb25zLmFyZ3M7XG4gICAgfVxuXG4gICAgaWYgKHR5cGVvZiBvcHRpb25zLmZ1bmMgIT09ICd1bmRlZmluZWQnKSB7XG4gICAgICAgIGlmICh0eXBlb2Ygb3B0aW9ucy5mdW5jID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgICAgICBvcHRpb25zLmNvZGUgPSAnKCcgKyBvcHRpb25zLmZ1bmMudG9TdHJpbmcoKSArICcpKCcgKyBzdHJpbmdpZmllZEFyZ3MgKyAnKSc7XG4gICAgICAgIH1cbiAgICAgICAgZGVsZXRlIG9wdGlvbnMuZnVuYztcbiAgICB9XG5cbiAgICByZXR1cm4gW3RhYklkLCBvcHRpb25zXTtcbn1cblxuLyoqXG4gKiBFeGVjdXRlIGEgc2NyaXB0L2Z1bmN0aW9uIGluIHRoZSB0YXJnZXQgdGFiLlxuICogVGhpcyBpcyBhIHdyYXBwZXIgYXJvdW5kIHRhYnMuZXhlY3V0ZVNjcmlwdCAoTVYyKSBhbmRcbiAqIHNjcmlwdGluZy5leGVjdXRlU2NyaXB0IChNVjMpLiBBcmd1bWVudHMgYXJlIGV4cGVjdGVkIGluIHRoZVxuICogc2NyaXB0aW5nLmV4ZWN1dGVTY3JpcHRbMV0gZm9ybWF0LlxuICogTm90ZXM6XG4gKiAgIC0gSW5zdGVhZCBvZiBwYXNzaW5nIHRoZSBgY29kZWAgb3B0aW9uIChKYXZhU2NyaXB0IHN0cmluZyB0byBleGVjdXRlKSwgcGFzc1xuICogICAgIHRoZSBgZnVuY2Agb3B0aW9uIChKYXZhU2NyaXB0IGZ1bmN0aW9uIHRvIGV4ZWN1dGUpLlxuICogICAtIFNvbWUgZmVhdHVyZXMgYXJlIG5vdCBzdXBwb3J0ZWQgaW4gTVYyLCBpbmNsdWRpbmcgdGFyZ2V0dGluZyBtdWx0aXBsZVxuICogICAgIHNwZWNpZmljIGZyYW1lcyBhbmQgdGFyZ2V0dGluZyBleGVjdXRpb24gJ3dvcmxkJy5cbiAqIDEgLSBodHRwczovL2RldmVsb3Blci5jaHJvbWUuY29tL2RvY3MvZXh0ZW5zaW9ucy9yZWZlcmVuY2Uvc2NyaXB0aW5nLyNtZXRob2QtZXhlY3V0ZVNjcmlwdFxuICogQHBhcmFtIHtvYmplY3R9IG9wdGlvbnNcbiAqICAgU2NyaXB0IGluamVjdGlvbiBvcHRpb25zLlxuICogQHJldHVybnMge1Byb21pc2U8Kj59XG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBleGVjdXRlU2NyaXB0KG9wdGlvbnMpIHtcbiAgICBpZiAodHlwZW9mIGJyb3dzZXIuc2NyaXB0aW5nID09PSAndW5kZWZpbmVkJykge1xuICAgICAgICByZXR1cm4gYXdhaXQgYnJvd3Nlci50YWJzLmV4ZWN1dGVTY3JpcHQoXG4gICAgICAgICAgICAvLyBAdHMtaWdub3JlXG4gICAgICAgICAgICAuLi5jb252ZXJ0U2NyaXB0aW5nQVBJT3B0aW9uc0ZvclRhYnNBUEkob3B0aW9ucyksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgcmV0dXJuIGF3YWl0IGJyb3dzZXIuc2NyaXB0aW5nLmV4ZWN1dGVTY3JpcHQob3B0aW9ucyk7XG59XG5cbi8qKlxuICogSW5zZXJ0IENTUyBpbiB0aGUgdGFyZ2V0IHRhYi5cbiAqIFRoaXMgaXMgYSB3cmFwcGVyIGFyb3VuZCB0YWJzLmluc2VydENTUyAoTVYyKSBhbmQgc2NyaXB0aW5nLmluc2VydENTUyAoTVYzKS5cbiAqIEFyZ3VtZW50cyBhcmUgZXhwZWN0ZWQgaW4gdGhlIHNjcmlwdGluZy5pbnNlcnRDU1NbMV0gZm9ybWF0LlxuICogTm90ZXM6XG4gKiAgIC0gU29tZSBmZWF0dXJlcyBhcmUgbm90IHN1cHBvcnRlZCBpbiBNVjIsIGluY2x1ZGluZyB0YXJnZXR0aW5nIG11bHRpcGxlXG4gKiAgICAgc3BlY2lmaWMgZnJhbWVzIGFuZCB0YXJnZXR0aW5nIGV4ZWN1dGlvbiAnd29ybGQnLlxuICogMSAtIGh0dHBzOi8vZGV2ZWxvcGVyLmNocm9tZS5jb20vZG9jcy9leHRlbnNpb25zL3JlZmVyZW5jZS9zY3JpcHRpbmcvI21ldGhvZC1pbnNlcnRDU1NcbiAqIEBwYXJhbSB7b2JqZWN0fSBvcHRpb25zXG4gKiAgIENTUyBpbnNlcnRpb24gb3B0aW9ucy5cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGluc2VydENTUyhvcHRpb25zKSB7XG4gICAgaWYgKHR5cGVvZiBicm93c2VyLnNjcmlwdGluZyA9PT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgICAgcmV0dXJuIGF3YWl0IGJyb3dzZXIudGFicy5pbnNlcnRDU1MoXG4gICAgICAgICAgICAvLyBAdHMtaWdub3JlXG4gICAgICAgICAgICAuLi5jb252ZXJ0U2NyaXB0aW5nQVBJT3B0aW9uc0ZvclRhYnNBUEkob3B0aW9ucyksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgcmV0dXJuIGF3YWl0IGJyb3dzZXIuc2NyaXB0aW5nLmluc2VydENTUyhvcHRpb25zKTtcbn1cblxuLy8gU2Vzc2lvbiBzdG9yYWdlXG4vLyBAdHMtaWdub3JlXG5jb25zdCBzZXNzaW9uU3RvcmFnZVN1cHBvcnRlZCA9IHR5cGVvZiBicm93c2VyLnN0b3JhZ2Uuc2Vzc2lvbiAhPT0gJ3VuZGVmaW5lZCc7XG5leHBvcnQgY29uc3Qgc2Vzc2lvblN0b3JhZ2VGYWxsYmFjayA9IHNlc3Npb25TdG9yYWdlU3VwcG9ydGVkID8gbnVsbCA6IG5ldyBNYXAoKTtcblxuLyoqXG4gKiBTYXZlIHNvbWUgZGF0YSB0byBtZW1vcnksIHdoaWNoIHBlcnNpc3RzIHVudGlsIHRoZSBzZXNzaW9uIGVuZHMgKGUuZy4gdW50aWxcbiAqIHRoZSBicm93c2VyIGlzIGNsb3NlZCkuXG4gKiBOb3RlOiBUaGVyZSBpcyBhIHF1b3RhIGZvciBob3cgbXVjaCBkYXRhIGNhbiBiZSBzdG9yZWQgaW4gbWVtb3J5LiBBdCB0aGUgdGltZVxuICogICAgICAgb2Ygd3JpdGluZyB0aGF0IHdhcyBhYm91dCAxIG1lZ2FieXRlLiBBdHRlbXB0aW5nIHRvIHdyaXRlIG1vcmUgZGF0YVxuICogICAgICAgdGhhbiB0aGlzIHdpbGwgcmVzdWx0IGluIGFuIGVycm9yLiBGb3IgbGFyZ2UgdmFsdWVzLCBwbGVhc2UgdXNlXG4gKiAgICAgICBgc3luY1RvU3RvcmFnZWAgKGJyb3dzZXIuc3RvcmFnZS5sb2NhbCkgaW5zdGVhZC5cbiAqICAgICAgIFNlZSBodHRwczovL2RldmVsb3Blci5jaHJvbWUuY29tL2RvY3MvZXh0ZW5zaW9ucy9yZWZlcmVuY2Uvc3RvcmFnZS8jcHJvcGVydHktc2Vzc2lvbi1zZXNzaW9uLVFVT1RBX0JZVEVTXG4gKiBAcGFyYW0ge3N0cmluZ30ga2V5XG4gKiAgIFRoZSBzdG9yYWdlIGtleSB0byB3cml0ZSB0by5cbiAqIEBwYXJhbSB7Kn0gZGF0YVxuICogICBUaGUgdmFsdWUgdG8gd3JpdGUuXG4gKiBAcmV0dXJuIHtQcm9taXNlPHVuZGVmaW5lZD59XG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRUb1Nlc3Npb25TdG9yYWdlKGtleSwgZGF0YSkge1xuICAgIGlmICh0eXBlb2Yga2V5ICE9PSAnc3RyaW5nJykge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0ludmFsaWQgc3RvcmFnZSBrZXksIHN0cmluZyBleHBlY3RlZC4nKTtcbiAgICB9XG5cbiAgICBpZiAoc2Vzc2lvblN0b3JhZ2VTdXBwb3J0ZWQpIHtcbiAgICAgICAgLy8gQHRzLWlnbm9yZVxuICAgICAgICByZXR1cm4gYXdhaXQgYnJvd3Nlci5zdG9yYWdlLnNlc3Npb24uc2V0KHsgW2tleV06IGRhdGEgfSk7XG4gICAgfVxuXG4gICAgLy8gQHRzLWlnbm9yZSAtIFRTIGRvZXNuJ3Qga25vdyBpdCBpcyBhIE1hcFxuICAgIHNlc3Npb25TdG9yYWdlRmFsbGJhY2suc2V0KGtleSwgZGF0YSk7XG59XG5cbi8qKlxuICogUmV0cmlldmUgYSB2YWx1ZSBmcm9tIG1lbW9yeS5cbiAqIEBwYXJhbSB7c3RyaW5nfSBrZXlcbiAqICAgVGhlIHN0b3JhZ2Uga2V5IHRvIHJldHJpZXZlLlxuICogQHJldHVybiB7UHJvbWlzZTwqPn1cbiAqICAgVGhlIHJldHJpZXZlZCB2YWx1ZS5cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEZyb21TZXNzaW9uU3RvcmFnZShrZXkpIHtcbiAgICBpZiAodHlwZW9mIGtleSAhPT0gJ3N0cmluZycpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdJbnZhbGlkIHN0b3JhZ2Uga2V5LCBzdHJpbmcgZXhwZWN0ZWQuJyk7XG4gICAgfVxuXG4gICAgaWYgKHNlc3Npb25TdG9yYWdlU3VwcG9ydGVkKSB7XG4gICAgICAgIC8vIEB0cy1pZ25vcmVcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgYnJvd3Nlci5zdG9yYWdlLnNlc3Npb24uZ2V0KFtrZXldKTtcbiAgICAgICAgcmV0dXJuIHJlc3VsdFtrZXldO1xuICAgIH1cblxuICAgIC8vIEB0cy1pZ25vcmVcbiAgICByZXR1cm4gc2Vzc2lvblN0b3JhZ2VGYWxsYmFjay5nZXQoa2V5KTtcbn1cblxuLyoqXG4gKiBSZW1vdmVzIGEgdmFsdWUgZnJvbSBtZW1vcnkuXG4gKiBAcGFyYW0ge3N0cmluZ30ga2V5XG4gKiAgIFRoZSBzdG9yYWdlIGtleSB0byByZW1vdmUuXG4gKiBAcmV0dXJuIHtQcm9taXNlPHVuZGVmaW5lZD59XG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiByZW1vdmVGcm9tU2Vzc2lvblN0b3JhZ2Uoa2V5KSB7XG4gICAgaWYgKHR5cGVvZiBrZXkgIT09ICdzdHJpbmcnKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcignSW52YWxpZCBzdG9yYWdlIGtleSwgc3RyaW5nIGV4cGVjdGVkLicpO1xuICAgIH1cblxuICAgIGlmIChzZXNzaW9uU3RvcmFnZVN1cHBvcnRlZCkge1xuICAgICAgICAvLyBAdHMtaWdub3JlXG4gICAgICAgIHJldHVybiBhd2FpdCBicm93c2VyLnN0b3JhZ2Uuc2Vzc2lvbi5yZW1vdmUoa2V5KTtcbiAgICB9XG5cbiAgICAvLyBAdHMtaWdub3JlXG4gICAgcmV0dXJuIHNlc3Npb25TdG9yYWdlRmFsbGJhY2suZGVsZXRlKGtleSk7XG59XG5cbi8qKlxuICogQ3JlYXRlIGFuIGFsYXJtLCB0YWtpbmcgY2FyZSB0byBjaGVjayBpdCBkb2Vzbid0IGV4aXN0IGZpcnN0LlxuICogU2VlIGh0dHBzOi8vc3RhY2tvdmVyZmxvdy5jb20vcXVlc3Rpb25zLzY2MzkxMDE4L2hvdy1kby1pLWNhbGwtYS1mdW5jdGlvbi1wZXJpb2RpY2FsbHktaW4tYS1tYW5pZmVzdC12My1jaHJvbWUtZXh0ZW5zaW9uLzY2MzkxNjAxIzY2MzkxNjAxXG4gKiBAcGFyYW0ge3N0cmluZ30gbmFtZVxuICogICBUaGUgYWxhcm0gbmFtZS5cbiAqIEBwYXJhbSB7T2JqZWN0fSBhbGFybUluZm9cbiAqICAgRGV0YWlscyB0aGF0IGRldGVybWluZSB3aGVuIHRoZSBhbGFybSBzaG91bGQgZmlyZS5cbiAqICAgU2VlIGh0dHBzOi8vZGV2ZWxvcGVyLmNocm9tZS5jb20vZG9jcy9leHRlbnNpb25zL3JlZmVyZW5jZS9hbGFybXMvI3R5cGUtQWxhcm1DcmVhdGVJbmZvXG4gKiBAcmV0dXJuIHtQcm9taXNlfVxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gY3JlYXRlQWxhcm0obmFtZSwgYWxhcm1JbmZvKSB7XG4gICAgY29uc3QgZXhpc3RpbmdBbGFybSA9IGF3YWl0IGJyb3dzZXIuYWxhcm1zLmdldChuYW1lKTtcbiAgICBpZiAoIWV4aXN0aW5nQWxhcm0pIHtcbiAgICAgICAgcmV0dXJuIGF3YWl0IGJyb3dzZXIuYWxhcm1zLmNyZWF0ZShuYW1lLCBhbGFybUluZm8pO1xuICAgIH1cbn1cbiIsICJtb2R1bGUuZXhwb3J0cyA9IHtcbiAgICBodHRwc0V2ZXJ5d2hlcmVFbmFibGVkOiB0cnVlLFxuICAgIGVtYmVkZGVkVHdlZXRzRW5hYmxlZDogZmFsc2UsXG4gICAgR1BDOiB0cnVlLFxuICAgIHlvdXR1YmVQcmV2aWV3c0VuYWJsZWQ6IGZhbHNlLFxuICAgIGF0YjogbnVsbCxcbiAgICBzZXRfYXRiOiBudWxsLFxuICAgICdjb25maWctZXRhZyc6IG51bGwsXG4gICAgJ2h0dHBzVXBncmFkZUJsb29tRmlsdGVyLWV0YWcnOiBudWxsLFxuICAgICdodHRwc0RvbnRVcGdyYWRlQmxvb21GaWx0ZXJzLWV0YWcnOiBudWxsLFxuICAgICdodHRwc1VwZ3JhZGVMaXN0LWV0YWcnOiBudWxsLFxuICAgICdodHRwc0RvbnRVcGdyYWRlTGlzdC1ldGFnJzogbnVsbCxcbiAgICBoYXNTZWVuUG9zdEluc3RhbGw6IGZhbHNlLFxuICAgIGV4dGlTZW50OiBmYWxzZSxcbiAgICAndGRzLWV0YWcnOiBudWxsLFxuICAgIGxhc3RUZHNVcGRhdGU6IDAsXG4gICAgZmlyZUJ1dHRvbkNsZWFySGlzdG9yeUVuYWJsZWQ6IHRydWUsXG4gICAgZmlyZUJ1dHRvblRhYkNsZWFyRW5hYmxlZDogdHJ1ZSxcbn07XG4iLCAiY29uc3QgZGVmYXVsdFNldHRpbmdzID0gcmVxdWlyZSgnLi4vLi4vZGF0YS9kZWZhdWx0U2V0dGluZ3MnKTtcbmNvbnN0IGJyb3dzZXJXcmFwcGVyID0gcmVxdWlyZSgnLi93cmFwcGVyJyk7XG5cbmNvbnN0IG9uU2V0dGluZ1VwZGF0ZSA9IG5ldyBFdmVudFRhcmdldCgpO1xuXG4vLyBAdHMtZXhwZWN0LWVycm9yIFdvcmthcm91bmQgZm9yIHRoZSB0ZXN0cyBpbiB1bml0LXRlc3RzL25vZGUvcmVmZXJlbmNlLXRlc3RzLlxuaWYgKHR5cGVvZiBDdXN0b21FdmVudCA9PT0gJ3VuZGVmaW5lZCcpIGdsb2JhbFRoaXMuQ3VzdG9tRXZlbnQgPSBFdmVudDtcblxuLyoqXG4gKiBTZXR0aW5ncyB3aG9zZSBkZWZhdWx0cyBjYW4gYnkgbWFuYWdlZCBieSB0aGUgc3lzdGVtIGFkbWluaXN0cmF0b3JcbiAqL1xuY29uc3QgTUFOQUdFRF9TRVRUSU5HUyA9IFsnaGFzU2VlblBvc3RJbnN0YWxsJ107XG4vKipcbiAqIFB1YmxpYyBhcGlcbiAqIFVzYWdlOlxuICogWW91IGNhbiB1c2UgcHJvbWlzZSBjYWxsYmFja3MgdG8gY2hlY2sgcmVhZHluZXNzIGJlZm9yZSBnZXR0aW5nIGFuZCB1cGRhdGluZ1xuICogc2V0dGluZ3MucmVhZHkoKS50aGVuKCgpID0+IHNldHRpbmdzLnVwZGF0ZVNldHRpbmcoJ3NldHRpbmdOYW1lJywgc2V0dGluZ1ZhbHVlKSlcbiAqL1xubGV0IHNldHRpbmdzID0ge307XG5sZXQgaXNSZWFkeSA9IGZhbHNlO1xuY29uc3QgX3JlYWR5ID0gaW5pdCgpLnRoZW4oKCkgPT4ge1xuICAgIGlzUmVhZHkgPSB0cnVlO1xuICAgIGNvbnNvbGUubG9nKCdTZXR0aW5ncyBhcmUgbG9hZGVkJyk7XG59KTtcblxuYXN5bmMgZnVuY3Rpb24gaW5pdCgpIHtcbiAgICBidWlsZFNldHRpbmdzRnJvbURlZmF1bHRzKCk7XG4gICAgYXdhaXQgYnVpbGRTZXR0aW5nc0Zyb21NYW5hZ2VkU3RvcmFnZSgpO1xuICAgIGF3YWl0IGJ1aWxkU2V0dGluZ3NGcm9tTG9jYWxTdG9yYWdlKCk7XG59XG5cbmZ1bmN0aW9uIHJlYWR5KCkge1xuICAgIHJldHVybiBfcmVhZHk7XG59XG5cbi8vIEVuc3VyZXMgd2UgaGF2ZSBjbGVhcmVkIHVwIG9sZCBzdG9yYWdlIGtleXMgd2UgaGF2ZSByZW5hbWVkXG5mdW5jdGlvbiBjaGVja0ZvckxlZ2FjeUtleXMoKSB7XG4gICAgY29uc3QgbGVnYWN5S2V5cyA9IHtcbiAgICAgICAgLy8gS2V5cyB0byBtaWdyYXRlXG4gICAgICAgIHdoaXRlbGlzdGVkOiAnYWxsb3dsaXN0ZWQnLFxuICAgICAgICB3aGl0ZWxpc3RPcHRJbjogJ2FsbG93bGlzdE9wdEluJyxcblxuICAgICAgICAvLyBLZXlzIHRvIHJlbW92ZVxuICAgICAgICBhZHZhbmNlZF9vcHRpb25zOiBudWxsLFxuICAgICAgICBjbGlja1RvTG9hZENsaWNrczogbnVsbCxcbiAgICAgICAgY29va2llRXhjbHVkZUxpc3Q6IG51bGwsXG4gICAgICAgIGRldjogbnVsbCxcbiAgICAgICAgZHVja3k6IG51bGwsXG4gICAgICAgIGV4dGVuc2lvbklzRW5hYmxlZDogbnVsbCxcbiAgICAgICAgZmFpbGVkVXBncmFkZXM6IG51bGwsXG4gICAgICAgIGxhc3Rfc2VhcmNoOiBudWxsLFxuICAgICAgICBsYXN0c2VhcmNoX2VuYWJsZWQ6IG51bGwsXG4gICAgICAgIG1lYW5pbmdzOiBudWxsLFxuICAgICAgICBzYWZlc2VhcmNoOiBudWxsLFxuICAgICAgICBzb2NpYWxCbG9ja2luZ0lzRW5hYmxlZDogbnVsbCxcbiAgICAgICAgdG90YWxVcGdyYWRlczogbnVsbCxcbiAgICAgICAgdHJhY2tlckJsb2NraW5nRW5hYmxlZDogbnVsbCxcbiAgICAgICAgdXNlX3Bvc3Q6IG51bGwsXG4gICAgICAgIHZlcnNpb246IG51bGwsXG4gICAgICAgIHplcm9jbGlja19nb29nbGVfcmlnaHQ6IG51bGwsXG5cbiAgICAgICAgJ3N1cnJvZ2F0ZXMtZXRhZyc6IG51bGwsXG4gICAgICAgICdicm9rZW5TaXRlTGlzdC1ldGFnJzogbnVsbCxcbiAgICAgICAgJ3N1cnJvZ2F0ZUxpc3QtZXRhZyc6IG51bGwsXG4gICAgICAgICd0cmFja2Vyc1doaXRlbGlzdC1ldGFnJzogbnVsbCxcbiAgICAgICAgJ3RyYWNrZXJzV2hpdGVsaXN0VGVtcG9yYXJ5LWV0YWcnOiBudWxsLFxuICAgIH07XG4gICAgbGV0IHN5bmNOZWVkZWQgPSBmYWxzZTtcbiAgICBmb3IgKGNvbnN0IGxlZ2FjeUtleSBpbiBsZWdhY3lLZXlzKSB7XG4gICAgICAgIGNvbnN0IGtleSA9IGxlZ2FjeUtleXNbbGVnYWN5S2V5XTtcbiAgICAgICAgaWYgKCEobGVnYWN5S2V5IGluIHNldHRpbmdzKSkge1xuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgc3luY05lZWRlZCA9IHRydWU7XG4gICAgICAgIGNvbnN0IGxlZ2FjeVZhbHVlID0gc2V0dGluZ3NbbGVnYWN5S2V5XTtcbiAgICAgICAgaWYgKGtleSAmJiBsZWdhY3lWYWx1ZSkge1xuICAgICAgICAgICAgc2V0dGluZ3Nba2V5XSA9IGxlZ2FjeVZhbHVlO1xuICAgICAgICB9XG4gICAgICAgIGRlbGV0ZSBzZXR0aW5nc1tsZWdhY3lLZXldO1xuICAgIH1cbiAgICBpZiAoc3luY05lZWRlZCkge1xuICAgICAgICBzeW5jU2V0dGluZ1RvbG9jYWxTdG9yYWdlKCk7XG4gICAgfVxufVxuXG5hc3luYyBmdW5jdGlvbiBidWlsZFNldHRpbmdzRnJvbUxvY2FsU3RvcmFnZSgpIHtcbiAgICBjb25zdCByZXN1bHRzID0gYXdhaXQgYnJvd3NlcldyYXBwZXIuZ2V0RnJvbVN0b3JhZ2UoWydzZXR0aW5ncyddKTtcbiAgICAvLyBjb3B5IG92ZXIgc2F2ZWQgc2V0dGluZ3MgZnJvbSBzdG9yYWdlXG4gICAgaWYgKCFyZXN1bHRzKSByZXR1cm47XG4gICAgc2V0dGluZ3MgPSBicm93c2VyV3JhcHBlci5tZXJnZVNhdmVkU2V0dGluZ3Moc2V0dGluZ3MsIHJlc3VsdHMpO1xuICAgIGNoZWNrRm9yTGVnYWN5S2V5cygpO1xufVxuXG5hc3luYyBmdW5jdGlvbiBidWlsZFNldHRpbmdzRnJvbU1hbmFnZWRTdG9yYWdlKCkge1xuICAgIGNvbnN0IHJlc3VsdHMgPSBhd2FpdCBicm93c2VyV3JhcHBlci5nZXRGcm9tTWFuYWdlZFN0b3JhZ2UoTUFOQUdFRF9TRVRUSU5HUyk7XG4gICAgc2V0dGluZ3MgPSBicm93c2VyV3JhcHBlci5tZXJnZVNhdmVkU2V0dGluZ3Moc2V0dGluZ3MsIHJlc3VsdHMpO1xufVxuXG5mdW5jdGlvbiBidWlsZFNldHRpbmdzRnJvbURlZmF1bHRzKCkge1xuICAgIC8vIGluaXRpYWwgc2V0dGluZ3MgYXJlIGEgY29weSBvZiBkZWZhdWx0IHNldHRpbmdzXG4gICAgc2V0dGluZ3MgPSBPYmplY3QuYXNzaWduKHt9LCBkZWZhdWx0U2V0dGluZ3MpO1xufVxuXG5mdW5jdGlvbiBzeW5jU2V0dGluZ1RvbG9jYWxTdG9yYWdlKCkge1xuICAgIHJldHVybiBicm93c2VyV3JhcHBlci5zeW5jVG9TdG9yYWdlKHsgc2V0dGluZ3MgfSk7XG59XG5cbmZ1bmN0aW9uIGdldFNldHRpbmcobmFtZSkge1xuICAgIGlmICghaXNSZWFkeSkge1xuICAgICAgICBjb25zb2xlLndhcm4oYFNldHRpbmdzOiBnZXRTZXR0aW5nKCkgU2V0dGluZ3Mgbm90IGxvYWRlZDogJHtuYW1lfWApO1xuICAgICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgLy8gbGV0IGFsbCBhbmQgbnVsbCByZXR1cm4gYWxsIHNldHRpbmdzXG4gICAgaWYgKG5hbWUgPT09ICdhbGwnKSBuYW1lID0gbnVsbDtcblxuICAgIGlmIChuYW1lKSB7XG4gICAgICAgIHJldHVybiBzZXR0aW5nc1tuYW1lXTtcbiAgICB9IGVsc2Uge1xuICAgICAgICByZXR1cm4gc2V0dGluZ3M7XG4gICAgfVxufVxuXG5mdW5jdGlvbiB1cGRhdGVTZXR0aW5nKG5hbWUsIHZhbHVlKSB7XG4gICAgaWYgKCFpc1JlYWR5KSB7XG4gICAgICAgIGNvbnNvbGUud2FybihgU2V0dGluZ3M6IHVwZGF0ZVNldHRpbmcoKSBTZXR0aW5nIG5vdCBsb2FkZWQ6ICR7bmFtZX1gKTtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIHNldHRpbmdzW25hbWVdID0gdmFsdWU7XG4gICAgc3luY1NldHRpbmdUb2xvY2FsU3RvcmFnZSgpLnRoZW4oKCkgPT4ge1xuICAgICAgICBvblNldHRpbmdVcGRhdGUuZGlzcGF0Y2hFdmVudChuZXcgQ3VzdG9tRXZlbnQobmFtZSwgeyBkZXRhaWw6IHZhbHVlIH0pKTtcbiAgICB9KTtcbn1cblxuZnVuY3Rpb24gaW5jcmVtZW50TnVtZXJpY1NldHRpbmcobmFtZSwgaW5jcmVtZW50ID0gMSkge1xuICAgIGlmICghaXNSZWFkeSkge1xuICAgICAgICBjb25zb2xlLndhcm4oJ1NldHRpbmdzOiBpbmNyZW1lbnROdW1lcmljU2V0dGluZygpIFNldHRpbmcgbm90IGxvYWRlZDonLCBuYW1lKTtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGxldCB2YWx1ZSA9IHNldHRpbmdzW25hbWVdO1xuICAgIGlmICh0eXBlb2YgdmFsdWUgIT09ICdudW1iZXInIHx8IGlzTmFOKHZhbHVlKSkge1xuICAgICAgICB2YWx1ZSA9IDA7XG4gICAgfVxuXG4gICAgdXBkYXRlU2V0dGluZyhuYW1lLCB2YWx1ZSArIGluY3JlbWVudCk7XG59XG5cbmZ1bmN0aW9uIHJlbW92ZVNldHRpbmcobmFtZSkge1xuICAgIGlmICghaXNSZWFkeSkge1xuICAgICAgICBjb25zb2xlLndhcm4oYFNldHRpbmdzOiByZW1vdmVTZXR0aW5nKCkgU2V0dGluZyBub3QgbG9hZGVkOiAke25hbWV9YCk7XG4gICAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKHNldHRpbmdzW25hbWVdKSB7XG4gICAgICAgIGRlbGV0ZSBzZXR0aW5nc1tuYW1lXTtcbiAgICAgICAgc3luY1NldHRpbmdUb2xvY2FsU3RvcmFnZSgpO1xuICAgIH1cbn1cblxuZnVuY3Rpb24gbG9nU2V0dGluZ3MoKSB7XG4gICAgYnJvd3NlcldyYXBwZXIuZ2V0RnJvbVN0b3JhZ2UoWydzZXR0aW5ncyddKS50aGVuKChzKSA9PiB7XG4gICAgICAgIGNvbnNvbGUubG9nKHMuc2V0dGluZ3MpO1xuICAgIH0pO1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IHtcbiAgICBnZXRTZXR0aW5nLFxuICAgIHVwZGF0ZVNldHRpbmcsXG4gICAgaW5jcmVtZW50TnVtZXJpY1NldHRpbmcsXG4gICAgcmVtb3ZlU2V0dGluZyxcbiAgICBsb2dTZXR0aW5ncyxcbiAgICByZWFkeSxcbiAgICBvblNldHRpbmdVcGRhdGUsXG59O1xuIiwgIm1vZHVsZS5leHBvcnRzID0gKHVhU3RyaW5nKSA9PiB7XG4gICAgaWYgKCFnbG9iYWxUaGlzLm5hdmlnYXRvcikgcmV0dXJuIHt9O1xuXG4gICAgaWYgKCF1YVN0cmluZykgdWFTdHJpbmcgPSBnbG9iYWxUaGlzLm5hdmlnYXRvci51c2VyQWdlbnQ7XG5cbiAgICBsZXQgYnJvd3NlcjtcbiAgICBsZXQgdmVyc2lvbjtcblxuICAgIHRyeSB7XG4gICAgICAgIGxldCBwYXJzZWRVYVBhcnRzID0gdWFTdHJpbmcubWF0Y2goLyhGaXJlZm94fENocm9tZXxFZGcpXFwvKFswLTldKykvKTtcbiAgICAgICAgY29uc3QgaXNFZGdlID0gLyhFZGdlPylcXC8oWzAtOV0rKS87XG4gICAgICAgIGNvbnN0IGlzT3BlcmEgPSAvKE9QUilcXC8oWzAtOV0rKS87XG4gICAgICAgIC8vIEFib3ZlIHJlZ2V4IG1hdGNoZXMgb24gQ2hyb21lIGZpcnN0LCBzbyBjaGVjayBpZiB0aGlzIGlzIHJlYWxseSBFZGdlXG4gICAgICAgIGlmICh1YVN0cmluZy5tYXRjaChpc0VkZ2UpKSB7XG4gICAgICAgICAgICBwYXJzZWRVYVBhcnRzID0gdWFTdHJpbmcubWF0Y2goaXNFZGdlKTtcbiAgICAgICAgfSBlbHNlIGlmICh1YVN0cmluZy5tYXRjaChpc09wZXJhKSkge1xuICAgICAgICAgICAgcGFyc2VkVWFQYXJ0cyA9IHVhU3RyaW5nLm1hdGNoKGlzT3BlcmEpO1xuICAgICAgICAgICAgcGFyc2VkVWFQYXJ0c1sxXSA9ICdPcGVyYSc7XG4gICAgICAgIH1cbiAgICAgICAgYnJvd3NlciA9IHBhcnNlZFVhUGFydHNbMV07XG4gICAgICAgIHZlcnNpb24gPSBwYXJzZWRVYVBhcnRzWzJdO1xuXG4gICAgICAgIC8vIEJyYXZlIGRvZXNuJ3QgaW5jbHVkZSBhbnkgaW5mb3JtYXRpb24gaW4gdGhlIFVzZXJBZ2VudFxuICAgICAgICAvLyBAdHMtaWdub3JlXG4gICAgICAgIGlmIChnbG9iYWxUaGlzLm5hdmlnYXRvci5icmF2ZSkge1xuICAgICAgICAgICAgYnJvd3NlciA9ICdCcmF2ZSc7XG4gICAgICAgIH1cbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIC8vIHVubGlrZWx5LCBwcmV2ZW50IGV4dGVuc2lvbiBmcm9tIGV4cGxvZGluZyBpZiB3ZSBkb24ndCByZWNvZ25pemUgdGhlIFVBXG4gICAgICAgIGJyb3dzZXIgPSB2ZXJzaW9uID0gJyc7XG4gICAgfVxuXG4gICAgbGV0IG9zID0gJ28nO1xuICAgIGlmIChnbG9iYWxUaGlzLm5hdmlnYXRvci51c2VyQWdlbnQuaW5kZXhPZignV2luZG93cycpICE9PSAtMSkgb3MgPSAndyc7XG4gICAgaWYgKGdsb2JhbFRoaXMubmF2aWdhdG9yLnVzZXJBZ2VudC5pbmRleE9mKCdNYWMnKSAhPT0gLTEpIG9zID0gJ20nO1xuICAgIGlmIChnbG9iYWxUaGlzLm5hdmlnYXRvci51c2VyQWdlbnQuaW5kZXhPZignTGludXgnKSAhPT0gLTEpIG9zID0gJ2wnO1xuXG4gICAgcmV0dXJuIHtcbiAgICAgICAgb3MsXG4gICAgICAgIGJyb3dzZXIsXG4gICAgICAgIHZlcnNpb24sXG4gICAgfTtcbn07XG4iLCAiLyogZXNsaW50LWRpc2FibGUgKi9cbi8vIEB0cy1ub2NoZWNrXG4vKlxuICogW2pzLXNoYTFde0BsaW5rIGh0dHBzOi8vZ2l0aHViLmNvbS9lbW4xNzgvanMtc2hhMX1cbiAqXG4gKiBAdmVyc2lvbiAwLjYuMFxuICogQGF1dGhvciBDaGVuLCBZaS1DeXVhbiBbZW1uMTc4QGdtYWlsLmNvbV1cbiAqIEBjb3B5cmlnaHQgQ2hlbiwgWWktQ3l1YW4gMjAxNC0yMDE3XG4gKiBAbGljZW5zZSBNSVRcbiAqL1xuLypqc2xpbnQgYml0d2lzZTogdHJ1ZSAqL1xuKGZ1bmN0aW9uICgpIHtcbiAgICAndXNlIHN0cmljdCc7XG5cbiAgICB2YXIgcm9vdCA9IHR5cGVvZiB3aW5kb3cgPT09ICdvYmplY3QnID8gd2luZG93IDoge307XG4gICAgdmFyIE5PREVfSlMgPSAhcm9vdC5KU19TSEExX05PX05PREVfSlMgJiYgdHlwZW9mIHByb2Nlc3MgPT09ICdvYmplY3QnICYmIHByb2Nlc3MudmVyc2lvbnMgJiYgcHJvY2Vzcy52ZXJzaW9ucy5ub2RlO1xuICAgIGlmIChOT0RFX0pTKSB7XG4gICAgICAgIHJvb3QgPSBnbG9iYWw7XG4gICAgfVxuICAgIHZhciBDT01NT05fSlMgPSAhcm9vdC5KU19TSEExX05PX0NPTU1PTl9KUyAmJiB0eXBlb2YgbW9kdWxlID09PSAnb2JqZWN0JyAmJiBtb2R1bGUuZXhwb3J0cztcbiAgICB2YXIgQU1EID0gdHlwZW9mIGRlZmluZSA9PT0gJ2Z1bmN0aW9uJyAmJiBkZWZpbmUuYW1kO1xuICAgIHZhciBIRVhfQ0hBUlMgPSAnMDEyMzQ1Njc4OWFiY2RlZicuc3BsaXQoJycpO1xuICAgIHZhciBFWFRSQSA9IFstMjE0NzQ4MzY0OCwgODM4ODYwOCwgMzI3NjgsIDEyOF07XG4gICAgdmFyIFNISUZUID0gWzI0LCAxNiwgOCwgMF07XG4gICAgdmFyIE9VVFBVVF9UWVBFUyA9IFsnaGV4JywgJ2FycmF5JywgJ2RpZ2VzdCcsICdhcnJheUJ1ZmZlciddO1xuXG4gICAgdmFyIGJsb2NrcyA9IFtdO1xuXG4gICAgdmFyIGNyZWF0ZU91dHB1dE1ldGhvZCA9IGZ1bmN0aW9uIChvdXRwdXRUeXBlKSB7XG4gICAgICAgIHJldHVybiBmdW5jdGlvbiAobWVzc2FnZSkge1xuICAgICAgICAgICAgcmV0dXJuIG5ldyBTaGExKHRydWUpLnVwZGF0ZShtZXNzYWdlKVtvdXRwdXRUeXBlXSgpO1xuICAgICAgICB9O1xuICAgIH07XG5cbiAgICB2YXIgY3JlYXRlTWV0aG9kID0gZnVuY3Rpb24gKCkge1xuICAgICAgICB2YXIgbWV0aG9kID0gY3JlYXRlT3V0cHV0TWV0aG9kKCdoZXgnKTtcbiAgICAgICAgaWYgKE5PREVfSlMpIHtcbiAgICAgICAgICAgIG1ldGhvZCA9IG5vZGVXcmFwKG1ldGhvZCk7XG4gICAgICAgIH1cbiAgICAgICAgbWV0aG9kLmNyZWF0ZSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHJldHVybiBuZXcgU2hhMSgpO1xuICAgICAgICB9O1xuICAgICAgICBtZXRob2QudXBkYXRlID0gZnVuY3Rpb24gKG1lc3NhZ2UpIHtcbiAgICAgICAgICAgIHJldHVybiBtZXRob2QuY3JlYXRlKCkudXBkYXRlKG1lc3NhZ2UpO1xuICAgICAgICB9O1xuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IE9VVFBVVF9UWVBFUy5sZW5ndGg7ICsraSkge1xuICAgICAgICAgICAgdmFyIHR5cGUgPSBPVVRQVVRfVFlQRVNbaV07XG4gICAgICAgICAgICBtZXRob2RbdHlwZV0gPSBjcmVhdGVPdXRwdXRNZXRob2QodHlwZSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIG1ldGhvZDtcbiAgICB9O1xuXG4gICAgdmFyIG5vZGVXcmFwID0gZnVuY3Rpb24gKG1ldGhvZCkge1xuICAgICAgICB2YXIgY3J5cHRvID0gZXZhbChcInJlcXVpcmUoJ2NyeXB0bycpXCIpO1xuICAgICAgICB2YXIgQnVmZmVyID0gZXZhbChcInJlcXVpcmUoJ2J1ZmZlcicpLkJ1ZmZlclwiKTtcbiAgICAgICAgdmFyIG5vZGVNZXRob2QgPSBmdW5jdGlvbiAobWVzc2FnZSkge1xuICAgICAgICAgICAgaWYgKHR5cGVvZiBtZXNzYWdlID09PSAnc3RyaW5nJykge1xuICAgICAgICAgICAgICAgIHJldHVybiBjcnlwdG8uY3JlYXRlSGFzaCgnc2hhMScpLnVwZGF0ZShtZXNzYWdlLCAndXRmOCcpLmRpZ2VzdCgnaGV4Jyk7XG4gICAgICAgICAgICB9IGVsc2UgaWYgKG1lc3NhZ2UuY29uc3RydWN0b3IgPT09IEFycmF5QnVmZmVyKSB7XG4gICAgICAgICAgICAgICAgbWVzc2FnZSA9IG5ldyBVaW50OEFycmF5KG1lc3NhZ2UpO1xuICAgICAgICAgICAgfSBlbHNlIGlmIChtZXNzYWdlLmxlbmd0aCA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIG1ldGhvZChtZXNzYWdlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBjcnlwdG8uY3JlYXRlSGFzaCgnc2hhMScpLnVwZGF0ZShuZXcgQnVmZmVyKG1lc3NhZ2UpKS5kaWdlc3QoJ2hleCcpO1xuICAgICAgICB9O1xuICAgICAgICByZXR1cm4gbm9kZU1ldGhvZDtcbiAgICB9O1xuXG4gICAgZnVuY3Rpb24gU2hhMShzaGFyZWRNZW1vcnkpIHtcbiAgICAgICAgaWYgKHNoYXJlZE1lbW9yeSkge1xuICAgICAgICAgICAgYmxvY2tzWzBdID1cbiAgICAgICAgICAgICAgICBibG9ja3NbMTZdID1cbiAgICAgICAgICAgICAgICBibG9ja3NbMV0gPVxuICAgICAgICAgICAgICAgIGJsb2Nrc1syXSA9XG4gICAgICAgICAgICAgICAgYmxvY2tzWzNdID1cbiAgICAgICAgICAgICAgICBibG9ja3NbNF0gPVxuICAgICAgICAgICAgICAgIGJsb2Nrc1s1XSA9XG4gICAgICAgICAgICAgICAgYmxvY2tzWzZdID1cbiAgICAgICAgICAgICAgICBibG9ja3NbN10gPVxuICAgICAgICAgICAgICAgIGJsb2Nrc1s4XSA9XG4gICAgICAgICAgICAgICAgYmxvY2tzWzldID1cbiAgICAgICAgICAgICAgICBibG9ja3NbMTBdID1cbiAgICAgICAgICAgICAgICBibG9ja3NbMTFdID1cbiAgICAgICAgICAgICAgICBibG9ja3NbMTJdID1cbiAgICAgICAgICAgICAgICBibG9ja3NbMTNdID1cbiAgICAgICAgICAgICAgICBibG9ja3NbMTRdID1cbiAgICAgICAgICAgICAgICBibG9ja3NbMTVdID1cbiAgICAgICAgICAgICAgICAgICAgMDtcbiAgICAgICAgICAgIHRoaXMuYmxvY2tzID0gYmxvY2tzO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5ibG9ja3MgPSBbMCwgMCwgMCwgMCwgMCwgMCwgMCwgMCwgMCwgMCwgMCwgMCwgMCwgMCwgMCwgMCwgMF07XG4gICAgICAgIH1cblxuICAgICAgICB0aGlzLmgwID0gMHg2NzQ1MjMwMTtcbiAgICAgICAgdGhpcy5oMSA9IDB4ZWZjZGFiODk7XG4gICAgICAgIHRoaXMuaDIgPSAweDk4YmFkY2ZlO1xuICAgICAgICB0aGlzLmgzID0gMHgxMDMyNTQ3NjtcbiAgICAgICAgdGhpcy5oNCA9IDB4YzNkMmUxZjA7XG5cbiAgICAgICAgdGhpcy5ibG9jayA9IHRoaXMuc3RhcnQgPSB0aGlzLmJ5dGVzID0gdGhpcy5oQnl0ZXMgPSAwO1xuICAgICAgICB0aGlzLmZpbmFsaXplZCA9IHRoaXMuaGFzaGVkID0gZmFsc2U7XG4gICAgICAgIHRoaXMuZmlyc3QgPSB0cnVlO1xuICAgIH1cblxuICAgIFNoYTEucHJvdG90eXBlLnVwZGF0ZSA9IGZ1bmN0aW9uIChtZXNzYWdlKSB7XG4gICAgICAgIGlmICh0aGlzLmZpbmFsaXplZCkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIHZhciBub3RTdHJpbmcgPSB0eXBlb2YgbWVzc2FnZSAhPT0gJ3N0cmluZyc7XG4gICAgICAgIGlmIChub3RTdHJpbmcgJiYgbWVzc2FnZS5jb25zdHJ1Y3RvciA9PT0gcm9vdC5BcnJheUJ1ZmZlcikge1xuICAgICAgICAgICAgbWVzc2FnZSA9IG5ldyBVaW50OEFycmF5KG1lc3NhZ2UpO1xuICAgICAgICB9XG4gICAgICAgIHZhciBjb2RlLFxuICAgICAgICAgICAgaW5kZXggPSAwLFxuICAgICAgICAgICAgaSxcbiAgICAgICAgICAgIGxlbmd0aCA9IG1lc3NhZ2UubGVuZ3RoIHx8IDAsXG4gICAgICAgICAgICBibG9ja3MgPSB0aGlzLmJsb2NrcztcblxuICAgICAgICB3aGlsZSAoaW5kZXggPCBsZW5ndGgpIHtcbiAgICAgICAgICAgIGlmICh0aGlzLmhhc2hlZCkge1xuICAgICAgICAgICAgICAgIHRoaXMuaGFzaGVkID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgYmxvY2tzWzBdID0gdGhpcy5ibG9jaztcbiAgICAgICAgICAgICAgICBibG9ja3NbMTZdID1cbiAgICAgICAgICAgICAgICAgICAgYmxvY2tzWzFdID1cbiAgICAgICAgICAgICAgICAgICAgYmxvY2tzWzJdID1cbiAgICAgICAgICAgICAgICAgICAgYmxvY2tzWzNdID1cbiAgICAgICAgICAgICAgICAgICAgYmxvY2tzWzRdID1cbiAgICAgICAgICAgICAgICAgICAgYmxvY2tzWzVdID1cbiAgICAgICAgICAgICAgICAgICAgYmxvY2tzWzZdID1cbiAgICAgICAgICAgICAgICAgICAgYmxvY2tzWzddID1cbiAgICAgICAgICAgICAgICAgICAgYmxvY2tzWzhdID1cbiAgICAgICAgICAgICAgICAgICAgYmxvY2tzWzldID1cbiAgICAgICAgICAgICAgICAgICAgYmxvY2tzWzEwXSA9XG4gICAgICAgICAgICAgICAgICAgIGJsb2Nrc1sxMV0gPVxuICAgICAgICAgICAgICAgICAgICBibG9ja3NbMTJdID1cbiAgICAgICAgICAgICAgICAgICAgYmxvY2tzWzEzXSA9XG4gICAgICAgICAgICAgICAgICAgIGJsb2Nrc1sxNF0gPVxuICAgICAgICAgICAgICAgICAgICBibG9ja3NbMTVdID1cbiAgICAgICAgICAgICAgICAgICAgICAgIDA7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGlmIChub3RTdHJpbmcpIHtcbiAgICAgICAgICAgICAgICBmb3IgKGkgPSB0aGlzLnN0YXJ0OyBpbmRleCA8IGxlbmd0aCAmJiBpIDwgNjQ7ICsraW5kZXgpIHtcbiAgICAgICAgICAgICAgICAgICAgYmxvY2tzW2kgPj4gMl0gfD0gbWVzc2FnZVtpbmRleF0gPDwgU0hJRlRbaSsrICYgM107XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBmb3IgKGkgPSB0aGlzLnN0YXJ0OyBpbmRleCA8IGxlbmd0aCAmJiBpIDwgNjQ7ICsraW5kZXgpIHtcbiAgICAgICAgICAgICAgICAgICAgY29kZSA9IG1lc3NhZ2UuY2hhckNvZGVBdChpbmRleCk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChjb2RlIDwgMHg4MCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2tzW2kgPj4gMl0gfD0gY29kZSA8PCBTSElGVFtpKysgJiAzXTtcbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIGlmIChjb2RlIDwgMHg4MDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGJsb2Nrc1tpID4+IDJdIHw9ICgweGMwIHwgKGNvZGUgPj4gNikpIDw8IFNISUZUW2krKyAmIDNdO1xuICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2tzW2kgPj4gMl0gfD0gKDB4ODAgfCAoY29kZSAmIDB4M2YpKSA8PCBTSElGVFtpKysgJiAzXTtcbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIGlmIChjb2RlIDwgMHhkODAwIHx8IGNvZGUgPj0gMHhlMDAwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBibG9ja3NbaSA+PiAyXSB8PSAoMHhlMCB8IChjb2RlID4+IDEyKSkgPDwgU0hJRlRbaSsrICYgM107XG4gICAgICAgICAgICAgICAgICAgICAgICBibG9ja3NbaSA+PiAyXSB8PSAoMHg4MCB8ICgoY29kZSA+PiA2KSAmIDB4M2YpKSA8PCBTSElGVFtpKysgJiAzXTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGJsb2Nrc1tpID4+IDJdIHw9ICgweDgwIHwgKGNvZGUgJiAweDNmKSkgPDwgU0hJRlRbaSsrICYgM107XG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb2RlID0gMHgxMDAwMCArICgoKGNvZGUgJiAweDNmZikgPDwgMTApIHwgKG1lc3NhZ2UuY2hhckNvZGVBdCgrK2luZGV4KSAmIDB4M2ZmKSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBibG9ja3NbaSA+PiAyXSB8PSAoMHhmMCB8IChjb2RlID4+IDE4KSkgPDwgU0hJRlRbaSsrICYgM107XG4gICAgICAgICAgICAgICAgICAgICAgICBibG9ja3NbaSA+PiAyXSB8PSAoMHg4MCB8ICgoY29kZSA+PiAxMikgJiAweDNmKSkgPDwgU0hJRlRbaSsrICYgM107XG4gICAgICAgICAgICAgICAgICAgICAgICBibG9ja3NbaSA+PiAyXSB8PSAoMHg4MCB8ICgoY29kZSA+PiA2KSAmIDB4M2YpKSA8PCBTSElGVFtpKysgJiAzXTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGJsb2Nrc1tpID4+IDJdIHw9ICgweDgwIHwgKGNvZGUgJiAweDNmKSkgPDwgU0hJRlRbaSsrICYgM107XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHRoaXMubGFzdEJ5dGVJbmRleCA9IGk7XG4gICAgICAgICAgICB0aGlzLmJ5dGVzICs9IGkgLSB0aGlzLnN0YXJ0O1xuICAgICAgICAgICAgaWYgKGkgPj0gNjQpIHtcbiAgICAgICAgICAgICAgICB0aGlzLmJsb2NrID0gYmxvY2tzWzE2XTtcbiAgICAgICAgICAgICAgICB0aGlzLnN0YXJ0ID0gaSAtIDY0O1xuICAgICAgICAgICAgICAgIHRoaXMuaGFzaCgpO1xuICAgICAgICAgICAgICAgIHRoaXMuaGFzaGVkID0gdHJ1ZTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgdGhpcy5zdGFydCA9IGk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRoaXMuYnl0ZXMgPiA0Mjk0OTY3Mjk1KSB7XG4gICAgICAgICAgICB0aGlzLmhCeXRlcyArPSAodGhpcy5ieXRlcyAvIDQyOTQ5NjcyOTYpIDw8IDA7XG4gICAgICAgICAgICB0aGlzLmJ5dGVzID0gdGhpcy5ieXRlcyAlIDQyOTQ5NjcyOTY7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfTtcblxuICAgIFNoYTEucHJvdG90eXBlLmZpbmFsaXplID0gZnVuY3Rpb24gKCkge1xuICAgICAgICBpZiAodGhpcy5maW5hbGl6ZWQpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLmZpbmFsaXplZCA9IHRydWU7XG4gICAgICAgIHZhciBibG9ja3MgPSB0aGlzLmJsb2NrcyxcbiAgICAgICAgICAgIGkgPSB0aGlzLmxhc3RCeXRlSW5kZXg7XG4gICAgICAgIGJsb2Nrc1sxNl0gPSB0aGlzLmJsb2NrO1xuICAgICAgICBibG9ja3NbaSA+PiAyXSB8PSBFWFRSQVtpICYgM107XG4gICAgICAgIHRoaXMuYmxvY2sgPSBibG9ja3NbMTZdO1xuICAgICAgICBpZiAoaSA+PSA1Nikge1xuICAgICAgICAgICAgaWYgKCF0aGlzLmhhc2hlZCkge1xuICAgICAgICAgICAgICAgIHRoaXMuaGFzaCgpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgYmxvY2tzWzBdID0gdGhpcy5ibG9jaztcbiAgICAgICAgICAgIGJsb2Nrc1sxNl0gPVxuICAgICAgICAgICAgICAgIGJsb2Nrc1sxXSA9XG4gICAgICAgICAgICAgICAgYmxvY2tzWzJdID1cbiAgICAgICAgICAgICAgICBibG9ja3NbM10gPVxuICAgICAgICAgICAgICAgIGJsb2Nrc1s0XSA9XG4gICAgICAgICAgICAgICAgYmxvY2tzWzVdID1cbiAgICAgICAgICAgICAgICBibG9ja3NbNl0gPVxuICAgICAgICAgICAgICAgIGJsb2Nrc1s3XSA9XG4gICAgICAgICAgICAgICAgYmxvY2tzWzhdID1cbiAgICAgICAgICAgICAgICBibG9ja3NbOV0gPVxuICAgICAgICAgICAgICAgIGJsb2Nrc1sxMF0gPVxuICAgICAgICAgICAgICAgIGJsb2Nrc1sxMV0gPVxuICAgICAgICAgICAgICAgIGJsb2Nrc1sxMl0gPVxuICAgICAgICAgICAgICAgIGJsb2Nrc1sxM10gPVxuICAgICAgICAgICAgICAgIGJsb2Nrc1sxNF0gPVxuICAgICAgICAgICAgICAgIGJsb2Nrc1sxNV0gPVxuICAgICAgICAgICAgICAgICAgICAwO1xuICAgICAgICB9XG4gICAgICAgIGJsb2Nrc1sxNF0gPSAodGhpcy5oQnl0ZXMgPDwgMykgfCAodGhpcy5ieXRlcyA+Pj4gMjkpO1xuICAgICAgICBibG9ja3NbMTVdID0gdGhpcy5ieXRlcyA8PCAzO1xuICAgICAgICB0aGlzLmhhc2goKTtcbiAgICB9O1xuXG4gICAgU2hhMS5wcm90b3R5cGUuaGFzaCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdmFyIGEgPSB0aGlzLmgwLFxuICAgICAgICAgICAgYiA9IHRoaXMuaDEsXG4gICAgICAgICAgICBjID0gdGhpcy5oMixcbiAgICAgICAgICAgIGQgPSB0aGlzLmgzLFxuICAgICAgICAgICAgZSA9IHRoaXMuaDQ7XG4gICAgICAgIHZhciBmLFxuICAgICAgICAgICAgaixcbiAgICAgICAgICAgIHQsXG4gICAgICAgICAgICBibG9ja3MgPSB0aGlzLmJsb2NrcztcblxuICAgICAgICBmb3IgKGogPSAxNjsgaiA8IDgwOyArK2opIHtcbiAgICAgICAgICAgIHQgPSBibG9ja3NbaiAtIDNdIF4gYmxvY2tzW2ogLSA4XSBeIGJsb2Nrc1tqIC0gMTRdIF4gYmxvY2tzW2ogLSAxNl07XG4gICAgICAgICAgICBibG9ja3Nbal0gPSAodCA8PCAxKSB8ICh0ID4+PiAzMSk7XG4gICAgICAgIH1cblxuICAgICAgICBmb3IgKGogPSAwOyBqIDwgMjA7IGogKz0gNSkge1xuICAgICAgICAgICAgZiA9IChiICYgYykgfCAofmIgJiBkKTtcbiAgICAgICAgICAgIHQgPSAoYSA8PCA1KSB8IChhID4+PiAyNyk7XG4gICAgICAgICAgICBlID0gKHQgKyBmICsgZSArIDE1MTg1MDAyNDkgKyBibG9ja3Nbal0pIDw8IDA7XG4gICAgICAgICAgICBiID0gKGIgPDwgMzApIHwgKGIgPj4+IDIpO1xuXG4gICAgICAgICAgICBmID0gKGEgJiBiKSB8ICh+YSAmIGMpO1xuICAgICAgICAgICAgdCA9IChlIDw8IDUpIHwgKGUgPj4+IDI3KTtcbiAgICAgICAgICAgIGQgPSAodCArIGYgKyBkICsgMTUxODUwMDI0OSArIGJsb2Nrc1tqICsgMV0pIDw8IDA7XG4gICAgICAgICAgICBhID0gKGEgPDwgMzApIHwgKGEgPj4+IDIpO1xuXG4gICAgICAgICAgICBmID0gKGUgJiBhKSB8ICh+ZSAmIGIpO1xuICAgICAgICAgICAgdCA9IChkIDw8IDUpIHwgKGQgPj4+IDI3KTtcbiAgICAgICAgICAgIGMgPSAodCArIGYgKyBjICsgMTUxODUwMDI0OSArIGJsb2Nrc1tqICsgMl0pIDw8IDA7XG4gICAgICAgICAgICBlID0gKGUgPDwgMzApIHwgKGUgPj4+IDIpO1xuXG4gICAgICAgICAgICBmID0gKGQgJiBlKSB8ICh+ZCAmIGEpO1xuICAgICAgICAgICAgdCA9IChjIDw8IDUpIHwgKGMgPj4+IDI3KTtcbiAgICAgICAgICAgIGIgPSAodCArIGYgKyBiICsgMTUxODUwMDI0OSArIGJsb2Nrc1tqICsgM10pIDw8IDA7XG4gICAgICAgICAgICBkID0gKGQgPDwgMzApIHwgKGQgPj4+IDIpO1xuXG4gICAgICAgICAgICBmID0gKGMgJiBkKSB8ICh+YyAmIGUpO1xuICAgICAgICAgICAgdCA9IChiIDw8IDUpIHwgKGIgPj4+IDI3KTtcbiAgICAgICAgICAgIGEgPSAodCArIGYgKyBhICsgMTUxODUwMDI0OSArIGJsb2Nrc1tqICsgNF0pIDw8IDA7XG4gICAgICAgICAgICBjID0gKGMgPDwgMzApIHwgKGMgPj4+IDIpO1xuICAgICAgICB9XG5cbiAgICAgICAgZm9yICg7IGogPCA0MDsgaiArPSA1KSB7XG4gICAgICAgICAgICBmID0gYiBeIGMgXiBkO1xuICAgICAgICAgICAgdCA9IChhIDw8IDUpIHwgKGEgPj4+IDI3KTtcbiAgICAgICAgICAgIGUgPSAodCArIGYgKyBlICsgMTg1OTc3NTM5MyArIGJsb2Nrc1tqXSkgPDwgMDtcbiAgICAgICAgICAgIGIgPSAoYiA8PCAzMCkgfCAoYiA+Pj4gMik7XG5cbiAgICAgICAgICAgIGYgPSBhIF4gYiBeIGM7XG4gICAgICAgICAgICB0ID0gKGUgPDwgNSkgfCAoZSA+Pj4gMjcpO1xuICAgICAgICAgICAgZCA9ICh0ICsgZiArIGQgKyAxODU5Nzc1MzkzICsgYmxvY2tzW2ogKyAxXSkgPDwgMDtcbiAgICAgICAgICAgIGEgPSAoYSA8PCAzMCkgfCAoYSA+Pj4gMik7XG5cbiAgICAgICAgICAgIGYgPSBlIF4gYSBeIGI7XG4gICAgICAgICAgICB0ID0gKGQgPDwgNSkgfCAoZCA+Pj4gMjcpO1xuICAgICAgICAgICAgYyA9ICh0ICsgZiArIGMgKyAxODU5Nzc1MzkzICsgYmxvY2tzW2ogKyAyXSkgPDwgMDtcbiAgICAgICAgICAgIGUgPSAoZSA8PCAzMCkgfCAoZSA+Pj4gMik7XG5cbiAgICAgICAgICAgIGYgPSBkIF4gZSBeIGE7XG4gICAgICAgICAgICB0ID0gKGMgPDwgNSkgfCAoYyA+Pj4gMjcpO1xuICAgICAgICAgICAgYiA9ICh0ICsgZiArIGIgKyAxODU5Nzc1MzkzICsgYmxvY2tzW2ogKyAzXSkgPDwgMDtcbiAgICAgICAgICAgIGQgPSAoZCA8PCAzMCkgfCAoZCA+Pj4gMik7XG5cbiAgICAgICAgICAgIGYgPSBjIF4gZCBeIGU7XG4gICAgICAgICAgICB0ID0gKGIgPDwgNSkgfCAoYiA+Pj4gMjcpO1xuICAgICAgICAgICAgYSA9ICh0ICsgZiArIGEgKyAxODU5Nzc1MzkzICsgYmxvY2tzW2ogKyA0XSkgPDwgMDtcbiAgICAgICAgICAgIGMgPSAoYyA8PCAzMCkgfCAoYyA+Pj4gMik7XG4gICAgICAgIH1cblxuICAgICAgICBmb3IgKDsgaiA8IDYwOyBqICs9IDUpIHtcbiAgICAgICAgICAgIGYgPSAoYiAmIGMpIHwgKGIgJiBkKSB8IChjICYgZCk7XG4gICAgICAgICAgICB0ID0gKGEgPDwgNSkgfCAoYSA+Pj4gMjcpO1xuICAgICAgICAgICAgZSA9ICh0ICsgZiArIGUgLSAxODk0MDA3NTg4ICsgYmxvY2tzW2pdKSA8PCAwO1xuICAgICAgICAgICAgYiA9IChiIDw8IDMwKSB8IChiID4+PiAyKTtcblxuICAgICAgICAgICAgZiA9IChhICYgYikgfCAoYSAmIGMpIHwgKGIgJiBjKTtcbiAgICAgICAgICAgIHQgPSAoZSA8PCA1KSB8IChlID4+PiAyNyk7XG4gICAgICAgICAgICBkID0gKHQgKyBmICsgZCAtIDE4OTQwMDc1ODggKyBibG9ja3NbaiArIDFdKSA8PCAwO1xuICAgICAgICAgICAgYSA9IChhIDw8IDMwKSB8IChhID4+PiAyKTtcblxuICAgICAgICAgICAgZiA9IChlICYgYSkgfCAoZSAmIGIpIHwgKGEgJiBiKTtcbiAgICAgICAgICAgIHQgPSAoZCA8PCA1KSB8IChkID4+PiAyNyk7XG4gICAgICAgICAgICBjID0gKHQgKyBmICsgYyAtIDE4OTQwMDc1ODggKyBibG9ja3NbaiArIDJdKSA8PCAwO1xuICAgICAgICAgICAgZSA9IChlIDw8IDMwKSB8IChlID4+PiAyKTtcblxuICAgICAgICAgICAgZiA9IChkICYgZSkgfCAoZCAmIGEpIHwgKGUgJiBhKTtcbiAgICAgICAgICAgIHQgPSAoYyA8PCA1KSB8IChjID4+PiAyNyk7XG4gICAgICAgICAgICBiID0gKHQgKyBmICsgYiAtIDE4OTQwMDc1ODggKyBibG9ja3NbaiArIDNdKSA8PCAwO1xuICAgICAgICAgICAgZCA9IChkIDw8IDMwKSB8IChkID4+PiAyKTtcblxuICAgICAgICAgICAgZiA9IChjICYgZCkgfCAoYyAmIGUpIHwgKGQgJiBlKTtcbiAgICAgICAgICAgIHQgPSAoYiA8PCA1KSB8IChiID4+PiAyNyk7XG4gICAgICAgICAgICBhID0gKHQgKyBmICsgYSAtIDE4OTQwMDc1ODggKyBibG9ja3NbaiArIDRdKSA8PCAwO1xuICAgICAgICAgICAgYyA9IChjIDw8IDMwKSB8IChjID4+PiAyKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGZvciAoOyBqIDwgODA7IGogKz0gNSkge1xuICAgICAgICAgICAgZiA9IGIgXiBjIF4gZDtcbiAgICAgICAgICAgIHQgPSAoYSA8PCA1KSB8IChhID4+PiAyNyk7XG4gICAgICAgICAgICBlID0gKHQgKyBmICsgZSAtIDg5OTQ5NzUxNCArIGJsb2Nrc1tqXSkgPDwgMDtcbiAgICAgICAgICAgIGIgPSAoYiA8PCAzMCkgfCAoYiA+Pj4gMik7XG5cbiAgICAgICAgICAgIGYgPSBhIF4gYiBeIGM7XG4gICAgICAgICAgICB0ID0gKGUgPDwgNSkgfCAoZSA+Pj4gMjcpO1xuICAgICAgICAgICAgZCA9ICh0ICsgZiArIGQgLSA4OTk0OTc1MTQgKyBibG9ja3NbaiArIDFdKSA8PCAwO1xuICAgICAgICAgICAgYSA9IChhIDw8IDMwKSB8IChhID4+PiAyKTtcblxuICAgICAgICAgICAgZiA9IGUgXiBhIF4gYjtcbiAgICAgICAgICAgIHQgPSAoZCA8PCA1KSB8IChkID4+PiAyNyk7XG4gICAgICAgICAgICBjID0gKHQgKyBmICsgYyAtIDg5OTQ5NzUxNCArIGJsb2Nrc1tqICsgMl0pIDw8IDA7XG4gICAgICAgICAgICBlID0gKGUgPDwgMzApIHwgKGUgPj4+IDIpO1xuXG4gICAgICAgICAgICBmID0gZCBeIGUgXiBhO1xuICAgICAgICAgICAgdCA9IChjIDw8IDUpIHwgKGMgPj4+IDI3KTtcbiAgICAgICAgICAgIGIgPSAodCArIGYgKyBiIC0gODk5NDk3NTE0ICsgYmxvY2tzW2ogKyAzXSkgPDwgMDtcbiAgICAgICAgICAgIGQgPSAoZCA8PCAzMCkgfCAoZCA+Pj4gMik7XG5cbiAgICAgICAgICAgIGYgPSBjIF4gZCBeIGU7XG4gICAgICAgICAgICB0ID0gKGIgPDwgNSkgfCAoYiA+Pj4gMjcpO1xuICAgICAgICAgICAgYSA9ICh0ICsgZiArIGEgLSA4OTk0OTc1MTQgKyBibG9ja3NbaiArIDRdKSA8PCAwO1xuICAgICAgICAgICAgYyA9IChjIDw8IDMwKSB8IChjID4+PiAyKTtcbiAgICAgICAgfVxuXG4gICAgICAgIHRoaXMuaDAgPSAodGhpcy5oMCArIGEpIDw8IDA7XG4gICAgICAgIHRoaXMuaDEgPSAodGhpcy5oMSArIGIpIDw8IDA7XG4gICAgICAgIHRoaXMuaDIgPSAodGhpcy5oMiArIGMpIDw8IDA7XG4gICAgICAgIHRoaXMuaDMgPSAodGhpcy5oMyArIGQpIDw8IDA7XG4gICAgICAgIHRoaXMuaDQgPSAodGhpcy5oNCArIGUpIDw8IDA7XG4gICAgfTtcblxuICAgIFNoYTEucHJvdG90eXBlLmhleCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdGhpcy5maW5hbGl6ZSgpO1xuXG4gICAgICAgIHZhciBoMCA9IHRoaXMuaDAsXG4gICAgICAgICAgICBoMSA9IHRoaXMuaDEsXG4gICAgICAgICAgICBoMiA9IHRoaXMuaDIsXG4gICAgICAgICAgICBoMyA9IHRoaXMuaDMsXG4gICAgICAgICAgICBoNCA9IHRoaXMuaDQ7XG5cbiAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgIEhFWF9DSEFSU1soaDAgPj4gMjgpICYgMHgwZl0gK1xuICAgICAgICAgICAgSEVYX0NIQVJTWyhoMCA+PiAyNCkgJiAweDBmXSArXG4gICAgICAgICAgICBIRVhfQ0hBUlNbKGgwID4+IDIwKSAmIDB4MGZdICtcbiAgICAgICAgICAgIEhFWF9DSEFSU1soaDAgPj4gMTYpICYgMHgwZl0gK1xuICAgICAgICAgICAgSEVYX0NIQVJTWyhoMCA+PiAxMikgJiAweDBmXSArXG4gICAgICAgICAgICBIRVhfQ0hBUlNbKGgwID4+IDgpICYgMHgwZl0gK1xuICAgICAgICAgICAgSEVYX0NIQVJTWyhoMCA+PiA0KSAmIDB4MGZdICtcbiAgICAgICAgICAgIEhFWF9DSEFSU1toMCAmIDB4MGZdICtcbiAgICAgICAgICAgIEhFWF9DSEFSU1soaDEgPj4gMjgpICYgMHgwZl0gK1xuICAgICAgICAgICAgSEVYX0NIQVJTWyhoMSA+PiAyNCkgJiAweDBmXSArXG4gICAgICAgICAgICBIRVhfQ0hBUlNbKGgxID4+IDIwKSAmIDB4MGZdICtcbiAgICAgICAgICAgIEhFWF9DSEFSU1soaDEgPj4gMTYpICYgMHgwZl0gK1xuICAgICAgICAgICAgSEVYX0NIQVJTWyhoMSA+PiAxMikgJiAweDBmXSArXG4gICAgICAgICAgICBIRVhfQ0hBUlNbKGgxID4+IDgpICYgMHgwZl0gK1xuICAgICAgICAgICAgSEVYX0NIQVJTWyhoMSA+PiA0KSAmIDB4MGZdICtcbiAgICAgICAgICAgIEhFWF9DSEFSU1toMSAmIDB4MGZdICtcbiAgICAgICAgICAgIEhFWF9DSEFSU1soaDIgPj4gMjgpICYgMHgwZl0gK1xuICAgICAgICAgICAgSEVYX0NIQVJTWyhoMiA+PiAyNCkgJiAweDBmXSArXG4gICAgICAgICAgICBIRVhfQ0hBUlNbKGgyID4+IDIwKSAmIDB4MGZdICtcbiAgICAgICAgICAgIEhFWF9DSEFSU1soaDIgPj4gMTYpICYgMHgwZl0gK1xuICAgICAgICAgICAgSEVYX0NIQVJTWyhoMiA+PiAxMikgJiAweDBmXSArXG4gICAgICAgICAgICBIRVhfQ0hBUlNbKGgyID4+IDgpICYgMHgwZl0gK1xuICAgICAgICAgICAgSEVYX0NIQVJTWyhoMiA+PiA0KSAmIDB4MGZdICtcbiAgICAgICAgICAgIEhFWF9DSEFSU1toMiAmIDB4MGZdICtcbiAgICAgICAgICAgIEhFWF9DSEFSU1soaDMgPj4gMjgpICYgMHgwZl0gK1xuICAgICAgICAgICAgSEVYX0NIQVJTWyhoMyA+PiAyNCkgJiAweDBmXSArXG4gICAgICAgICAgICBIRVhfQ0hBUlNbKGgzID4+IDIwKSAmIDB4MGZdICtcbiAgICAgICAgICAgIEhFWF9DSEFSU1soaDMgPj4gMTYpICYgMHgwZl0gK1xuICAgICAgICAgICAgSEVYX0NIQVJTWyhoMyA+PiAxMikgJiAweDBmXSArXG4gICAgICAgICAgICBIRVhfQ0hBUlNbKGgzID4+IDgpICYgMHgwZl0gK1xuICAgICAgICAgICAgSEVYX0NIQVJTWyhoMyA+PiA0KSAmIDB4MGZdICtcbiAgICAgICAgICAgIEhFWF9DSEFSU1toMyAmIDB4MGZdICtcbiAgICAgICAgICAgIEhFWF9DSEFSU1soaDQgPj4gMjgpICYgMHgwZl0gK1xuICAgICAgICAgICAgSEVYX0NIQVJTWyhoNCA+PiAyNCkgJiAweDBmXSArXG4gICAgICAgICAgICBIRVhfQ0hBUlNbKGg0ID4+IDIwKSAmIDB4MGZdICtcbiAgICAgICAgICAgIEhFWF9DSEFSU1soaDQgPj4gMTYpICYgMHgwZl0gK1xuICAgICAgICAgICAgSEVYX0NIQVJTWyhoNCA+PiAxMikgJiAweDBmXSArXG4gICAgICAgICAgICBIRVhfQ0hBUlNbKGg0ID4+IDgpICYgMHgwZl0gK1xuICAgICAgICAgICAgSEVYX0NIQVJTWyhoNCA+PiA0KSAmIDB4MGZdICtcbiAgICAgICAgICAgIEhFWF9DSEFSU1toNCAmIDB4MGZdXG4gICAgICAgICk7XG4gICAgfTtcblxuICAgIFNoYTEucHJvdG90eXBlLnRvU3RyaW5nID0gU2hhMS5wcm90b3R5cGUuaGV4O1xuXG4gICAgU2hhMS5wcm90b3R5cGUuZGlnZXN0ID0gZnVuY3Rpb24gKCkge1xuICAgICAgICB0aGlzLmZpbmFsaXplKCk7XG5cbiAgICAgICAgdmFyIGgwID0gdGhpcy5oMCxcbiAgICAgICAgICAgIGgxID0gdGhpcy5oMSxcbiAgICAgICAgICAgIGgyID0gdGhpcy5oMixcbiAgICAgICAgICAgIGgzID0gdGhpcy5oMyxcbiAgICAgICAgICAgIGg0ID0gdGhpcy5oNDtcblxuICAgICAgICByZXR1cm4gW1xuICAgICAgICAgICAgKGgwID4+IDI0KSAmIDB4ZmYsXG4gICAgICAgICAgICAoaDAgPj4gMTYpICYgMHhmZixcbiAgICAgICAgICAgIChoMCA+PiA4KSAmIDB4ZmYsXG4gICAgICAgICAgICBoMCAmIDB4ZmYsXG4gICAgICAgICAgICAoaDEgPj4gMjQpICYgMHhmZixcbiAgICAgICAgICAgIChoMSA+PiAxNikgJiAweGZmLFxuICAgICAgICAgICAgKGgxID4+IDgpICYgMHhmZixcbiAgICAgICAgICAgIGgxICYgMHhmZixcbiAgICAgICAgICAgIChoMiA+PiAyNCkgJiAweGZmLFxuICAgICAgICAgICAgKGgyID4+IDE2KSAmIDB4ZmYsXG4gICAgICAgICAgICAoaDIgPj4gOCkgJiAweGZmLFxuICAgICAgICAgICAgaDIgJiAweGZmLFxuICAgICAgICAgICAgKGgzID4+IDI0KSAmIDB4ZmYsXG4gICAgICAgICAgICAoaDMgPj4gMTYpICYgMHhmZixcbiAgICAgICAgICAgIChoMyA+PiA4KSAmIDB4ZmYsXG4gICAgICAgICAgICBoMyAmIDB4ZmYsXG4gICAgICAgICAgICAoaDQgPj4gMjQpICYgMHhmZixcbiAgICAgICAgICAgIChoNCA+PiAxNikgJiAweGZmLFxuICAgICAgICAgICAgKGg0ID4+IDgpICYgMHhmZixcbiAgICAgICAgICAgIGg0ICYgMHhmZixcbiAgICAgICAgXTtcbiAgICB9O1xuXG4gICAgU2hhMS5wcm90b3R5cGUuYXJyYXkgPSBTaGExLnByb3RvdHlwZS5kaWdlc3Q7XG5cbiAgICBTaGExLnByb3RvdHlwZS5hcnJheUJ1ZmZlciA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdGhpcy5maW5hbGl6ZSgpO1xuXG4gICAgICAgIHZhciBidWZmZXIgPSBuZXcgQXJyYXlCdWZmZXIoMjApO1xuICAgICAgICB2YXIgZGF0YVZpZXcgPSBuZXcgRGF0YVZpZXcoYnVmZmVyKTtcbiAgICAgICAgZGF0YVZpZXcuc2V0VWludDMyKDAsIHRoaXMuaDApO1xuICAgICAgICBkYXRhVmlldy5zZXRVaW50MzIoNCwgdGhpcy5oMSk7XG4gICAgICAgIGRhdGFWaWV3LnNldFVpbnQzMig4LCB0aGlzLmgyKTtcbiAgICAgICAgZGF0YVZpZXcuc2V0VWludDMyKDEyLCB0aGlzLmgzKTtcbiAgICAgICAgZGF0YVZpZXcuc2V0VWludDMyKDE2LCB0aGlzLmg0KTtcbiAgICAgICAgcmV0dXJuIGJ1ZmZlcjtcbiAgICB9O1xuXG4gICAgdmFyIGV4cG9ydHMgPSBjcmVhdGVNZXRob2QoKTtcblxuICAgIGlmIChDT01NT05fSlMpIHtcbiAgICAgICAgbW9kdWxlLmV4cG9ydHMgPSBleHBvcnRzO1xuICAgIH0gZWxzZSB7XG4gICAgICAgIHJvb3Quc2hhMSA9IGV4cG9ydHM7XG4gICAgICAgIGlmIChBTUQpIHtcbiAgICAgICAgICAgIGRlZmluZShmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGV4cG9ydHM7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgIH1cbn0pKCk7XG4iLCAiLypcbiAqIENvcHlyaWdodCAoQykgMjAxMiwgMjAxNiBEdWNrRHVja0dvLCBJbmMuXG4gKlxuICogTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlLCBWZXJzaW9uIDIuMCAodGhlIFwiTGljZW5zZVwiKTtcbiAqIHlvdSBtYXkgbm90IHVzZSB0aGlzIGZpbGUgZXhjZXB0IGluIGNvbXBsaWFuY2Ugd2l0aCB0aGUgTGljZW5zZS5cbiAqIFlvdSBtYXkgb2J0YWluIGEgY29weSBvZiB0aGUgTGljZW5zZSBhdFxuICpcbiAqICAgICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcbiAqXG4gKiBVbmxlc3MgcmVxdWlyZWQgYnkgYXBwbGljYWJsZSBsYXcgb3IgYWdyZWVkIHRvIGluIHdyaXRpbmcsIHNvZnR3YXJlXG4gKiBkaXN0cmlidXRlZCB1bmRlciB0aGUgTGljZW5zZSBpcyBkaXN0cmlidXRlZCBvbiBhbiBcIkFTIElTXCIgQkFTSVMsXG4gKiBXSVRIT1VUIFdBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBBTlkgS0lORCwgZWl0aGVyIGV4cHJlc3Mgb3IgaW1wbGllZC5cbiAqIFNlZSB0aGUgTGljZW5zZSBmb3IgdGhlIHNwZWNpZmljIGxhbmd1YWdlIGdvdmVybmluZyBwZXJtaXNzaW9ucyBhbmRcbiAqIGxpbWl0YXRpb25zIHVuZGVyIHRoZSBMaWNlbnNlLlxuICovXG5cbi8qXG4gKiBUaGlzIGlzIGEgc3RyaXBwZWQtZG93biB2ZXJzaW9uIG9mIHRoZSBleHRlbnNpb24gZm9yIGVtYmVkZGluZyBpbiBuYXRpdmUgYXBwcy5cbiAqIE11Y2ggb2YgdGhlIGZ1bmN0aW9uYWxpdHkgaXMgb2ZmbG9hZGVkIHRvIHRoZSBuYXRpdmUgYXBwLlxuICovXG4vKiBnbG9iYWwgUkVMT0FERVIgKi9cblxuaW1wb3J0IGJyb3dzZXIgZnJvbSAnd2ViZXh0ZW5zaW9uLXBvbHlmaWxsJztcbmltcG9ydCBDb29raWVQcm9tcHRNYW5hZ2VtZW50IGZyb20gJy4vY29tcG9uZW50cy9jb29raWUtcHJvbXB0LW1hbmFnZW1lbnQnO1xuaW1wb3J0IHsgQ1BNRW1iZWRkZWRNZXNzYWdpbmcgfSBmcm9tICcuL2NvbXBvbmVudHMvY3BtLWVtYmVkZGVkLW1lc3NhZ2luZyc7XG5pbXBvcnQgTWVzc2FnZVJvdXRlciBmcm9tICcuL2NvbXBvbmVudHMvbWVzc2FnZS1yb3V0ZXInO1xuaW1wb3J0IGluaXRSZWxvYWRlciBmcm9tICcuL2RldmJ1aWxkLXJlbG9hZGVyJztcblxuaW1wb3J0IE5hdGl2ZU1lc3NhZ2luZyBmcm9tICcuL2NvbXBvbmVudHMvbmF0aXZlLW1lc3NhZ2luZyc7XG5jb25zdCBuYXRpdmVNZXNzYWdpbmcgPSBuZXcgTmF0aXZlTWVzc2FnaW5nKCdkZGdJbnRlcm5hbEV4dGVuc2lvbicsICdhdXRvY29uc2VudCcsICdjb20uZHVja2R1Y2tnby5tYWNvcy5icm93c2VyJyk7XG5cbi8vIE9uIEFwcGxlLCBKUyBjb25zb2xlIGxvZ3MgZG9uJ3Qgd29yayBpbiBNVjMgZXh0ZW5zaW9ucywgc28gd2UgdHJ5IHRvIHBhc3MgdGhlbSB0byB0aGUgbmF0aXZlIGFwcC5cbmdsb2JhbFRoaXMuYWRkRXZlbnRMaXN0ZW5lcignZXJyb3InLCAoZXZlbnQpID0+IHtcbiAgICBuYXRpdmVNZXNzYWdpbmdcbiAgICAgICAgLm5vdGlmeSgnZXh0ZW5zaW9uRXhjZXB0aW9uJywge1xuICAgICAgICAgICAgbWVzc2FnZTogYFVuY2F1Z2h0IGVycm9yOiAke2V2ZW50LmVycm9yPy5tZXNzYWdlID8/IGV2ZW50Lm1lc3NhZ2V9YCxcbiAgICAgICAgICAgIHN0YWNrOiBldmVudC5lcnJvcj8uc3RhY2ssXG4gICAgICAgIH0pXG4gICAgICAgIC5jYXRjaCgoZSkgPT4ge1xuICAgICAgICAgICAgLyogaWdub3JlIGVycm9ycyAqL1xuICAgICAgICB9KTtcbn0pO1xuXG5nbG9iYWxUaGlzLmFkZEV2ZW50TGlzdGVuZXIoJ3VuaGFuZGxlZHJlamVjdGlvbicsIChldmVudCkgPT4ge1xuICAgIG5hdGl2ZU1lc3NhZ2luZ1xuICAgICAgICAubm90aWZ5KCdleHRlbnNpb25FeGNlcHRpb24nLCB7XG4gICAgICAgICAgICBtZXNzYWdlOiBgVW5oYW5kbGVkIHByb21pc2UgcmVqZWN0aW9uOiAke2V2ZW50LnJlYXNvbn1gLFxuICAgICAgICAgICAgc3RhY2s6IGV2ZW50LnJlYXNvbj8uc3RhY2ssXG4gICAgICAgIH0pXG4gICAgICAgIC5jYXRjaCgoZSkgPT4ge1xuICAgICAgICAgICAgLyogaWdub3JlIGVycm9ycyAqL1xuICAgICAgICB9KTtcbn0pO1xuXG5jb25zdCBjcG1NZXNzYWdpbmcgPSBuZXcgQ1BNRW1iZWRkZWRNZXNzYWdpbmcobmF0aXZlTWVzc2FnaW5nKTtcblxuLy8gTWVzc2FnZVJvdXRlciBzZXRzIHVwIGJyb3dzZXIucnVudGltZS5vbk1lc3NhZ2UgZGlzcGF0Y2hpbmcgZnJvbSB0aGUgc2hhcmVkXG4vLyBtZXNzYWdlIHJlZ2lzdHJ5LiBJdCBtdXN0IGJlIGNyZWF0ZWQgYmVmb3JlIGNvbXBvbmVudHMgdGhhdCByZWdpc3RlciBoYW5kbGVycy5cbmNvbnN0IG1lc3NhZ2luZyA9IG5ldyBNZXNzYWdlUm91dGVyKCk7XG5cbmNvbnN0IGNwbSA9IG5ldyBDb29raWVQcm9tcHRNYW5hZ2VtZW50KHtcbiAgICBjcG1NZXNzYWdpbmcsXG59KTtcblxuLyoqXG4gKiBDb21wb25lbnRzIGV4cG9zZWQgZm9yIGRlYnVnZ2luZyBhbmQgbmF0aXZlIGFwcCBpbnRlZ3JhdGlvblxuICogQHR5cGUge3tcbiAqICBtZXNzYWdpbmc6IE1lc3NhZ2VSb3V0ZXI7XG4gKiAgY3BtOiBDb29raWVQcm9tcHRNYW5hZ2VtZW50O1xuICogfX1cbiAqL1xuY29uc3QgY29tcG9uZW50cyA9IHtcbiAgICBtZXNzYWdpbmcsXG4gICAgY3BtLFxufTtcblxuUHJvbWlzZS5hbGwoW1xuICAgIGJyb3dzZXIuc2NyaXB0aW5nLmdldFJlZ2lzdGVyZWRDb250ZW50U2NyaXB0cygpLFxuICAgIGJyb3dzZXIuYWxhcm1zLmdldEFsbCgpLFxuICAgIC8vIEB0cy1pZ25vcmUgLSBnZXRCeXRlc0luVXNlIGlzIG5vdCBhdmFpbGFibGUgaW4gdGhlIHR5cGVcbiAgICBicm93c2VyLnN0b3JhZ2Uuc2Vzc2lvbi5nZXRCeXRlc0luVXNlKG51bGwpLFxuXSkudGhlbigoW3NjcmlwdHMsIGFsYXJtcywgYnl0ZXNJblNlc3Npb25TdG9yYWdlXSkgPT4ge1xuICAgIC8vIEB0cy1pZ25vcmUgLSBRVU9UQV9CWVRFUyBpcyBub3QgYXZhaWxhYmxlIGluIHRoZSB0eXBlXG4gICAgY29uc3QgcXVvdGFCeXRlcyA9IGJyb3dzZXIuc3RvcmFnZS5zZXNzaW9uLlFVT1RBX0JZVEVTO1xuICAgIGNwbU1lc3NhZ2luZy5sb2dNZXNzYWdlKFxuICAgICAgICBgRHVja0R1Y2tHbyBFbWJlZGRlZCBFeHRlbnNpb24gbG9hZGVkLlxuICAgICAgICBDb250ZW50IHNjcmlwdHM6ICR7SlNPTi5zdHJpbmdpZnkoc2NyaXB0cyl9XG4gICAgICAgIEFsYXJtczogJHtKU09OLnN0cmluZ2lmeShhbGFybXMpfVxuICAgICAgICBDdXJyZW50IHRpbWU6ICR7RGF0ZS5ub3coKX1cbiAgICAgICAgQnl0ZXMgaW4gc2Vzc2lvbiBzdG9yYWdlOiAke2J5dGVzSW5TZXNzaW9uU3RvcmFnZX0gKFF1b3RhICR7cXVvdGFCeXRlc30pXG4gICAgICAgIGAsXG4gICAgKTtcbn0pO1xuLy8gQHRzLWlnbm9yZVxuc2VsZi5jb21wb25lbnRzID0gY29tcG9uZW50cztcblxuUkVMT0FERVIgJiYgaW5pdFJlbG9hZGVyKCk7XG4iLCAidmFyIF9fdHlwZUVycm9yID0gKG1zZykgPT4ge1xuICB0aHJvdyBUeXBlRXJyb3IobXNnKTtcbn07XG52YXIgX19hY2Nlc3NDaGVjayA9IChvYmosIG1lbWJlciwgbXNnKSA9PiBtZW1iZXIuaGFzKG9iaikgfHwgX190eXBlRXJyb3IoXCJDYW5ub3QgXCIgKyBtc2cpO1xudmFyIF9fcHJpdmF0ZUdldCA9IChvYmosIG1lbWJlciwgZ2V0dGVyKSA9PiAoX19hY2Nlc3NDaGVjayhvYmosIG1lbWJlciwgXCJyZWFkIGZyb20gcHJpdmF0ZSBmaWVsZFwiKSwgZ2V0dGVyID8gZ2V0dGVyLmNhbGwob2JqKSA6IG1lbWJlci5nZXQob2JqKSk7XG52YXIgX19wcml2YXRlQWRkID0gKG9iaiwgbWVtYmVyLCB2YWx1ZSkgPT4gbWVtYmVyLmhhcyhvYmopID8gX190eXBlRXJyb3IoXCJDYW5ub3QgYWRkIHRoZSBzYW1lIHByaXZhdGUgbWVtYmVyIG1vcmUgdGhhbiBvbmNlXCIpIDogbWVtYmVyIGluc3RhbmNlb2YgV2Vha1NldCA/IG1lbWJlci5hZGQob2JqKSA6IG1lbWJlci5zZXQob2JqLCB2YWx1ZSk7XG52YXIgX19wcml2YXRlU2V0ID0gKG9iaiwgbWVtYmVyLCB2YWx1ZSwgc2V0dGVyKSA9PiAoX19hY2Nlc3NDaGVjayhvYmosIG1lbWJlciwgXCJ3cml0ZSB0byBwcml2YXRlIGZpZWxkXCIpLCBzZXR0ZXIgPyBzZXR0ZXIuY2FsbChvYmosIHZhbHVlKSA6IG1lbWJlci5zZXQob2JqLCB2YWx1ZSksIHZhbHVlKTtcblxuLy8gbGliL2NvbnNlbnRvbWF0aWMvdG9vbHMudHNcbnZhciBfVG9vbHMgPSBjbGFzcyBfVG9vbHMge1xuICBzdGF0aWMgc2V0QmFzZShiYXNlKSB7XG4gICAgX1Rvb2xzLmJhc2UgPSBiYXNlO1xuICB9XG4gIHN0YXRpYyBmaW5kRWxlbWVudChvcHRpb25zLCBwYXJlbnQgPSBudWxsLCBtdWx0aXBsZSA9IGZhbHNlKSB7XG4gICAgbGV0IHBvc3NpYmxlVGFyZ2V0cyA9IG51bGw7XG4gICAgaWYgKHBhcmVudCAhPSBudWxsKSB7XG4gICAgICBwb3NzaWJsZVRhcmdldHMgPSBBcnJheS5mcm9tKHBhcmVudC5xdWVyeVNlbGVjdG9yQWxsKG9wdGlvbnMuc2VsZWN0b3IpKTtcbiAgICB9IGVsc2Uge1xuICAgICAgaWYgKF9Ub29scy5iYXNlICE9IG51bGwpIHtcbiAgICAgICAgcG9zc2libGVUYXJnZXRzID0gQXJyYXkuZnJvbShcbiAgICAgICAgICBfVG9vbHMuYmFzZS5xdWVyeVNlbGVjdG9yQWxsKG9wdGlvbnMuc2VsZWN0b3IpXG4gICAgICAgICk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBwb3NzaWJsZVRhcmdldHMgPSBBcnJheS5mcm9tKFxuICAgICAgICAgIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwob3B0aW9ucy5zZWxlY3RvcilcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKG9wdGlvbnMudGV4dEZpbHRlciAhPSBudWxsKSB7XG4gICAgICBwb3NzaWJsZVRhcmdldHMgPSBwb3NzaWJsZVRhcmdldHMuZmlsdGVyKChwb3NzaWJsZVRhcmdldCkgPT4ge1xuICAgICAgICBjb25zdCB0ZXh0Q29udGVudCA9IHBvc3NpYmxlVGFyZ2V0LnRleHRDb250ZW50LnRvTG93ZXJDYXNlKCk7XG4gICAgICAgIGlmIChBcnJheS5pc0FycmF5KG9wdGlvbnMudGV4dEZpbHRlcikpIHtcbiAgICAgICAgICBsZXQgZm91bmRUZXh0ID0gZmFsc2U7XG4gICAgICAgICAgZm9yIChjb25zdCB0ZXh0IG9mIG9wdGlvbnMudGV4dEZpbHRlcikge1xuICAgICAgICAgICAgaWYgKHRleHRDb250ZW50LmluZGV4T2YodGV4dC50b0xvd2VyQ2FzZSgpKSAhPT0gLTEpIHtcbiAgICAgICAgICAgICAgZm91bmRUZXh0ID0gdHJ1ZTtcbiAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICAgIHJldHVybiBmb3VuZFRleHQ7XG4gICAgICAgIH0gZWxzZSBpZiAob3B0aW9ucy50ZXh0RmlsdGVyICE9IG51bGwpIHtcbiAgICAgICAgICByZXR1cm4gdGV4dENvbnRlbnQuaW5kZXhPZihvcHRpb25zLnRleHRGaWx0ZXIudG9Mb3dlckNhc2UoKSkgIT09IC0xO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgIH0pO1xuICAgIH1cbiAgICBpZiAob3B0aW9ucy5zdHlsZUZpbHRlcnMgIT0gbnVsbCkge1xuICAgICAgcG9zc2libGVUYXJnZXRzID0gcG9zc2libGVUYXJnZXRzLmZpbHRlcigocG9zc2libGVUYXJnZXQpID0+IHtcbiAgICAgICAgY29uc3Qgc3R5bGVzID0gd2luZG93LmdldENvbXB1dGVkU3R5bGUocG9zc2libGVUYXJnZXQpO1xuICAgICAgICBsZXQga2VlcCA9IHRydWU7XG4gICAgICAgIGZvciAoY29uc3Qgc3R5bGVGaWx0ZXIgb2Ygb3B0aW9ucy5zdHlsZUZpbHRlcnMpIHtcbiAgICAgICAgICBjb25zdCBvcHRpb24gPSBzdHlsZXNbc3R5bGVGaWx0ZXIub3B0aW9uXTtcbiAgICAgICAgICBpZiAoc3R5bGVGaWx0ZXIubmVnYXRlZCkge1xuICAgICAgICAgICAga2VlcCA9IGtlZXAgJiYgb3B0aW9uICE9PSBzdHlsZUZpbHRlci52YWx1ZTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAga2VlcCA9IGtlZXAgJiYgb3B0aW9uID09PSBzdHlsZUZpbHRlci52YWx1ZTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGtlZXA7XG4gICAgICB9KTtcbiAgICB9XG4gICAgaWYgKG9wdGlvbnMuZGlzcGxheUZpbHRlciAhPSBudWxsKSB7XG4gICAgICBwb3NzaWJsZVRhcmdldHMgPSBwb3NzaWJsZVRhcmdldHMuZmlsdGVyKChwb3NzaWJsZVRhcmdldCkgPT4ge1xuICAgICAgICBpZiAob3B0aW9ucy5kaXNwbGF5RmlsdGVyKSB7XG4gICAgICAgICAgcmV0dXJuIHBvc3NpYmxlVGFyZ2V0Lm9mZnNldEhlaWdodCAhPT0gMDtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICByZXR1cm4gcG9zc2libGVUYXJnZXQub2Zmc2V0SGVpZ2h0ID09PSAwO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9XG4gICAgaWYgKG9wdGlvbnMuaWZyYW1lRmlsdGVyICE9IG51bGwpIHtcbiAgICAgIHBvc3NpYmxlVGFyZ2V0cyA9IHBvc3NpYmxlVGFyZ2V0cy5maWx0ZXIoKCkgPT4ge1xuICAgICAgICBpZiAob3B0aW9ucy5pZnJhbWVGaWx0ZXIpIHtcbiAgICAgICAgICByZXR1cm4gd2luZG93LmxvY2F0aW9uICE9PSB3aW5kb3cucGFyZW50LmxvY2F0aW9uO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHJldHVybiB3aW5kb3cubG9jYXRpb24gPT09IHdpbmRvdy5wYXJlbnQubG9jYXRpb247XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH1cbiAgICBpZiAob3B0aW9ucy5jaGlsZEZpbHRlciAhPSBudWxsKSB7XG4gICAgICBwb3NzaWJsZVRhcmdldHMgPSBwb3NzaWJsZVRhcmdldHMuZmlsdGVyKChwb3NzaWJsZVRhcmdldCkgPT4ge1xuICAgICAgICBjb25zdCBvbGRCYXNlID0gX1Rvb2xzLmJhc2U7XG4gICAgICAgIF9Ub29scy5zZXRCYXNlKHBvc3NpYmxlVGFyZ2V0KTtcbiAgICAgICAgY29uc3QgY2hpbGRSZXN1bHRzID0gX1Rvb2xzLmZpbmQob3B0aW9ucy5jaGlsZEZpbHRlcik7XG4gICAgICAgIF9Ub29scy5zZXRCYXNlKG9sZEJhc2UpO1xuICAgICAgICByZXR1cm4gY2hpbGRSZXN1bHRzLnRhcmdldCAhPSBudWxsO1xuICAgICAgfSk7XG4gICAgfVxuICAgIGlmIChtdWx0aXBsZSkge1xuICAgICAgcmV0dXJuIHBvc3NpYmxlVGFyZ2V0cztcbiAgICB9IGVsc2Uge1xuICAgICAgaWYgKHBvc3NpYmxlVGFyZ2V0cy5sZW5ndGggPiAxKSB7XG4gICAgICAgIGNvbnNvbGUud2FybihcbiAgICAgICAgICBcIk11bHRpcGxlIHBvc3NpYmxlIHRhcmdldHM6IFwiLFxuICAgICAgICAgIHBvc3NpYmxlVGFyZ2V0cyxcbiAgICAgICAgICBvcHRpb25zLFxuICAgICAgICAgIHBhcmVudFxuICAgICAgICApO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHBvc3NpYmxlVGFyZ2V0c1swXTtcbiAgICB9XG4gIH1cbiAgc3RhdGljIGZpbmQob3B0aW9ucywgbXVsdGlwbGUgPSBmYWxzZSkge1xuICAgIGNvbnN0IHJlc3VsdHMgPSBbXTtcbiAgICBpZiAob3B0aW9ucy5wYXJlbnQgIT0gbnVsbCkge1xuICAgICAgY29uc3QgcGFyZW50ID0gX1Rvb2xzLmZpbmRFbGVtZW50KG9wdGlvbnMucGFyZW50LCBudWxsLCBtdWx0aXBsZSk7XG4gICAgICBpZiAocGFyZW50ICE9IG51bGwpIHtcbiAgICAgICAgaWYgKHBhcmVudCBpbnN0YW5jZW9mIEFycmF5KSB7XG4gICAgICAgICAgcGFyZW50LmZvckVhY2goKHApID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHRhcmdldHMgPSBfVG9vbHMuZmluZEVsZW1lbnQob3B0aW9ucy50YXJnZXQsIHAsIG11bHRpcGxlKTtcbiAgICAgICAgICAgIGlmICh0YXJnZXRzIGluc3RhbmNlb2YgQXJyYXkpIHtcbiAgICAgICAgICAgICAgdGFyZ2V0cy5mb3JFYWNoKCh0YXJnZXQpID0+IHtcbiAgICAgICAgICAgICAgICByZXN1bHRzLnB1c2goe1xuICAgICAgICAgICAgICAgICAgcGFyZW50OiBwLFxuICAgICAgICAgICAgICAgICAgdGFyZ2V0XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgcmVzdWx0cy5wdXNoKHtcbiAgICAgICAgICAgICAgICBwYXJlbnQ6IHAsXG4gICAgICAgICAgICAgICAgdGFyZ2V0OiB0YXJnZXRzXG4gICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH0pO1xuICAgICAgICAgIHJldHVybiByZXN1bHRzO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGNvbnN0IHRhcmdldHMgPSBfVG9vbHMuZmluZEVsZW1lbnQob3B0aW9ucy50YXJnZXQsIHBhcmVudCwgbXVsdGlwbGUpO1xuICAgICAgICAgIGlmICh0YXJnZXRzIGluc3RhbmNlb2YgQXJyYXkpIHtcbiAgICAgICAgICAgIHRhcmdldHMuZm9yRWFjaCgodGFyZ2V0KSA9PiB7XG4gICAgICAgICAgICAgIHJlc3VsdHMucHVzaCh7XG4gICAgICAgICAgICAgICAgcGFyZW50LFxuICAgICAgICAgICAgICAgIHRhcmdldFxuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICByZXN1bHRzLnB1c2goe1xuICAgICAgICAgICAgICBwYXJlbnQsXG4gICAgICAgICAgICAgIHRhcmdldDogdGFyZ2V0c1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbnN0IHRhcmdldHMgPSBfVG9vbHMuZmluZEVsZW1lbnQob3B0aW9ucy50YXJnZXQsIG51bGwsIG11bHRpcGxlKTtcbiAgICAgIGlmICh0YXJnZXRzIGluc3RhbmNlb2YgQXJyYXkpIHtcbiAgICAgICAgdGFyZ2V0cy5mb3JFYWNoKCh0YXJnZXQpID0+IHtcbiAgICAgICAgICByZXN1bHRzLnB1c2goe1xuICAgICAgICAgICAgcGFyZW50OiBudWxsLFxuICAgICAgICAgICAgdGFyZ2V0XG4gICAgICAgICAgfSk7XG4gICAgICAgIH0pO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmVzdWx0cy5wdXNoKHtcbiAgICAgICAgICBwYXJlbnQ6IG51bGwsXG4gICAgICAgICAgdGFyZ2V0OiB0YXJnZXRzXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAocmVzdWx0cy5sZW5ndGggPT09IDApIHtcbiAgICAgIHJlc3VsdHMucHVzaCh7XG4gICAgICAgIHBhcmVudDogbnVsbCxcbiAgICAgICAgdGFyZ2V0OiBudWxsXG4gICAgICB9KTtcbiAgICB9XG4gICAgaWYgKG11bHRpcGxlKSB7XG4gICAgICByZXR1cm4gcmVzdWx0cztcbiAgICB9IGVsc2Uge1xuICAgICAgaWYgKHJlc3VsdHMubGVuZ3RoICE9PSAxKSB7XG4gICAgICAgIGNvbnNvbGUud2FybihcbiAgICAgICAgICBcIk11bHRpcGxlIHJlc3VsdHMgZm91bmQsIGV2ZW4gdGhvdWdoIG11bHRpcGxlIGZhbHNlXCIsXG4gICAgICAgICAgcmVzdWx0c1xuICAgICAgICApO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHJlc3VsdHNbMF07XG4gICAgfVxuICB9XG59O1xuX1Rvb2xzLmJhc2UgPSBudWxsO1xudmFyIFRvb2xzID0gX1Rvb2xzO1xuXG4vLyBsaWIvY29uc2VudG9tYXRpYy9pbmRleC50c1xuZnVuY3Rpb24gbWF0Y2hlcyhjb25maWcpIHtcbiAgY29uc3QgcmVzdWx0ID0gVG9vbHMuZmluZChjb25maWcpO1xuICBpZiAoY29uZmlnLnR5cGUgPT09IFwiY3NzXCIpIHtcbiAgICByZXR1cm4gISFyZXN1bHQudGFyZ2V0O1xuICB9IGVsc2UgaWYgKGNvbmZpZy50eXBlID09PSBcImNoZWNrYm94XCIpIHtcbiAgICByZXR1cm4gISFyZXN1bHQudGFyZ2V0ICYmIHJlc3VsdC50YXJnZXQuY2hlY2tlZDtcbiAgfVxufVxuYXN5bmMgZnVuY3Rpb24gZXhlY3V0ZUFjdGlvbihjb25maWcsIHBhcmFtKSB7XG4gIHN3aXRjaCAoY29uZmlnLnR5cGUpIHtcbiAgICBjYXNlIFwiY2xpY2tcIjpcbiAgICAgIHJldHVybiBjbGlja0FjdGlvbihjb25maWcpO1xuICAgIGNhc2UgXCJsaXN0XCI6XG4gICAgICByZXR1cm4gbGlzdEFjdGlvbihjb25maWcsIHBhcmFtKTtcbiAgICBjYXNlIFwiY29uc2VudFwiOlxuICAgICAgcmV0dXJuIGNvbnNlbnRBY3Rpb24oY29uZmlnLCBwYXJhbSk7XG4gICAgY2FzZSBcImlmY3NzXCI6XG4gICAgICByZXR1cm4gaWZDc3NBY3Rpb24oY29uZmlnLCBwYXJhbSk7XG4gICAgY2FzZSBcIndhaXRjc3NcIjpcbiAgICAgIHJldHVybiB3YWl0Q3NzQWN0aW9uKGNvbmZpZyk7XG4gICAgY2FzZSBcImZvcmVhY2hcIjpcbiAgICAgIHJldHVybiBmb3JFYWNoQWN0aW9uKGNvbmZpZywgcGFyYW0pO1xuICAgIGNhc2UgXCJoaWRlXCI6XG4gICAgICByZXR1cm4gaGlkZUFjdGlvbihjb25maWcpO1xuICAgIGNhc2UgXCJzbGlkZVwiOlxuICAgICAgcmV0dXJuIHNsaWRlQWN0aW9uKGNvbmZpZyk7XG4gICAgY2FzZSBcImNsb3NlXCI6XG4gICAgICByZXR1cm4gY2xvc2VBY3Rpb24oKTtcbiAgICBjYXNlIFwid2FpdFwiOlxuICAgICAgcmV0dXJuIHdhaXRBY3Rpb24oY29uZmlnKTtcbiAgICBjYXNlIFwiZXZhbFwiOlxuICAgICAgcmV0dXJuIGV2YWxBY3Rpb24oY29uZmlnKTtcbiAgICBkZWZhdWx0OlxuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiVW5rbm93biBhY3Rpb24gdHlwZTogXCIgKyBjb25maWcudHlwZSk7XG4gIH1cbn1cbnZhciBTVEVQX1RJTUVPVVQgPSAwO1xuZnVuY3Rpb24gd2FpdFRpbWVvdXQodGltZW91dCkge1xuICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcbiAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgIHJlc29sdmUoKTtcbiAgICB9LCB0aW1lb3V0KTtcbiAgfSk7XG59XG5hc3luYyBmdW5jdGlvbiBjbGlja0FjdGlvbihjb25maWcpIHtcbiAgY29uc3QgcmVzdWx0ID0gVG9vbHMuZmluZChjb25maWcpO1xuICBpZiAocmVzdWx0LnRhcmdldCAhPSBudWxsKSB7XG4gICAgcmVzdWx0LnRhcmdldC5jbGljaygpO1xuICB9XG4gIHJldHVybiB3YWl0VGltZW91dChTVEVQX1RJTUVPVVQpO1xufVxuYXN5bmMgZnVuY3Rpb24gbGlzdEFjdGlvbihjb25maWcsIHBhcmFtKSB7XG4gIGZvciAoY29uc3QgYWN0aW9uIG9mIGNvbmZpZy5hY3Rpb25zKSB7XG4gICAgYXdhaXQgZXhlY3V0ZUFjdGlvbihhY3Rpb24sIHBhcmFtKTtcbiAgfVxufVxuYXN5bmMgZnVuY3Rpb24gY29uc2VudEFjdGlvbihjb25maWcsIGNvbnNlbnRUeXBlcykge1xuICBmb3IgKGNvbnN0IGNvbnNlbnRDb25maWcgb2YgY29uZmlnLmNvbnNlbnRzKSB7XG4gICAgY29uc3Qgc2hvdWxkRW5hYmxlID0gY29uc2VudFR5cGVzLmluZGV4T2YoY29uc2VudENvbmZpZy50eXBlKSAhPT0gLTE7XG4gICAgaWYgKGNvbnNlbnRDb25maWcubWF0Y2hlciAmJiBjb25zZW50Q29uZmlnLnRvZ2dsZUFjdGlvbikge1xuICAgICAgY29uc3QgaXNFbmFibGVkID0gbWF0Y2hlcyhjb25zZW50Q29uZmlnLm1hdGNoZXIpO1xuICAgICAgaWYgKGlzRW5hYmxlZCAhPT0gc2hvdWxkRW5hYmxlKSB7XG4gICAgICAgIGF3YWl0IGV4ZWN1dGVBY3Rpb24oY29uc2VudENvbmZpZy50b2dnbGVBY3Rpb24pO1xuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICBpZiAoc2hvdWxkRW5hYmxlKSB7XG4gICAgICAgIGF3YWl0IGV4ZWN1dGVBY3Rpb24oY29uc2VudENvbmZpZy50cnVlQWN0aW9uKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGF3YWl0IGV4ZWN1dGVBY3Rpb24oY29uc2VudENvbmZpZy5mYWxzZUFjdGlvbik7XG4gICAgICB9XG4gICAgfVxuICB9XG59XG5hc3luYyBmdW5jdGlvbiBpZkNzc0FjdGlvbihjb25maWcsIHBhcmFtKSB7XG4gIGNvbnN0IHJlc3VsdCA9IFRvb2xzLmZpbmQoY29uZmlnKTtcbiAgaWYgKCFyZXN1bHQudGFyZ2V0KSB7XG4gICAgaWYgKGNvbmZpZy50cnVlQWN0aW9uKSB7XG4gICAgICBhd2FpdCBleGVjdXRlQWN0aW9uKGNvbmZpZy50cnVlQWN0aW9uLCBwYXJhbSk7XG4gICAgfVxuICB9IGVsc2Uge1xuICAgIGlmIChjb25maWcuZmFsc2VBY3Rpb24pIHtcbiAgICAgIGF3YWl0IGV4ZWN1dGVBY3Rpb24oY29uZmlnLmZhbHNlQWN0aW9uLCBwYXJhbSk7XG4gICAgfVxuICB9XG59XG5hc3luYyBmdW5jdGlvbiB3YWl0Q3NzQWN0aW9uKGNvbmZpZykge1xuICBhd2FpdCBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4ge1xuICAgIGxldCBudW1SZXRyaWVzID0gY29uZmlnLnJldHJpZXMgfHwgMTA7XG4gICAgY29uc3Qgd2FpdFRpbWUgPSBjb25maWcud2FpdFRpbWUgfHwgMjUwO1xuICAgIGNvbnN0IGNoZWNrQ3NzID0gKCkgPT4ge1xuICAgICAgY29uc3QgcmVzdWx0ID0gVG9vbHMuZmluZChjb25maWcpO1xuICAgICAgaWYgKGNvbmZpZy5uZWdhdGVkICYmIHJlc3VsdC50YXJnZXQgfHwgIWNvbmZpZy5uZWdhdGVkICYmICFyZXN1bHQudGFyZ2V0KSB7XG4gICAgICAgIGlmIChudW1SZXRyaWVzID4gMCkge1xuICAgICAgICAgIG51bVJldHJpZXMgLT0gMTtcbiAgICAgICAgICBzZXRUaW1lb3V0KGNoZWNrQ3NzLCB3YWl0VGltZSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgcmVzb2x2ZSgpO1xuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICByZXNvbHZlKCk7XG4gICAgICB9XG4gICAgfTtcbiAgICBjaGVja0NzcygpO1xuICB9KTtcbn1cbmFzeW5jIGZ1bmN0aW9uIGZvckVhY2hBY3Rpb24oY29uZmlnLCBwYXJhbSkge1xuICBjb25zdCByZXN1bHRzID0gVG9vbHMuZmluZChjb25maWcsIHRydWUpO1xuICBjb25zdCBvbGRCYXNlID0gVG9vbHMuYmFzZTtcbiAgZm9yIChjb25zdCByZXN1bHQgb2YgcmVzdWx0cykge1xuICAgIGlmIChyZXN1bHQudGFyZ2V0KSB7XG4gICAgICBUb29scy5zZXRCYXNlKHJlc3VsdC50YXJnZXQpO1xuICAgICAgYXdhaXQgZXhlY3V0ZUFjdGlvbihjb25maWcuYWN0aW9uLCBwYXJhbSk7XG4gICAgfVxuICB9XG4gIFRvb2xzLnNldEJhc2Uob2xkQmFzZSk7XG59XG5hc3luYyBmdW5jdGlvbiBoaWRlQWN0aW9uKGNvbmZpZykge1xuICBjb25zdCByZXN1bHQgPSBUb29scy5maW5kKGNvbmZpZyk7XG4gIGlmIChyZXN1bHQudGFyZ2V0KSB7XG4gICAgcmVzdWx0LnRhcmdldC5jbGFzc0xpc3QuYWRkKFwiQXV0b2NvbnNlbnQtSGlkZGVuXCIpO1xuICB9XG59XG5hc3luYyBmdW5jdGlvbiBzbGlkZUFjdGlvbihjb25maWcpIHtcbiAgY29uc3QgcmVzdWx0ID0gVG9vbHMuZmluZChjb25maWcpO1xuICBjb25zdCBkcmFnUmVzdWx0ID0gVG9vbHMuZmluZChjb25maWcuZHJhZ1RhcmdldCk7XG4gIGlmIChyZXN1bHQudGFyZ2V0KSB7XG4gICAgY29uc3QgdGFyZ2V0Qm91bmRzID0gcmVzdWx0LnRhcmdldC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgICBjb25zdCBkcmFnVGFyZ2V0Qm91bmRzID0gZHJhZ1Jlc3VsdC50YXJnZXQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gICAgbGV0IHlEaWZmID0gZHJhZ1RhcmdldEJvdW5kcy50b3AgLSB0YXJnZXRCb3VuZHMudG9wO1xuICAgIGxldCB4RGlmZiA9IGRyYWdUYXJnZXRCb3VuZHMubGVmdCAtIHRhcmdldEJvdW5kcy5sZWZ0O1xuICAgIGlmICh0aGlzLmNvbmZpZy5heGlzLnRvTG93ZXJDYXNlKCkgPT09IFwieVwiKSB7XG4gICAgICB4RGlmZiA9IDA7XG4gICAgfVxuICAgIGlmICh0aGlzLmNvbmZpZy5heGlzLnRvTG93ZXJDYXNlKCkgPT09IFwieFwiKSB7XG4gICAgICB5RGlmZiA9IDA7XG4gICAgfVxuICAgIGNvbnN0IHNjcmVlblggPSB3aW5kb3cuc2NyZWVuWCArIHRhcmdldEJvdW5kcy5sZWZ0ICsgdGFyZ2V0Qm91bmRzLndpZHRoIC8gMjtcbiAgICBjb25zdCBzY3JlZW5ZID0gd2luZG93LnNjcmVlblkgKyB0YXJnZXRCb3VuZHMudG9wICsgdGFyZ2V0Qm91bmRzLmhlaWdodCAvIDI7XG4gICAgY29uc3QgY2xpZW50WCA9IHRhcmdldEJvdW5kcy5sZWZ0ICsgdGFyZ2V0Qm91bmRzLndpZHRoIC8gMjtcbiAgICBjb25zdCBjbGllbnRZID0gdGFyZ2V0Qm91bmRzLnRvcCArIHRhcmdldEJvdW5kcy5oZWlnaHQgLyAyO1xuICAgIGNvbnN0IG1vdXNlRG93biA9IGRvY3VtZW50LmNyZWF0ZUV2ZW50KFwiTW91c2VFdmVudHNcIik7XG4gICAgbW91c2VEb3duLmluaXRNb3VzZUV2ZW50KFxuICAgICAgXCJtb3VzZWRvd25cIixcbiAgICAgIHRydWUsXG4gICAgICB0cnVlLFxuICAgICAgd2luZG93LFxuICAgICAgMCxcbiAgICAgIHNjcmVlblgsXG4gICAgICBzY3JlZW5ZLFxuICAgICAgY2xpZW50WCxcbiAgICAgIGNsaWVudFksXG4gICAgICBmYWxzZSxcbiAgICAgIGZhbHNlLFxuICAgICAgZmFsc2UsXG4gICAgICBmYWxzZSxcbiAgICAgIDAsXG4gICAgICByZXN1bHQudGFyZ2V0XG4gICAgKTtcbiAgICBjb25zdCBtb3VzZU1vdmUgPSBkb2N1bWVudC5jcmVhdGVFdmVudChcIk1vdXNlRXZlbnRzXCIpO1xuICAgIG1vdXNlTW92ZS5pbml0TW91c2VFdmVudChcbiAgICAgIFwibW91c2Vtb3ZlXCIsXG4gICAgICB0cnVlLFxuICAgICAgdHJ1ZSxcbiAgICAgIHdpbmRvdyxcbiAgICAgIDAsXG4gICAgICBzY3JlZW5YICsgeERpZmYsXG4gICAgICBzY3JlZW5ZICsgeURpZmYsXG4gICAgICBjbGllbnRYICsgeERpZmYsXG4gICAgICBjbGllbnRZICsgeURpZmYsXG4gICAgICBmYWxzZSxcbiAgICAgIGZhbHNlLFxuICAgICAgZmFsc2UsXG4gICAgICBmYWxzZSxcbiAgICAgIDAsXG4gICAgICByZXN1bHQudGFyZ2V0XG4gICAgKTtcbiAgICBjb25zdCBtb3VzZVVwID0gZG9jdW1lbnQuY3JlYXRlRXZlbnQoXCJNb3VzZUV2ZW50c1wiKTtcbiAgICBtb3VzZVVwLmluaXRNb3VzZUV2ZW50KFxuICAgICAgXCJtb3VzZXVwXCIsXG4gICAgICB0cnVlLFxuICAgICAgdHJ1ZSxcbiAgICAgIHdpbmRvdyxcbiAgICAgIDAsXG4gICAgICBzY3JlZW5YICsgeERpZmYsXG4gICAgICBzY3JlZW5ZICsgeURpZmYsXG4gICAgICBjbGllbnRYICsgeERpZmYsXG4gICAgICBjbGllbnRZICsgeURpZmYsXG4gICAgICBmYWxzZSxcbiAgICAgIGZhbHNlLFxuICAgICAgZmFsc2UsXG4gICAgICBmYWxzZSxcbiAgICAgIDAsXG4gICAgICByZXN1bHQudGFyZ2V0XG4gICAgKTtcbiAgICByZXN1bHQudGFyZ2V0LmRpc3BhdGNoRXZlbnQobW91c2VEb3duKTtcbiAgICBhd2FpdCB0aGlzLndhaXRUaW1lb3V0KDEwKTtcbiAgICByZXN1bHQudGFyZ2V0LmRpc3BhdGNoRXZlbnQobW91c2VNb3ZlKTtcbiAgICBhd2FpdCB0aGlzLndhaXRUaW1lb3V0KDEwKTtcbiAgICByZXN1bHQudGFyZ2V0LmRpc3BhdGNoRXZlbnQobW91c2VVcCk7XG4gIH1cbn1cbmFzeW5jIGZ1bmN0aW9uIHdhaXRBY3Rpb24oY29uZmlnKSB7XG4gIGF3YWl0IHdhaXRUaW1lb3V0KGNvbmZpZy53YWl0VGltZSk7XG59XG5hc3luYyBmdW5jdGlvbiBjbG9zZUFjdGlvbigpIHtcbiAgd2luZG93LmNsb3NlKCk7XG59XG5hc3luYyBmdW5jdGlvbiBldmFsQWN0aW9uKGNvbmZpZykge1xuICBjb25zb2xlLmxvZyhcImV2YWwhXCIsIGNvbmZpZy5jb2RlKTtcbiAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGlmIChjb25maWcuYXN5bmMpIHtcbiAgICAgICAgd2luZG93LmV2YWwoY29uZmlnLmNvZGUpO1xuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICByZXNvbHZlKHdpbmRvdy5ldmFsKFwid2luZG93Ll9fY29uc2VudENoZWNrUmVzdWx0XCIpKTtcbiAgICAgICAgfSwgY29uZmlnLnRpbWVvdXQgfHwgMjUwKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHJlc29sdmUod2luZG93LmV2YWwoY29uZmlnLmNvZGUpKTtcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBjb25zb2xlLndhcm4oXCJldmFsIGVycm9yXCIsIGUsIGNvbmZpZy5jb2RlKTtcbiAgICAgIHJlc29sdmUoZmFsc2UpO1xuICAgIH1cbiAgfSk7XG59XG5cbi8vIGxpYi9yYW5kb20udHNcbmZ1bmN0aW9uIGdldFJhbmRvbUlEKCkge1xuICBpZiAoY3J5cHRvICYmIHR5cGVvZiBjcnlwdG8ucmFuZG9tVVVJRCAhPT0gXCJ1bmRlZmluZWRcIikge1xuICAgIHJldHVybiBjcnlwdG8ucmFuZG9tVVVJRCgpO1xuICB9XG4gIHJldHVybiBNYXRoLnJhbmRvbSgpLnRvU3RyaW5nKCk7XG59XG5cbi8vIGxpYi9ldmFsLWhhbmRsZXIudHNcbnZhciBEZWZlcnJlZCA9IGNsYXNzIHtcbiAgY29uc3RydWN0b3IoaWQsIHRpbWVvdXQgPSAxZTMpIHtcbiAgICB0aGlzLmlkID0gaWQ7XG4gICAgdGhpcy5wcm9taXNlID0gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgdGhpcy5yZXNvbHZlID0gcmVzb2x2ZTtcbiAgICAgIHRoaXMucmVqZWN0ID0gcmVqZWN0O1xuICAgIH0pO1xuICAgIHRoaXMudGltZXIgPSB3aW5kb3cuc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICB0aGlzLnJlamVjdChuZXcgRXJyb3IoXCJ0aW1lb3V0XCIpKTtcbiAgICB9LCB0aW1lb3V0KTtcbiAgfVxufTtcbnZhciBldmFsU3RhdGUgPSB7XG4gIHBlbmRpbmc6IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCksXG4gIHNlbmRDb250ZW50TWVzc2FnZTogbnVsbFxufTtcbmZ1bmN0aW9uIHJlcXVlc3RFdmFsKGNvZGUsIHNuaXBwZXRJZCkge1xuICBjb25zdCBpZCA9IGdldFJhbmRvbUlEKCk7XG4gIGV2YWxTdGF0ZS5zZW5kQ29udGVudE1lc3NhZ2Uoe1xuICAgIHR5cGU6IFwiZXZhbFwiLFxuICAgIGlkLFxuICAgIGNvZGUsXG4gICAgc25pcHBldElkXG4gIH0pO1xuICBjb25zdCBkZWZlcnJlZCA9IG5ldyBEZWZlcnJlZChpZCk7XG4gIGV2YWxTdGF0ZS5wZW5kaW5nLnNldChkZWZlcnJlZC5pZCwgZGVmZXJyZWQpO1xuICByZXR1cm4gZGVmZXJyZWQucHJvbWlzZTtcbn1cbmZ1bmN0aW9uIHJlc29sdmVFdmFsKGlkLCB2YWx1ZSkge1xuICBjb25zdCBkZWZlcnJlZCA9IGV2YWxTdGF0ZS5wZW5kaW5nLmdldChpZCk7XG4gIGlmIChkZWZlcnJlZCkge1xuICAgIGV2YWxTdGF0ZS5wZW5kaW5nLmRlbGV0ZShpZCk7XG4gICAgZGVmZXJyZWQudGltZXIgJiYgd2luZG93LmNsZWFyVGltZW91dChkZWZlcnJlZC50aW1lcik7XG4gICAgZGVmZXJyZWQucmVzb2x2ZSh2YWx1ZSk7XG4gIH0gZWxzZSB7XG4gICAgY29uc29sZS53YXJuKFwibm8gZXZhbCAjXCIsIGlkKTtcbiAgfVxufVxuXG4vLyBsaWIvZXZhbC1zbmlwcGV0cy50c1xudmFyIHNuaXBwZXRzID0ge1xuICAvLyBjb2RlLWJhc2VkIHJ1bGVzXG4gIEVWQUxfMDogKCkgPT4gY29uc29sZS5sb2coMSksXG4gIEVWQUxfQ09OU0VOVE1BTkFHRVJfMTogKCkgPT4gd2luZG93Ll9fY21wICYmIHR5cGVvZiBfX2NtcChcImdldENNUERhdGFcIikgPT09IFwib2JqZWN0XCIsXG4gIEVWQUxfQ09OU0VOVE1BTkFHRVJfMjogKCkgPT4gIV9fY21wKFwiY29uc2VudFN0YXR1c1wiKS51c2VyQ2hvaWNlRXhpc3RzLFxuICBFVkFMX0NPTlNFTlRNQU5BR0VSXzM6ICgpID0+IF9fY21wKFwic2V0Q29uc2VudFwiLCAwKSxcbiAgRVZBTF9DT05TRU5UTUFOQUdFUl80OiAoKSA9PiBfX2NtcChcInNldENvbnNlbnRcIiwgMSksXG4gIEVWQUxfQ09OU0VOVE1BTkFHRVJfNTogKCkgPT4gX19jbXAoXCJjb25zZW50U3RhdHVzXCIpLnVzZXJDaG9pY2VFeGlzdHMsXG4gIEVWQUxfQ09PS0lFQk9UXzE6ICgpID0+ICEhd2luZG93LkNvb2tpZWJvdCxcbiAgRVZBTF9DT09LSUVCT1RfMjogKCkgPT4gIXdpbmRvdy5Db29raWVib3QuaGFzUmVzcG9uc2UgJiYgd2luZG93LkNvb2tpZWJvdC5kaWFsb2c/LnZpc2libGUgPT09IHRydWUsXG4gIEVWQUxfQ09PS0lFQk9UXzM6ICgpID0+IHdpbmRvdy5Db29raWVib3Qud2l0aGRyYXcoKSB8fCB0cnVlLFxuICBFVkFMX0NPT0tJRUJPVF80OiAoKSA9PiB3aW5kb3cuQ29va2llYm90LmhpZGUoKSB8fCB0cnVlLFxuICBFVkFMX0NPT0tJRUJPVF81OiAoKSA9PiB3aW5kb3cuQ29va2llYm90LmRlY2xpbmVkID09PSB0cnVlLFxuICBFVkFMX0tMQVJPXzE6ICgpID0+IHtcbiAgICBjb25zdCBjb25maWcgPSBnbG9iYWxUaGlzLmtsYXJvQ29uZmlnIHx8IGdsb2JhbFRoaXMua2xhcm8/LmdldE1hbmFnZXIgJiYgZ2xvYmFsVGhpcy5rbGFyby5nZXRNYW5hZ2VyKCkuY29uZmlnO1xuICAgIGlmICghY29uZmlnKSB7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgY29uc3Qgb3B0aW9uYWxTZXJ2aWNlcyA9IChjb25maWcuc2VydmljZXMgfHwgY29uZmlnLmFwcHMpLmZpbHRlcigocykgPT4gIXMucmVxdWlyZWQpLm1hcCgocykgPT4gcy5uYW1lKTtcbiAgICBpZiAoa2xhcm8gJiYga2xhcm8uZ2V0TWFuYWdlcikge1xuICAgICAgY29uc3QgbWFuYWdlciA9IGtsYXJvLmdldE1hbmFnZXIoKTtcbiAgICAgIHJldHVybiBvcHRpb25hbFNlcnZpY2VzLmV2ZXJ5KChuYW1lKSA9PiAhbWFuYWdlci5jb25zZW50c1tuYW1lXSk7XG4gICAgfSBlbHNlIGlmIChrbGFyb0NvbmZpZyAmJiBrbGFyb0NvbmZpZy5zdG9yYWdlTWV0aG9kID09PSBcImNvb2tpZVwiKSB7XG4gICAgICBjb25zdCBjb29raWVOYW1lID0ga2xhcm9Db25maWcuY29va2llTmFtZSB8fCBrbGFyb0NvbmZpZy5zdG9yYWdlTmFtZTtcbiAgICAgIGNvbnN0IGNvbnNlbnRzID0gSlNPTi5wYXJzZShcbiAgICAgICAgZGVjb2RlVVJJQ29tcG9uZW50KFxuICAgICAgICAgIGRvY3VtZW50LmNvb2tpZS5zcGxpdChcIjtcIikuZmluZCgoYykgPT4gYy50cmltKCkuc3RhcnRzV2l0aChjb29raWVOYW1lKSkuc3BsaXQoXCI9XCIpWzFdXG4gICAgICAgIClcbiAgICAgICk7XG4gICAgICByZXR1cm4gT2JqZWN0LmtleXMoY29uc2VudHMpLmZpbHRlcigoaykgPT4gb3B0aW9uYWxTZXJ2aWNlcy5pbmNsdWRlcyhrKSkuZXZlcnkoKGspID0+IGNvbnNlbnRzW2tdID09PSBmYWxzZSk7XG4gICAgfVxuICB9LFxuICBFVkFMX0tMQVJPX09QRU5fUE9QVVA6ICgpID0+IHtcbiAgICBrbGFyby5zaG93KHZvaWQgMCwgdHJ1ZSk7XG4gIH0sXG4gIEVWQUxfS0xBUk9fVFJZX0FQSV9PUFRfT1VUOiAoKSA9PiB7XG4gICAgaWYgKHdpbmRvdy5rbGFybyAmJiB0eXBlb2Yga2xhcm8uc2hvdyA9PT0gXCJmdW5jdGlvblwiICYmIHR5cGVvZiBrbGFyby5nZXRNYW5hZ2VyID09PSBcImZ1bmN0aW9uXCIpIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGtsYXJvLmdldE1hbmFnZXIoKS5jaGFuZ2VBbGwoZmFsc2UpO1xuICAgICAgICBrbGFyby5nZXRNYW5hZ2VyKCkuc2F2ZUFuZEFwcGx5Q29uc2VudHMoKTtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIGNvbnNvbGUud2FybihlKTtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gZmFsc2U7XG4gIH0sXG4gIEVWQUxfT05FVFJVU1RfMTogKCkgPT4gd2luZG93Lk9uZXRydXN0QWN0aXZlR3JvdXBzLnNwbGl0KFwiLFwiKS5maWx0ZXIoKHMpID0+IHMubGVuZ3RoID4gMCkubGVuZ3RoIDw9IDEsXG4gIEVWQUxfVFJVU1RBUkNfVE9QOiAoKSA9PiB3aW5kb3cgJiYgd2luZG93LnRydXN0ZSAmJiB3aW5kb3cudHJ1c3RlLmV1LmJpbmRNYXAucHJlZkNvb2tpZSA9PT0gXCIwXCIsXG4gIEVWQUxfVFJVU1RBUkNfRlJBTUVfVEVTVDogKCkgPT4gd2luZG93ICYmIHdpbmRvdy5RdWVyeVN0cmluZyAmJiB3aW5kb3cuUXVlcnlTdHJpbmcucHJlZmVyZW5jZXMgPT09IFwiMFwiLFxuICBFVkFMX1RSVVNUQVJDX0ZSQU1FX0dUTTogKCkgPT4gd2luZG93ICYmIHdpbmRvdy5RdWVyeVN0cmluZyAmJiB3aW5kb3cuUXVlcnlTdHJpbmcuZ3RtID09PSBcIjFcIixcbiAgLy8gZGVjbGFyYXRpdmUgcnVsZXNcbiAgRVZBTF9BRE9QVF9URVNUOiAoKSA9PiAhIWxvY2FsU3RvcmFnZS5nZXRJdGVtKFwiYWRvcHRDb25zZW50TW9kZVwiKSxcbiAgRVZBTF9BRFVMVEZSSUVOREZJTkRFUl9URVNUOiAoKSA9PiAhIWxvY2FsU3RvcmFnZS5nZXRJdGVtKFwiY29va2llQ29uc2VudFwiKSxcbiAgRVZBTF9CQUhOX1RFU1Q6ICgpID0+IHV0YWcuZ2Rwci5nZXRTZWxlY3RlZENhdGVnb3JpZXMoKS5sZW5ndGggPT09IDEsXG4gIEVWQUxfQklHQ09NTUVSQ0VfQ09OU0VOVF9NQU5BR0VSX0RFVEVDVDogKCkgPT4gISEod2luZG93LmNvbnNlbnRNYW5hZ2VyICYmIHdpbmRvdy5jb25zZW50TWFuYWdlci52ZXJzaW9uKSxcbiAgRVZBTF9CT1JMQUJTXzA6ICgpID0+ICFKU09OLnBhcnNlKFxuICAgIGRlY29kZVVSSUNvbXBvbmVudChcbiAgICAgIGRvY3VtZW50LmNvb2tpZS5zcGxpdChcIjtcIikuZmluZCgoYykgPT4gYy5pbmRleE9mKFwiYm9ybGFicy1jb29raWVcIikgIT09IC0xKS5zcGxpdChcIj1cIiwgMilbMV1cbiAgICApXG4gICkuY29uc2VudHMuc3RhdGlzdGljcyxcbiAgRVZBTF9DQ19CQU5ORVIyXzA6ICgpID0+ICEhZG9jdW1lbnQuY29va2llLm1hdGNoKC9zbmNjPVteO10rRCUzRHRydWUvKSxcbiAgRVZBTF9DT0lOQkFTRV8wOiAoKSA9PiBKU09OLnBhcnNlKGRlY29kZVVSSUNvbXBvbmVudChkb2N1bWVudC5jb29raWUubWF0Y2goL2NtXyhldXxkZWZhdWx0KV9wcmVmZXJlbmNlcz0oWzAtOWEtekEtWlxcXFx7XFxcXH1cXFxcW1xcXFxdJTpdKik7Py8pWzJdKSkuY29uc2VudC5sZW5ndGggPD0gMSxcbiAgRVZBTF9DT09LSUVfTEFXX0lORk9fMDogKCkgPT4ge1xuICAgIGlmIChDTEkuZGlzYWJsZUFsbENvb2tpZXMpIENMSS5kaXNhYmxlQWxsQ29va2llcygpO1xuICAgIGlmIChDTEkucmVqZWN0X2Nsb3NlKSBDTEkucmVqZWN0X2Nsb3NlKCk7XG4gICAgZG9jdW1lbnQuYm9keS5jbGFzc0xpc3QucmVtb3ZlKFwiY2xpLWJhcm1vZGFsLW9wZW5cIik7XG4gICAgcmV0dXJuIHRydWU7XG4gIH0sXG4gIEVWQUxfQ09PS0lFX0xBV19JTkZPX0RFVEVDVDogKCkgPT4gISF3aW5kb3cuQ0xJLFxuICBFVkFMX0NPT0tJRV9NQU5BR0VSX1BPUFVQXzA6ICgpID0+IEpTT04ucGFyc2UoXG4gICAgZG9jdW1lbnQuY29va2llLnNwbGl0KFwiO1wiKS5maW5kKChjKSA9PiBjLnRyaW0oKS5zdGFydHNXaXRoKFwiQ29va2llTGV2ZWxcIikpLnNwbGl0KFwiPVwiKVsxXVxuICApLnNvY2lhbCA9PT0gZmFsc2UsXG4gIEVWQUxfQ09PS0lFQUxFUlRfMDogKCkgPT4gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcImJvZHlcIikucmVtb3ZlQXR0cmlidXRlKFwic3R5bGVcIikgfHwgdHJ1ZSxcbiAgRVZBTF9DT09LSUVBTEVSVF8xOiAoKSA9PiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiYm9keVwiKS5yZW1vdmVBdHRyaWJ1dGUoXCJzdHlsZVwiKSB8fCB0cnVlLFxuICBFVkFMX0NPT0tJRUFMRVJUXzI6ICgpID0+IHdpbmRvdy5Db29raWVDb25zZW50LmRlY2xpbmVkID09PSB0cnVlLFxuICBFVkFMX0NPT0tJRUZJUlNUXzA6ICgpID0+ICgobykgPT4gby5wZXJmb3JtYW5jZSA9PT0gZmFsc2UgJiYgby5mdW5jdGlvbmFsID09PSBmYWxzZSAmJiBvLmFkdmVydGlzaW5nID09PSBmYWxzZSkoXG4gICAgSlNPTi5wYXJzZShcbiAgICAgIGRlY29kZVVSSUNvbXBvbmVudChcbiAgICAgICAgZG9jdW1lbnQuY29va2llLnNwbGl0KFwiO1wiKS5maW5kKChjKSA9PiBjLmluZGV4T2YoXCJjb29raWVmaXJzdFwiKSAhPT0gLTEpLnRyaW0oKVxuICAgICAgKS5zcGxpdChcIj1cIilbMV1cbiAgICApXG4gICksXG4gIEVWQUxfQ09PS0lFRklSU1RfMTogKCkgPT4gZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbChcImJ1dHRvbltkYXRhLWNvb2tpZWZpcnN0LWFjY2VudC1jb2xvcj10cnVlXVtyb2xlPWNoZWNrYm94XTpub3QoW2Rpc2FibGVkXSlcIikuZm9yRWFjaCgoaSkgPT4gaS5nZXRBdHRyaWJ1dGUoXCJhcmlhLWNoZWNrZWRcIikgPT09IFwidHJ1ZVwiICYmIGkuY2xpY2soKSkgfHwgdHJ1ZSxcbiAgRVZBTF9DT09LSUVJTkZPUk1BVElPTl8wOiAoKSA9PiBDb29raWVJbmZvcm1hdGlvbi5kZWNsaW5lQWxsQ2F0ZWdvcmllcygpIHx8IHRydWUsXG4gIEVWQUxfQ09PS0lFSU5GT1JNQVRJT05fMTogKCkgPT4gQ29va2llSW5mb3JtYXRpb24uc3VibWl0QWxsQ2F0ZWdvcmllcygpIHx8IHRydWUsXG4gIEVWQUxfRVRTWV8wOiAoKSA9PiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKFwiLmdkcHItb3ZlcmxheS1ib2R5IGlucHV0XCIpLmZvckVhY2goKHRvZ2dsZSkgPT4ge1xuICAgIHRvZ2dsZS5jaGVja2VkID0gZmFsc2U7XG4gIH0pIHx8IHRydWUsXG4gIEVWQUxfRVRTWV8xOiAoKSA9PiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiLmdkcHItb3ZlcmxheS12aWV3IGJ1dHRvbltkYXRhLXd0LW92ZXJsYXktY2xvc2VdXCIpLmNsaWNrKCkgfHwgdHJ1ZSxcbiAgRVZBTF9FWk9JQ18wOiAoKSA9PiBlekNNUC5oYW5kbGVBY2NlcHRBbGxDbGljaygpLFxuICBFVkFMX0ZJREVTX0RFVEVDVF9QT1BVUDogKCkgPT4gd2luZG93LkZpZGVzPy5pbml0aWFsaXplZCxcbiAgRVZBTF9HRFBSX0xFR0FMX0NPT0tJRV9ERVRFQ1RfQ01QOiAoKSA9PiAhIXdpbmRvdy5HRFBSX0xDLFxuICBFVkFMX0dEUFJfTEVHQUxfQ09PS0lFX1RFU1Q6ICgpID0+ICEhd2luZG93LkdEUFJfTEM/LnVzZXJDb25zZW50U2V0dGluZyxcbiAgRVZBTF9JVUJFTkRBXzA6ICgpID0+IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoXCIucHVycG9zZXMtaXRlbSBpbnB1dFt0eXBlPWNoZWNrYm94XTpub3QoW2Rpc2FibGVkXSlcIikuZm9yRWFjaCgoeCkgPT4ge1xuICAgIGlmICh4LmNoZWNrZWQpIHguY2xpY2soKTtcbiAgfSkgfHwgdHJ1ZSxcbiAgRVZBTF9JVUJFTkRBXzE6ICgpID0+ICEhZG9jdW1lbnQuY29va2llLm1hdGNoKC9faXViX2NzLVxcZCs9LyksXG4gIEVWQUxfTUVESUFWSU5FXzA6ICgpID0+IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoJ1tkYXRhLW5hbWU9XCJtZWRpYXZpbmUtZ2Rwci1jbXBcIl0gaW5wdXRbdHlwZT1jaGVja2JveF0nKS5mb3JFYWNoKCh4KSA9PiB4LmNoZWNrZWQgJiYgeC5jbGljaygpKSB8fCB0cnVlLFxuICBFVkFMX01JQ1JPU09GVF8wOiAoKSA9PiBBcnJheS5mcm9tKGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoXCJkaXYgPiBidXR0b25cIikpLmZpbHRlcigoZWwpID0+IGVsLmlubmVyVGV4dC5tYXRjaChcIlJlamVjdHxBYmxlaG5lblwiKSlbMF0uY2xpY2soKSB8fCB0cnVlLFxuICBFVkFMX01JQ1JPU09GVF8xOiAoKSA9PiBBcnJheS5mcm9tKGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoXCJkaXYgPiBidXR0b25cIikpLmZpbHRlcigoZWwpID0+IGVsLmlubmVyVGV4dC5tYXRjaChcIkFjY2VwdHxBbm5laG1lblwiKSlbMF0uY2xpY2soKSB8fCB0cnVlLFxuICBFVkFMX01JQ1JPU09GVF8yOiAoKSA9PiAhIWRvY3VtZW50LmNvb2tpZS5tYXRjaChcIk1TQ0N8R0hDQ1wiKSxcbiAgRVZBTF9NT09WRV8wOiAoKSA9PiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKFwiI21vb3ZlX2dkcHJfY29va2llX21vZGFsIGlucHV0XCIpLmZvckVhY2goKGkpID0+IHtcbiAgICBpZiAoIWkuZGlzYWJsZWQpIGkuY2hlY2tlZCA9IGkubmFtZSA9PT0gXCJtb292ZV9nZHByX3N0cmljdF9jb29raWVzXCIgfHwgaS5pZCA9PT0gXCJtb292ZV9nZHByX3N0cmljdF9jb29raWVzXCI7XG4gIH0pIHx8IHRydWUsXG4gIEVWQUxfTkhOSUVVV1NfVEVTVDogKCkgPT4gISFsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInBzaDpjb29raWVzLXNlZW5cIiksXG4gIEVWQUxfT1NBTk9fREVURUNUOiAoKSA9PiAhIXdpbmRvdy5Pc2Fubz8uY20/LmRpYWxvZ09wZW4sXG4gIEVWQUxfUEFOREVDVEVTX1RFU1Q6ICgpID0+IGRvY3VtZW50LmNvb2tpZS5pbmNsdWRlcyhcIl9wYW5kZWN0ZXNfZ2Rwcj1cIikgJiYgSlNPTi5wYXJzZShcbiAgICBhdG9iKFxuICAgICAgZG9jdW1lbnQuY29va2llLnNwbGl0KFwiO1wiKS5maW5kKChzKSA9PiBzLnRyaW0oKS5zdGFydHNXaXRoKFwiX3BhbmRlY3Rlc19nZHByXCIpKS5zcGxpdChcIj1cIilbMV1cbiAgICApXG4gICkuc3RhdHVzID09PSBcImRlbnlcIixcbiAgRVZBTF9QT1ZSX0dPQkFDSzogKCkgPT4gd2luZG93Lmhpc3RvcnkuYmFjaygpIHx8IHRydWUsXG4gIEVWQUxfUFVCVEVDSF8wOiAoKSA9PiBkb2N1bWVudC5jb29raWUuaW5jbHVkZXMoXCJldWNvbnNlbnQtdjJcIikgJiYgKGRvY3VtZW50LmNvb2tpZS5tYXRjaCgvLllBQUFBQUFBQUFBQS8pIHx8IGRvY3VtZW50LmNvb2tpZS5tYXRjaCgvLmFBQUFBQUFBQUFBQS8pIHx8IGRvY3VtZW50LmNvb2tpZS5tYXRjaCgvLllBQUFDRmdBQUFBQS8pKSxcbiAgRVZBTF9SRU1BUktBQkxFX1RFU1Q6ICgpID0+ICEhbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJybUNvb2tpZUNvbnNlbnRcIiksXG4gIEVWQUxfU0hPUElGWV9URVNUOiAoKSA9PiBkb2N1bWVudC5jb29raWUuaW5jbHVkZXMoXCJnZHByX2Nvb2tpZV9jb25zZW50PTBcIikgfHwgZG9jdW1lbnQuY29va2llLmluY2x1ZGVzKFwiX3RyYWNraW5nX2NvbnNlbnQ9XCIpICYmIEpTT04ucGFyc2UoXG4gICAgZGVjb2RlVVJJQ29tcG9uZW50KFxuICAgICAgZG9jdW1lbnQuY29va2llLnNwbGl0KFwiO1wiKS5maW5kKChzKSA9PiBzLnRyaW0oKS5zdGFydHNXaXRoKFwiX3RyYWNraW5nX2NvbnNlbnRcIikpLnNwbGl0KFwiPVwiKVsxXVxuICAgIClcbiAgKS5wdXJwb3Nlcy5hID09PSBmYWxzZSxcbiAgRVZBTF9TS1lTQ0FOTkVSX1RFU1Q6ICgpID0+IGRvY3VtZW50LmNvb2tpZS5tYXRjaCgvZ2Rwcj1bXjtdKmFkdmVydHM6OjpmYWxzZS8pICYmICFkb2N1bWVudC5jb29raWUubWF0Y2goL2dkcHI9W147XSppbml0Ojo6dHJ1ZS8pLFxuICBFVkFMX1NJUkRBVEFfVU5CTE9DS19TQ1JPTEw6ICgpID0+IHtcbiAgICBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuY2xhc3NMaXN0LmZvckVhY2goKGNscykgPT4ge1xuICAgICAgaWYgKGNscy5zdGFydHNXaXRoKFwic2QtY21wLVwiKSkgZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LmNsYXNzTGlzdC5yZW1vdmUoY2xzKTtcbiAgICB9KTtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfSxcbiAgRVZBTF9TVEVBTVBPV0VSRURfMDogKCkgPT4gSlNPTi5wYXJzZShcbiAgICBkZWNvZGVVUklDb21wb25lbnQoXG4gICAgICBkb2N1bWVudC5jb29raWUuc3BsaXQoXCI7XCIpLmZpbmQoKHMpID0+IHMudHJpbSgpLnN0YXJ0c1dpdGgoXCJjb29raWVTZXR0aW5nc1wiKSkuc3BsaXQoXCI9XCIpWzFdXG4gICAgKVxuICApLnByZWZlcmVuY2Vfc3RhdGUgPT09IDIsXG4gIEVWQUxfVEFLRUFMT1RfMDogKCkgPT4gZG9jdW1lbnQuYm9keS5jbGFzc0xpc3QucmVtb3ZlKFwiZnJlZXplXCIpIHx8IChkb2N1bWVudC5ib2R5LnN0eWxlID0gXCJcIikgfHwgdHJ1ZSxcbiAgRVZBTF9UQVJURUFVQ0lUUk9OXzA6ICgpID0+IHRhcnRlYXVjaXRyb24udXNlckludGVyZmFjZS5yZXNwb25kQWxsKGZhbHNlKSB8fCB0cnVlLFxuICBFVkFMX1RBUlRFQVVDSVRST05fMTogKCkgPT4gdGFydGVhdWNpdHJvbi51c2VySW50ZXJmYWNlLnJlc3BvbmRBbGwodHJ1ZSkgfHwgdHJ1ZSxcbiAgRVZBTF9UQVJURUFVQ0lUUk9OXzI6ICgpID0+IGRvY3VtZW50LmNvb2tpZS5tYXRjaCgvdGFydGVhdWNpdHJvbj1bXjtdKi8pPy5bMF0uaW5jbHVkZXMoXCJmYWxzZVwiKSxcbiAgRVZBTF9URUFMSVVNXzA6ICgpID0+IHR5cGVvZiB3aW5kb3cudXRhZyAhPT0gXCJ1bmRlZmluZWRcIiAmJiB0eXBlb2YgdXRhZy5nZHByID09PSBcIm9iamVjdFwiLFxuICBFVkFMX1RFQUxJVU1fMTogKCkgPT4gdXRhZy5nZHByLnNldENvbnNlbnRWYWx1ZShmYWxzZSkgfHwgdHJ1ZSxcbiAgRVZBTF9URUFMSVVNX0RPTk9UU0VMTDogKCkgPT4gdXRhZy5nZHByLmRucz8uc2V0RG5zU3RhdGUoZmFsc2UpIHx8IHRydWUsXG4gIEVWQUxfVEVBTElVTV8yOiAoKSA9PiB1dGFnLmdkcHIuc2V0Q29uc2VudFZhbHVlKHRydWUpIHx8IHRydWUsXG4gIEVWQUxfVEVBTElVTV8zOiAoKSA9PiB1dGFnLmdkcHIuZ2V0Q29uc2VudFN0YXRlKCkgIT09IDEsXG4gIEVWQUxfVEVBTElVTV9ET05PVFNFTExfQ0hFQ0s6ICgpID0+IHV0YWcuZ2Rwci5kbnM/LmdldERuc1N0YXRlKCkgIT09IDEsXG4gIEVWQUxfVEVTVENNUF9TVEVQOiAoKSA9PiAhIWRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIjcmVqZWN0LWFsbFwiKSxcbiAgRVZBTF9URVNUQ01QXzA6ICgpID0+IHdpbmRvdy5yZXN1bHRzLnJlc3VsdHNbMF0gPT09IFwiYnV0dG9uX2NsaWNrZWRcIixcbiAgRVZBTF9URVNUQ01QX0NPU01FVElDXzA6ICgpID0+IHdpbmRvdy5yZXN1bHRzLnJlc3VsdHNbMF0gPT09IFwiYmFubmVyX2hpZGRlblwiLFxuICBFVkFMX1RIRUZSRUVESUNUSU9OQVJZXzA6ICgpID0+IGNtcFVpLnNob3dQdXJwb3NlcygpIHx8IGNtcFVpLnJlamVjdEFsbCgpIHx8IHRydWUsXG4gIEVWQUxfVEhFRlJFRURJQ1RJT05BUllfMTogKCkgPT4gY21wVWkuYWxsb3dBbGwoKSB8fCB0cnVlLFxuICBFVkFMX1VTRVJDRU5UUklDU19BUElfMDogKCkgPT4gdHlwZW9mIFVDX1VJID09PSBcIm9iamVjdFwiLFxuICBFVkFMX1VTRVJDRU5UUklDU19BUElfMTogKCkgPT4gISFVQ19VSS5jbG9zZUNNUCgpLFxuICBFVkFMX1VTRVJDRU5UUklDU19BUElfMjogKCkgPT4gISFVQ19VSS5kZW55QWxsQ29uc2VudHMoKSxcbiAgRVZBTF9VU0VSQ0VOVFJJQ1NfQVBJXzM6ICgpID0+ICEhVUNfVUkuYWNjZXB0QWxsQ29uc2VudHMoKSxcbiAgRVZBTF9VU0VSQ0VOVFJJQ1NfQVBJXzQ6ICgpID0+ICEhVUNfVUkuY2xvc2VDTVAoKSxcbiAgRVZBTF9VU0VSQ0VOVFJJQ1NfQVBJXzU6ICgpID0+IFVDX1VJLmFyZUFsbENvbnNlbnRzQWNjZXB0ZWQoKSA9PT0gdHJ1ZSxcbiAgRVZBTF9VU0VSQ0VOVFJJQ1NfQVBJXzY6ICgpID0+IFVDX1VJLmFyZUFsbENvbnNlbnRzQWNjZXB0ZWQoKSA9PT0gZmFsc2UsXG4gIEVWQUxfVVNFUkNFTlRSSUNTX0JVVFRPTl8wOiAoKSA9PiBKU09OLnBhcnNlKGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwidXNlcmNlbnRyaWNzXCIpKS5jb25zZW50cy5ldmVyeSgoYykgPT4gYy5pc0Vzc2VudGlhbCB8fCAhYy5jb25zZW50U3RhdHVzKSxcbiAgRVZBTF9XQUlUUk9TRV8wOiAoKSA9PiBBcnJheS5mcm9tKGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoXCJsYWJlbFtpZCQ9Y29va2llcy1kZW55LWxhYmVsXVwiKSkuZm9yRWFjaCgoZSkgPT4gZS5jbGljaygpKSB8fCB0cnVlXG59O1xuZnVuY3Rpb24gZ2V0RnVuY3Rpb25Cb2R5KHNuaXBwZXRGdW5jKSB7XG4gIGNvbnN0IHNuaXBwZXRTdHIgPSBzbmlwcGV0RnVuYy50b1N0cmluZygpO1xuICByZXR1cm4gYCgke3NuaXBwZXRTdHJ9KSgpYDtcbn1cblxuLy8gbGliL3V0aWxzLnRzXG5mdW5jdGlvbiBnZXRTdHlsZUVsZW1lbnQoc3R5bGVPdmVycmlkZUVsZW1lbnRJZCA9IFwiYXV0b2NvbnNlbnQtY3NzLXJ1bGVzXCIpIHtcbiAgY29uc3Qgc3R5bGVTZWxlY3RvciA9IGBzdHlsZSMke3N0eWxlT3ZlcnJpZGVFbGVtZW50SWR9YDtcbiAgY29uc3QgZXhpc3RpbmdFbGVtZW50ID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihzdHlsZVNlbGVjdG9yKTtcbiAgaWYgKGV4aXN0aW5nRWxlbWVudCAmJiBleGlzdGluZ0VsZW1lbnQgaW5zdGFuY2VvZiBIVE1MU3R5bGVFbGVtZW50KSB7XG4gICAgcmV0dXJuIGV4aXN0aW5nRWxlbWVudDtcbiAgfSBlbHNlIHtcbiAgICBjb25zdCBwYXJlbnQgPSBkb2N1bWVudC5oZWFkIHx8IGRvY3VtZW50LmdldEVsZW1lbnRzQnlUYWdOYW1lKFwiaGVhZFwiKVswXSB8fCBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQ7XG4gICAgY29uc3QgY3NzID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcInN0eWxlXCIpO1xuICAgIGNzcy5pZCA9IHN0eWxlT3ZlcnJpZGVFbGVtZW50SWQ7XG4gICAgcGFyZW50LmFwcGVuZENoaWxkKGNzcyk7XG4gICAgcmV0dXJuIGNzcztcbiAgfVxufVxuZnVuY3Rpb24gZ2V0SGlkaW5nU3R5bGUobWV0aG9kKSB7XG4gIGNvbnN0IGhpZGluZ1NuaXBwZXQgPSBtZXRob2QgPT09IFwib3BhY2l0eVwiID8gYG9wYWNpdHk6IDBgIDogYGRpc3BsYXk6IG5vbmVgO1xuICByZXR1cm4gYCR7aGlkaW5nU25pcHBldH0gIWltcG9ydGFudDsgei1pbmRleDogLTEgIWltcG9ydGFudDsgcG9pbnRlci1ldmVudHM6IG5vbmUgIWltcG9ydGFudDtgO1xufVxuZnVuY3Rpb24gaGlkZUVsZW1lbnRzKHN0eWxlRWwsIHNlbGVjdG9yLCBtZXRob2QgPSBcImRpc3BsYXlcIikge1xuICBjb25zdCBydWxlID0gYCR7c2VsZWN0b3J9IHsgJHtnZXRIaWRpbmdTdHlsZShtZXRob2QpfSB9IGA7XG4gIGlmIChzdHlsZUVsIGluc3RhbmNlb2YgSFRNTFN0eWxlRWxlbWVudCkge1xuICAgIHN0eWxlRWwuaW5uZXJUZXh0ICs9IHJ1bGU7XG4gICAgcmV0dXJuIHNlbGVjdG9yLmxlbmd0aCA+IDA7XG4gIH1cbiAgcmV0dXJuIGZhbHNlO1xufVxuYXN5bmMgZnVuY3Rpb24gd2FpdEZvcihwcmVkaWNhdGUsIG1heFRpbWVzLCBpbnRlcnZhbCkge1xuICBjb25zdCByZXN1bHQgPSBhd2FpdCBwcmVkaWNhdGUoKTtcbiAgaWYgKCFyZXN1bHQgJiYgbWF4VGltZXMgPiAwKSB7XG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XG4gICAgICBzZXRUaW1lb3V0KGFzeW5jICgpID0+IHtcbiAgICAgICAgcmVzb2x2ZSh3YWl0Rm9yKHByZWRpY2F0ZSwgbWF4VGltZXMgLSAxLCBpbnRlcnZhbCkpO1xuICAgICAgfSwgaW50ZXJ2YWwpO1xuICAgIH0pO1xuICB9XG4gIHJldHVybiBQcm9taXNlLnJlc29sdmUocmVzdWx0KTtcbn1cbmZ1bmN0aW9uIGlzRWxlbWVudFZpc2libGUoZWxlbSkge1xuICBpZiAoIWVsZW0pIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgaWYgKGVsZW0ub2Zmc2V0UGFyZW50ICE9PSBudWxsKSB7XG4gICAgcmV0dXJuIHRydWU7XG4gIH0gZWxzZSB7XG4gICAgY29uc3QgY3NzID0gd2luZG93LmdldENvbXB1dGVkU3R5bGUoZWxlbSk7XG4gICAgaWYgKGNzcy5wb3NpdGlvbiA9PT0gXCJmaXhlZFwiICYmIGNzcy5kaXNwbGF5ICE9PSBcIm5vbmVcIikge1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICB9XG4gIHJldHVybiBmYWxzZTtcbn1cbmZ1bmN0aW9uIGNvcHlPYmplY3QoZGF0YSkge1xuICBpZiAoZ2xvYmFsVGhpcy5zdHJ1Y3R1cmVkQ2xvbmUpIHtcbiAgICByZXR1cm4gc3RydWN0dXJlZENsb25lKGRhdGEpO1xuICB9XG4gIHJldHVybiBKU09OLnBhcnNlKEpTT04uc3RyaW5naWZ5KGRhdGEpKTtcbn1cbmZ1bmN0aW9uIG5vcm1hbGl6ZUNvbmZpZyhwcm92aWRlZENvbmZpZykge1xuICBjb25zdCBkZWZhdWx0Q29uZmlnID0ge1xuICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgYXV0b0FjdGlvbjogXCJvcHRPdXRcIixcbiAgICAvLyBpZiBmYWxzeSwgdGhlIGV4dGVuc2lvbiB3aWxsIHdhaXQgZm9yIGFuIGV4cGxpY2l0IHVzZXIgc2lnbmFsIGJlZm9yZSBvcHRpbmcgaW4vb3V0XG4gICAgZGlzYWJsZWRDbXBzOiBbXSxcbiAgICBlbmFibGVQcmVoaWRlOiB0cnVlLFxuICAgIGVuYWJsZUNvc21ldGljUnVsZXM6IHRydWUsXG4gICAgZW5hYmxlR2VuZXJhdGVkUnVsZXM6IHRydWUsXG4gICAgZW5hYmxlSGV1cmlzdGljRGV0ZWN0aW9uOiBmYWxzZSxcbiAgICBlbmFibGVIZXVyaXN0aWNBY3Rpb246IGZhbHNlLFxuICAgIGRldGVjdFJldHJpZXM6IDIwLFxuICAgIGlzTWFpbldvcmxkOiBmYWxzZSxcbiAgICBwcmVoaWRlVGltZW91dDogMmUzLFxuICAgIGVuYWJsZUZpbHRlckxpc3Q6IGZhbHNlLFxuICAgIHZpc3VhbFRlc3Q6IGZhbHNlLFxuICAgIGxvZ3M6IHtcbiAgICAgIGxpZmVjeWNsZTogZmFsc2UsXG4gICAgICBydWxlc3RlcHM6IGZhbHNlLFxuICAgICAgZGV0ZWN0aW9uc3RlcHM6IGZhbHNlLFxuICAgICAgZXZhbHM6IGZhbHNlLFxuICAgICAgZXJyb3JzOiB0cnVlLFxuICAgICAgbWVzc2FnZXM6IGZhbHNlLFxuICAgICAgd2FpdHM6IGZhbHNlXG4gICAgfVxuICB9O1xuICBjb25zdCB1cGRhdGVkQ29uZmlnID0gY29weU9iamVjdChkZWZhdWx0Q29uZmlnKTtcbiAgZm9yIChjb25zdCBrZXkgb2YgT2JqZWN0LmtleXMoZGVmYXVsdENvbmZpZykpIHtcbiAgICBpZiAodHlwZW9mIHByb3ZpZGVkQ29uZmlnW2tleV0gIT09IFwidW5kZWZpbmVkXCIpIHtcbiAgICAgIHVwZGF0ZWRDb25maWdba2V5XSA9IHByb3ZpZGVkQ29uZmlnW2tleV07XG4gICAgfVxuICB9XG4gIHJldHVybiB1cGRhdGVkQ29uZmlnO1xufVxuZnVuY3Rpb24gc2NoZWR1bGVXaGVuSWRsZShjYWxsYmFjaywgdGltZW91dCA9IDUwMCkge1xuICBpZiAoZ2xvYmFsVGhpcy5yZXF1ZXN0SWRsZUNhbGxiYWNrKSB7XG4gICAgcmVxdWVzdElkbGVDYWxsYmFjayhjYWxsYmFjaywgeyB0aW1lb3V0IH0pO1xuICB9IGVsc2Uge1xuICAgIHNldFRpbWVvdXQoY2FsbGJhY2ssIDApO1xuICB9XG59XG5mdW5jdGlvbiBoaWdobGlnaHROb2RlKG5vZGUpIHtcbiAgaWYgKCFub2RlLnN0eWxlKSByZXR1cm47XG4gIGlmIChub2RlLl9fb2xkU3R5bGVzICE9PSB2b2lkIDApIHtcbiAgICByZXR1cm47XG4gIH1cbiAgaWYgKG5vZGUuaGFzQXR0cmlidXRlKFwic3R5bGVcIikpIHtcbiAgICBub2RlLl9fb2xkU3R5bGVzID0gbm9kZS5zdHlsZS5jc3NUZXh0O1xuICB9XG4gIG5vZGUuc3R5bGUuYW5pbWF0aW9uID0gXCJwdWxzYXRlIC41cyBpbmZpbml0ZVwiO1xuICBub2RlLnN0eWxlLm91dGxpbmUgPSBcInNvbGlkIHJlZFwiO1xuICBsZXQgc3R5bGVUYWcgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwic3R5bGUjYXV0b2NvbnNlbnQtZGVidWctc3R5bGVzXCIpO1xuICBpZiAoIXN0eWxlVGFnKSB7XG4gICAgc3R5bGVUYWcgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwic3R5bGVcIik7XG4gICAgc3R5bGVUYWcuaWQgPSBcImF1dG9jb25zZW50LWRlYnVnLXN0eWxlc1wiO1xuICB9XG4gIHN0eWxlVGFnLnRleHRDb250ZW50ID0gYFxuICAgICAgQGtleWZyYW1lcyBwdWxzYXRlIHtcbiAgICAgICAgMCUge1xuICAgICAgICAgIG91dGxpbmUtd2lkdGg6IDhweDtcbiAgICAgICAgICBvdXRsaW5lLW9mZnNldDogLTRweDtcbiAgICAgICAgfVxuICAgICAgICA1MCUge1xuICAgICAgICAgIG91dGxpbmUtd2lkdGg6IDRweDtcbiAgICAgICAgICBvdXRsaW5lLW9mZnNldDogLTJweDtcbiAgICAgICAgfVxuICAgICAgICAxMDAlIHtcbiAgICAgICAgICBvdXRsaW5lLXdpZHRoOiA4cHg7XG4gICAgICAgICAgb3V0bGluZS1vZmZzZXQ6IC00cHg7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICBgO1xuICBkb2N1bWVudC5oZWFkLmFwcGVuZENoaWxkKHN0eWxlVGFnKTtcbn1cbmZ1bmN0aW9uIHVuaGlnaGxpZ2h0Tm9kZShub2RlKSB7XG4gIGlmICghbm9kZS5zdHlsZSB8fCAhbm9kZS5oYXNBdHRyaWJ1dGUoXCJzdHlsZVwiKSkgcmV0dXJuO1xuICBpZiAobm9kZS5fX29sZFN0eWxlcyAhPT0gdm9pZCAwKSB7XG4gICAgbm9kZS5zdHlsZS5jc3NUZXh0ID0gbm9kZS5fX29sZFN0eWxlcztcbiAgICBkZWxldGUgbm9kZS5fX29sZFN0eWxlcztcbiAgfSBlbHNlIHtcbiAgICBub2RlLnJlbW92ZUF0dHJpYnV0ZShcInN0eWxlXCIpO1xuICB9XG59XG5mdW5jdGlvbiBpc1RvcEZyYW1lKCkge1xuICByZXR1cm4gd2luZG93LnRvcCA9PT0gd2luZG93ICYmICghZ2xvYmFsVGhpcy5sb2NhdGlvbi5hbmNlc3Rvck9yaWdpbnMgfHwgZ2xvYmFsVGhpcy5sb2NhdGlvbi5hbmNlc3Rvck9yaWdpbnMubGVuZ3RoID09PSAwKTtcbn1cblxuLy8gbGliL2hldXJpc3RpYy1wYXR0ZXJucy50c1xudmFyIERFVEVDVF9QQVRURVJOUyA9IFtcbiAgL2FjY2VwdCBjb29raWVzL2dpLFxuICAvYWNjZXB0IGFsbC9naSxcbiAgL3JlamVjdCBhbGwvZ2ksXG4gIC9vbmx5IG5lY2Vzc2FyeSBjb29raWVzL2dpLFxuICAvLyBcIm9ubHkgbmVjZXNzYXJ5XCIgaXMgcHJvYmFibHkgdG9vIGJyb2FkXG4gIC8oPzpieSBjb250aW51aW5nLnswLDEwMH1jb29raWUpfCg/OmNvb2tpZS57MCwxMDB9YnkgY29udGludWluZykvZ2ksXG4gIC8oPzpieSBjb250aW51aW5nLnswLDEwMH1wcml2YWN5KXwoPzpwcml2YWN5LnswLDEwMH1ieSBjb250aW51aW5nKS9naSxcbiAgL2J5IGNsaWNraW5nLnswLDEwMH0oPzphY2NlcHR8YWdyZWV8YWxsb3cpL2dpLFxuICAvd2UgKD86dXNlfHNlcnZlKSg/OiBvcHRpb25hbCk/IGNvb2tpZXMvZ2ksXG4gIC93ZSBhcmUgdXNpbmcgY29va2llcy9naSxcbiAgL3VzZSBvZiBjb29raWVzL2dpLFxuICAvKD86dGhpc3xvdXIpICg/OndlYik/c2l0ZS57MCwxMDB9Y29va2llcy9naSxcbiAgL2Nvb2tpZXMgKD86YW5kfG9yKSAuezAsMTAwfSB0ZWNobm9sb2dpZXMvZ2ksXG4gIC9zdWNoIGFzIGNvb2tpZXMvZ2ksXG4gIC9yZWFkIG1vcmUgYWJvdXQuezAsMTAwfWNvb2tpZXMvZ2ksXG4gIC9jb25zZW50IHRvLnswLDEwMH1jb29raWVzL2dpLFxuICAvd2UgYW5kIG91ciBwYXJ0bmVycy57MCwxMDB9Y29va2llcy9naSxcbiAgL3dlLnswLDEwMH1zdG9yZS57MCwxMDB9aW5mb3JtYXRpb24uezAsMTAwfXN1Y2ggYXMuezAsMTAwfWNvb2tpZXMvZ2ksXG4gIC9zdG9yZSBhbmRcXC9vciBhY2Nlc3MgaW5mb3JtYXRpb24uezAsMTAwfW9uIGEgZGV2aWNlL2dpLFxuICAvcGVyc29uYWxpc2VkIGFkcyBhbmQgY29udGVudCwgYWQgYW5kIGNvbnRlbnQgbWVhc3VyZW1lbnQvZ2ksXG4gIC8vIGl0IG1pZ2h0IGJlIHRlbXB0aW5nIHRvIGFkZCB0aGUgcGF0dGVybnMgYmVsb3csIGJ1dCB0aGV5IGNhdXNlIHRvbyBtYW55IGZhbHNlIHBvc2l0aXZlcy4gRG9uJ3QgZG8gaXQgOilcbiAgLy8gL2Nvb2tpZXM/IHNldHRpbmdzL2ksXG4gIC8vIC9jb29raWVzPyBwcmVmZXJlbmNlcy9pLFxuICAvLyBGUlxuICAvdXRpbGlzb25zLnswLDEwMH1kZXMuezAsMTAwfWNvb2tpZXMvZ2ksXG4gIC9ub3VzLnswLDEwMH11dGlsaXNvbnMuezAsMTAwfWRlcy9naSxcbiAgL2Rlcy57MCwxMDB9Y29va2llcy57MCwxMDB9cG91ci9naSxcbiAgL2Rlcy57MCwxMDB9aW5mb3JtYXRpb25zLnswLDEwMH1zdXIvZ2ksXG4gIC9yZXRpcmVyLnswLDEwMH12b3RyZS57MCwxMDB9Y29uc2VudGVtZW50L2dpLFxuICAvYWNjXHUwMEU5ZGVyLnswLDEwMH1cdTAwRTAuezAsMTAwfWRlcy9naSxcbiAgL1x1MDBFMC57MCwxMDB9ZGVzLnswLDEwMH1pbmZvcm1hdGlvbnMvZ2ksXG4gIC9ldC57MCwxMDB9bm9zLnswLDEwMH1wYXJ0ZW5haXJlcy9naSxcbiAgL3B1YmxpY2l0XHUwMEU5cy57MCwxMDB9ZXQuezAsMTAwfWR1LnswLDEwMH1jb250ZW51L2dpLFxuICAvdXRpbGlzZS57MCwxMDB9ZGVzLnswLDEwMH1jb29raWVzL2dpLFxuICAvdXRpbGlzZW50LnswLDEwMH1kZXMuezAsMTAwfWNvb2tpZXMvZ2ksXG4gIC9zdG9ja2VyLnswLDEwMH1ldC57MCwxMDB9b3UuezAsMTAwfWFjY1x1MDBFOWRlci9naSxcbiAgL2NvbnNlbnRlbWVudC57MCwxMDB9XHUwMEUwLnswLDEwMH10b3V0LnswLDEwMH1tb21lbnQvZ2ksXG4gIC92b3RyZS57MCwxMDB9Y29uc2VudGVtZW50L2dpLFxuICAvYWNjZXB0ZXIuezAsMTAwfXRvdXQvZ2ksXG4gIC91dGlsaXNhdGlvbi57MCwxMDB9ZGVzLnswLDEwMH1jb29raWVzL2dpLFxuICAvY29va2llcy57MCwxMDB9b3UuezAsMTAwfXRlY2hub2xvZ2llcy9naSxcbiAgL2FjY2VwdGV6LnswLDEwMH1sLnswLDEwMH11dGlsaXNhdGlvbi9naSxcbiAgL2NvbnRpbnVlciBzYW5zIGFjY2VwdGVyL2dpLFxuICAvdG91dCByZWZ1c2VyL2dpLFxuICAvKD86cmVmdXNlcnxyZWpldGVyKSB0b3VzIGxlcyBjb29raWVzL2dpLFxuICAvamUgcmVmdXNlL2dpLFxuICAvcmVmdXNlciBldCBjb250aW51ZXIvZ2ksXG4gIC9yZWZ1c2VyIGxlcyBjb29raWVzL2dpLFxuICAvc2V1bGVtZW50IG5cdTAwRTljZXNzYWlyZXMvZ2ksXG4gIC9qZSBkXHUwMEU5c2FjdGl2ZSBsZXMgZmluYWxpdFx1MDBFOXMgbm9uIGVzc2VudGllbGxlcy9naSxcbiAgL2Nvb2tpZXMgZXNzZW50aWVscyB1bmlxdWVtZW50L2dpLFxuICAvblx1MDBFOWNlc3NhaXJlcyB1bmlxdWVtZW50L2dpLFxuICAvLyBERVxuICAvd2lyLnswLDEwMH12ZXJ3ZW5kZW4uezAsMTAwfWNvb2tpZXMvZ2ksXG4gIC93aXIuezAsMTAwfXVuZC57MCwxMDB9dW5zZXJlLnswLDEwMH1wYXJ0bmVyL2dpLFxuICAvenVncmlmZi57MCwxMDB9YXVmLnswLDEwMH1pbmZvcm1hdGlvbmVuLnswLDEwMH1hdWYvZ2ksXG4gIC9pbmhhbHRlLnswLDEwMH1tZXNzdW5nLnswLDEwMH12b24uezAsMTAwfXdlcmJlbGVpc3R1bmcuezAsMTAwfXVuZC9naSxcbiAgL2Nvb2tpZXMuezAsMTAwfXVuZC57MCwxMDB9YW5kZXJlL2dpLFxuICAvdmVyd2VuZHVuZy57MCwxMDB9dm9uLnswLDEwMH1jb29raWVzL2dpLFxuICAvd2lyLnswLDEwMH1udXR6ZW4uezAsMTAwfWNvb2tpZXMvZ2ksXG4gIC92ZXJ3ZW5kZXQuezAsMTAwfWNvb2tpZXMvZ2ksXG4gIC9zaWUuezAsMTAwfWtcdTAwRjZubmVuLnswLDEwMH1paHJlLnswLDEwMH1hdXN3YWhsL2dpLFxuICAvdW5kLnswLDEwMH1cdTAwRTRobmxpY2hlLnswLDEwMH10ZWNobm9sb2dpZW4vZ2ksXG4gIC9jb29raWVzLnswLDEwMH13aXIuezAsMTAwfXZlcndlbmRlbi9naSxcbiAgL2FsbGVzPy57MCwxMDB9YWJsZWhuZW4vZ2ksXG4gIC8oPzpudXJ8bmljaHQpLnswLDEwMH0oPzp6dXNcdTAwRTR0emxpY2hlfGVzc2VuemllbGxlfGZ1bmt0aW9uYWxlfG5vdHdlbmRpZ2V8ZXJmb3JkZXJsaWNoZSkuezAsMTAwfSg/OmNvb2tpZXN8YWt6ZXB0aWVyZW58ZXJsYXViZW58YWJsZWhuZW4pL2dpLFxuICAvd2VpdGVyLnswLDEwMH0oPzpvaG5lfG1pdCkuezAsMTAwfSg/OmVpbndpbGxpZ3VuZ3x6dXN0aW1tdW5nfGNvb2tpZXMpL2dpLFxuICAvKD86Y29va2llc3xlaW53aWxsaWd1bmcpLnswLDEwMH1hYmxlaG5lbi9naSxcbiAgL251ciBmdW5rdGlvbmFsZSBjb29raWVzIGFremVwdGllcmVuL2dpLFxuICAvb3B0aW9uYWxlIGFibGVobmVuL2dpLFxuICAvenVzdGltbXVuZyB2ZXJ3ZWlnZXJuL2dpLFxuICAvLyBOTFxuICAvZ2VicnVpay57MCwxMDB9dmFuLnswLDEwMH1jb29raWVzL2dpLFxuICAvKD86d2V8d2lqKS57MCwxMDB9Z2VicnVpa2VuLnswLDEwMH1jb29raWVzLnswLDEwMH1vbS9naSxcbiAgL2Nvb2tpZXMuezAsMTAwfWVuLnswLDEwMH12ZXJnZWxpamtiYXJlL2dpLFxuICAvKD86YWxsZXN8Y29va2llcykuezAsMTAwfSg/OmFmd2lqemVufHdlaWdlcmVufHZlcndlcnBlbikvZ2ksXG4gIC9hbGxlZW4uezAsMTAwfW5vb2R6YWtlbGlqa2U/XFxiL2dpLFxuICAvY29va2llcyB3ZWlnZXJlbi9naSxcbiAgL3dlaWdlci57MCwxMDB9KD86Y29va2llc3xhbGxlcykvZ2ksXG4gIC9kb29yZ2FhbiB6b25kZXIgKD86dGUgYWNjZXB0ZXJlbnxha2tvb3JkIHRlIGdhYW4pL2dpLFxuICAvYWxsZWVuLnswLDEwMH0oPzpvcHRpb25lbGV8ZnVuY3Rpb25lbGV8ZnVuY3Rpb25lZWx8bm9vZHpha2VsaWprZXxlc3NlbnRpXHUwMEVCbGUpLnswLDEwMH1jb29raWVzL2dpLFxuICAvd2lqcyBhbGxlcyBhZi9naVxuXTtcbnZhciBSRUpFQ1RfUEFUVEVSTlNfRU5HTElTSCA9IFtcbiAgLy8gZS5nLiBcImkgcmVqZWN0IGNvb2tpZXNcIiwgXCJyZWplY3QgYWxsXCIsIFwicmVqZWN0IGFsbCBjb29raWVzXCIsIFwicmVqZWN0IGNvb2tpZXNcIiwgXCJkZW55IGFsbFwiLCBcImRlbnkgYWxsIGNvb2tpZXNcIiwgXCJyZWZ1c2VcIiwgXCJyZWZ1c2UgYWxsXCIsIFwicmVmdXNlIGNvb2tpZXNcIiwgXCJyZWZ1c2UgYWxsIGNvb2tpZXNcIiwgXCJkZW55XCIsIFwicmVqZWN0IGFsbCBhbmQgY2xvc2VcIiwgXCJkZW55IGFsbCBhbmQgY2xvc2VcIiwgXCJyZWplY3Qgbm9uLWVzc2VudGlhbCBjb29raWVzXCIsIFwicmVqZWN0IGFsbCBub24tZXNzZW50aWFsIGNvb2tpZXMgYW5kIGNvbnRpbnVlXCIsIFwicmVqZWN0IG9wdGlvbmFsIGNvb2tpZXNcIiwgXCJyZWplY3QgYWRkaXRpb25hbCBjb29raWVzXCIsIFwicmVqZWN0IHRhcmdldGluZyBjb29raWVzXCIsIFwicmVqZWN0IG1hcmtldGluZyBjb29raWVzXCIsIFwicmVqZWN0IGFuYWx5dGljcyBjb29raWVzXCIsIFwicmVqZWN0IHRyYWNraW5nIGNvb2tpZXNcIiwgXCJyZWplY3QgYWR2ZXJ0aXNpbmcgY29va2llc1wiLCBcInJlamVjdCBhbGwgYW5kIGNsb3NlXCIsIFwiZGVueSBhbGwgYW5kIGNsb3NlXCJcbiAgLy8gbm90ZSB0aGF0IFwicmVqZWN0IGFuZCBzdWJzY3JpYmVcIiBhbmQgXCJyZWplY3QgYW5kIHBheVwiIGFyZSBleGNsdWRlZFxuICAvXlxccyooaSk/XFxzKihyZWplY3R8ZGVueXxyZWZ1c2V8ZGVjbGluZXxkaXNhYmxlKVxccyooYWxsKT9cXHMqKG5vbi1lc3NlbnRpYWx8b3B0aW9uYWx8YWRkaXRpb25hbHx0YXJnZXRpbmd8YW5hbHl0aWNzfG1hcmtldGluZ3x1bnJlcXVpcmVkfG5vbi1uZWNlc3Nhcnl8ZXh0cmF8dHJhY2tpbmd8YWR2ZXJ0aXNpbmcpP1xccyooY29va2llcyk/XFxzKiQvaXMsXG4gIC8vIGUuZy4gXCJpIGRvIG5vdCBhY2NlcHRcIiwgXCJpIGRvIG5vdCBhY2NlcHQgY29va2llc1wiLCBcImRvIG5vdCBhY2NlcHRcIiwgXCJkbyBub3QgYWNjZXB0IGNvb2tpZXNcIlxuICAvXlxccyooaSk/XFxzKmRvXFxzK25vdFxccythY2NlcHRcXHMqKGNvb2tpZXMpP1xccyokL2lzLFxuICAvLyBlLmcuIFwiY29udGludWUgd2l0aG91dCBhY2NlcHRpbmdcIiwgXCJjb250aW51ZSB3aXRob3V0IGFncmVlaW5nXCIsIFwiY29udGludWUgd2l0aG91dCBhZ3JlZWluZyBcdTIxOTJcIlxuICAvXlxccyooY29udGludWV8cHJvY2VlZHxjb250aW51ZVxccyticm93c2luZylcXHMrd2l0aG91dFxccysoYWNjZXB0aW5nfGFncmVlaW5nfGNvbnNlbnR8Y29va2llc3x0cmFja2luZykoXFxzKlx1MjE5Mik/XFxzKiQvaXMsXG4gIC8vIGUuZy4gXCJzdHJpY3RseSBuZWNlc3NhcnkgY29va2llcyBvbmx5XCIsIFwiZXNzZW50aWFsIGNvb2tpZXMgb25seVwiLCBcInJlcXVpcmVkIG9ubHlcIiwgXCJ1c2UgbmVjZXNzYXJ5IGNvb2tpZXMgb25seVwiLCBcImVzc2VudGlhbHMgb25seVwiXG4gIC8vIG5vdGUgdGhhdCBcIm9ubHlcIiBpcyByZXF1aXJlZFxuICAvXlxccyoodXNlfGFjY2VwdHxhbGxvd3xjb250aW51ZVxccyt3aXRoKT9cXHMqKHN0cmljdGx5KT9cXHMqKG5lY2Vzc2FyeXxlc3NlbnRpYWxzP3xyZXF1aXJlZCk/XFxzKihjb29raWVzKT9cXHMqb25seVxccyokL2lzLFxuICAvLyBlLmcuIFwiYWxsb3cgZXNzZW50aWFsIGNvb2tpZXNcIiwgXCJhbGxvdyBuZWNlc3NhcnlcIiwgXCJhbGxvdyBlc3NlbnRpYWxzXCIsIFwiYWxsb3cgZXNzZW50aWFscyBvbmx5XCJcbiAgLy8gbm90ZSB0aGF0IFwiZXNzZW50aWFsXCIgaXMgcmVxdWlyZWRcbiAgL15cXHMqKHVzZXxhY2NlcHR8YWxsb3d8Y29udGludWVcXHMrd2l0aCk/XFxzKihzdHJpY3RseSk/XFxzKihuZWNlc3Nhcnl8ZXNzZW50aWFscz98cmVxdWlyZWQpXFxzKihjb29raWVzKT9cXHMqJC9pcyxcbiAgLy8gZS5nLiBcImFjY2VwdCBvbmx5IGVzc2VudGlhbCBjb29raWVzXCIsIFwidXNlIG9ubHkgbmVjZXNzYXJ5IGNvb2tpZXNcIiwgXCJhbGxvdyBvbmx5IGVzc2VudGlhbFwiLCBcIm9ubHkgZXNzZW50aWFsc1wiLCBcImNvbnRpbnVlIHdpdGggb25seSBlc3NlbnRpYWwgY29va2llc1wiXG4gIC8vIG5vdGUgdGhhdCBcIm9ubHlcIiBpcyByZXF1aXJlZFxuICAvXlxccyoodXNlfGFjY2VwdHxhbGxvd3xjb250aW51ZVxccyt3aXRoKT9cXHMqb25seVxccyooc3RyaWN0bHkpP1xccyoobmVjZXNzYXJ5fGVzc2VudGlhbHM/fHJlcXVpcmVkKT9cXHMqKGNvb2tpZXMpP1xccyokL2lzLFxuICAvLyBlLmcuIFwiZG8gbm90IHNlbGwgb3Igc2hhcmUgbXkgcGVyc29uYWwgaW5mb3JtYXRpb25cIiwgXCJkbyBub3Qgc2VsbCBteSBwZXJzb25hbCBpbmZvcm1hdGlvblwiXG4gIC8vIG9mdGVuIHVzZWQgaW4gQ0NQQVxuICAvXlxccypkb1xccytub3RcXHMrc2VsbChcXHMrb3JcXHMrc2hhcmUpP1xccypteVxccypwZXJzb25hbFxccyppbmZvcm1hdGlvblxccyokL2lzXG4gIC8vIFRoZXNlIGFyZSBpbXBhY3RmdWwsIGJ1dCBsb29rIGVycm9yLXByb25lXG4gIC8vIC8vIGUuZy4gXCJkaXNhZ3JlZVwiXG4gIC8vIC9eXFxzKihpKT9cXHMqZGlzYWdyZWVcXHMqKGFuZFxccytjbG9zZSk/XFxzKiQvaSxcbiAgLy8gLy8gZS5nLiBcImkgZG8gbm90IGFncmVlXCJcbiAgLy8gL15cXHMqKGlcXHMrKT9kb1xccytub3RcXHMrYWdyZWVcXHMqJC9pLFxuXTtcbnZhciBSRUpFQ1RfUEFUVEVSTlNfRFVUQ0ggPSBbXG4gIFwid2VpZ2VyZW5cIixcbiAgXCJhbGxlcyBhZndpanplblwiLFxuICBcImFsbGVlbiBub29kemFrZWxpamtlIGNvb2tpZXNcIixcbiAgXCJhZndpanplblwiLFxuICBcImFsbGVzIHdlaWdlcmVuXCIsXG4gIFwiY29va2llcyB3ZWlnZXJlblwiLFxuICBcImFsbGVlbiBub29kemFrZWxpamtcIixcbiAgXCJ3ZWlnZXJcIixcbiAgXCJ3ZWlnZXIgY29va2llc1wiLFxuICBcImRvb3JnYWFuIHpvbmRlciB0ZSBhY2NlcHRlcmVuXCIsXG4gIFwiYWxsZWVuIGZ1bmN0aW9uZWxlIGNvb2tpZXNcIixcbiAgXCJhbGxlZW4gZnVuY3Rpb25lZWxcIixcbiAgXCJhbGxlZW4gbm9vZHpha2VsaWprZVwiLFxuICBcImFsbGVlbiBlc3NlbnRpXFx4RUJsZSBjb29raWVzXCIsXG4gIFwiZnVuY3Rpb25lZWxcIixcbiAgXCJhbGxlIGNvb2tpZXMgdmVyd2VycGVuXCIsXG4gIFwiZG9vcmdhYW4gem9uZGVyIGFra29vcmQgdGUgZ2FhblwiLFxuICBcIndlaWdlciBhbGxlc1wiLFxuICBcIm5lZSwgYmVkYW5rdFwiLFxuICBcImFsbGUgY29va2llcyB3ZWlnZXJlblwiLFxuICBcIndlaWdlciBhbGxlIGNvb2tpZXNcIixcbiAgXCJhbGxlZW4gbm9vZHpha2VsaWprZSBjb29raWVzIGFjY2VwdGVyZW5cIixcbiAgXCJhbGxlZW4gc3RyaWt0IG5vb2R6YWtlbGlqa1wiLFxuICBcImlrIHdlaWdlclwiLFxuICBcIm9wdGlvbmVsZSBjb29raWVzIHdlaWdlcmVuXCIsXG4gIFwiYWxsZSB3ZWlnZXJlblwiLFxuICBcImFjY2VwdGVlciBhbGxlZW4gbm9vZHpha2VsaWprZSBjb29raWVzXCIsXG4gIFwiYWxsZWVuIGZ1bmN0aW9uZWxlIGNvb2tpZXMgYWNjZXB0ZXJlblwiLFxuICBcImVua2VsIG5vb2R6YWtlbGlqa2UgY29va2llc1wiLFxuICBcIm5pZXQgYWNjZXB0ZXJlblwiLFxuICBcIndlaWdlciBuaWV0LWVzc2VudGlcXHhFQmxlIGNvb2tpZXNcIixcbiAgXCJ3ZWlnZXIgbmlldC1ub29kemFrZWxpamtlIGNvb2tpZXNcIixcbiAgXCJ3aWpzIGFsbGVzIGFmXCIsXG4gIFwiYWxsZSBjb29raWVzIGFmd2lqemVuXCIsXG4gIFwiYWxsZWVuIHZlcmVpc3RlIGNvb2tpZXNcIixcbiAgXCJjb29raWVzIGFmd2lqemVuXCIsXG4gIFwiZG9vcmdhYW4gem9uZGVyIGFjY2VwdGVyZW5cIixcbiAgXCJoaWVyIHdlaWdlcmVuXCIsXG4gIFwid2VpZ2VyIGFsbGVcIixcbiAgXCJhYW52YWFyZCBlbmtlbCBlc3NlbnRpXFx4RUJsZSBjb29raWVzXCIsXG4gIFwiYWFudnVsbGVuZGUgY29va2llcyB3ZWlnZXJlblwiLFxuICBcImFjY2VwdGVyZW4gd2VpZ2VyZW5cIixcbiAgXCJhbGxlIGFmd2lqemVuXCIsXG4gIFwiYWxsZSBuaWV0IGZ1bmN0aW9uZWxlIGFmd2lqemVuXCIsXG4gIFwiYWxsZSBvcHRpb25lbGUgd2VpZ2VyZW5cIixcbiAgXCJhbGxlZW4gbm9vZHpha2VsaWprZSBhY2NlcHRlcmVuXCIsXG4gIFwiYWxsZWVuIHN0cmlrdCBub29kemFrZWxpamtlIGNvb2tpZXNcIixcbiAgXCJhbGxlbiBhZndpanplblwiLFxuICBcImNsZWFyIHdlaWdlcmVuXCIsXG4gIFwiZW5rZWwgZnVuY3Rpb25lZWxcIixcbiAgXCJlbmtlbCBub29kemFrZWxpamtlIGNvb2tpZXMgYWFudmFhcmRlblwiLFxuICBcImZ1bmN0aW9uZWVsIGFsdGlqZCBhY3RpZWZcIixcbiAgXCJuZWUsIGFjY2VwdGVlciBhbGxlZW4gZGUgbm9vZHpha2VsaWprZVwiLFxuICBcIm5lZSwgZ2VlbiBjb29raWVzIGEudS5iLlwiLFxuICBcIm5lZSwgd2VpZ2VyIGNvb2tpZXNcIixcbiAgXCJuZWUsIHdlaWdlcmVuXCIsXG4gIFwibmlldC1ub29kemFrZWxpamtlIGNvb2tpZXMgd2VpZ2VyZW5cIixcbiAgXCJvcHRpb25lZWwgYWZ3aWp6ZW5cIixcbiAgXCJ0cmFja2luZyBjb29raWVzIHdlaWdlcmVuXCIsXG4gIFwid2VpZ2VyZW4gY29va2llc1wiLFxuICBcIndlaWdlcmVuP1wiLFxuICBcIndlaWdlcmVuLlwiLFxuICBcInN0cmlrdCBub29kemFrZWxpamtcIixcbiAgXCJ3ZWlnZXIgb3B0aW9uZWxlIGNvb2tpZXNcIixcbiAgXCJub29kemFrZWxpamtlIGNvb2tpZXNcIixcbiAgXCJlc3NlbnRpXFx4RUJsZSBjb29raWVzXCIsXG4gIFwiZ2EgdmVyZGVyIHpvbmRlciBhYW52YWFyZGVuXCIsXG4gIFwiZG9vcmdhYW4gem9uZGVyIGNvb2tpZXNcIixcbiAgXCJhY2NlcHRlZXIgbm9vZHpha2VsaWprZSBjb29raWVzXCIsXG4gIFwibm9vZHpha2VsaWprZVwiLFxuICBcImluZGllbiBqZSBlbmtlbCB0ZWNobmlzY2ggbm9vZHpha2VsaWprZSBjb29raWVzIHdlbnN0IHRlIGFjY2VwdGVyZW4sIGtsaWsgZGFuIGhpZXJcIixcbiAgXCJ3ZWlnZXJcIixcbiAgXCJhbGxlZW4gZGUgbm9vZHpha2VsaWprZSBjb29raWVzXCIsXG4gIFwiYWxsZWVuIG5vb2R6YWtlbGlqa1wiLFxuICBcImFsbGVlbiB2ZXJwbGljaHRlIGNvb2tpZXNcIixcbiAgXCJpayB3aWwgYWxsZWVuIG1pbmltYWxlIGNvb2tpZXNcIixcbiAgXCJkb29yZ2FhbiB6b25kZXIgdGUgYWNjZXB0ZXJlblwiLFxuICBcImdlZW4gY29va2llcyB0b2VzdGFhblwiLFxuICBcImxpZXZlciBnZWVuIGNvb2tpZXNcIixcbiAgXCJuZWUsIGdlZW4gcGVyc29vbmxpamtlIGNvb2tpZXNcIixcbiAgXCJuZWUsIGxpZXZlciBnZWVuIGNvb2tpZXNcIixcbiAgXCJnYSBkb29yIHpvbmRlciB0ZSBhY2NlcHRlcmVuXCIsXG4gIFwidmVyZGVyIHpvbmRlciBhY2NlcHRlcmVuXCIsXG4gIFwiZXNzZW50aVxceEVCbGUgYWNjZXB0ZXJlblwiLFxuICBcImZ1bmN0aW9uZWxlIGNvb2tpZXNcIixcbiAgXCJzdHJpa3Qgbm9vZHpha2VsaWprZSBjb29raWVzXCIsXG4gIFwiYWxsZWVuIGJhc2ljIGNvb2tpZXNcIixcbiAgXCJhbGxlZW4gYmFzaXNjb29raWVzXCIsXG4gIFwiYWxsZWVuIHN0YW5kYWFyZCBjb29raWVzXCIsXG4gIFwiYWxsZSBjb29raWVzIHZlcndlcnBlblwiLFxuICBcIm5vb2R6YWtlbGlqa1wiLFxuICBcIm5vb2R6YWtlbGlqayBjb29raWVzIGFjY2VwdGVyZW5cIixcbiAgXCJub29kemFrZWxpamtlIGNvb2tpZXMgYWNjZXB0ZXJlblwiLFxuICBcImFjY2VwdGVlciBhbGxlZW4gbm9vZHpha2VsaWprXCIsXG4gIFwiZW5rZWwgbm9vZHpha2VsaWprZSB0b2VzdGFhblwiLFxuICBcImVua2VsIHN0cmlrdCBub29kemFrZWxpamtlIGNvb2tpZXNcIixcbiAgXCJpayB3aWpzIHplIGxpZXZlciBhZlwiLFxuICBcImlrIHdlaWdlciBjb29raWVzXCIsXG4gIFwiaWsgd2VpZ2VyIG9wdGlvbmVsZSBjb29raWVzXCIsXG4gIFwid2VpZ2VyIGFsbGUgY29va2llc1wiLFxuICBcIndlaWdlciBhbGxlIG5pZXQtbm9vZHpha2VsaWprZSBjb29raWVzXCIsXG4gIFwid2VpZ2VyIGFsbGUgb25ub2RpZ2UgY29va2llc1wiLFxuICBcIndlaWdlciBhbGxlIG9wdGlvbmVsZVwiLFxuICBcIndlaWdlciBhbGxlc1wiLFxuICBcIndlaWdlciB0YXJnZXRpbmcgZW4gdGhpcmQgcGFydHkgY29va2llcy5cIlxuXTtcbnZhciBSRUpFQ1RfUEFUVEVSTlNfRlJFTkNIID0gW1xuICBcImNvbnRpbnVlciBzYW5zIGFjY2VwdGVyXCIsXG4gIFwidG91dCByZWZ1c2VyXCIsXG4gIFwicmVmdXNlclwiLFxuICBcInJlZnVzZXIgdG91cyBsZXMgY29va2llc1wiLFxuICBcImplIHJlZnVzZVwiLFxuICBcInJlZnVzZXIgdG91dFwiLFxuICBcInRvdXQgcmVqZXRlclwiLFxuICBcInJlZnVzZXIgZXQgY29udGludWVyXCIsXG4gIFwicmVqZXRlclwiLFxuICBcInJlZnVzZXIgbGVzIGNvb2tpZXNcIixcbiAgXCJjb29raWVzIG5cXHhFOWNlc3NhaXJlcyB1bmlxdWVtZW50XCIsXG4gIFwic2V1bGVtZW50IG5cXHhFOWNlc3NhaXJlc1wiLFxuICBcInJlamV0ZXIgdG91dFwiLFxuICBcInJlZnVzZXIgbGVzIGNvb2tpZXMgb3B0aW9ubmVsc1wiLFxuICBcImplIGRcXHhFOXNhY3RpdmUgbGVzIGZpbmFsaXRcXHhFOXMgbm9uIGVzc2VudGllbGxlc1wiLFxuICBcInJlZnVzZXIgbGVzIGNvb2tpZXMgbm9uIG5cXHhFOWNlc3NhaXJlc1wiLFxuICBcInJlamV0ZXIgdG91cyBsZXMgY29va2llc1wiLFxuICBcImNvb2tpZXMgZXNzZW50aWVscyB1bmlxdWVtZW50XCIsXG4gIFwiblxceEU5Y2Vzc2FpcmVzIHVuaXF1ZW1lbnRcIixcbiAgXCJyZWZ1c2VyIGxlcyBjb29raWVzIG5vbiBlc3NlbnRpZWxzXCIsXG4gIFwidG91dCByZWZ1c2VyIGV0IGZlcm1lclwiLFxuICBcInRvdXQgcmVmdXNlciBzYXVmIGxlcyBjb29raWVzIHRlY2huaXF1ZXNcIixcbiAgXCJjb250aW51ZXIgc2FucyBhY2NlcHRlciB4XCIsXG4gIFwiamUgcmVmdXNlIGx1dGlsaXNhdGlvbiBkZSBjb29raWVzXCIsXG4gIFwibm9uIG1lcmNpLCBzZXVsZW1lbnQgZGVzIGNvb2tpZXMgdGVjaG5pcXVlc1wiLFxuICBcIm5vbiwgdG91dCByZWZ1c2VyXCIsXG4gIFwicmVmdXNlciB0b3VzIGxlcyBjb29raWVzIG5vbiBuXFx4RTljZXNzYWlyZXNcIixcbiAgXCJyZWpldGVyIGxlcyBjb29raWVzXCIsXG4gIFwidW5pcXVlbWVudCBsZXMgZXNzZW50aWVsc1wiLFxuICBcInJlZnVzZXIgdG91c1wiLFxuICBcImFjY2VwdGVyIHVuaXF1ZW1lbnQgbGVzIG5cXHhFOWNlc3NhaXJlc1wiLFxuICBcImFsbG93IGFub255bW91cyBhbmFseXRpY3NcIixcbiAgXCJhdXRvcmlzZXIgbGVzIGNvb2tpZXMgZXNzZW50aWVscyB1bmlxdWVtZW50XCIsXG4gIFwiYXV0b3Jpc2VyIHVuaXF1ZW1lbnQgbGVzIG5cXHhFOWNlc3NhaXJlc1wiLFxuICBcImNvb2tpZXMgZXNzZW50aWVscyBzZXVsZW1lbnRcIixcbiAgXCJjb29raWVzIG5cXHhFOWNlc3NhaXJlcyBzZXVsZW1lbnRcIixcbiAgXCJjb29raWVzIHRlY2huaXF1ZXMgdW5pcXVlbWVudFwiLFxuICBcImplIHByXFx4RTlmXFx4RThyZSBsZXMgcmVqZXRlclwiLFxuICBcImplIHJlZnVzZSA6KFwiLFxuICBcImplIHJlZnVzZSBsZXMgY29va2llc1wiLFxuICBcImplIHJlZnVzZSB0b3VzIGxlcyBjb29raWVzXCIsXG4gIFwiamUgcmVmdXNlIHRvdXRcIixcbiAgXCJuZSBwYXMgYWNjZXB0ZXJcIixcbiAgXCJub24sIGFjY2VwdGVyIGxlcyBuXFx4RTljZXNzYWlyZXMgdW5pcXVlbWVudFwiLFxuICBcInJlZnVzZXIgKHNhdWYgY29va2llcyBuXFx4RTljZXNzYWlyZXMpXCIsXG4gIFwicmVmdXNlciBjZSBjb29raWVcIixcbiAgXCJyZWZ1c2VyIGxlcyBjb29ja2llc1wiLFxuICBcInJlZnVzZXIgbGVzIGNvb2tpZXMgZmFjdWx0YXRpZnNcIixcbiAgXCJyZWZ1c2VyIHRvdXQsIHNhdWYgbGVzIGNvb2tpZXMgdGVjaG5pcXVlc1wiLFxuICBcInJlZnVzZXIgdG91dGVzXCIsXG4gIFwicmVmdXNlciB0b3V0ZXMgbGVzIG9wdGlvbnNcIixcbiAgXCJyZWpldGVyIGxhIGJhbm5pXFx4RThyZVwiLFxuICBcInJlamV0ZXIgbGVzIGNvb2tpZXMgbm9uIGVzc2VudGllbHNcIixcbiAgXCJyZWpldGVyIGxlcyBjb29raWVzIG9wdGlvbm5lbHNcIixcbiAgXCJyZWpldGVyIHRvdXMgbGVzIG5vbiBmb25jdGlvbm5lbHNcIixcbiAgXCJyZWpldGVyIHRvdXQgb3B0aW9ubmVsXCIsXG4gIFwidG91dCByZWZ1c2VyLCBzYXVmIGxlcyBjb29raWVzIHRlY2huaXF1ZXNcIixcbiAgXCJ1bmlxdWVtZW50IG5cXHhFOWNlc3NhaXJlc1wiLFxuICBcInggY29udGludWVyIHNhbnMgYWNjZXB0ZXJcIixcbiAgXCJzdHJpY3RlbWVudCBuXFx4RTljZXNzYWlyZXNcIixcbiAgXCJ1dGlsaXNlciB1bmlxdWVtZW50IGxlcyBjb29raWVzIG5cXHhFOWNlc3NhaXJlc1wiLFxuICBcImNvb2tpZXMgblxceEU5Y2Vzc2FpcmVzXCIsXG4gIFwiYWNjZXB0ZXIgdW5pcXVlbWVudCBsZXMgY29va2llcyBlc3NlbnRpZWxzXCIsXG4gIFwiYWNjZXB0ZXIgbGVzIGNvb2tpZXMgblxceEU5Y2Vzc2FpcmVzXCIsXG4gIFwidW5pcXVlbWVudCBsZXMgY29va2llcyBuXFx4RTljZXNzYWlyZXNcIixcbiAgXCJhdXRvcmlzZXIgdW5pcXVlbWVudCBsZXMgY29va2llcyBlc3NlbnRpZWxzXCIsXG4gIFwiYXV0b3Jpc2VyIHVuaXF1ZW1lbnQgbGVzIGNvb2tpZXMgblxceEU5Y2Vzc2FpcmVzXCIsXG4gIFwic2kgdm91cyBuZSBzb3VoYWl0ZXogcGFzIGFjY2VwdGVyIGxlcyBjb29raWVzIFxceEUwIGxleGNlcHRpb24gZGVzIGNvb2tpZXMgdGVjaG5pcXVlbWVudCBuXFx4RTljZXNzYWlyZXMsIHZldWlsbGV6IGNsaXF1ZXIgaWNpXCIsXG4gIFwiY29va2llcyBzdHJpY3RlbWVudCBuXFx4RTljZXNzYWlyZXNcIixcbiAgXCJhY2NlcHRlciBsZXMgY29va2llcyBzdHJpY3RlbWVudCBuXFx4RTljZXNzYWlyZXNcIixcbiAgXCJhdXRvcmlzZXIgbGVzIGNvb2tpZXMgZXNzZW50aWVsc1wiLFxuICBcIm5vbiwgbWVyY2ksIHVuaXF1ZW1lbnQgbGVzIGNvb2tpZXMgblxceEU5Y2Vzc2FpcmVzXCIsXG4gIFwiaW5kaXNwZW5zYWJsZSB1bmlxdWVtZW50XCIsXG4gIFwidW5pcXVlbWVudCBhdXRvcmlzZXIgbGVzIGNvb2tpZXMgZXNzZW50aWVsc1wiLFxuICBcInV0aWxpc2VyIHF1ZSBsZXMgY29va2llcyBuXFx4RTljZXNzYWlyZXNcIixcbiAgXCJ1bmlxdWVtZW50IGxlcyBzZGsgblxceEU5Y2Vzc2FpcmVzXCIsXG4gIFwidW5pcXVlbWVudCBuXFx4RTljZXNzYWlyZVwiLFxuICBcInV0aWxpc2VyIHVuaXF1ZW1lbnQgbGVzIGNvb2tpZXMgZm9uY3Rpb25uZWxzXCIsXG4gIFwicmVmdXNcIixcbiAgXCJyZWZ1c2V6XCIsXG4gIFwibmFjY2VwdGVyIHF1ZSBsZXMgY29va2llcyBpbmRpc3BlbnNhYmxlc1wiLFxuICBcIm5hY2NlcHRlciBxdWUgbGVzIGNvb2tpZXMgblxceEU5Y2Vzc2FpcmVzXCIsXG4gIFwibmFjY2VwdGVyIHF1ZSBsZXMgY29va2llcyB0ZWNobmlxdWVzXCIsXG4gIFwiblxceEU5Y2Vzc2FpcmVzIHNldWxlbWVudFwiXG5dO1xudmFyIFJFSkVDVF9QQVRURVJOU19HRVJNQU4gPSBbXG4gIFwiYWJsZWhuZW5cIixcbiAgXCJhbGxlIGFibGVobmVuXCIsXG4gIFwibnVyIG5vdHdlbmRpZ2UgY29va2llc1wiLFxuICBcIm51ciBlc3NlbnppZWxsZSBjb29raWVzIGFremVwdGllcmVuXCIsXG4gIFwibnVyIG5vdHdlbmRpZ2UgY29va2llcyB2ZXJ3ZW5kZW5cIixcbiAgXCJhbGxlcyBhYmxlaG5lblwiLFxuICBcIm51ciBub3R3ZW5kaWdlXCIsXG4gIFwiYWxsZSBjb29raWVzIGFibGVobmVuXCIsXG4gIFwid2VpdGVyIG9obmUgZWlud2lsbGlndW5nXCIsXG4gIFwibWl0IGRpZXNlbSBidXR0b24gd2lyZCBkZXIgZGlhbG9nIGdlc2NobG9zc2VuLiBzZWluZSBmdW5rdGlvbmFsaXRcXHhFNHQgaXN0IGlkZW50aXNjaCBtaXQgZGVyIGRlcyBidXR0b25zIG51ciBlc3NlbnppZWxsZSBjb29raWVzIGFremVwdGllcmVuLlwiLFxuICBcImNvb2tpZXMgYWJsZWhuZW5cIixcbiAgXCJvcHRpb25hbGUgY29va2llcyBhYmxlaG5lblwiLFxuICBcIm51ciBlcmZvcmRlcmxpY2hlIGNvb2tpZXNcIixcbiAgXCJlaW53aWxsaWd1bmcgYWJsZWhuZW5cIixcbiAgXCJudXIgZXJmb3JkZXJsaWNoZVwiLFxuICBcIm51ciBub3R3ZW5kaWdlIGNvb2tpZXMgenVsYXNzZW5cIixcbiAgXCJudXIgZnVua3Rpb25hbGUgY29va2llcyBha3plcHRpZXJlblwiLFxuICBcIm51ciBub3R3ZW5kaWdlIGNvb2tpZXMgYWt6ZXB0aWVyZW5cIixcbiAgXCJudXIgbm90d2VuZGlnZSB0ZWNobm9sb2dpZW5cIixcbiAgXCJ2ZXJ3ZWlnZXJuXCIsXG4gIFwid2ViYW5hbHlzZSBhYmxlaG5lblwiLFxuICBcIndlaXRlciBvaG5lIHp1c3RpbW11bmdcIixcbiAgXCJvcHRpb25hbGUgYWJsZWhuZW5cIixcbiAgXCJudXIgbm90d2VuZGlnZSBha3plcHRpZXJlblwiLFxuICBcIm51ciBmdW5rdGlvbmFsZSBjb29raWVzXCIsXG4gIFwibWl0IGRpZXNlbSBidXR0b24gd2lyZCBkZXIgZGlhbG9nIGdlc2NobG9zc2VuLiBzZWluZSBmdW5rdGlvbmFsaXRcXHhFNHQgaXN0IGlkZW50aXNjaCBtaXQgZGVyIGRlcyBidXR0b25zIGFibGVobmVuLlwiLFxuICBcIm51ciBub3R3ZW5kaWdlIGNvb2tpZXMgZXJsYXViZW5cIixcbiAgXCJ6dXN0aW1tdW5nIHZlcndlaWdlcm5cIixcbiAgXCJuZWluLCBkYW5rZVwiLFxuICBcIm51ciBlcmZvcmRlcmxpY2hlIGNvb2tpZXMgYWt6ZXB0aWVyZW5cIixcbiAgXCJ6dXNcXHhFNHR6bGljaGUgY29va2llcyBhYmxlaG5lblwiLFxuICBcImFibGVobmVuIHVuZCBudXIgZXNzZW56aWVsbGUgY29va2llcyBha3plcHRpZXJlblwiLFxuICBcIm5pY2h0IGVyZm9yZGVybGljaGUgYWJsZWhuZW5cIixcbiAgXCJuaWNodCBlc3NlbnppZWxsZSBjb29raWVzIGRhdGVuIGFibGVobmVuXCIsXG4gIFwibnVyIHRlY2huaXNjaCBub3R3ZW5kaWdlIGNvb2tpZXNcIixcbiAgXCJudXIgdGVjaG5pc2NoIG5vdHdlbmRpZ2UgY29va2llcyBha3plcHRpZXJlblwiLFxuICBcImFibGVobmVuIHNwZWljaGVyblwiLFxuICBcImFsbGUgZnVua3Rpb25lbiBhYmxlaG5lblwiLFxuICBcImFsbGUgb3B0aW9uYWxlbiBjb29raWVzIGFibGVobmVuXCIsXG4gIFwiYWxsZXMgdmVyd2VpZ2VyblwiLFxuICBcIm1pdCBlcmZvcmRlcmxpY2hlbiBlaW5zdGVsbHVuZ2VuIGZvcnRmYWhyZW5cIixcbiAgXCJuaWNodCBub3R3ZW5kaWdlIGFibGVobmVuXCIsXG4gIFwibm90d2VuZGlnZSBjb29raWVzIGFremVwdGllcmVuXCIsXG4gIFwibnVyIGVyZm9yZGVybGljaGUgdGVjaG5vbG9naWVuXCIsXG4gIFwibnVyIGVzc2VuemllbGxlIGNvb2tpZXNcIixcbiAgXCJudXIgZXNzZW56aWVsbGUgY29va2llcyBlcmxhdWJlblwiLFxuICBcInRlY2huaXNjaCBuaWNodCBub3R3ZW5kaWdlIGNvb2tpZXMgYWJsZWhuZW5cIixcbiAgXCJ0aXBwZW4gc2llIHp1bSBhYmxlaG5lbiBiaXR0ZSBoaWVyXCIsXG4gIFwiYWJsZWhuZW4gZGVueVwiLFxuICBcImZvcnRmYWhyZW4gb2huZSB6dSBha3plcHRpZXJlblwiLFxuICBcIm51ciBlcmZvcmRlcmxpY2hlIGFremVwdGllcmVuXCIsXG4gIFwibnVyIG5vdHdlbmRpZ2UgZXJsYXViZW5cIixcbiAgXCJhYmxlaG5lbiAuLi5udXIgdGVjaG5pc2NoIG5vdHdlbmRpZ2UgY29va2llcyB2ZXJ3ZW5kZXQgd2VyZGVuXCIsXG4gIFwiYWJsZWhuZW4gKGF1XFx4REZlciBub3R3ZW5kaWdlIGNvb2tpZXMpXCIsXG4gIFwiYWJsZWhuZW4gdW5kIGZvcnRmYWhyZW5cIixcbiAgXCJhYmxlaG5lbiB1bmQgc2NobGllXFx4REZlblwiLFxuICBcImFibGVobmVuOiBudXIgZ3J1bmRmdW5rdGlvbmVuXCIsXG4gIFwiYWt6ZXB0aWVyZW4gbnVyIG5vdHdlbmRpZ2UgY29va2llc1wiLFxuICBcImFsbGUgYWJsZWhuZW4gKGF1XFx4REZlciBub3R3ZW5kaWdlIGNvb2tpZXMpXCIsXG4gIFwiYWxsZSBuaWNodCBlc3NlbnppZWxsZW4gY29va2llcyBhYmxlaG5lblwiLFxuICBcImFsbGUgbmljaHQgbm90d2VuZGlnZW4gY29va2llcyBhYmxlaG5lblwiLFxuICBcImFsbGUgb3B0aW9uYWxlIGFibGVobmVuXCIsXG4gIFwiYWxsZSBvcHRpb25hbGVuIGFibGVobmVuXCIsXG4gIFwiYWxsZSB2ZXJ3ZWlnZXJuXCIsXG4gIFwiYW5hbHlzZSBjb29raWVzIGFibGVobmVuXCIsXG4gIFwiY29va2llIGVpbnN0ZWxsdW5nZW5hYmxlaG5lblwiLFxuICBcImVyZm9yZGVybGljaGUgY29va2llcyBha3plcHRpZXJlblwiLFxuICBcImVyZm9yZGVybGljaGUgY29va2llcyB6dWxhc3NlblwiLFxuICBcImV4dGVybmUgaW5oYWx0ZSBhYmxlaG5lblwiLFxuICBcIm1pdCBkaWVzZW0gYnV0dG9uIHdpcmQgZGVyIGRpYWxvZyBnZXNjaGxvc3Nlbi4gc2VpbmUgZnVua3Rpb25hbGl0XFx4RTR0IGlzdCBpZGVudGlzY2ggbWl0IGRlciBkZXMgYnV0dG9ucyBhYmxlaG5lbiB1bmQgbnVyIGVzc2VuemllbGxlIGNvb2tpZXMgYWt6ZXB0aWVyZW4uXCIsXG4gIFwibWl0IGRpZXNlbSBidXR0b24gd2lyZCBkZXIgZGlhbG9nIGdlc2NobG9zc2VuLiBzZWluZSBmdW5rdGlvbmFsaXRcXHhFNHQgaXN0IGlkZW50aXNjaCBtaXQgZGVyIGRlcyBidXR0b25zIG5pY2h0LWVzc2VuemllbGxlIGNvb2tpZXMgdmVyd2VpZ2Vybi5cIixcbiAgXCJtaXQgZGllc2VtIGJ1dHRvbiB3aXJkIGRlciBkaWFsb2cgZ2VzY2hsb3NzZW4uIHNlaW5lIGZ1bmt0aW9uYWxpdFxceEU0dCBpc3QgaWRlbnRpc2NoIG1pdCBkZXIgZGVzIGJ1dHRvbnMgbnVyIGVzc2VuemllbGxlIGFremVwdGllcmVuLlwiLFxuICBcIm1pdCBlcmZvcmRlcmxpY2hlbiBjb29raWVzIGZvcnRmYWhyZW5cIixcbiAgXCJtaXQgbm90d2VuZGlnZW4gZm9ydGZhaHJlblwiLFxuICBcIm5laW4sIGJpdHRlIG5pY2h0XCIsXG4gIFwibmVpbiwgaWNoIHN0aW1tZSBuaWNodCB6dVwiLFxuICBcIm5pY2h0IGZ1bmt0aW9uYWxlIGNvb2tpZXMgYWJsZWhuZW5cIixcbiAgXCJuaWNodCBub3R3ZW5kaWdlIGNvb2tpZXMgYWJsZWhuZW5cIixcbiAgXCJuaWNodC1lc3NlbnppZWxsZSBjb29raWVzIGFibGVobmVuXCIsXG4gIFwibmljaHQtZXNzZW56aWVsbGUgY29va2llcyB2ZXJ3ZWlnZXJuXCIsXG4gIFwibm90d2VuZGlnZSBjb29raWVzIHp1bGFzc2VuXCIsXG4gIFwibnVyIGVyZm9yZGVybGljaGUgY29va2llcyBlcmxhdWJlblwiLFxuICBcIm51ciBlcmZvcmRlcmxpY2hlIGNvb2tpZXMgc2V0emVuXCIsXG4gIFwibnVyIGVyZm9yZGVybGljaGUgY29va2llcyB2ZXJ3ZW5kZW5cIixcbiAgXCJudXIgZXNzZW56aWVsbGUgYWt6ZXB0aWVyZW5cIixcbiAgXCJudXIgbm90d2VuZGlnZSBjb29raWVzIGFubmVobWVuXCIsXG4gIFwibnVyIG5vdHdlbmRpZ2UgY29va2llcyBzcGVpY2hlcm5cIixcbiAgXCJudXIgbm90d2VuZGlnZSBjb29raWVzIHZlcndlbmRlbi5cIixcbiAgXCJudXIgbm90d2VuZGlnZSBmdW5rdGlvbnNjb29raWVzIGFremVwdGllcmVuXCIsXG4gIFwibnVyIG5vdHdlbmRpZ2VuIGNvb2tpZXMgenVzdGltbWVuXCIsXG4gIFwibnVyIG5vdHdlbmRpZ2VzIGFremVwdGllcmVuXCIsXG4gIFwibnVyIHdlc2VudGxpY2hlIGNvb2tpZXMgYW5uZWhtZW5cIixcbiAgXCJvcHQuIGNvb2tpZXMgYWJsZWhuZW5cIixcbiAgXCJvcHRpb25hbGUgZGllbnN0ZSBhYmxlaG5lblwiLFxuICBcIm9wdGlvbmFsZSB0b29scyBhYmxlaG5lblwiLFxuICBcInNpZSBhbGxlIGNvb2tpZXMgYWJsZWhuZW5cIixcbiAgXCJ0ZWNobmlzY2ggbm90d2VuZGlnZSBhbm5laG1lblwiLFxuICBcIm51ciBlc3NlbnRpZWxsZSBjb29raWVzXCIsXG4gIFwibnVyIGVzc2VudGllbGxlXCIsXG4gIFwibnVyIGZ1bmt0aW9uYWxlIGFremVwdGllcmVuXCIsXG4gIFwibnVyIHRlY2huaXNjaCBub3R3ZW5kaWdlIGFremVwdGllcmVuXCIsXG4gIFwibnVyIHRlY2huaXNjaCBub3R3ZW5kaWdlIGRhdGVuIHVuZCBjb29raWVzIC4uLlwiLFxuICBcIm51ciB0ZWNobmlzY2ggbm90d2VuZGlnZSB6dWxhc3NlblwiLFxuICBcIm51ciB3ZXNlbnRsaWNoZVwiLFxuICBcIm9obmUgZWludmVyc3RcXHhFNG5kbmlzIGZvcnRmYWhyZW5cIixcbiAgXCJvaG5lIGVpbndpbGxpZ3VuZ1wiLFxuICBcIm9obmUgenVzdGltbXVuZyBmb3J0ZmFocmVuXCIsXG4gIFwib2huZSB6dXN0aW1tdW5nIHdlaXRlclwiLFxuICBcIndlaXRlciBtaXQgZXNzZW50aWVsbGVuIGNvb2tpZXNcIixcbiAgXCJ3ZWl0ZXIgb2huZSBhbm5haG1lXCIsXG4gIFwid2VpdGVyIG9obmUgc3RhdGlzdGlzY2hlIGFuYWx5c2UtY29va2llc1wiLFxuICBcIndlaXRlciBvaG5lIHN0YXRpc3Rpc2NoZSBjb29raWVzXCIsXG4gIFwid2VzZW50bGljaGUgY29va2llc1wiLFxuICBcImZvcnRmYWhyZW4gb2huZSB6dXN0aW1tdW5nXCJcbl07XG52YXIgUkVKRUNUX1BBVFRFUk5TX0lUQUxJQU4gPSBbXG4gIFwicmlmaXV0YVwiLFxuICBcInJpZml1dGEgY29va2llc1wiLFxuICBcInJpZml1dGEgaSBjb29raWVcIixcbiAgXCJyaWZpdXRhIGkgY29va2llc1wiLFxuICBcInJpZml1dGEgdHV0dGkgaSBjb29raWVcIixcbiAgXCJyaWZpdXRhIHR1dHRpIGkgY29va2llc1wiLFxuICBcInJpZml1dGEgY29va2llIG5vbiBuZWNlc3NhcmlcIixcbiAgXCJyaWZpdXRhIGkgY29va2llIG5vbiB0ZWNuaWNpXCIsXG4gIFwicmlmaXV0YSBub24gbmVjZXNzYXJpXCIsXG4gIFwicmlmaXV0YSB0dXR0b1wiLFxuICBcInJpZml1dGEgdHV0dGlcIixcbiAgXCJyaWZpdXRhIGUgY2hpdWRpXCIsXG4gIFwiY2hpdWRpIHJpZml1dGEgdHV0dGkgaSBjb29raWVcIixcbiAgXCJjaGl1ZGkgZSByaWZpdXRhIHR1dHRpIGkgY29va2llXCIsXG4gIFwiY2hpdWRpIGUgcmlmaXV0YSB0dXR0b1wiLFxuICBcIm5lZ2FcIixcbiAgXCJuZWdhIHR1dHRpXCIsXG4gIFwibmVnYXJlXCIsXG4gIFwibm9uIGFjY2V0dG9cIixcbiAgXCJhY2NldHRhIHNvbG8gaSBuZWNlc3NhcmlcIixcbiAgXCJ1c2Egc29sbyBpIGNvb2tpZSBuZWNlc3NhcmlcIixcbiAgXCJhY2NldHRhIHNvbG8gbmVjZXNzYXJpXCIsXG4gIFwic29sbyBuZWNlc3NhcmlcIixcbiAgXCJjb250aW51YSBzZW56YSBhY2NldHRhcmUgeFwiLFxuICBcImNvbnRpbnVhIHNlbnphIGFjY2V0dGFyZVwiLFxuICBcInJpZml1dGFyZVwiLFxuICBcInJpZml1dGFyZSBpIGNvb2tpZVwiLFxuICBcInJpZml1dGFyZSB0dXR0aSBpIGNvb2tpZVwiLFxuICBcInJpZml1dGFyZSB0dXR0aVwiLFxuICBcInJpZml1dGFyZSBlIGNvbnRpbnVhcmVcIixcbiAgXCJpbnN0YWxsYSBzb2xvIGkgY29va2llIHN0cmV0dGFtZW50ZSBuZWNlc3NhcmlcIixcbiAgXCJzb2xvIGNvb2tpZXMgdGVjbmljaVwiLFxuICBcImFjY2V0dGEgbmVjZXNzYXJpXCIsXG4gIFwic29sbyBjb29raWUgdGVjbmljaVwiLFxuICBcInNvbG8gY29va2llIG5lY2Vzc2FyaVwiLFxuICBcInN0cmV0dGFtZW50ZSBuZWNlc3NhcmlcIixcbiAgXCJ0ZWNuaWNpXCIsXG4gIFwiYWNjZXR0YSBzb2xvIGNvb2tpZSBkaSBuYXZpZ2F6aW9uZVwiLFxuICBcImNoaXVkaSBlIHByb3NlZ3VpIHNvbG8gY29uIGkgY29va2llcyB0ZWNuaWNpIG5lY2Vzc2FyaVwiLFxuICBcImNvbnNlbnRpIHNvbG8gaSBjb29raWUgdGVjbmljaVwiLFxuICBcInNvbG8gY29va2llIGVzc2VuemlhbGlcIixcbiAgXCJibG9jY2EgaSBjb29raWUgbm9uIGVzc2VuemlhbGlcIixcbiAgXCJhY2NldHRhIGkgY29va2llIG5lY2Vzc2FyaVwiLFxuICBcImFjY2V0dGEgc29sbyBjb29raWUgdGVjbmljaVwiLFxuICBcImFjY2V0dGEgc29sbyBpIGNvb2tpZSBlc3NlbnppYWxpXCIsXG4gIFwiYWNjZXR0YSBzb2xvIGkgY29va2llIG5lY2Vzc2FyaVwiLFxuICBcImFjY2V0dGEgc29sbyBpIG5lY2Vzc2FyeVwiLFxuICBcImFjY2V0dGEgaSBjb29raWUgZXNzZW56aWFsaVwiLFxuICBcImFjY2V0dGEgY29va2llIHRlY25pY2lcIixcbiAgXCJuZWNlc3NhcmlcIixcbiAgXCJ1c2Egc29sbyBpIGNvb2tpZSB0ZWNuaWNpXCIsXG4gIFwidXNhIHNvbG8gaSBuZWNlc3NhcmlcIixcbiAgXCJyaWZpdXRvXCIsXG4gIFwiZXNzZW56aWFsaVwiLFxuICBcImFjY2V0dGEgY29va2llIGVzc2VuemlhbGlcIixcbiAgXCJhY2NldHRhIGNvb2tpZSBuZWNlc3NhcmlcIixcbiAgXCJhY2NldHRhIHNvbG8gY29va2llIGVzc2VuemlhbGlcIixcbiAgXCJhY2NldHRhIHNvbG8gY29va2llIG5lY2Vzc2FyaVwiLFxuICBcInJpZml1dGEgY29va2llIG5vbiBuZWNlc3NhcmlcIixcbiAgXCJyaWZpdXRhIGNvb2tpZSBub24gZXNzZW56aWFsaVwiLFxuICBcInJpZml1dGEgaSBjb29raWUgbm9uIG5lY2Vzc2FyaVwiLFxuICBcInJpZml1dGEgaSBjb29raWUgbm9uIGVzc2VuemlhbGlcIixcbiAgXCJyaWZpdXRhIHR1dHRpIGkgY29va2llIGUgY2hpdWRpXCIsXG4gIFwicmlmaXV0YSB0dXR0byBlIGNoaXVkaVwiLFxuICBcInJpZml1dGEgdHV0dGkgaSBjb29raWUgY2hpdWRpXCIsXG4gIFwiY29udGludWFyZSBzZW56YSBhY2NldHRhcmVcIixcbiAgXCJyaWZpdXRhcmUgY29va2llc1wiLFxuICBcInJpZml1dGFyZSBpIGNvb2tpZXNcIixcbiAgXCJyaWZpdXRhcmUgbm9uIG5lY2Vzc2FyaVwiLFxuICBcInJpZml1dGFyZSB0dXR0b1wiLFxuICBcInJpZml1dGFyZSBlIGNoaXVkZXJlXCIsXG4gIFwic29sbyBlc3NlbnppYWxpXCIsXG4gIFwic29sbyB0ZWNuaWNpXCIsXG4gIFwibmVnYXJlIHR1dHRpXCJcbl07XG52YXIgUkVKRUNUX1BBVFRFUk5TX0JSQVpJTElBTl9QT1JUVUdVRVNFID0gW1xuICAvLyAoZGVueSlcbiAgL15cXHMqKHJlamVpdGFyfHJlY3VzYXJ8ZGVzYXRpdmFyfGJsb3F1ZWFyfG5lZ2FyfG5cdTAwRTNvXFxzKmFjZWl0b3xuXHUwMEUzbyBcXHMqYWNlaXRhcilcXHMqJC9pcyxcbiAgLy8gKHByb2NlZWQpICh3aXRob3V0IGFjY2VwdGluZylcbiAgL15cXHMqKGNvbnRpbnVhcnxwcm9zc2VndWlyfHNlZ3VpcilcXHMqKHNlbVxccyphY2VpdGFyKVxccyokL2lzLFxuICAvLyAoZGVueSkgKGV2ZXJ5dGhpbmcpIChvcHRpb25hbClcbiAgL15cXHMqKHJlamVpdGFyfHJlY3VzYXJ8ZGVzYXRpdmFyfGJsb3F1ZWFyfG5lZ2FyfG5cdTAwRTNvXFxzKmFjZWl0b3xuXHUwMEUzbyBcXHMqYWNlaXRhcilcXHMqKHR1ZG98byk/XFxzKihvcGNpb25hbHwoblx1MDBFM29bLVxcc10oZXNzZW5jaWFsfGZ1bmNpb25hbHxvYnJpZ2F0XHUwMEYzcmlvfG5lY2Vzc1x1MDBFMXJpbykpKT9cXHMqJC9pcyxcbiAgLy8gKGRlbnkpIChhbGwpICh0aGUpIChvcHRpb25hbCkgKGNvb2tpZXMpXG4gIC9eXFxzKihyZWplaXRhcnxyZWN1c2FyfGRlc2F0aXZhcnxibG9xdWVhcnxuZWdhcnxuXHUwMEUzb1xccyphY2VpdG98blx1MDBFM28gXFxzKmFjZWl0YXIpXFxzKih0b2Rvcyk/XFxzKihvcyk/XFxzKihjb29raWVzKT9cXHMqKG9wY2lvbmFpc3woblx1MDBFM29bLVxcc10oZXNzZW5jaWFpc3xmdW5jaW9uYWlzfG9icmlnYXRcdTAwRjNyaW9zfG5lY2Vzc1x1MDBFMXJpb3MpKSk/XFxzKiQvaXMsXG4gIC8vIChhY2NlcHQpIChvbmx5KSAodGhlKSAoZXNzZW50aWFsKVxuICAvXlxccyooYWNlaXRhcnx1dGlsaXphcik/XFxzKihhcGVuYXN8c29tZW50ZXxzXHUwMEYzKT9cXHMqKG8pP1xccyooZXNzZW5jaWFsfGZ1bmNpb25hbHxvYnJpZ2F0XHUwMEYzcmlvfG5lY2Vzc1x1MDBFMXJpbylcXHMqJC9pcyxcbiAgLy8gKGFjY2VwdCkgKG9ubHkpICh0aGUpIChlc3NlbnRpYWwpIChjb29raWVzKVxuICAvXlxccyooYWNlaXRhcnx1dGlsaXphcik/XFxzKihhcGVuYXN8c29tZW50ZXxzXHUwMEYzKT9cXHMqKG9zKT9cXHMqKGNvb2tpZXMpP1xccyooZXNzZW5jaWFpc3xmdW5jaW9uYWlzfG9icmlnYXRcdTAwRjNyaW9zfG5lY2Vzc1x1MDBFMXJpb3MpXFxzKiQvaXNcbl07XG52YXIgUkVKRUNUX1BBVFRFUk5TX1NQQU5JU0ggPSBbXG4gIFwicmVjaGF6YXJcIixcbiAgXCJyZWNoYXphciB0b2RvXCIsXG4gIFwicmVjaGF6YXIgdG9kYXNcIixcbiAgXCJkZW5lZ2FyXCIsXG4gIFwicmVjaGF6YXIgY29va2llc1wiLFxuICBcInJlY2hhemFybGFzIHRvZGFzXCIsXG4gIFwibm8gYWNlcHRvXCIsXG4gIFwicmVjaGF6YXIgdG9kYXMgbGFzIGNvb2tpZXNcIixcbiAgXCJyZWNoYXphciB5IGNlcnJhclwiLFxuICBcImRlbmVnYXIgdG9kYXNcIixcbiAgXCJzb2xvIG5lY2VzYXJpYXNcIixcbiAgXCJyZWNoYXphciBjb29raWVzIG9wY2lvbmFsZXNcIixcbiAgXCJyZWNoYXphciBvcGNpb25hbGVzXCIsXG4gIFwiY29va2llcyBlc3RyaWN0YW1lbnRlIG5lY2VzYXJpYXNcIixcbiAgXCJhY2VwdGFyIHNcXHhGM2xvIG5lY2VzYXJpYXNcIixcbiAgXCJkZW5lZ2FyIHRvZG9cIixcbiAgXCJjbGVhciByZWNoYXphciBjb29raWVzXCIsXG4gIFwiY29uZmlndXJhciByZWNoYXphciBjb29raWVzXCIsXG4gIFwiZGVuZWdhciBjb29raWVzXCIsXG4gIFwicmVjaGF6YXIgeSBjb250aW51YXJcIixcbiAgXCJyZWNoYXphciBsYXMgY29va2llc1wiLFxuICBcImNsZWFyIHJlY2hhemFyXCIsXG4gIFwiZGVuZWdhciB0b2RhcyBsYXMgY29va2llc1wiLFxuICBcInJlY2hhemFyIGNvb2tpZXMgbm8gZXNlbmNpYWxlc1wiLFxuICBcInJlY2hhemFybGFzXCIsXG4gIFwibm8sIG5vIGFjZXB0b1wiLFxuICBcInBlcm1pdGlyIHNcXHhGM2xvIG5lY2VzYXJpYXNcIixcbiAgXCJyZWNoYXphciBjb29raWVzIGFkaWNpb25hbGVzXCIsXG4gIFwicmVjaGF6YXIgY29va2llcyBhbmFsXFx4RUR0aWNhc1wiLFxuICBcInJlY2hhemFyIG5vIG5lY2VzYXJpYXNcIixcbiAgXCJyZWNoYXphciBvcGNpb25hbFwiLFxuICBcInJlY2hhemFyIHRvZG8gbG8gb3BjaW9uYWxcIixcbiAgXCJzb2xvIGNvb2tpZXMgZXN0cmljdGFtZW50ZSBuZWNlc2FyaWFzXCIsXG4gIFwic29sbyBlc2VuY2lhbGVzXCIsXG4gIFwieCByZWNoYXphciB0b2RhcyBsYXMgY29va2llc1wiLFxuICBcInNvbG8gdXNhciBjb29raWVzIG5lY2VzYXJpYXNcIixcbiAgXCJzb2xvIGNvb2tpZXMgbmVjZXNhcmlhc1wiLFxuICBcImRlY2xpbmFyXCIsXG4gIFwiYWNlcHRhciBzb2xvIGxhcyBjb29raWVzIGVzZW5jaWFsZXNcIixcbiAgXCJuZWNlc2FyaWFzXCIsXG4gIFwiYWNlcHRhciBjb29raWVzIG9wY2lvbmFsZXNcIixcbiAgXCJhY2VwdGFyIHNvbG8gbG8gbmVjZXNhcmlvXCIsXG4gIFwic29sbyBmdW5jaW9uYWxlc1wiLFxuICBcImRlY2xpbmFyIHkgY2VycmFyXCIsXG4gIFwiZFxceEU5Y2xpblwiLFxuICBcImRlY2xpbmFcIixcbiAgXCJkZWNsaW5hciBjb25zZW50aW1pZW50b1wiLFxuICBcImRlY2xpbmFyIHRvZGFzXCIsXG4gIFwic29sbyBsYXMgY29va2llcyBuZWNlc2FyaWFzXCIsXG4gIFwibm9tXFx4RTlzIHN1dGlsaXR6ZW4gY29va2llcyBxdWFuIFxceEU5cyBuZWNlc3NhcmlcIixcbiAgXCJubywgc1xceEYzbG8gbGFzIGVzdHJpY3RhbWVudGUgbmVjZXNhcmlhc1wiLFxuICBcInNvbG8gbGFzIG5lY2VzYXJpYXNcIixcbiAgXCJhY2NlcHRhciBub21cXHhFOXMgbGVzIG5lY2Vzc1xceEUwcmllc1wiLFxuICBcImFjZXB0YSBzb2xvIGxhcyBuZWNlc2FyaWFzXCIsXG4gIFwiYWNlcHRhciBzb2xvIGxvIGVzZW5jaWFsXCIsXG4gIFwiYWNlcHRhciBsYXMgb2JsaWdhdG9yaWFzXCIsXG4gIFwicGVybWl0aXIgc29sbyBjb29raWVzIHRcXHhFOWNuaWNhc1wiLFxuICBcImNvb2tpZXMgdFxceEU5Y25pY2FzXCIsXG4gIFwicGVybWl0aXIgc29sbyBjb29raWVzIHRcXHhFOWNuaWNhc1wiLFxuICBcInVzYXIgc29sbyBjb29raWVzIHRcXHhFOWNuaWNhc1wiLFxuICBcImFjZXB0YXIgc29sbyBsYXMgZXNlbmNpYWxlc1wiXG5dO1xudmFyIFJFSkVDVF9QQVRURVJOU19TV0VESVNIID0gW1xuICBcImF2dmlzYVwiLFxuICBcImVuZGFzdCBuXFx4RjZkdlxceEU0bmRpZ2FcIixcbiAgXCJhdnZpc2EgYWxsYVwiLFxuICBcImVuZGFzdCBuXFx4RjZkdlxceEU0bmRpZ2EgY29va2llc1wiLFxuICBcIm5la2FcIixcbiAgXCJuZWthIGFsbGFcIixcbiAgXCJhdnZpc2EgYWxsdFwiLFxuICBcImF2dmlzYSBhbGxhIGNvb2tpZXNcIixcbiAgXCJ0aWxsXFx4RTV0IGJhcmEgblxceEY2ZHZcXHhFNG5kaWdhIGNvb2tpZXNcIixcbiAgXCJiYXJhIG5cXHhGNmR2XFx4RTRuZGlnYVwiLFxuICBcImJhcmEgblxceEY2ZHZcXHhFNG5kaWdhIGNvb2tpZXNcIixcbiAgXCJ0aWxsXFx4RTV0IGJhcmEgblxceEY2ZHZcXHhFNG5kaWdhIGtha29yXCIsXG4gIFwiZW5kYXN0IG5cXHhGNmR2XFx4RTRuZGlnYSBrYWtvclwiLFxuICBcInRpbGxcXHhFNXQgZW5kYXN0IG5cXHhGNmR2XFx4RTRuZGlnYVwiLFxuICBcImZvcnRzXFx4RTR0dCB1dGFuIGF0dCBhY2NlcHRlcmFcIixcbiAgXCJnb2RrXFx4RTRubiBlbmRhc3QgblxceEY2ZHZcXHhFNG5kaWdhXCIsXG4gIFwiYWNjZXB0ZXJhIGVuZGFzdCBuXFx4RjZkdlxceEU0bmRpZ2FcIixcbiAgXCJhdnZpc2EgY29va2llc1wiLFxuICBcInRpbGxcXHhFNXQgZW5kYXN0IG5cXHhGNmR2XFx4RTRuZGlnYSBrYWtvclwiLFxuICBcImFjY2VwdGVyYSBlbmRhc3QgblxceEY2ZHZcXHhFNG5kaWdhIGNvb2tpZXNcIixcbiAgXCJuZWthIGtha29yXCIsXG4gIFwiYmFyYSBuXFx4RjZkdlxceEU0bmRpZ2Ega2Frb3JcIixcbiAgXCJuZWthIGFsbGEgY29va2llc1wiLFxuICBcImFudlxceEU0bmQgZW5kYXN0IG5cXHhGNmR2XFx4RTRuZGlnYVwiLFxuICBcImF2dmlzYSBhbGxhIHV0b20gblxceEY2ZHZcXHhFNG5kaWdhXCIsXG4gIFwiaGFudGVyYSBlbGxlciBhdnZpc2FcIixcbiAgXCJuZWthIGFsbGEgdXRvbSBuXFx4RjZkdlxceEU0bmRpZ2Ega2Frb3JcIixcbiAgXCJuZWthIG9jaCBzdFxceEU0bmdcIixcbiAgXCJ0aWxsXFx4RTV0IGJhcmEgblxceEY2ZHZcXHhFNG5kaWdhIHRqXFx4RTRuc3RlclwiLFxuICBcImF2dmlzYSBhbGxhIHV0b20gblxceEY2ZHZcXHhFNG5kaWdhIGtha29yXCIsXG4gIFwiYXZ2aXNhIGFsbGEgdmFsZnJpYVwiLFxuICBcImdvZGtcXHhFNG5uIGJhcmEgblxceEY2ZHZcXHhFNG5kaWdhIGNvb2tpZXNcIixcbiAgXCJhY2NlcHRlcmEgZW5kYXN0IG5cXHhGNmR2XFx4RTRuZGlnYSBrYWtvclwiLFxuICBcImFudlxceEU0bmQgZW5kYXN0IG5cXHhGNmR2XFx4RTRuZGlnYSBjb29raWVzXCIsXG4gIFwiYXZ2aXNhIGFsbGEga2Frb3JcIixcbiAgXCJhdnZpc2EgYWxsYSB2YWxtXFx4RjZqbGlnaGV0ZXJcIixcbiAgXCJhdnZpc2EgZWogblxceEY2ZHZcXHhFNG5kaWdhXCIsXG4gIFwiYXZ2aXNhIGlja2UtblxceEY2ZHZcXHhFNG5kaWdhXCIsXG4gIFwiZlxceEY2cm5la2FcIixcbiAgXCJnb2RrXFx4RTRubiBiYXJhIG5cXHhGNmR2XFx4RTRuZGlnYVwiLFxuICBcImdvZGtcXHhFNG5uIGJhcmEgblxceEY2ZHZcXHhFNG5kaWdhIGtha29yXCIsXG4gIFwiZ29ka1xceEU0bm4gZW5kYXN0IG5cXHhGNmR2XFx4RTRuZGlnYSBjb29raWVzXCIsXG4gIFwiZ29ka1xceEU0bm4gZW5kYXN0IG5cXHhGNmR2XFx4RTRuZGlnYSBrYWtvclwiLFxuICBcImdvZHRhIGVuZGFzdCBuXFx4RjZkdlxceEU0bmRpZ2FcIixcbiAgXCJqYWcgZ29ka1xceEU0bm5lciBiYXJhIG5cXHhGNmR2XFx4RTRuZGlnYSBrYWtvclwiLFxuICBcIm5laiwgYXZ2aXNhIGFsbGFcIixcbiAgXCJuZWosIGJhcmEgblxceEY2ZHZcXHhFNG5kaWdhXCIsXG4gIFwibmVqLCBiYXJhIG5cXHhGNmR2XFx4RTRuZGlnYSBjb29raWVzXCIsXG4gIFwibmVrYSBhbGxhIHV0b20gblxceEY2ZHZcXHhFNG5kaWdhXCIsXG4gIFwibmVrYSBhbGxhLlwiLFxuICBcIm5la2EgY29va2llc1wiLFxuICBcIm5la2Egc2FtdGxpZ2FcIixcbiAgXCJvaywgZW5kYXN0IG5cXHhGNmR2XFx4RTRuZGlnYVwiLFxuICBcInNwYXJhIGVuZGFzdCBuXFx4RjZkdlxceEU0bmRpZ2FcIixcbiAgXCJzdFxceEU0bmcgb2NoIGF2dmlzYVwiLFxuICBcInRpbGxcXHhFNXQgYmFyYSBuXFx4RjZkdlxceEU0bmRpZ2FcIixcbiAgXCJnb2RrXFx4RTRubiBuXFx4RjZkdlxceEU0bmRpZ2Ega2Frb3JcIixcbiAgXCJnb2RrXFx4RTRubiBuXFx4RjZkdlxceEU0bmRpZ2FcIixcbiAgXCJhY2NlcHRlcmEgblxceEY2ZHZcXHhFNG5kaWdhXCIsXG4gIFwic3RyaWt0IG5cXHhGNmR2XFx4RTRuZGlndFwiLFxuICBcInRpbGxcXHhFNXQgblxceEY2ZHZcXHhFNG5kaWdhXCIsXG4gIFwiblxceEY2ZHZcXHhFNG5kaWdhXCIsXG4gIFwiZW5iYXJ0IG5cXHhGNmR2XFx4RTRuZGlnYVwiLFxuICBcImphZyBnb2RrXFx4RTRubmVyIG5cXHhGNmR2XFx4RTRuZGlnYSBrYWtvclwiLFxuICBcImFjY2VwdGVyYSBuXFx4RjZkdlxceEU0bmRpZ2Ega2Frb3JcIixcbiAgXCJnb2RrXFx4RTRubiBlbmJhcnQgblxceEY2ZHZcXHhFNG5kaWdhIGtha29yXCIsXG4gIFwiZ29ka1xceEU0bm4gblxceEY2ZHZcXHhFNG5kaWdhIGNvb2tpZXNcIixcbiAgXCJvbSBkdSBpbnRlIHZpbGwgYWNjZXB0ZXJhIGFuZHJhIGNvb2tpZXMgXFx4RTRuIGRlIHNvbSBcXHhFNHIgdGVrbmlza3QgblxceEY2ZHZcXHhFNG5kaWdhIGtsaWNrYXIgZHUgaFxceEU0clwiLFxuICBcImFjY2VwdGVyYSBlbmJhcnQgblxceEY2ZHZcXHhFNG5kaWdhXCIsXG4gIFwiblxceEY2ZHZcXHhFNG5kaWdhIGNvb2tpZXNcIixcbiAgXCJqYWcgZ29ka1xceEU0bm5lciBlbmJhcnQgYXR0IG5pIGFudlxceEU0bmRlciBuXFx4RjZkdlxceEU0bmRpZ2EgY29va2llc1wiLFxuICBcIisgc3RyaWt0IG5cXHhGNmR2XFx4RTRuZGlnYSBjb29raWVzXCIsXG4gIFwiYW52XFx4RTRuZCBlbmJhcnQgblxceEY2ZHZcXHhFNG5kaWdhIGNvb2tpZXNcIixcbiAgXCJlbmJhcnQgblxceEY2ZHZcXHhFNG5kaWdhIGNvb2tpZXNcIixcbiAgXCJnb2RrXFx4RTRubiBuXFx4RjZkdlxceEU0bmRpZ2Ega2Frb3Igc3RcXHhFNG5nXCIsXG4gIFwib2sgdGlsbCBuXFx4RjZkdlxceEU0bmRpZ2FcIixcbiAgXCJzdHJpa3QgblxceEY2ZHZcXHhFNG5kaWdhXCIsXG4gIFwiZm9ydHNcXHhFNHR0IHV0YW4gYXR0IGdvZGtcXHhFNG5uYVwiLFxuICBcImF2YlxceEY2aiBhbGxhIGNvb2tpZXNcIixcbiAgXCJqYWcgYWNjZXB0ZXJhciBlbmRhc3QgZ3J1bmRsXFx4RTRnZ2FuZGUga2Frb3JcIixcbiAgXCJuZWosIGphZyBhdmJcXHhGNmplclwiLFxuICBcInRpbGxcXHhFNXQgaW50ZSBjb29raWVzXCJcbl07XG52YXIgUkVKRUNUX1BBVFRFUk5TID0gW1xuICAuLi5SRUpFQ1RfUEFUVEVSTlNfRU5HTElTSCxcbiAgLi4uUkVKRUNUX1BBVFRFUk5TX0RVVENILFxuICAuLi5SRUpFQ1RfUEFUVEVSTlNfRlJFTkNILFxuICAuLi5SRUpFQ1RfUEFUVEVSTlNfR0VSTUFOLFxuICAuLi5SRUpFQ1RfUEFUVEVSTlNfSVRBTElBTixcbiAgLi4uUkVKRUNUX1BBVFRFUk5TX0JSQVpJTElBTl9QT1JUVUdVRVNFLFxuICAuLi5SRUpFQ1RfUEFUVEVSTlNfU1BBTklTSCxcbiAgLi4uUkVKRUNUX1BBVFRFUk5TX1NXRURJU0hcbl07XG52YXIgTkVWRVJfTUFUQ0hfUEFUVEVSTlMgPSBbXG4gIC9wYXl8c3Vic2NyaWJlL2lzLFxuICAvYWJvbm5lZXIvaXMsXG4gIC9hYm9ubmllci9pcyxcbiAgL2Fib25uZXIvaXMsXG4gIC9hYmJvbmF0aS9pcyxcbiAgL2lzY3Jpdml0aS9pcyxcbiAgL2FiYm9uYXJlL2lzLFxuICAvaXNjcml2ZXJlL2lzLFxuICAvc29zdGllbmljaS9pcyxcbiAgL3N1c2NyaWJpci9pc1xuXTtcblxuLy8gbGliL2hldXJpc3RpY3MudHNcbnZhciBCVVRUT05fTElLRV9FTEVNRU5UX1NFTEVDVE9SID0gJ2J1dHRvbiwgaW5wdXRbdHlwZT1cImJ1dHRvblwiXSwgaW5wdXRbdHlwZT1cInN1Ym1pdFwiXSwgYSwgW3JvbGU9XCJidXR0b25cIl0sIFtjbGFzcyo9XCJidXR0b25cIl0nO1xudmFyIFRFWFRfTElNSVQgPSAxZTU7XG5mdW5jdGlvbiBjaGVja0hldXJpc3RpY1BhdHRlcm5zKGFsbFRleHQsIGRldGVjdFBhdHRlcm5zID0gREVURUNUX1BBVFRFUk5TKSB7XG4gIGFsbFRleHQgPSBhbGxUZXh0LnNsaWNlKDAsIFRFWFRfTElNSVQpO1xuICBjb25zdCBwYXR0ZXJucyA9IFtdO1xuICBjb25zdCBzbmlwcGV0czIgPSBbXTtcbiAgZm9yIChjb25zdCBwIG9mIGRldGVjdFBhdHRlcm5zKSB7XG4gICAgY29uc3QgbWF0Y2hlczIgPSBhbGxUZXh0Py5tYXRjaChwKTtcbiAgICBpZiAobWF0Y2hlczIpIHtcbiAgICAgIHBhdHRlcm5zLnB1c2gocC50b1N0cmluZygpKTtcbiAgICAgIHNuaXBwZXRzMi5wdXNoKC4uLm1hdGNoZXMyLm1hcCgobSkgPT4gbS5zdWJzdHJpbmcoMCwgMjAwKSkpO1xuICAgIH1cbiAgfVxuICByZXR1cm4geyBwYXR0ZXJucywgc25pcHBldHM6IHNuaXBwZXRzMiB9O1xufVxuZnVuY3Rpb24gZ2V0QWN0aW9uYWJsZVBvcHVwcygpIHtcbiAgY29uc3QgcG9wdXBzID0gZ2V0UG90ZW50aWFsUG9wdXBzKCk7XG4gIGNvbnN0IHJlc3VsdCA9IHBvcHVwcy5yZWR1Y2UoKGFjYywgcG9wdXApID0+IHtcbiAgICBjb25zdCBwb3B1cFRleHQgPSBwb3B1cC50ZXh0Py50cmltKCk7XG4gICAgaWYgKHBvcHVwVGV4dCkge1xuICAgICAgY29uc3QgeyBwYXR0ZXJucyB9ID0gY2hlY2tIZXVyaXN0aWNQYXR0ZXJucyhwb3B1cFRleHQpO1xuICAgICAgaWYgKHBhdHRlcm5zLmxlbmd0aCA+IDApIHtcbiAgICAgICAgY29uc3QgeyByZWplY3RCdXR0b25zLCBvdGhlckJ1dHRvbnMgfSA9IGNsYXNzaWZ5QnV0dG9ucyhwb3B1cC5idXR0b25zKTtcbiAgICAgICAgaWYgKHJlamVjdEJ1dHRvbnMubGVuZ3RoID4gMCkge1xuICAgICAgICAgIGFjYy5wdXNoKHtcbiAgICAgICAgICAgIC4uLnBvcHVwLFxuICAgICAgICAgICAgcmVqZWN0QnV0dG9ucyxcbiAgICAgICAgICAgIG90aGVyQnV0dG9uc1xuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiBhY2M7XG4gIH0sIFtdKTtcbiAgcmV0dXJuIHJlc3VsdDtcbn1cbmZ1bmN0aW9uIGNsYXNzaWZ5QnV0dG9ucyhidXR0b25zKSB7XG4gIGNvbnN0IHJlamVjdEJ1dHRvbnMgPSBbXTtcbiAgY29uc3Qgb3RoZXJCdXR0b25zID0gW107XG4gIGZvciAoY29uc3QgYnV0dG9uIG9mIGJ1dHRvbnMpIHtcbiAgICBpZiAoaXNSZWplY3RCdXR0b24oYnV0dG9uLnRleHQpKSB7XG4gICAgICByZWplY3RCdXR0b25zLnB1c2goYnV0dG9uKTtcbiAgICB9IGVsc2Uge1xuICAgICAgb3RoZXJCdXR0b25zLnB1c2goYnV0dG9uKTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHtcbiAgICByZWplY3RCdXR0b25zLFxuICAgIG90aGVyQnV0dG9uc1xuICB9O1xufVxuZnVuY3Rpb24gaXNSZWplY3RCdXR0b24oYnV0dG9uVGV4dCwgcmVqZWN0UGF0dGVybnMgPSBSRUpFQ1RfUEFUVEVSTlMsIG5ldmVyTWF0Y2hQYXR0ZXJucyA9IE5FVkVSX01BVENIX1BBVFRFUk5TKSB7XG4gIGlmICghYnV0dG9uVGV4dCkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBjb25zdCBjbGVhbmVkQnV0dG9uVGV4dCA9IGNsZWFuQnV0dG9uVGV4dChidXR0b25UZXh0KTtcbiAgcmV0dXJuICFuZXZlck1hdGNoUGF0dGVybnMuc29tZSgocCkgPT4gcC50ZXN0KGNsZWFuZWRCdXR0b25UZXh0KSkgJiYgcmVqZWN0UGF0dGVybnMuc29tZSgocCkgPT4gcCBpbnN0YW5jZW9mIFJlZ0V4cCAmJiBwLnRlc3QoY2xlYW5lZEJ1dHRvblRleHQpIHx8IHAgPT09IGNsZWFuZWRCdXR0b25UZXh0KTtcbn1cbmZ1bmN0aW9uIGNsZWFuQnV0dG9uVGV4dChidXR0b25UZXh0KSB7XG4gIGxldCByZXN1bHQgPSBidXR0b25UZXh0LnRvTG93ZXJDYXNlKCk7XG4gIHJlc3VsdCA9IHJlc3VsdC5yZXBsYWNlKC9bXHUyMDFDXHUyMDFEXCInLyMmW1xcXVx1MjE5Mlx1MjcxNVx1MDBEN1x1MjdFOVx1Mjc2Rj48XHUyNzE3XHUwMEQ3XHUyMDE4XHUyMDE5XHUyMDNBXHUwMEFCXHUwMEJCXSsvZywgXCJcIik7XG4gIHJlc3VsdCA9IHJlc3VsdC5yZXBsYWNlKFxuICAgIC9bXFx1ezFGNjAwfS1cXHV7MUY2NEZ9XFx1ezFGMzAwfS1cXHV7MUY1RkZ9XFx1ezFGNjgwfS1cXHV7MUY2RkZ9XFx1ezFGMUUwfS1cXHV7MUYxRkZ9XFx1MjYwMC1cXHUyNkZGXFx1MjcwMC1cXHUyN0JGXFx1ezFGOTAwfS1cXHV7MUY5RkZ9XFx1ezFGQTcwfS1cXHV7MUZBRkZ9XS9ndSxcbiAgICBcIlwiXG4gICk7XG4gIHJlc3VsdCA9IHJlc3VsdC5yZXBsYWNlKC9cXG4rL2csIFwiIFwiKTtcbiAgcmVzdWx0ID0gcmVzdWx0LnJlcGxhY2UoL1xccysvZywgXCIgXCIpO1xuICByZXN1bHQgPSByZXN1bHQudHJpbSgpO1xuICByZXR1cm4gcmVzdWx0O1xufVxuZnVuY3Rpb24gZ2V0UG90ZW50aWFsUG9wdXBzKCkge1xuICBjb25zdCBpc0ZyYW1lZCA9ICFpc1RvcEZyYW1lKCk7XG4gIGlmIChpc0ZyYW1lZCAmJiB3aW5kb3cucGFyZW50ICYmIHdpbmRvdy5wYXJlbnQgIT09IHdpbmRvdy50b3ApIHtcbiAgICByZXR1cm4gW107XG4gIH1cbiAgcmV0dXJuIGNvbGxlY3RQb3RlbnRpYWxQb3B1cHMoaXNGcmFtZWQpO1xufVxuZnVuY3Rpb24gY29sbGVjdFBvdGVudGlhbFBvcHVwcyhpc0ZyYW1lZCkge1xuICBsZXQgZWxlbWVudHMgPSBbXTtcbiAgaWYgKCFpc0ZyYW1lZCkge1xuICAgIGVsZW1lbnRzID0gZ2V0UG9wdXBMaWtlRWxlbWVudHMoKTtcbiAgfSBlbHNlIHtcbiAgICBjb25zdCBkb2MgPSBkb2N1bWVudC5ib2R5IHx8IGRvY3VtZW50LmRvY3VtZW50RWxlbWVudDtcbiAgICBpZiAoZG9jICYmIGlzRWxlbWVudFZpc2libGUoZG9jKSAmJiBkb2MuaW5uZXJUZXh0KSB7XG4gICAgICBlbGVtZW50cy5wdXNoKGRvYyk7XG4gICAgfVxuICB9XG4gIGNvbnN0IHBvdGVudGlhbFBvcHVwcyA9IFtdO1xuICBmb3IgKGNvbnN0IGVsIG9mIGVsZW1lbnRzKSB7XG4gICAgaWYgKGVsLmlubmVyVGV4dCkge1xuICAgICAgcG90ZW50aWFsUG9wdXBzLnB1c2goe1xuICAgICAgICB0ZXh0OiBlbC5pbm5lclRleHQsXG4gICAgICAgIGVsZW1lbnQ6IGVsLFxuICAgICAgICBidXR0b25zOiBnZXRCdXR0b25EYXRhKGVsKVxuICAgICAgfSk7XG4gICAgfVxuICB9XG4gIHJldHVybiBwb3RlbnRpYWxQb3B1cHM7XG59XG5mdW5jdGlvbiBnZXRQb3B1cExpa2VFbGVtZW50cygpIHtcbiAgY29uc3Qgd2Fsa2VyID0gZG9jdW1lbnQuY3JlYXRlVHJlZVdhbGtlcihcbiAgICBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQsXG4gICAgTm9kZUZpbHRlci5TSE9XX0VMRU1FTlQsXG4gICAgLy8gdmlzaXQgb25seSBlbGVtZW50IG5vZGVzXG4gICAge1xuICAgICAgYWNjZXB0Tm9kZShub2RlKSB7XG4gICAgICAgIGlmIChub2RlLnRhZ05hbWUgPT09IFwiQk9EWVwiKSB7XG4gICAgICAgICAgcmV0dXJuIE5vZGVGaWx0ZXIuRklMVEVSX1NLSVA7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgY3NzUG9zaXRpb24gPSB3aW5kb3cuZ2V0Q29tcHV0ZWRTdHlsZShub2RlKS5wb3NpdGlvbjtcbiAgICAgICAgaWYgKChjc3NQb3NpdGlvbiA9PT0gXCJmaXhlZFwiIHx8IGNzc1Bvc2l0aW9uID09PSBcInN0aWNreVwiKSAmJiBpc0VsZW1lbnRWaXNpYmxlKG5vZGUpKSB7XG4gICAgICAgICAgcmV0dXJuIE5vZGVGaWx0ZXIuRklMVEVSX0FDQ0VQVDtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gTm9kZUZpbHRlci5GSUxURVJfU0tJUDtcbiAgICAgIH1cbiAgICB9XG4gICk7XG4gIGNvbnN0IGZvdW5kID0gW107XG4gIGZvciAobGV0IG5vZGUgPSB3YWxrZXIubmV4dE5vZGUoKTsgbm9kZTsgbm9kZSA9IHdhbGtlci5uZXh0Tm9kZSgpKSB7XG4gICAgZm91bmQucHVzaChub2RlKTtcbiAgfVxuICByZXR1cm4gZXhjbHVkZUNvbnRhaW5lcnMoZm91bmQpO1xufVxuZnVuY3Rpb24gZ2V0QnV0dG9uRGF0YShlbCkge1xuICBjb25zdCBhY3Rpb25hYmxlQnV0dG9ucyA9IGV4Y2x1ZGVDb250YWluZXJzKGdldEJ1dHRvbkxpa2VFbGVtZW50cyhlbCkpLmZpbHRlcihcbiAgICAoYikgPT4gaXNFbGVtZW50VmlzaWJsZShiKSAmJiAhaXNEaXNhYmxlZChiKSAmJiAoYi5pbm5lclRleHQudHJpbSgpIHx8IC8vIDxpbnB1dD4gdmFsdWVzIGRvIG5vdCBhcHBlYXIgaW4gaW5uZXJUZXh0XG4gICAgYiBpbnN0YW5jZW9mIEhUTUxJbnB1dEVsZW1lbnQgJiYgW1wic3VibWl0XCIsIFwiYnV0dG9uXCJdLmluY2x1ZGVzKGIudHlwZSkgJiYgYi52YWx1ZT8udHJpbSgpKVxuICApO1xuICByZXR1cm4gYWN0aW9uYWJsZUJ1dHRvbnMubWFwKChiKSA9PiAoe1xuICAgIHRleHQ6IChiLmlubmVyVGV4dCB8fCBiLnRleHRDb250ZW50IHx8IFwiXCIpLnRyaW0oKSB8fCBiLnZhbHVlPy50cmltKCkgfHwgXCJcIixcbiAgICBlbGVtZW50OiBiXG4gIH0pKTtcbn1cbmZ1bmN0aW9uIGdldEJ1dHRvbkxpa2VFbGVtZW50cyhlbCkge1xuICByZXR1cm4gQXJyYXkuZnJvbShlbC5xdWVyeVNlbGVjdG9yQWxsKEJVVFRPTl9MSUtFX0VMRU1FTlRfU0VMRUNUT1IpKTtcbn1cbmZ1bmN0aW9uIGlzRGlzYWJsZWQoZWwpIHtcbiAgcmV0dXJuIFwiZGlzYWJsZWRcIiBpbiBlbCAmJiBCb29sZWFuKGVsLmRpc2FibGVkKSB8fCBlbC5oYXNBdHRyaWJ1dGUoXCJkaXNhYmxlZFwiKTtcbn1cbmZ1bmN0aW9uIGV4Y2x1ZGVDb250YWluZXJzKGVsZW1lbnRzKSB7XG4gIGNvbnN0IHJlc3VsdHMgPSBbXTtcbiAgaWYgKGVsZW1lbnRzLmxlbmd0aCA+IDApIHtcbiAgICBmb3IgKGxldCBpID0gZWxlbWVudHMubGVuZ3RoIC0gMTsgaSA+PSAwOyBpLS0pIHtcbiAgICAgIGxldCBjb250YWluZXIgPSBmYWxzZTtcbiAgICAgIGZvciAobGV0IGogPSAwOyBqIDwgZWxlbWVudHMubGVuZ3RoOyBqKyspIHtcbiAgICAgICAgaWYgKGkgIT09IGogJiYgZWxlbWVudHNbaV0uY29udGFpbnMoZWxlbWVudHNbal0pKSB7XG4gICAgICAgICAgY29udGFpbmVyID0gdHJ1ZTtcbiAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgaWYgKCFjb250YWluZXIpIHtcbiAgICAgICAgcmVzdWx0cy5wdXNoKGVsZW1lbnRzW2ldKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgcmV0dXJuIHJlc3VsdHM7XG59XG5cbi8vIGxpYi9jbXBzL2Jhc2UudHNcbnZhciBkZWZhdWx0UnVuQ29udGV4dCA9IHtcbiAgbWFpbjogdHJ1ZSxcbiAgZnJhbWU6IGZhbHNlLFxuICB1cmxQYXR0ZXJuOiBcIlwiXG59O1xudmFyIEF1dG9Db25zZW50Q01QQmFzZSA9IGNsYXNzIHtcbiAgY29uc3RydWN0b3IoYXV0b2NvbnNlbnRJbnN0YW5jZSkge1xuICAgIHRoaXMubmFtZSA9IFwiQkFTRVJVTEVcIjtcbiAgICB0aGlzLnJ1bkNvbnRleHQgPSBkZWZhdWx0UnVuQ29udGV4dDtcbiAgICB0aGlzLmF1dG9jb25zZW50ID0gYXV0b2NvbnNlbnRJbnN0YW5jZTtcbiAgfVxuICBnZXQgaGFzU2VsZlRlc3QoKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFwiTm90IEltcGxlbWVudGVkXCIpO1xuICB9XG4gIGdldCBpc0ludGVybWVkaWF0ZSgpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJOb3QgSW1wbGVtZW50ZWRcIik7XG4gIH1cbiAgZ2V0IGlzQ29zbWV0aWMoKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFwiTm90IEltcGxlbWVudGVkXCIpO1xuICB9XG4gIG1haW5Xb3JsZEV2YWwoc25pcHBldElkKSB7XG4gICAgY29uc3Qgc25pcHBldCA9IHNuaXBwZXRzW3NuaXBwZXRJZF07XG4gICAgaWYgKCFzbmlwcGV0KSB7XG4gICAgICB0aGlzLmF1dG9jb25zZW50LmNvbmZpZy5sb2dzLmVycm9ycyAmJiBjb25zb2xlLndhcm4oXCJTbmlwcGV0IG5vdCBmb3VuZFwiLCBzbmlwcGV0SWQpO1xuICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZShmYWxzZSk7XG4gICAgfVxuICAgIGNvbnN0IGxvZ3NDb25maWcgPSB0aGlzLmF1dG9jb25zZW50LmNvbmZpZy5sb2dzO1xuICAgIGlmICh0aGlzLmF1dG9jb25zZW50LmNvbmZpZy5pc01haW5Xb3JsZCkge1xuICAgICAgbG9nc0NvbmZpZy5ldmFscyAmJiBjb25zb2xlLmxvZyhcImlubGluZSBldmFsOlwiLCBzbmlwcGV0SWQsIHNuaXBwZXQpO1xuICAgICAgbGV0IHJlc3VsdCA9IGZhbHNlO1xuICAgICAgdHJ5IHtcbiAgICAgICAgcmVzdWx0ID0gISFzbmlwcGV0LmNhbGwoZ2xvYmFsVGhpcyk7XG4gICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIGxvZ3NDb25maWcuZXZhbHMgJiYgY29uc29sZS5lcnJvcihcImVycm9yIGV2YWx1YXRpbmcgcnVsZVwiLCBzbmlwcGV0SWQsIGUpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZShyZXN1bHQpO1xuICAgIH1cbiAgICBjb25zdCBzbmlwcGV0U3JjID0gZ2V0RnVuY3Rpb25Cb2R5KHNuaXBwZXQpO1xuICAgIGxvZ3NDb25maWcuZXZhbHMgJiYgY29uc29sZS5sb2coXCJhc3luYyBldmFsOlwiLCBzbmlwcGV0SWQsIHNuaXBwZXRTcmMpO1xuICAgIHJldHVybiByZXF1ZXN0RXZhbChzbmlwcGV0U3JjLCBzbmlwcGV0SWQpLmNhdGNoKChlKSA9PiB7XG4gICAgICBsb2dzQ29uZmlnLmV2YWxzICYmIGNvbnNvbGUuZXJyb3IoXCJlcnJvciBldmFsdWF0aW5nIHJ1bGVcIiwgc25pcHBldElkLCBlKTtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9KTtcbiAgfVxuICBjaGVja1J1bkNvbnRleHQoKSB7XG4gICAgaWYgKCF0aGlzLmNoZWNrRnJhbWVDb250ZXh0KGlzVG9wRnJhbWUoKSkpIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgaWYgKHRoaXMucnVuQ29udGV4dC51cmxQYXR0ZXJuICYmICF0aGlzLmhhc01hdGNoaW5nVXJsUGF0dGVybigpKSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIGNoZWNrRnJhbWVDb250ZXh0KGlzVG9wKSB7XG4gICAgY29uc3QgcnVuQ3R4ID0ge1xuICAgICAgLi4uZGVmYXVsdFJ1bkNvbnRleHQsXG4gICAgICAuLi50aGlzLnJ1bkNvbnRleHRcbiAgICB9O1xuICAgIGlmIChpc1RvcCAmJiAhcnVuQ3R4Lm1haW4pIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgaWYgKCFpc1RvcCAmJiAhcnVuQ3R4LmZyYW1lKSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIGhhc01hdGNoaW5nVXJsUGF0dGVybigpIHtcbiAgICByZXR1cm4gQm9vbGVhbih0aGlzLnJ1bkNvbnRleHQ/LnVybFBhdHRlcm4gJiYgd2luZG93LmxvY2F0aW9uLmhyZWYubWF0Y2godGhpcy5ydW5Db250ZXh0LnVybFBhdHRlcm4pKTtcbiAgfVxuICBkZXRlY3RDbXAoKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFwiTm90IEltcGxlbWVudGVkXCIpO1xuICB9XG4gIGFzeW5jIGRldGVjdFBvcHVwKCkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBvcHRPdXQoKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFwiTm90IEltcGxlbWVudGVkXCIpO1xuICB9XG4gIG9wdEluKCkge1xuICAgIHRocm93IG5ldyBFcnJvcihcIk5vdCBJbXBsZW1lbnRlZFwiKTtcbiAgfVxuICBvcGVuQ21wKCkge1xuICAgIHRocm93IG5ldyBFcnJvcihcIk5vdCBJbXBsZW1lbnRlZFwiKTtcbiAgfVxuICBhc3luYyB0ZXN0KCkge1xuICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUodHJ1ZSk7XG4gIH1cbiAgYXN5bmMgaGlnaGxpZ2h0RWxlbWVudHMoZWxlbWVudHMsIGFsbCA9IGZhbHNlLCBkZWxheVRpbWVvdXQgPSAyZTMpIHtcbiAgICBpZiAoZWxlbWVudHMubGVuZ3RoID09PSAwKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmICghYWxsKSB7XG4gICAgICBlbGVtZW50cyA9IFtlbGVtZW50c1swXV07XG4gICAgfVxuICAgIHRoaXMuYXV0b2NvbnNlbnQuc2VuZENvbnRlbnRNZXNzYWdlKHtcbiAgICAgIHR5cGU6IFwidmlzdWFsRGVsYXlcIixcbiAgICAgIHRpbWVvdXQ6IGRlbGF5VGltZW91dFxuICAgIH0pO1xuICAgIGZvciAoY29uc3QgZWwgb2YgZWxlbWVudHMpIHtcbiAgICAgIHRoaXMuYXV0b2NvbnNlbnQuY29uZmlnLmxvZ3MucnVsZXN0ZXBzICYmIGNvbnNvbGUubG9nKFwiaGlnaGxpZ2h0aW5nXCIsIGVsKTtcbiAgICAgIGhpZ2hsaWdodE5vZGUoZWwpO1xuICAgIH1cbiAgICBhd2FpdCB0aGlzLndhaXQoZGVsYXlUaW1lb3V0KTtcbiAgICBmb3IgKGNvbnN0IGVsIG9mIGVsZW1lbnRzKSB7XG4gICAgICB1bmhpZ2hsaWdodE5vZGUoZWwpO1xuICAgIH1cbiAgfVxuICAvLyBJbXBsZW1lbnRpbmcgRG9tQWN0aW9uc1Byb3ZpZGVyIGJlbG93OlxuICBhc3luYyBjbGlja0VsZW1lbnQoZWxlbWVudCkge1xuICAgIGlmICh0aGlzLmF1dG9jb25zZW50LmNvbmZpZy52aXN1YWxUZXN0KSB7XG4gICAgICBhd2FpdCB0aGlzLmhpZ2hsaWdodEVsZW1lbnRzKFtlbGVtZW50XSk7XG4gICAgfVxuICAgIHRoaXMuYXV0b2NvbnNlbnQudXBkYXRlU3RhdGUoeyBjbGlja3M6IHRoaXMuYXV0b2NvbnNlbnQuc3RhdGUuY2xpY2tzICsgMSB9KTtcbiAgICByZXR1cm4gdGhpcy5hdXRvY29uc2VudC5kb21BY3Rpb25zLmNsaWNrRWxlbWVudChlbGVtZW50KTtcbiAgfVxuICBhc3luYyBjbGljayhzZWxlY3RvciwgYWxsID0gZmFsc2UpIHtcbiAgICBpZiAodGhpcy5hdXRvY29uc2VudC5jb25maWcudmlzdWFsVGVzdCkge1xuICAgICAgYXdhaXQgdGhpcy5oaWdobGlnaHRFbGVtZW50cyh0aGlzLmVsZW1lbnRTZWxlY3RvcihzZWxlY3RvciksIGFsbCk7XG4gICAgfVxuICAgIHRoaXMuYXV0b2NvbnNlbnQudXBkYXRlU3RhdGUoeyBjbGlja3M6IHRoaXMuYXV0b2NvbnNlbnQuc3RhdGUuY2xpY2tzICsgMSB9KTtcbiAgICByZXR1cm4gdGhpcy5hdXRvY29uc2VudC5kb21BY3Rpb25zLmNsaWNrKHNlbGVjdG9yLCBhbGwpO1xuICB9XG4gIGVsZW1lbnRFeGlzdHMoc2VsZWN0b3IpIHtcbiAgICByZXR1cm4gdGhpcy5hdXRvY29uc2VudC5kb21BY3Rpb25zLmVsZW1lbnRFeGlzdHMoc2VsZWN0b3IpO1xuICB9XG4gIGVsZW1lbnRWaXNpYmxlKHNlbGVjdG9yLCBjaGVjaykge1xuICAgIHJldHVybiB0aGlzLmF1dG9jb25zZW50LmRvbUFjdGlvbnMuZWxlbWVudFZpc2libGUoc2VsZWN0b3IsIGNoZWNrKTtcbiAgfVxuICB3YWl0Rm9yRWxlbWVudChzZWxlY3RvciwgdGltZW91dCkge1xuICAgIHJldHVybiB0aGlzLmF1dG9jb25zZW50LmRvbUFjdGlvbnMud2FpdEZvckVsZW1lbnQoc2VsZWN0b3IsIHRpbWVvdXQpO1xuICB9XG4gIHdhaXRGb3JWaXNpYmxlKHNlbGVjdG9yLCB0aW1lb3V0LCBjaGVjaykge1xuICAgIHJldHVybiB0aGlzLmF1dG9jb25zZW50LmRvbUFjdGlvbnMud2FpdEZvclZpc2libGUoc2VsZWN0b3IsIHRpbWVvdXQsIGNoZWNrKTtcbiAgfVxuICBhc3luYyB3YWl0Rm9yVGhlbkNsaWNrKHNlbGVjdG9yLCB0aW1lb3V0LCBhbGwpIHtcbiAgICBpZiAodGhpcy5hdXRvY29uc2VudC5jb25maWcudmlzdWFsVGVzdCkge1xuICAgICAgYXdhaXQgdGhpcy5oaWdobGlnaHRFbGVtZW50cyh0aGlzLmVsZW1lbnRTZWxlY3RvcihzZWxlY3RvciksIGFsbCk7XG4gICAgfVxuICAgIHRoaXMuYXV0b2NvbnNlbnQudXBkYXRlU3RhdGUoeyBjbGlja3M6IHRoaXMuYXV0b2NvbnNlbnQuc3RhdGUuY2xpY2tzICsgMSB9KTtcbiAgICByZXR1cm4gdGhpcy5hdXRvY29uc2VudC5kb21BY3Rpb25zLndhaXRGb3JUaGVuQ2xpY2soc2VsZWN0b3IsIHRpbWVvdXQsIGFsbCk7XG4gIH1cbiAgd2FpdChtcykge1xuICAgIHJldHVybiB0aGlzLmF1dG9jb25zZW50LmRvbUFjdGlvbnMud2FpdChtcyk7XG4gIH1cbiAgaGlkZShzZWxlY3RvciwgbWV0aG9kKSB7XG4gICAgcmV0dXJuIHRoaXMuYXV0b2NvbnNlbnQuZG9tQWN0aW9ucy5oaWRlKHNlbGVjdG9yLCBtZXRob2QpO1xuICB9XG4gIGNvb2tpZUNvbnRhaW5zKHN1YnN0cmluZykge1xuICAgIHJldHVybiB0aGlzLmF1dG9jb25zZW50LmRvbUFjdGlvbnMuY29va2llQ29udGFpbnMoc3Vic3RyaW5nKTtcbiAgfVxuICBwcmVoaWRlKHNlbGVjdG9yKSB7XG4gICAgcmV0dXJuIHRoaXMuYXV0b2NvbnNlbnQuZG9tQWN0aW9ucy5wcmVoaWRlKHNlbGVjdG9yKTtcbiAgfVxuICB1bmRvUHJlaGlkZSgpIHtcbiAgICByZXR1cm4gdGhpcy5hdXRvY29uc2VudC5kb21BY3Rpb25zLnVuZG9QcmVoaWRlKCk7XG4gIH1cbiAgcXVlcnlTaW5nbGVSZXBseVNlbGVjdG9yKHNlbGVjdG9yLCBwYXJlbnQpIHtcbiAgICByZXR1cm4gdGhpcy5hdXRvY29uc2VudC5kb21BY3Rpb25zLnF1ZXJ5U2luZ2xlUmVwbHlTZWxlY3RvcihzZWxlY3RvciwgcGFyZW50KTtcbiAgfVxuICBxdWVyeVNlbGVjdG9yQ2hhaW4oc2VsZWN0b3JzKSB7XG4gICAgcmV0dXJuIHRoaXMuYXV0b2NvbnNlbnQuZG9tQWN0aW9ucy5xdWVyeVNlbGVjdG9yQ2hhaW4oc2VsZWN0b3JzKTtcbiAgfVxuICBlbGVtZW50U2VsZWN0b3Ioc2VsZWN0b3IpIHtcbiAgICByZXR1cm4gdGhpcy5hdXRvY29uc2VudC5kb21BY3Rpb25zLmVsZW1lbnRTZWxlY3RvcihzZWxlY3Rvcik7XG4gIH1cbiAgd2FpdEZvck11dGF0aW9uKHNlbGVjdG9yKSB7XG4gICAgcmV0dXJuIHRoaXMuYXV0b2NvbnNlbnQuZG9tQWN0aW9ucy53YWl0Rm9yTXV0YXRpb24oc2VsZWN0b3IpO1xuICB9XG59O1xudmFyIEF1dG9Db25zZW50Q01QID0gY2xhc3MgZXh0ZW5kcyBBdXRvQ29uc2VudENNUEJhc2Uge1xuICBjb25zdHJ1Y3RvcihydWxlLCBhdXRvY29uc2VudEluc3RhbmNlKSB7XG4gICAgc3VwZXIoYXV0b2NvbnNlbnRJbnN0YW5jZSk7XG4gICAgdGhpcy5ydWxlID0gcnVsZTtcbiAgICB0aGlzLm5hbWUgPSBydWxlLm5hbWU7XG4gICAgdGhpcy5ydW5Db250ZXh0ID0gcnVsZS5ydW5Db250ZXh0IHx8IGRlZmF1bHRSdW5Db250ZXh0O1xuICB9XG4gIGdldCBoYXNTZWxmVGVzdCgpIHtcbiAgICByZXR1cm4gISF0aGlzLnJ1bGUudGVzdCAmJiB0aGlzLnJ1bGUudGVzdC5sZW5ndGggPiAwO1xuICB9XG4gIGdldCBpc0ludGVybWVkaWF0ZSgpIHtcbiAgICByZXR1cm4gISF0aGlzLnJ1bGUuaW50ZXJtZWRpYXRlO1xuICB9XG4gIGdldCBpc0Nvc21ldGljKCkge1xuICAgIHJldHVybiAhIXRoaXMucnVsZS5jb3NtZXRpYztcbiAgfVxuICBnZXQgcHJlaGlkZVNlbGVjdG9ycygpIHtcbiAgICByZXR1cm4gdGhpcy5ydWxlLnByZWhpZGVTZWxlY3RvcnMgfHwgW107XG4gIH1cbiAgYXN5bmMgZGV0ZWN0Q21wKCkge1xuICAgIGlmICh0aGlzLnJ1bGUuZGV0ZWN0Q21wKSB7XG4gICAgICByZXR1cm4gdGhpcy5fcnVuUnVsZXNTZXF1ZW50aWFsbHkodGhpcy5ydWxlLmRldGVjdENtcCwgdGhpcy5hdXRvY29uc2VudC5jb25maWcubG9ncy5kZXRlY3Rpb25zdGVwcyk7XG4gICAgfVxuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBhc3luYyBkZXRlY3RQb3B1cCgpIHtcbiAgICBpZiAodGhpcy5ydWxlLmRldGVjdFBvcHVwKSB7XG4gICAgICByZXR1cm4gdGhpcy5fcnVuUnVsZXNTZXF1ZW50aWFsbHkodGhpcy5ydWxlLmRldGVjdFBvcHVwLCB0aGlzLmF1dG9jb25zZW50LmNvbmZpZy5sb2dzLmRldGVjdGlvbnN0ZXBzKTtcbiAgICB9XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGFzeW5jIG9wdE91dCgpIHtcbiAgICBjb25zdCBsb2dzQ29uZmlnID0gdGhpcy5hdXRvY29uc2VudC5jb25maWcubG9ncztcbiAgICBpZiAodGhpcy5ydWxlLm9wdE91dCkge1xuICAgICAgbG9nc0NvbmZpZy5saWZlY3ljbGUgJiYgY29uc29sZS5sb2coXCJJbml0aWF0ZWQgb3B0T3V0KClcIiwgdGhpcy5ydWxlLm9wdE91dCk7XG4gICAgICByZXR1cm4gdGhpcy5fcnVuUnVsZXNTZXF1ZW50aWFsbHkodGhpcy5ydWxlLm9wdE91dCwgdGhpcy5hdXRvY29uc2VudC5jb25maWcubG9ncy5ydWxlc3RlcHMpO1xuICAgIH1cbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgYXN5bmMgb3B0SW4oKSB7XG4gICAgY29uc3QgbG9nc0NvbmZpZyA9IHRoaXMuYXV0b2NvbnNlbnQuY29uZmlnLmxvZ3M7XG4gICAgaWYgKHRoaXMucnVsZS5vcHRJbikge1xuICAgICAgbG9nc0NvbmZpZy5saWZlY3ljbGUgJiYgY29uc29sZS5sb2coXCJJbml0aWF0ZWQgb3B0SW4oKVwiLCB0aGlzLnJ1bGUub3B0SW4pO1xuICAgICAgcmV0dXJuIHRoaXMuX3J1blJ1bGVzU2VxdWVudGlhbGx5KHRoaXMucnVsZS5vcHRJbiwgdGhpcy5hdXRvY29uc2VudC5jb25maWcubG9ncy5ydWxlc3RlcHMpO1xuICAgIH1cbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgYXN5bmMgb3BlbkNtcCgpIHtcbiAgICBpZiAodGhpcy5ydWxlLm9wZW5DbXApIHtcbiAgICAgIHJldHVybiB0aGlzLl9ydW5SdWxlc1NlcXVlbnRpYWxseSh0aGlzLnJ1bGUub3BlbkNtcCwgdGhpcy5hdXRvY29uc2VudC5jb25maWcubG9ncy5ydWxlc3RlcHMpO1xuICAgIH1cbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgYXN5bmMgdGVzdCgpIHtcbiAgICBpZiAodGhpcy5oYXNTZWxmVGVzdCAmJiB0aGlzLnJ1bGUudGVzdCkge1xuICAgICAgcmV0dXJuIHRoaXMuX3J1blJ1bGVzU2VxdWVudGlhbGx5KHRoaXMucnVsZS50ZXN0LCB0aGlzLmF1dG9jb25zZW50LmNvbmZpZy5sb2dzLnJ1bGVzdGVwcyk7XG4gICAgfVxuICAgIHJldHVybiBzdXBlci50ZXN0KCk7XG4gIH1cbiAgYXN5bmMgZXZhbHVhdGVSdWxlU3RlcChydWxlKSB7XG4gICAgY29uc3QgcmVzdWx0cyA9IFtdO1xuICAgIGNvbnN0IGxvZ3NDb25maWcgPSB0aGlzLmF1dG9jb25zZW50LmNvbmZpZy5sb2dzO1xuICAgIGlmIChydWxlLmV4aXN0cykge1xuICAgICAgcmVzdWx0cy5wdXNoKHRoaXMuZWxlbWVudEV4aXN0cyhydWxlLmV4aXN0cykpO1xuICAgIH1cbiAgICBpZiAocnVsZS52aXNpYmxlKSB7XG4gICAgICByZXN1bHRzLnB1c2godGhpcy5lbGVtZW50VmlzaWJsZShydWxlLnZpc2libGUsIHJ1bGUuY2hlY2spKTtcbiAgICB9XG4gICAgaWYgKHJ1bGUuZXZhbCkge1xuICAgICAgY29uc3QgcmVzID0gdGhpcy5tYWluV29ybGRFdmFsKHJ1bGUuZXZhbCk7XG4gICAgICByZXN1bHRzLnB1c2gocmVzKTtcbiAgICB9XG4gICAgaWYgKHJ1bGUud2FpdEZvcikge1xuICAgICAgcmVzdWx0cy5wdXNoKHRoaXMud2FpdEZvckVsZW1lbnQocnVsZS53YWl0Rm9yLCBydWxlLnRpbWVvdXQpKTtcbiAgICB9XG4gICAgaWYgKHJ1bGUud2FpdEZvclZpc2libGUpIHtcbiAgICAgIHJlc3VsdHMucHVzaCh0aGlzLndhaXRGb3JWaXNpYmxlKHJ1bGUud2FpdEZvclZpc2libGUsIHJ1bGUudGltZW91dCwgcnVsZS5jaGVjaykpO1xuICAgIH1cbiAgICBpZiAocnVsZS5jbGljaykge1xuICAgICAgcmVzdWx0cy5wdXNoKHRoaXMuY2xpY2socnVsZS5jbGljaywgcnVsZS5hbGwpKTtcbiAgICB9XG4gICAgaWYgKHJ1bGUud2FpdEZvclRoZW5DbGljaykge1xuICAgICAgcmVzdWx0cy5wdXNoKHRoaXMud2FpdEZvclRoZW5DbGljayhydWxlLndhaXRGb3JUaGVuQ2xpY2ssIHJ1bGUudGltZW91dCwgcnVsZS5hbGwpKTtcbiAgICB9XG4gICAgaWYgKHJ1bGUud2FpdCkge1xuICAgICAgcmVzdWx0cy5wdXNoKHRoaXMud2FpdChydWxlLndhaXQpKTtcbiAgICB9XG4gICAgaWYgKHJ1bGUuaGlkZSkge1xuICAgICAgcmVzdWx0cy5wdXNoKHRoaXMuaGlkZShydWxlLmhpZGUsIHJ1bGUubWV0aG9kKSk7XG4gICAgfVxuICAgIGlmIChydWxlLmNvb2tpZUNvbnRhaW5zKSB7XG4gICAgICByZXN1bHRzLnB1c2godGhpcy5jb29raWVDb250YWlucyhydWxlLmNvb2tpZUNvbnRhaW5zKSk7XG4gICAgfVxuICAgIGlmIChydWxlLmlmKSB7XG4gICAgICBpZiAoIXJ1bGUuaWYuZXhpc3RzICYmICFydWxlLmlmLnZpc2libGUpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihcImludmFsaWQgY29uZGl0aW9uYWwgcnVsZVwiLCBydWxlLmlmKTtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgfVxuICAgICAgaWYgKCFydWxlLnRoZW4pIHtcbiAgICAgICAgY29uc29sZS5lcnJvcignaW52YWxpZCBjb25kaXRpb25hbCBydWxlLCBtaXNzaW5nIFwidGhlblwiIHN0ZXAnLCBydWxlLmlmKTtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgfVxuICAgICAgY29uc3QgY29uZGl0aW9uID0gYXdhaXQgdGhpcy5ldmFsdWF0ZVJ1bGVTdGVwKHJ1bGUuaWYpO1xuICAgICAgbG9nc0NvbmZpZy5ydWxlc3RlcHMgJiYgY29uc29sZS5sb2coXCJDb25kaXRpb24gaXNcIiwgY29uZGl0aW9uKTtcbiAgICAgIGlmIChjb25kaXRpb24pIHtcbiAgICAgICAgcmVzdWx0cy5wdXNoKHRoaXMuX3J1blJ1bGVzU2VxdWVudGlhbGx5KHJ1bGUudGhlbiwgbG9nc0NvbmZpZy5ydWxlc3RlcHMpKTtcbiAgICAgIH0gZWxzZSBpZiAocnVsZS5lbHNlKSB7XG4gICAgICAgIHJlc3VsdHMucHVzaCh0aGlzLl9ydW5SdWxlc1NlcXVlbnRpYWxseShydWxlLmVsc2UsIGxvZ3NDb25maWcucnVsZXN0ZXBzKSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICByZXN1bHRzLnB1c2godHJ1ZSk7XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChydWxlLmFueSkge1xuICAgICAgbGV0IHJlc3VsdE9mQW55ID0gZmFsc2U7XG4gICAgICBmb3IgKGNvbnN0IHN0ZXAgb2YgcnVsZS5hbnkpIHtcbiAgICAgICAgaWYgKGF3YWl0IHRoaXMuZXZhbHVhdGVSdWxlU3RlcChzdGVwKSkge1xuICAgICAgICAgIHJlc3VsdE9mQW55ID0gdHJ1ZTtcbiAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmVzdWx0cy5wdXNoKHJlc3VsdE9mQW55KTtcbiAgICB9XG4gICAgaWYgKHJlc3VsdHMubGVuZ3RoID09PSAwKSB7XG4gICAgICBsb2dzQ29uZmlnLmVycm9ycyAmJiBjb25zb2xlLndhcm4oXCJVbnJlY29nbml6ZWQgcnVsZVwiLCBydWxlKTtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgY29uc3QgYWxsID0gYXdhaXQgUHJvbWlzZS5hbGwocmVzdWx0cyk7XG4gICAgY29uc3QgcmVzdWx0ID0gYWxsLnJlZHVjZSgoYSwgYikgPT4gYSAmJiBiLCB0cnVlKTtcbiAgICBpZiAocnVsZS5uZWdhdGVkKSB7XG4gICAgICByZXR1cm4gIXJlc3VsdDtcbiAgICB9XG4gICAgcmV0dXJuIHJlc3VsdDtcbiAgfVxuICBhc3luYyBfcnVuUnVsZXNQYXJhbGxlbChydWxlcykge1xuICAgIGNvbnN0IHJlc3VsdHMgPSBydWxlcy5tYXAoKHJ1bGUpID0+IHRoaXMuZXZhbHVhdGVSdWxlU3RlcChydWxlKSk7XG4gICAgY29uc3QgZGV0ZWN0aW9ucyA9IGF3YWl0IFByb21pc2UuYWxsKHJlc3VsdHMpO1xuICAgIHJldHVybiBkZXRlY3Rpb25zLmV2ZXJ5KChyKSA9PiAhIXIpO1xuICB9XG4gIGFzeW5jIF9ydW5SdWxlc1NlcXVlbnRpYWxseShydWxlcywgbG9nU3RlcHMgPSB0cnVlKSB7XG4gICAgZm9yIChjb25zdCBydWxlIG9mIHJ1bGVzKSB7XG4gICAgICBsb2dTdGVwcyAmJiBjb25zb2xlLmxvZyhcIlJ1bm5pbmcgcnVsZS4uLlwiLCBydWxlKTtcbiAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHRoaXMuZXZhbHVhdGVSdWxlU3RlcChydWxlKTtcbiAgICAgIGxvZ1N0ZXBzICYmIGNvbnNvbGUubG9nKFwiLi4ucnVsZSByZXN1bHRcIiwgcmVzdWx0KTtcbiAgICAgIGlmICghcmVzdWx0ICYmICFydWxlLm9wdGlvbmFsKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbn07XG52YXIgQXV0b0NvbnNlbnRIZXVyaXN0aWNDTVAgPSBjbGFzcyBleHRlbmRzIEF1dG9Db25zZW50Q01QQmFzZSB7XG4gIGNvbnN0cnVjdG9yKGF1dG9jb25zZW50SW5zdGFuY2UpIHtcbiAgICBzdXBlcihhdXRvY29uc2VudEluc3RhbmNlKTtcbiAgICB0aGlzLnBvcHVwcyA9IFtdO1xuICAgIHRoaXMubmFtZSA9IFwiSEVVUklTVElDXCI7XG4gICAgdGhpcy5ydW5Db250ZXh0ID0ge1xuICAgICAgbWFpbjogdHJ1ZSxcbiAgICAgIGZyYW1lOiBmYWxzZVxuICAgICAgLy8gZG8gbm90IHJ1biBpbiBpZnJhbWVzIGZvciBzZWN1cml0eSByZWFzb25zXG4gICAgfTtcbiAgfVxuICBnZXQgaGFzU2VsZlRlc3QoKSB7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbiAgZ2V0IGlzSW50ZXJtZWRpYXRlKCkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBnZXQgaXNDb3NtZXRpYygpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgZGV0ZWN0Q21wKCkge1xuICAgIHRoaXMucG9wdXBzID0gZ2V0QWN0aW9uYWJsZVBvcHVwcygpO1xuICAgIGlmICh0aGlzLnBvcHVwcy5sZW5ndGggPiAwKSB7XG4gICAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKHRydWUpO1xuICAgIH1cbiAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKGZhbHNlKTtcbiAgfVxuICBhc3luYyBkZXRlY3RQb3B1cCgpIHtcbiAgICBpZiAodGhpcy5wb3B1cHMubGVuZ3RoID4gMCkge1xuICAgICAgaWYgKHRoaXMucG9wdXBzLmxlbmd0aCA+IDEgfHwgdGhpcy5wb3B1cHNbMF0ucmVqZWN0QnV0dG9ucyAmJiB0aGlzLnBvcHVwc1swXS5yZWplY3RCdXR0b25zLmxlbmd0aCA+IDEpIHtcbiAgICAgICAgdGhpcy5hdXRvY29uc2VudC5jb25maWcubG9ncy5lcnJvcnMgJiYgY29uc29sZS53YXJuKFwiSGV1cmlzdGljIGZvdW5kIG11bHRpcGxlIHJlamVjdCBidXR0b25zXCIpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBvcHRPdXQoKSB7XG4gICAgY29uc3QgYnV0dG9uID0gdGhpcy5wb3B1cHNbMF0/LnJlamVjdEJ1dHRvbnM/LlswXTtcbiAgICBpZiAoYnV0dG9uKSB7XG4gICAgICByZXR1cm4gdGhpcy5jbGlja0VsZW1lbnQoYnV0dG9uLmVsZW1lbnQpO1xuICAgIH1cbiAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKGZhbHNlKTtcbiAgfVxuICBvcHRJbigpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJOb3QgSW1wbGVtZW50ZWRcIik7XG4gIH1cbiAgb3BlbkNtcCgpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJOb3QgSW1wbGVtZW50ZWRcIik7XG4gIH1cbiAgYXN5bmMgdGVzdCgpIHtcbiAgICBjb25zdCBidXR0b24gPSB0aGlzLnBvcHVwc1swXS5yZWplY3RCdXR0b25zPy5bMF07XG4gICAgaWYgKGJ1dHRvbikge1xuICAgICAgYXdhaXQgdGhpcy53YWl0KDUwMCk7XG4gICAgICByZXR1cm4gIWlzRWxlbWVudFZpc2libGUoYnV0dG9uLmVsZW1lbnQpO1xuICAgIH1cbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbn07XG5cbi8vIGxpYi9jbXBzL2NvbnNlbnRvbWF0aWMudHNcbnZhciBDb25zZW50T01hdGljQ01QID0gY2xhc3Mge1xuICBjb25zdHJ1Y3RvcihuYW1lLCBjb25maWcpIHtcbiAgICB0aGlzLm5hbWUgPSBuYW1lO1xuICAgIHRoaXMuY29uZmlnID0gY29uZmlnO1xuICAgIHRoaXMubWV0aG9kcyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG4gICAgdGhpcy5ydW5Db250ZXh0ID0gZGVmYXVsdFJ1bkNvbnRleHQ7XG4gICAgdGhpcy5pc0Nvc21ldGljID0gZmFsc2U7XG4gICAgY29uZmlnLm1ldGhvZHMuZm9yRWFjaCgobWV0aG9kQ29uZmlnKSA9PiB7XG4gICAgICBpZiAobWV0aG9kQ29uZmlnLmFjdGlvbikge1xuICAgICAgICB0aGlzLm1ldGhvZHMuc2V0KG1ldGhvZENvbmZpZy5uYW1lLCBtZXRob2RDb25maWcuYWN0aW9uKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgICB0aGlzLmhhc1NlbGZUZXN0ID0gZmFsc2U7XG4gIH1cbiAgZ2V0IGlzSW50ZXJtZWRpYXRlKCkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBjaGVja1J1bkNvbnRleHQoKSB7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbiAgY2hlY2tGcmFtZUNvbnRleHQoaXNUb3ApIHtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICBoYXNNYXRjaGluZ1VybFBhdHRlcm4oKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGFzeW5jIGRldGVjdENtcCgpIHtcbiAgICBjb25zdCBtYXRjaFJlc3VsdHMgPSB0aGlzLmNvbmZpZy5kZXRlY3RvcnMubWFwKChkZXRlY3RvckNvbmZpZykgPT4gbWF0Y2hlcyhkZXRlY3RvckNvbmZpZy5wcmVzZW50TWF0Y2hlcikpO1xuICAgIHJldHVybiBtYXRjaFJlc3VsdHMuc29tZSgocikgPT4gISFyKTtcbiAgfVxuICBhc3luYyBkZXRlY3RQb3B1cCgpIHtcbiAgICBjb25zdCBtYXRjaFJlc3VsdHMgPSB0aGlzLmNvbmZpZy5kZXRlY3RvcnMubWFwKChkZXRlY3RvckNvbmZpZykgPT4gbWF0Y2hlcyhkZXRlY3RvckNvbmZpZy5zaG93aW5nTWF0Y2hlcikpO1xuICAgIHJldHVybiBtYXRjaFJlc3VsdHMuc29tZSgocikgPT4gISFyKTtcbiAgfVxuICBhc3luYyBleGVjdXRlQWN0aW9uKG1ldGhvZCwgcGFyYW0pIHtcbiAgICBpZiAodGhpcy5tZXRob2RzLmhhcyhtZXRob2QpKSB7XG4gICAgICByZXR1cm4gZXhlY3V0ZUFjdGlvbih0aGlzLm1ldGhvZHMuZ2V0KG1ldGhvZCksIHBhcmFtKTtcbiAgICB9XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbiAgYXN5bmMgb3B0T3V0KCkge1xuICAgIGF3YWl0IHRoaXMuZXhlY3V0ZUFjdGlvbihcIkhJREVfQ01QXCIpO1xuICAgIGF3YWl0IHRoaXMuZXhlY3V0ZUFjdGlvbihcIk9QRU5fT1BUSU9OU1wiKTtcbiAgICBhd2FpdCB0aGlzLmV4ZWN1dGVBY3Rpb24oXCJISURFX0NNUFwiKTtcbiAgICBhd2FpdCB0aGlzLmV4ZWN1dGVBY3Rpb24oXCJET19DT05TRU5UXCIsIFtdKTtcbiAgICBhd2FpdCB0aGlzLmV4ZWN1dGVBY3Rpb24oXCJTQVZFX0NPTlNFTlRcIik7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbiAgYXN5bmMgb3B0SW4oKSB7XG4gICAgYXdhaXQgdGhpcy5leGVjdXRlQWN0aW9uKFwiSElERV9DTVBcIik7XG4gICAgYXdhaXQgdGhpcy5leGVjdXRlQWN0aW9uKFwiT1BFTl9PUFRJT05TXCIpO1xuICAgIGF3YWl0IHRoaXMuZXhlY3V0ZUFjdGlvbihcIkhJREVfQ01QXCIpO1xuICAgIGF3YWl0IHRoaXMuZXhlY3V0ZUFjdGlvbihcIkRPX0NPTlNFTlRcIiwgW1wiRFwiLCBcIkFcIiwgXCJCXCIsIFwiRVwiLCBcIkZcIiwgXCJYXCJdKTtcbiAgICBhd2FpdCB0aGlzLmV4ZWN1dGVBY3Rpb24oXCJTQVZFX0NPTlNFTlRcIik7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbiAgYXN5bmMgb3BlbkNtcCgpIHtcbiAgICBhd2FpdCB0aGlzLmV4ZWN1dGVBY3Rpb24oXCJISURFX0NNUFwiKTtcbiAgICBhd2FpdCB0aGlzLmV4ZWN1dGVBY3Rpb24oXCJPUEVOX09QVElPTlNcIik7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbiAgYXN5bmMgdGVzdCgpIHtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxufTtcblxuLy8gbGliL3J1bGVzLnRzXG52YXIgU1VQUE9SVEVEX1JVTEVfU1RFUF9WRVJTSU9OID0gMTtcblxuLy8gbGliL2NtcHMvdHJ1c3RhcmMtdG9wLnRzXG52YXIgY29va2llU2V0dGluZ3NCdXR0b24gPSBcIiN0cnVzdGUtc2hvdy1jb25zZW50XCI7XG52YXIgc2hvcnRjdXRPcHRPdXQgPSBcIiN0cnVzdGUtY29uc2VudC1yZXF1aXJlZFwiO1xudmFyIHNob3J0Y3V0T3B0SW4gPSBcIiN0cnVzdGUtY29uc2VudC1idXR0b25cIjtcbnZhciBwb3B1cENvbnRlbnQgPSBcIiN0cnVzdGUtY29uc2VudC1jb250ZW50XCI7XG52YXIgYmFubmVyT3ZlcmxheSA9IFwiI3RydXN0YXJjLWJhbm5lci1vdmVybGF5XCI7XG52YXIgYmFubmVyQ29udGFpbmVyID0gXCIjdHJ1c3RlLWNvbnNlbnQtdHJhY2tcIjtcbnZhciBUcnVzdEFyY1RvcCA9IGNsYXNzIGV4dGVuZHMgQXV0b0NvbnNlbnRDTVBCYXNlIHtcbiAgY29uc3RydWN0b3IoYXV0b2NvbnNlbnRJbnN0YW5jZSkge1xuICAgIHN1cGVyKGF1dG9jb25zZW50SW5zdGFuY2UpO1xuICAgIHRoaXMubmFtZSA9IFwiVHJ1c3RBcmMtdG9wXCI7XG4gICAgdGhpcy5wcmVoaWRlU2VsZWN0b3JzID0gW1wiLnRydXN0YXJjLWJhbm5lci1jb250YWluZXJcIiwgYC50cnVzdGVfcG9wZnJhbWUsLnRydXN0ZV9vdmVybGF5LC50cnVzdGVfYm94X292ZXJsYXksJHtiYW5uZXJDb250YWluZXJ9YF07XG4gICAgdGhpcy5ydW5Db250ZXh0ID0ge1xuICAgICAgbWFpbjogdHJ1ZSxcbiAgICAgIGZyYW1lOiBmYWxzZVxuICAgIH07XG4gICAgdGhpcy5fc2hvcnRjdXRCdXR0b24gPSBudWxsO1xuICAgIHRoaXMuX29wdEluRG9uZSA9IGZhbHNlO1xuICB9XG4gIGdldCBoYXNTZWxmVGVzdCgpIHtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICBnZXQgaXNJbnRlcm1lZGlhdGUoKSB7XG4gICAgaWYgKHRoaXMuX29wdEluRG9uZSkge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICByZXR1cm4gIXRoaXMuX3Nob3J0Y3V0QnV0dG9uO1xuICB9XG4gIGdldCBpc0Nvc21ldGljKCkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBhc3luYyBkZXRlY3RDbXAoKSB7XG4gICAgY29uc3QgcmVzdWx0ID0gdGhpcy5lbGVtZW50RXhpc3RzKGAke2Nvb2tpZVNldHRpbmdzQnV0dG9ufSwke2Jhbm5lckNvbnRhaW5lcn1gKTtcbiAgICBpZiAocmVzdWx0KSB7XG4gICAgICB0aGlzLl9zaG9ydGN1dEJ1dHRvbiA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3Ioc2hvcnRjdXRPcHRPdXQpO1xuICAgIH1cbiAgICByZXR1cm4gcmVzdWx0O1xuICB9XG4gIGFzeW5jIGRldGVjdFBvcHVwKCkge1xuICAgIHJldHVybiB0aGlzLmVsZW1lbnRWaXNpYmxlKGAke3BvcHVwQ29udGVudH0sJHtiYW5uZXJPdmVybGF5fSwke2Jhbm5lckNvbnRhaW5lcn1gLCBcImFueVwiKTtcbiAgfVxuICBhc3luYyBvcHRPdXQoKSB7XG4gICAgaWYgKHRoaXMuX3Nob3J0Y3V0QnV0dG9uKSB7XG4gICAgICB0aGlzLl9zaG9ydGN1dEJ1dHRvbi5jbGljaygpO1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIGhpZGVFbGVtZW50cyhnZXRTdHlsZUVsZW1lbnQoKSwgYC50cnVzdGVfcG9wZnJhbWUsIC50cnVzdGVfb3ZlcmxheSwgLnRydXN0ZV9ib3hfb3ZlcmxheSwgJHtiYW5uZXJDb250YWluZXJ9YCk7XG4gICAgYXdhaXQgdGhpcy5jbGljayhjb29raWVTZXR0aW5nc0J1dHRvbik7XG4gICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICBnZXRTdHlsZUVsZW1lbnQoKS5yZW1vdmUoKTtcbiAgICB9LCAxZTQpO1xuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIGFzeW5jIG9wdEluKCkge1xuICAgIHRoaXMuX29wdEluRG9uZSA9IHRydWU7XG4gICAgcmV0dXJuIGF3YWl0IHRoaXMuY2xpY2soc2hvcnRjdXRPcHRJbik7XG4gIH1cbiAgYXN5bmMgb3BlbkNtcCgpIHtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICBhc3luYyB0ZXN0KCkge1xuICAgIGF3YWl0IHRoaXMud2FpdCg1MDApO1xuICAgIHJldHVybiBhd2FpdCB0aGlzLm1haW5Xb3JsZEV2YWwoXCJFVkFMX1RSVVNUQVJDX1RPUFwiKTtcbiAgfVxufTtcblxuLy8gbGliL2NtcHMvdHJ1c3RhcmMtZnJhbWUudHNcbnZhciBUcnVzdEFyY0ZyYW1lID0gY2xhc3MgZXh0ZW5kcyBBdXRvQ29uc2VudENNUEJhc2Uge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlciguLi5hcmd1bWVudHMpO1xuICAgIHRoaXMubmFtZSA9IFwiVHJ1c3RBcmMtZnJhbWVcIjtcbiAgICB0aGlzLnJ1bkNvbnRleHQgPSB7XG4gICAgICBtYWluOiBmYWxzZSxcbiAgICAgIGZyYW1lOiB0cnVlLFxuICAgICAgdXJsUGF0dGVybjogXCJeaHR0cHM6Ly9jb25zZW50LXByZWZcXFxcLnRydXN0YXJjXFxcXC5jb20vXFxcXD9cIlxuICAgIH07XG4gIH1cbiAgZ2V0IGhhc1NlbGZUZXN0KCkge1xuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIGdldCBpc0ludGVybWVkaWF0ZSgpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgZ2V0IGlzQ29zbWV0aWMoKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGFzeW5jIGRldGVjdENtcCgpIHtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICBhc3luYyBkZXRlY3RQb3B1cCgpIHtcbiAgICByZXR1cm4gdGhpcy5lbGVtZW50VmlzaWJsZShcIiNkZWZhdWx0cHJlZmVyZW5jZW1hbmFnZXJcIiwgXCJhbnlcIikgJiYgdGhpcy5lbGVtZW50VmlzaWJsZShcIi5tYWluQ29udGVudFwiLCBcImFueVwiKTtcbiAgfVxuICBhc3luYyBuYXZpZ2F0ZVRvU2V0dGluZ3MoKSB7XG4gICAgYXdhaXQgd2FpdEZvcihcbiAgICAgIGFzeW5jICgpID0+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuZWxlbWVudEV4aXN0cyhcIi5zaHBcIikgfHwgdGhpcy5lbGVtZW50VmlzaWJsZShcIi5hZHZhbmNlXCIsIFwiYW55XCIpIHx8IHRoaXMuZWxlbWVudEV4aXN0cyhcIi5zd2l0Y2ggc3BhbjpmaXJzdC1jaGlsZFwiKTtcbiAgICAgIH0sXG4gICAgICAxMCxcbiAgICAgIDUwMFxuICAgICk7XG4gICAgaWYgKHRoaXMuZWxlbWVudEV4aXN0cyhcIi5zaHBcIikpIHtcbiAgICAgIGF3YWl0IHRoaXMuY2xpY2soXCIuc2hwXCIpO1xuICAgIH1cbiAgICBhd2FpdCB0aGlzLndhaXRGb3JFbGVtZW50KFwiLnByZWZQYW5lbFwiLCA1ZTMpO1xuICAgIGlmICh0aGlzLmVsZW1lbnRWaXNpYmxlKFwiLmFkdmFuY2VcIiwgXCJhbnlcIikpIHtcbiAgICAgIGF3YWl0IHRoaXMuY2xpY2soXCIuYWR2YW5jZVwiKTtcbiAgICB9XG4gICAgcmV0dXJuIGF3YWl0IHdhaXRGb3IoKCkgPT4gdGhpcy5lbGVtZW50VmlzaWJsZShcIi5zd2l0Y2ggc3BhbjpmaXJzdC1jaGlsZFwiLCBcImFueVwiKSwgNSwgMWUzKTtcbiAgfVxuICBhc3luYyBvcHRPdXQoKSB7XG4gICAgaWYgKGF3YWl0IHRoaXMubWFpbldvcmxkRXZhbChcIkVWQUxfVFJVU1RBUkNfRlJBTUVfVEVTVFwiKSkge1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIGxldCB0aW1lb3V0ID0gM2UzO1xuICAgIGlmIChhd2FpdCB0aGlzLm1haW5Xb3JsZEV2YWwoXCJFVkFMX1RSVVNUQVJDX0ZSQU1FX0dUTVwiKSkge1xuICAgICAgdGltZW91dCA9IDE1MDA7XG4gICAgfVxuICAgIGF3YWl0IHdhaXRGb3IoKCkgPT4gZG9jdW1lbnQucmVhZHlTdGF0ZSA9PT0gXCJjb21wbGV0ZVwiLCAyMCwgMTAwKTtcbiAgICBhd2FpdCB0aGlzLndhaXRGb3JFbGVtZW50KFwiLm1haW5Db250ZW50W2FyaWEtaGlkZGVuPWZhbHNlXVwiLCB0aW1lb3V0KTtcbiAgICBpZiAoYXdhaXQgdGhpcy5jbGljayhcIi5yZWplY3RBbGxcIikpIHtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICBpZiAodGhpcy5lbGVtZW50RXhpc3RzKFwiLnByZWZQYW5lbFwiKSkge1xuICAgICAgYXdhaXQgdGhpcy53YWl0Rm9yRWxlbWVudCgnLnByZWZQYW5lbFtzdHlsZT1cInZpc2liaWxpdHk6IHZpc2libGU7XCJdJywgdGltZW91dCk7XG4gICAgfVxuICAgIGlmIChhd2FpdCB0aGlzLmNsaWNrKFwiI2NhdERldGFpbHMwXCIpKSB7XG4gICAgICBhd2FpdCB0aGlzLmNsaWNrKFwiLnN1Ym1pdFwiKTtcbiAgICAgIHRoaXMud2FpdEZvclRoZW5DbGljayhcIiNnd3QtZGVidWctY2xvc2VfaWRcIiwgdGltZW91dCk7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgaWYgKGF3YWl0IHRoaXMuY2xpY2soXCIucmVxdWlyZWRcIikpIHtcbiAgICAgIHRoaXMud2FpdEZvclRoZW5DbGljayhcIiNnd3QtZGVidWctY2xvc2VfaWRcIiwgdGltZW91dCk7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgYXdhaXQgdGhpcy5uYXZpZ2F0ZVRvU2V0dGluZ3MoKTtcbiAgICBhd2FpdCB0aGlzLmNsaWNrKFwiLnN3aXRjaCBzcGFuOm50aC1jaGlsZCgxKTpub3QoLmFjdGl2ZSlcIiwgdHJ1ZSk7XG4gICAgYXdhaXQgdGhpcy5jbGljayhcIi5zdWJtaXRcIik7XG4gICAgdGhpcy53YWl0Rm9yVGhlbkNsaWNrKFwiI2d3dC1kZWJ1Zy1jbG9zZV9pZFwiLCB0aW1lb3V0ICogMTApO1xuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIGFzeW5jIG9wdEluKCkge1xuICAgIGlmIChhd2FpdCB0aGlzLmNsaWNrKFwiLmNhbGxcIikpIHtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICBhd2FpdCB0aGlzLm5hdmlnYXRlVG9TZXR0aW5ncygpO1xuICAgIGF3YWl0IHRoaXMuY2xpY2soXCIuc3dpdGNoIHNwYW46bnRoLWNoaWxkKDIpXCIsIHRydWUpO1xuICAgIGF3YWl0IHRoaXMuY2xpY2soXCIuc3VibWl0XCIpO1xuICAgIHRoaXMud2FpdEZvckVsZW1lbnQoXCIjZ3d0LWRlYnVnLWNsb3NlX2lkXCIsIDNlNSkudGhlbigoKSA9PiB7XG4gICAgICB0aGlzLmNsaWNrKFwiI2d3dC1kZWJ1Zy1jbG9zZV9pZFwiKTtcbiAgICB9KTtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICBhc3luYyB0ZXN0KCkge1xuICAgIGF3YWl0IHRoaXMud2FpdCg1MDApO1xuICAgIHJldHVybiBhd2FpdCB0aGlzLm1haW5Xb3JsZEV2YWwoXCJFVkFMX1RSVVNUQVJDX0ZSQU1FX1RFU1RcIik7XG4gIH1cbn07XG5cbi8vIGxpYi9jbXBzL2Nvb2tpZWJvdC50c1xudmFyIENvb2tpZWJvdCA9IGNsYXNzIGV4dGVuZHMgQXV0b0NvbnNlbnRDTVBCYXNlIHtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoLi4uYXJndW1lbnRzKTtcbiAgICB0aGlzLm5hbWUgPSBcIkN5Ym90Y29va2llYm90XCI7XG4gICAgdGhpcy5wcmVoaWRlU2VsZWN0b3JzID0gW1xuICAgICAgXCIjQ3lib3RDb29raWVib3REaWFsb2csI0N5Ym90Q29va2llYm90RGlhbG9nQm9keVVuZGVybGF5LCNkdGNvb2tpZS1jb250YWluZXIsI2Nvb2tpZWJhbm5lciwjY2ItY29va2llb3ZlcmxheSwubW9kYWwtLWNvb2tpZS1iYW5uZXIsI2Nvb2tpZWJhbm5lcl9vdXRlciwjQ29va2llQmFubmVyXCJcbiAgICBdO1xuICB9XG4gIGdldCBoYXNTZWxmVGVzdCgpIHtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICBnZXQgaXNJbnRlcm1lZGlhdGUoKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGdldCBpc0Nvc21ldGljKCkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBhc3luYyBkZXRlY3RDbXAoKSB7XG4gICAgcmV0dXJuIGF3YWl0IHRoaXMubWFpbldvcmxkRXZhbChcIkVWQUxfQ09PS0lFQk9UXzFcIik7XG4gIH1cbiAgYXN5bmMgZGV0ZWN0UG9wdXAoKSB7XG4gICAgcmV0dXJuIHRoaXMubWFpbldvcmxkRXZhbChcIkVWQUxfQ09PS0lFQk9UXzJcIik7XG4gIH1cbiAgYXN5bmMgb3B0T3V0KCkge1xuICAgIGF3YWl0IHRoaXMud2FpdCg1MDApO1xuICAgIGxldCByZXMgPSBhd2FpdCB0aGlzLm1haW5Xb3JsZEV2YWwoXCJFVkFMX0NPT0tJRUJPVF8zXCIpO1xuICAgIGF3YWl0IHRoaXMud2FpdCgxZTMpO1xuICAgIHJlcyA9IHJlcyAmJiBhd2FpdCB0aGlzLm1haW5Xb3JsZEV2YWwoXCJFVkFMX0NPT0tJRUJPVF80XCIpO1xuICAgIHJldHVybiByZXM7XG4gIH1cbiAgYXN5bmMgb3B0SW4oKSB7XG4gICAgaWYgKHRoaXMuZWxlbWVudEV4aXN0cyhcIiNkdGNvb2tpZS1jb250YWluZXJcIikpIHtcbiAgICAgIHJldHVybiBhd2FpdCB0aGlzLmNsaWNrKFwiLmgtZHRjb29raWUtYWNjZXB0XCIpO1xuICAgIH1cbiAgICBhd2FpdCB0aGlzLmNsaWNrKFwiLkN5Ym90Q29va2llYm90RGlhbG9nQm9keUxldmVsQnV0dG9uOm5vdCg6Y2hlY2tlZCk6ZW5hYmxlZFwiLCB0cnVlKTtcbiAgICBhd2FpdCB0aGlzLmNsaWNrKFwiI0N5Ym90Q29va2llYm90RGlhbG9nQm9keUxldmVsQnV0dG9uQWNjZXB0XCIpO1xuICAgIGF3YWl0IHRoaXMuY2xpY2soXCIjQ3lib3RDb29raWVib3REaWFsb2dCb2R5QnV0dG9uQWNjZXB0XCIpO1xuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIGFzeW5jIHRlc3QoKSB7XG4gICAgYXdhaXQgdGhpcy53YWl0KDUwMCk7XG4gICAgcmV0dXJuIGF3YWl0IHRoaXMubWFpbldvcmxkRXZhbChcIkVWQUxfQ09PS0lFQk9UXzVcIik7XG4gIH1cbn07XG5cbi8vIGxpYi9jbXBzL3NvdXJjZXBvaW50LWZyYW1lLnRzXG52YXIgU291cmNlUG9pbnQgPSBjbGFzcyBleHRlbmRzIEF1dG9Db25zZW50Q01QQmFzZSB7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHN1cGVyKC4uLmFyZ3VtZW50cyk7XG4gICAgdGhpcy5uYW1lID0gXCJTb3VyY2Vwb2ludC1mcmFtZVwiO1xuICAgIHRoaXMucHJlaGlkZVNlbGVjdG9ycyA9IFtcImRpdltpZF49J3NwX21lc3NhZ2VfY29udGFpbmVyXyddLC5tZXNzYWdlLW92ZXJsYXlcIiwgXCIjc3BfcHJpdmFjeV9tYW5hZ2VyX2NvbnRhaW5lclwiXTtcbiAgICB0aGlzLmNjcGFOb3RpY2UgPSBmYWxzZTtcbiAgICB0aGlzLmNjcGFQb3B1cCA9IGZhbHNlO1xuICAgIHRoaXMucnVuQ29udGV4dCA9IHtcbiAgICAgIG1haW46IHRydWUsXG4gICAgICBmcmFtZTogdHJ1ZVxuICAgIH07XG4gIH1cbiAgZ2V0IGhhc1NlbGZUZXN0KCkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBnZXQgaXNJbnRlcm1lZGlhdGUoKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGdldCBpc0Nvc21ldGljKCkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBhc3luYyBkZXRlY3RDbXAoKSB7XG4gICAgY29uc3QgdXJsID0gbmV3IFVSTChsb2NhdGlvbi5ocmVmKTtcbiAgICBpZiAodXJsLnNlYXJjaFBhcmFtcy5oYXMoXCJtZXNzYWdlX2lkXCIpICYmIHVybC5ob3N0bmFtZSA9PT0gXCJjY3BhLW5vdGljZS5zcC1wcm9kLm5ldFwiKSB7XG4gICAgICB0aGlzLmNjcGFOb3RpY2UgPSB0cnVlO1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIGlmICh1cmwuaG9zdG5hbWUgPT09IFwiY2NwYS1wbS5zcC1wcm9kLm5ldFwiKSB7XG4gICAgICB0aGlzLmNjcGFQb3B1cCA9IHRydWU7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgcmV0dXJuICh1cmwucGF0aG5hbWUgPT09IFwiL2luZGV4Lmh0bWxcIiB8fCB1cmwucGF0aG5hbWUgPT09IFwiL3ByaXZhY3ktbWFuYWdlci9pbmRleC5odG1sXCIgfHwgdXJsLnBhdGhuYW1lID09PSBcIi9jY3BhX3BtL2luZGV4Lmh0bWxcIiB8fCB1cmwucGF0aG5hbWUgPT09IFwiL3VzX3BtL2luZGV4Lmh0bWxcIikgJiYgKHVybC5zZWFyY2hQYXJhbXMuaGFzKFwibWVzc2FnZV9pZFwiKSB8fCB1cmwuc2VhcmNoUGFyYW1zLmhhcyhcInJlcXVlc3RVVUlEXCIpIHx8IHVybC5zZWFyY2hQYXJhbXMuaGFzKFwiY29uc2VudFVVSURcIikpO1xuICB9XG4gIGFzeW5jIGRldGVjdFBvcHVwKCkge1xuICAgIGlmICh0aGlzLmNjcGFOb3RpY2UpIHtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICBpZiAodGhpcy5jY3BhUG9wdXApIHtcbiAgICAgIHJldHVybiBhd2FpdCB0aGlzLndhaXRGb3JFbGVtZW50KFwiLnByaXYtc2F2ZS1idG5cIiwgMmUzKTtcbiAgICB9XG4gICAgYXdhaXQgdGhpcy53YWl0Rm9yRWxlbWVudChcbiAgICAgIFwiLnNwX2Nob2ljZV90eXBlXzExLC5zcF9jaG9pY2VfdHlwZV8xMiwuc3BfY2hvaWNlX3R5cGVfMTMsLnNwX2Nob2ljZV90eXBlX0FDQ0VQVF9BTEwsLnNwX2Nob2ljZV90eXBlX1NBVkVfQU5EX0VYSVRcIixcbiAgICAgIDJlM1xuICAgICk7XG4gICAgcmV0dXJuICF0aGlzLmVsZW1lbnRFeGlzdHMoXCIuc3BfY2hvaWNlX3R5cGVfOVwiKTtcbiAgfVxuICBhc3luYyBvcHRJbigpIHtcbiAgICBhd2FpdCB0aGlzLndhaXRGb3JFbGVtZW50KFwiLnNwX2Nob2ljZV90eXBlXzExLC5zcF9jaG9pY2VfdHlwZV9BQ0NFUFRfQUxMXCIsIDJlMyk7XG4gICAgaWYgKGF3YWl0IHRoaXMuY2xpY2soXCIuc3BfY2hvaWNlX3R5cGVfMTFcIikpIHtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICBpZiAoYXdhaXQgdGhpcy5jbGljayhcIi5zcF9jaG9pY2VfdHlwZV9BQ0NFUFRfQUxMXCIpKSB7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGlzTWFuYWdlck9wZW4oKSB7XG4gICAgcmV0dXJuIGxvY2F0aW9uLnBhdGhuYW1lID09PSBcIi9wcml2YWN5LW1hbmFnZXIvaW5kZXguaHRtbFwiIHx8IGxvY2F0aW9uLnBhdGhuYW1lID09PSBcIi9jY3BhX3BtL2luZGV4Lmh0bWxcIjtcbiAgfVxuICBhc3luYyBvcHRPdXQoKSB7XG4gICAgYXdhaXQgdGhpcy53YWl0KDUwMCk7XG4gICAgY29uc3QgbG9nc0NvbmZpZyA9IHRoaXMuYXV0b2NvbnNlbnQuY29uZmlnLmxvZ3M7XG4gICAgaWYgKHRoaXMuY2NwYVBvcHVwKSB7XG4gICAgICBjb25zdCB0b2dnbGVzID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbChcbiAgICAgICAgXCIucHJpdi1wdXJwb3NlLWNvbnRhaW5lciAuc3Atc3dpdGNoLWFycm93LWJsb2NrIGEubmV1dHJhbC5vbiAucmlnaHRcIlxuICAgICAgKTtcbiAgICAgIGZvciAoY29uc3QgdCBvZiB0b2dnbGVzKSB7XG4gICAgICAgIHQuY2xpY2soKTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHN3aXRjaGVzID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbChcbiAgICAgICAgXCIucHJpdi1wdXJwb3NlLWNvbnRhaW5lciAuc3Atc3dpdGNoLWFycm93LWJsb2NrIGEuc3dpdGNoLWJnLm9uXCJcbiAgICAgICk7XG4gICAgICBmb3IgKGNvbnN0IHQgb2Ygc3dpdGNoZXMpIHtcbiAgICAgICAgdC5jbGljaygpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIGF3YWl0IHRoaXMuY2xpY2soXCIucHJpdi1zYXZlLWJ0blwiKTtcbiAgICB9XG4gICAgaWYgKHRoaXMuZWxlbWVudFZpc2libGUoXCIuc3BfY2hvaWNlX3R5cGVfU0VcIiwgXCJhbnlcIikpIHtcbiAgICAgIGF3YWl0IHRoaXMuY2xpY2soXG4gICAgICAgIFtcbiAgICAgICAgICBcInhwYXRoLy8vZGl2W2NvbnRhaW5zKC4sICdEbyBub3Qgc2hhcmUgbXkgcGVyc29uYWwgaW5mb3JtYXRpb24nKSBhbmQgY29udGFpbnMoQGNsYXNzLCAnc3dpdGNoLWNvbnRhaW5lcicpXVwiLFxuICAgICAgICAgIFwiLnBtLXN3aXRjaFthcmlhLWNoZWNrZWQ9ZmFsc2VdIC5zbGlkZXJcIlxuICAgICAgICBdLFxuICAgICAgICBmYWxzZVxuICAgICAgKTtcbiAgICAgIHJldHVybiBhd2FpdCB0aGlzLmNsaWNrKFwiLnNwX2Nob2ljZV90eXBlX1NFXCIpO1xuICAgIH1cbiAgICBpZiAoIXRoaXMuaXNNYW5hZ2VyT3BlbigpKSB7XG4gICAgICBjb25zdCBhY3Rpb25hYmxlID0gYXdhaXQgdGhpcy53YWl0Rm9yVmlzaWJsZSgnLnNwX2Nob2ljZV90eXBlXzEyLC5zcF9jaG9pY2VfdHlwZV8xMyxbZGF0YS1jaG9pY2U9XCIxNzM5OTY4NTA4Nzk5XCJdJyk7XG4gICAgICBpZiAoIWFjdGlvbmFibGUpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgfVxuICAgICAgaWYgKCF0aGlzLmVsZW1lbnRFeGlzdHMoJy5zcF9jaG9pY2VfdHlwZV8xMixbZGF0YS1jaG9pY2U9XCIxNzM5OTY4NTA4Nzk5XCJdJykpIHtcbiAgICAgICAgcmV0dXJuIGF3YWl0IHRoaXMuY2xpY2soXCIuc3BfY2hvaWNlX3R5cGVfMTNcIik7XG4gICAgICB9XG4gICAgICBhd2FpdCB0aGlzLmNsaWNrKCcuc3BfY2hvaWNlX3R5cGVfMTIsW2RhdGEtY2hvaWNlPVwiMTczOTk2ODUwODc5OVwiXScpO1xuICAgICAgYXdhaXQgd2FpdEZvcigoKSA9PiB0aGlzLmlzTWFuYWdlck9wZW4oKSwgMjAwLCAxMDApO1xuICAgIH1cbiAgICBhd2FpdCB0aGlzLndhaXRGb3JFbGVtZW50KFwiLnR5cGUtbW9kYWxcIiwgMmU0KTtcbiAgICBpZiAodGhpcy5lbGVtZW50RXhpc3RzKFwiW3JvbGU9dGFibGlzdF1cIikpIHtcbiAgICAgIGF3YWl0IHRoaXMud2FpdEZvckVsZW1lbnQoXCJbcm9sZT10YWJsaXN0XSBbcm9sZT10YWJdXCIsIDFlNCk7XG4gICAgfVxuICAgIHRoaXMud2FpdEZvclRoZW5DbGljayhcIi5jY3BhLXN0YWNrIC5wbS1zd2l0Y2hbYXJpYS1jaGVja2VkPXRydWVdIC5zbGlkZXJcIiwgNTAwLCB0cnVlKTtcbiAgICB0cnkge1xuICAgICAgY29uc3QgcmVqZWN0U2VsZWN0b3IxID0gXCIuc3BfY2hvaWNlX3R5cGVfUkVKRUNUX0FMTFwiO1xuICAgICAgY29uc3QgcmVqZWN0U2VsZWN0b3IyID0gXCIucmVqZWN0LXRvZ2dsZVwiO1xuICAgICAgY29uc3QgcGF0aCA9IGF3YWl0IFByb21pc2UucmFjZShbXG4gICAgICAgIHRoaXMud2FpdEZvckVsZW1lbnQocmVqZWN0U2VsZWN0b3IxLCAyZTMpLnRoZW4oKHN1Y2Nlc3MpID0+IHN1Y2Nlc3MgPyAwIDogLTEpLFxuICAgICAgICB0aGlzLndhaXRGb3JFbGVtZW50KHJlamVjdFNlbGVjdG9yMiwgMmUzKS50aGVuKChzdWNjZXNzKSA9PiBzdWNjZXNzID8gMSA6IC0xKSxcbiAgICAgICAgdGhpcy53YWl0Rm9yRWxlbWVudChcIi5wbS1mZWF0dXJlc1wiLCAyZTMpLnRoZW4oKHN1Y2Nlc3MpID0+IHN1Y2Nlc3MgPyAyIDogLTEpXG4gICAgICBdKTtcbiAgICAgIGlmIChwYXRoID09PSAwKSB7XG4gICAgICAgIGF3YWl0IHRoaXMud2FpdEZvclZpc2libGUocmVqZWN0U2VsZWN0b3IxKTtcbiAgICAgICAgcmV0dXJuIGF3YWl0IHRoaXMuY2xpY2socmVqZWN0U2VsZWN0b3IxKTtcbiAgICAgIH0gZWxzZSBpZiAocGF0aCA9PT0gMSkge1xuICAgICAgICBhd2FpdCB0aGlzLmNsaWNrKHJlamVjdFNlbGVjdG9yMik7XG4gICAgICB9IGVsc2UgaWYgKHBhdGggPT09IDIpIHtcbiAgICAgICAgYXdhaXQgdGhpcy53YWl0Rm9yRWxlbWVudChcIi5wbS1mZWF0dXJlc1wiLCAxZTQpO1xuICAgICAgICBhd2FpdCB0aGlzLmNsaWNrKFwiLmNoZWNrZWQgPiBzcGFuXCIsIHRydWUpO1xuICAgICAgICBhd2FpdCB0aGlzLmNsaWNrKFwiLmNoZXZyb25cIik7XG4gICAgICB9XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgbG9nc0NvbmZpZy5lcnJvcnMgJiYgY29uc29sZS53YXJuKGUpO1xuICAgIH1cbiAgICByZXR1cm4gYXdhaXQgdGhpcy5jbGljayhcIi5zcF9jaG9pY2VfdHlwZV9TQVZFX0FORF9FWElUXCIpO1xuICB9XG59O1xuXG4vLyBsaWIvY21wcy9jb25zZW50bWFuYWdlci50c1xudmFyIENvbnNlbnRNYW5hZ2VyID0gY2xhc3MgZXh0ZW5kcyBBdXRvQ29uc2VudENNUEJhc2Uge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlciguLi5hcmd1bWVudHMpO1xuICAgIHRoaXMubmFtZSA9IFwiY29uc2VudG1hbmFnZXIubmV0XCI7XG4gICAgdGhpcy5wcmVoaWRlU2VsZWN0b3JzID0gW1wiI2NtcGJveCwjY21wYm94MlwiXTtcbiAgICB0aGlzLmFwaUF2YWlsYWJsZSA9IGZhbHNlO1xuICB9XG4gIGdldCBoYXNTZWxmVGVzdCgpIHtcbiAgICByZXR1cm4gdGhpcy5hcGlBdmFpbGFibGU7XG4gIH1cbiAgZ2V0IGlzSW50ZXJtZWRpYXRlKCkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBnZXQgaXNDb3NtZXRpYygpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgYXN5bmMgZGV0ZWN0Q21wKCkge1xuICAgIHRoaXMuYXBpQXZhaWxhYmxlID0gYXdhaXQgdGhpcy5tYWluV29ybGRFdmFsKFwiRVZBTF9DT05TRU5UTUFOQUdFUl8xXCIpO1xuICAgIGlmICghdGhpcy5hcGlBdmFpbGFibGUpIHtcbiAgICAgIHJldHVybiB0aGlzLmVsZW1lbnRFeGlzdHMoXCIjY21wYm94XCIpO1xuICAgIH0gZWxzZSB7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gIH1cbiAgYXN5bmMgZGV0ZWN0UG9wdXAoKSB7XG4gICAgaWYgKHRoaXMuYXBpQXZhaWxhYmxlKSB7XG4gICAgICBhd2FpdCB0aGlzLndhaXQoNTAwKTtcbiAgICAgIHJldHVybiBhd2FpdCB0aGlzLm1haW5Xb3JsZEV2YWwoXCJFVkFMX0NPTlNFTlRNQU5BR0VSXzJcIik7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLmVsZW1lbnRWaXNpYmxlKFwiI2NtcGJveCAuY21wbW9yZVwiLCBcImFueVwiKTtcbiAgfVxuICBhc3luYyBvcHRPdXQoKSB7XG4gICAgYXdhaXQgdGhpcy53YWl0KDUwMCk7XG4gICAgaWYgKHRoaXMuYXBpQXZhaWxhYmxlKSB7XG4gICAgICByZXR1cm4gYXdhaXQgdGhpcy5tYWluV29ybGRFdmFsKFwiRVZBTF9DT05TRU5UTUFOQUdFUl8zXCIpO1xuICAgIH1cbiAgICBpZiAoYXdhaXQgdGhpcy5jbGljayhcIi5jbXBib3hidG5ub1wiKSkge1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIGlmICh0aGlzLmVsZW1lbnRFeGlzdHMoXCIuY21wd2VsY29tZXBycHNidG5cIikpIHtcbiAgICAgIGF3YWl0IHRoaXMuY2xpY2soXCIuY21wd2VsY29tZXBycHNidG4gPiBhW2FyaWEtY2hlY2tlZD10cnVlXVwiLCB0cnVlKTtcbiAgICAgIGF3YWl0IHRoaXMuY2xpY2soXCIuY21wYm94YnRuc2F2ZVwiKTtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICBhd2FpdCB0aGlzLmNsaWNrKFwiLmNtcGJveGJ0bmN1c3RvbVwiKTtcbiAgICBhd2FpdCB0aGlzLndhaXRGb3JFbGVtZW50KFwiLmNtcHRibGJveFwiLCAyZTMpO1xuICAgIGF3YWl0IHRoaXMuY2xpY2soXCIuY21wdGRjaG9pY2UgPiBhW2FyaWEtY2hlY2tlZD10cnVlXVwiLCB0cnVlKTtcbiAgICBhd2FpdCB0aGlzLmNsaWNrKFwiLmNtcGJveGJ0bnllc2N1c3RvbWNob2ljZXNcIik7XG4gICAgdGhpcy5oaWRlKFwiI2NtcHdyYXBwZXIsI2NtcGJveFwiLCBcImRpc3BsYXlcIik7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbiAgYXN5bmMgb3B0SW4oKSB7XG4gICAgaWYgKHRoaXMuYXBpQXZhaWxhYmxlKSB7XG4gICAgICByZXR1cm4gYXdhaXQgdGhpcy5tYWluV29ybGRFdmFsKFwiRVZBTF9DT05TRU5UTUFOQUdFUl80XCIpO1xuICAgIH1cbiAgICByZXR1cm4gYXdhaXQgdGhpcy5jbGljayhcIi5jbXBib3hidG55ZXNcIik7XG4gIH1cbiAgYXN5bmMgdGVzdCgpIHtcbiAgICBpZiAodGhpcy5hcGlBdmFpbGFibGUpIHtcbiAgICAgIHJldHVybiBhd2FpdCB0aGlzLm1haW5Xb3JsZEV2YWwoXCJFVkFMX0NPTlNFTlRNQU5BR0VSXzVcIik7XG4gICAgfVxuICAgIHJldHVybiBmYWxzZTtcbiAgfVxufTtcblxuLy8gbGliL2NtcHMvZXZpZG9uLnRzXG52YXIgRXZpZG9uID0gY2xhc3MgZXh0ZW5kcyBBdXRvQ29uc2VudENNUEJhc2Uge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlciguLi5hcmd1bWVudHMpO1xuICAgIHRoaXMubmFtZSA9IFwiRXZpZG9uXCI7XG4gIH1cbiAgZ2V0IGhhc1NlbGZUZXN0KCkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBnZXQgaXNJbnRlcm1lZGlhdGUoKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGdldCBpc0Nvc21ldGljKCkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBhc3luYyBkZXRlY3RDbXAoKSB7XG4gICAgcmV0dXJuIHRoaXMuZWxlbWVudEV4aXN0cyhcIiNfZXZpZG9uX2Jhbm5lclwiKTtcbiAgfVxuICBhc3luYyBkZXRlY3RQb3B1cCgpIHtcbiAgICByZXR1cm4gdGhpcy5lbGVtZW50VmlzaWJsZShcIiNfZXZpZG9uX2Jhbm5lclwiLCBcImFueVwiKTtcbiAgfVxuICBhc3luYyBvcHRPdXQoKSB7XG4gICAgaWYgKGF3YWl0IHRoaXMuY2xpY2soXCIjX2V2aWRvbi1kZWNsaW5lLWJ1dHRvblwiKSkge1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIGhpZGVFbGVtZW50cyhnZXRTdHlsZUVsZW1lbnQoKSwgXCIjZXZpZG9uLXByZWZkaWFnLW92ZXJsYXksI2V2aWRvbi1wcmVmZGlhZy1iYWNrZ3JvdW5kLCNfZXZpZG9uLWJhY2tncm91bmRcIik7XG4gICAgYXdhaXQgdGhpcy53YWl0Rm9yVGhlbkNsaWNrKFwiI19ldmlkb24tb3B0aW9uLWJ1dHRvblwiKTtcbiAgICBhd2FpdCB0aGlzLndhaXRGb3JFbGVtZW50KFwiI2V2aWRvbi1wcmVmZGlhZy1vdmVybGF5XCIsIDVlMyk7XG4gICAgYXdhaXQgdGhpcy53YWl0KDUwMCk7XG4gICAgYXdhaXQgdGhpcy53YWl0Rm9yVGhlbkNsaWNrKFwiI2V2aWRvbi1wcmVmZGlhZy1kZWNsaW5lXCIpO1xuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIGFzeW5jIG9wdEluKCkge1xuICAgIHJldHVybiBhd2FpdCB0aGlzLmNsaWNrKFwiI19ldmlkb24tYWNjZXB0LWJ1dHRvblwiKTtcbiAgfVxufTtcblxuLy8gbGliL2NtcHMvb25ldHJ1c3QudHNcbnZhciBPbmV0cnVzdCA9IGNsYXNzIGV4dGVuZHMgQXV0b0NvbnNlbnRDTVBCYXNlIHtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoLi4uYXJndW1lbnRzKTtcbiAgICB0aGlzLm5hbWUgPSBcIk9uZXRydXN0XCI7XG4gICAgdGhpcy5wcmVoaWRlU2VsZWN0b3JzID0gW1wiI29uZXRydXN0LWJhbm5lci1zZGssI29uZXRydXN0LWNvbnNlbnQtc2RrLC5vbmV0cnVzdC1wYy1kYXJrLWZpbHRlciwuanMtY29uc2VudC1iYW5uZXJcIl07XG4gIH1cbiAgZ2V0IGhhc1NlbGZUZXN0KCkge1xuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIGdldCBpc0ludGVybWVkaWF0ZSgpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgZ2V0IGlzQ29zbWV0aWMoKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGFzeW5jIGRldGVjdENtcCgpIHtcbiAgICByZXR1cm4gdGhpcy5lbGVtZW50RXhpc3RzKFwiI29uZXRydXN0LWJhbm5lci1zZGssI29uZXRydXN0LXBjLXNka1wiKTtcbiAgfVxuICBhc3luYyBkZXRlY3RQb3B1cCgpIHtcbiAgICByZXR1cm4gdGhpcy5lbGVtZW50VmlzaWJsZShcIiNvbmV0cnVzdC1iYW5uZXItc2RrLCNvbmV0cnVzdC1wYy1zZGtcIiwgXCJhbnlcIik7XG4gIH1cbiAgYXN5bmMgb3B0T3V0KCkge1xuICAgIGlmICh0aGlzLmVsZW1lbnRWaXNpYmxlKFwiI29uZXRydXN0LXJlamVjdC1hbGwtaGFuZGxlciwub3QtcGMtcmVmdXNlLWFsbC1oYW5kbGVyLC5qcy1yZWplY3QtY29va2llc1wiLCBcImFueVwiKSkge1xuICAgICAgcmV0dXJuIGF3YWl0IHRoaXMuY2xpY2soXCIjb25ldHJ1c3QtcmVqZWN0LWFsbC1oYW5kbGVyLC5vdC1wYy1yZWZ1c2UtYWxsLWhhbmRsZXIsLmpzLXJlamVjdC1jb29raWVzXCIpO1xuICAgIH1cbiAgICBpZiAodGhpcy5lbGVtZW50RXhpc3RzKFwiI29uZXRydXN0LXBjLWJ0bi1oYW5kbGVyXCIpKSB7XG4gICAgICBhd2FpdCB0aGlzLmNsaWNrKFwiI29uZXRydXN0LXBjLWJ0bi1oYW5kbGVyXCIpO1xuICAgIH0gZWxzZSB7XG4gICAgICBhd2FpdCB0aGlzLmNsaWNrKFwiLm90LXNkay1zaG93LXNldHRpbmdzLGJ1dHRvbi5qcy1jb29raWUtc2V0dGluZ3NcIik7XG4gICAgfVxuICAgIGF3YWl0IHRoaXMud2FpdEZvckVsZW1lbnQoXCIjb25ldHJ1c3QtY29uc2VudC1zZGtcIiwgMmUzKTtcbiAgICBhd2FpdCB0aGlzLndhaXQoMWUzKTtcbiAgICBhd2FpdCB0aGlzLmNsaWNrKFwiI29uZXRydXN0LWNvbnNlbnQtc2RrIGlucHV0LmNhdGVnb3J5LXN3aXRjaC1oYW5kbGVyOmNoZWNrZWQsLmpzLWVkaXRvci10b2dnbGUtc3RhdGU6Y2hlY2tlZFwiLCB0cnVlKTtcbiAgICBhd2FpdCB0aGlzLndhaXQoMWUzKTtcbiAgICBhd2FpdCB0aGlzLndhaXRGb3JFbGVtZW50KFwiLnNhdmUtcHJlZmVyZW5jZS1idG4taGFuZGxlciwuanMtY29uc2VudC1zYXZlXCIsIDJlMyk7XG4gICAgYXdhaXQgdGhpcy5jbGljayhcIi5zYXZlLXByZWZlcmVuY2UtYnRuLWhhbmRsZXIsLmpzLWNvbnNlbnQtc2F2ZVwiKTtcbiAgICBhd2FpdCB0aGlzLndhaXRGb3JWaXNpYmxlKFwiI29uZXRydXN0LWJhbm5lci1zZGtcIiwgNWUzLCBcIm5vbmVcIik7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbiAgYXN5bmMgb3B0SW4oKSB7XG4gICAgcmV0dXJuIGF3YWl0IHRoaXMuY2xpY2soXCIjb25ldHJ1c3QtYWNjZXB0LWJ0bi1oYW5kbGVyLCNhY2NlcHQtcmVjb21tZW5kZWQtYnRuLWhhbmRsZXIsLmpzLWFjY2VwdC1jb29raWVzXCIpO1xuICB9XG4gIGFzeW5jIHRlc3QoKSB7XG4gICAgcmV0dXJuIGF3YWl0IHdhaXRGb3IoKCkgPT4gdGhpcy5tYWluV29ybGRFdmFsKFwiRVZBTF9PTkVUUlVTVF8xXCIpLCAxMCwgNTAwKTtcbiAgfVxufTtcblxuLy8gbGliL2NtcHMva2xhcm8udHNcbnZhciBLbGFybyA9IGNsYXNzIGV4dGVuZHMgQXV0b0NvbnNlbnRDTVBCYXNlIHtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoLi4uYXJndW1lbnRzKTtcbiAgICB0aGlzLm5hbWUgPSBcIktsYXJvXCI7XG4gICAgdGhpcy5wcmVoaWRlU2VsZWN0b3JzID0gW1wiLmtsYXJvXCJdO1xuICAgIHRoaXMuc2V0dGluZ3NPcGVuID0gZmFsc2U7XG4gIH1cbiAgZ2V0IGhhc1NlbGZUZXN0KCkge1xuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIGdldCBpc0ludGVybWVkaWF0ZSgpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgZ2V0IGlzQ29zbWV0aWMoKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGFzeW5jIGRldGVjdENtcCgpIHtcbiAgICBpZiAodGhpcy5lbGVtZW50RXhpc3RzKFwiLmtsYXJvID4gLmNvb2tpZS1tb2RhbFwiKSkge1xuICAgICAgdGhpcy5zZXR0aW5nc09wZW4gPSB0cnVlO1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLmVsZW1lbnRFeGlzdHMoXCIua2xhcm8gPiAuY29va2llLW5vdGljZVwiKTtcbiAgfVxuICBhc3luYyBkZXRlY3RQb3B1cCgpIHtcbiAgICByZXR1cm4gdGhpcy5lbGVtZW50VmlzaWJsZShcIi5rbGFybyA+IC5jb29raWUtbm90aWNlLC5rbGFybyA+IC5jb29raWUtbW9kYWxcIiwgXCJhbnlcIik7XG4gIH1cbiAgYXN5bmMgb3B0T3V0KCkge1xuICAgIGNvbnN0IGFwaU9wdE91dFN1Y2Nlc3MgPSBhd2FpdCB0aGlzLm1haW5Xb3JsZEV2YWwoXCJFVkFMX0tMQVJPX1RSWV9BUElfT1BUX09VVFwiKTtcbiAgICBpZiAoYXBpT3B0T3V0U3VjY2Vzcykge1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIGlmIChhd2FpdCB0aGlzLmNsaWNrKFwiLmtsYXJvIC5jbi1kZWNsaW5lXCIpKSB7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgYXdhaXQgdGhpcy5tYWluV29ybGRFdmFsKFwiRVZBTF9LTEFST19PUEVOX1BPUFVQXCIpO1xuICAgIGlmIChhd2FpdCB0aGlzLmNsaWNrKFwiLmtsYXJvIC5jbi1kZWNsaW5lXCIpKSB7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgYXdhaXQgdGhpcy5jbGljayhcbiAgICAgIFwiLmNtLXB1cnBvc2U6bm90KC5jbS10b2dnbGUtYWxsKSA+IGlucHV0Om5vdCguaGFsZi1jaGVja2VkLC5yZXF1aXJlZCwub25seS1yZXF1aXJlZCksLmNtLXB1cnBvc2U6bm90KC5jbS10b2dnbGUtYWxsKSA+IGRpdiA+IGlucHV0Om5vdCguaGFsZi1jaGVja2VkLC5yZXF1aXJlZCwub25seS1yZXF1aXJlZClcIixcbiAgICAgIHRydWVcbiAgICApO1xuICAgIHJldHVybiBhd2FpdCB0aGlzLmNsaWNrKFwiLmNtLWJ0bi1hY2NlcHQsLmNtLWJ1dHRvblwiKTtcbiAgfVxuICBhc3luYyBvcHRJbigpIHtcbiAgICBpZiAoYXdhaXQgdGhpcy5jbGljayhcIi5rbGFybyAuY20tYnRuLWFjY2VwdC1hbGxcIikpIHtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICBpZiAodGhpcy5zZXR0aW5nc09wZW4pIHtcbiAgICAgIGF3YWl0IHRoaXMuY2xpY2soXCIuY20tcHVycG9zZTpub3QoLmNtLXRvZ2dsZS1hbGwpID4gaW5wdXQuaGFsZi1jaGVja2VkXCIsIHRydWUpO1xuICAgICAgcmV0dXJuIGF3YWl0IHRoaXMuY2xpY2soXCIuY20tYnRuLWFjY2VwdFwiKTtcbiAgICB9XG4gICAgcmV0dXJuIGF3YWl0IHRoaXMuY2xpY2soXCIua2xhcm8gLmNvb2tpZS1ub3RpY2UgLmNtLWJ0bi1zdWNjZXNzXCIpO1xuICB9XG4gIGFzeW5jIHRlc3QoKSB7XG4gICAgcmV0dXJuIGF3YWl0IHRoaXMubWFpbldvcmxkRXZhbChcIkVWQUxfS0xBUk9fMVwiKTtcbiAgfVxufTtcblxuLy8gbGliL2NtcHMvdW5pY29uc2VudC50c1xudmFyIFVuaWNvbnNlbnQgPSBjbGFzcyBleHRlbmRzIEF1dG9Db25zZW50Q01QQmFzZSB7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHN1cGVyKC4uLmFyZ3VtZW50cyk7XG4gICAgdGhpcy5uYW1lID0gXCJVbmljb25zZW50XCI7XG4gIH1cbiAgZ2V0IHByZWhpZGVTZWxlY3RvcnMoKSB7XG4gICAgcmV0dXJuIFtcIi51bmljXCIsIFwiLm1vZGFsOmhhcygudW5pYylcIl07XG4gIH1cbiAgZ2V0IGhhc1NlbGZUZXN0KCkge1xuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIGdldCBpc0ludGVybWVkaWF0ZSgpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgZ2V0IGlzQ29zbWV0aWMoKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGFzeW5jIGRldGVjdENtcCgpIHtcbiAgICByZXR1cm4gdGhpcy5lbGVtZW50RXhpc3RzKFwiLnVuaWMgLnVuaWMtYm94LC51bmljIC51bmljLWJhciwudW5pYyAudW5pYy1tb2RhbFwiKTtcbiAgfVxuICBhc3luYyBkZXRlY3RQb3B1cCgpIHtcbiAgICByZXR1cm4gdGhpcy5lbGVtZW50VmlzaWJsZShcIi51bmljIC51bmljLWJveCwudW5pYyAudW5pYy1iYXIsLnVuaWMgLnVuaWMtbW9kYWxcIiwgXCJhbnlcIik7XG4gIH1cbiAgYXN5bmMgb3B0T3V0KCkge1xuICAgIGF3YWl0IHRoaXMud2FpdEZvckVsZW1lbnQoXCIudW5pYyBidXR0b25cIiwgMWUzKTtcbiAgICBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKFwiLnVuaWMgYnV0dG9uXCIpLmZvckVhY2goKGJ1dHRvbikgPT4ge1xuICAgICAgY29uc3QgdGV4dCA9IGJ1dHRvbi50ZXh0Q29udGVudDtcbiAgICAgIGlmICh0ZXh0LmluY2x1ZGVzKFwiTWFuYWdlIE9wdGlvbnNcIikgfHwgdGV4dC5pbmNsdWRlcyhcIk9wdGlvbmVuIHZlcndhbHRlblwiKSkge1xuICAgICAgICBidXR0b24uY2xpY2soKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgICBpZiAoYXdhaXQgdGhpcy53YWl0Rm9yRWxlbWVudChcIi51bmljIGlucHV0W3R5cGU9Y2hlY2tib3hdXCIsIDFlMykpIHtcbiAgICAgIGF3YWl0IHRoaXMud2FpdEZvckVsZW1lbnQoXCIudW5pYyBidXR0b25cIiwgMWUzKTtcbiAgICAgIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoXCIudW5pYyBpbnB1dFt0eXBlPWNoZWNrYm94XVwiKS5mb3JFYWNoKChjKSA9PiB7XG4gICAgICAgIGlmIChjLmNoZWNrZWQpIHtcbiAgICAgICAgICBjLmNsaWNrKCk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgICAgZm9yIChjb25zdCBiIG9mIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoXCIudW5pYyBidXR0b25cIikpIHtcbiAgICAgICAgY29uc3QgdGV4dCA9IGIudGV4dENvbnRlbnQ7XG4gICAgICAgIGZvciAoY29uc3QgcGF0dGVybiBvZiBbXCJDb25maXJtIENob2ljZXNcIiwgXCJTYXZlIENob2ljZXNcIiwgXCJBdXN3YWhsIHNwZWljaGVyblwiXSkge1xuICAgICAgICAgIGlmICh0ZXh0LmluY2x1ZGVzKHBhdHRlcm4pKSB7XG4gICAgICAgICAgICBiLmNsaWNrKCk7XG4gICAgICAgICAgICBhd2FpdCB0aGlzLndhaXQoNTAwKTtcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgYXN5bmMgb3B0SW4oKSB7XG4gICAgcmV0dXJuIHRoaXMud2FpdEZvclRoZW5DbGljayhcIi51bmljICN1bmljLWFncmVlXCIpO1xuICB9XG4gIGFzeW5jIHRlc3QoKSB7XG4gICAgYXdhaXQgdGhpcy53YWl0KDFlMyk7XG4gICAgY29uc3QgcmVzID0gdGhpcy5lbGVtZW50RXhpc3RzKFwiLnVuaWMgLnVuaWMtYm94LC51bmljIC51bmljLWJhclwiKTtcbiAgICByZXR1cm4gIXJlcztcbiAgfVxufTtcblxuLy8gbGliL2NtcHMvY29udmVyc2FudC50c1xudmFyIENvbnZlcnNhbnQgPSBjbGFzcyBleHRlbmRzIEF1dG9Db25zZW50Q01QQmFzZSB7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHN1cGVyKC4uLmFyZ3VtZW50cyk7XG4gICAgdGhpcy5wcmVoaWRlU2VsZWN0b3JzID0gW1wiLmNtcC1yb290XCJdO1xuICAgIHRoaXMubmFtZSA9IFwiQ29udmVyc2FudFwiO1xuICB9XG4gIGdldCBoYXNTZWxmVGVzdCgpIHtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICBnZXQgaXNJbnRlcm1lZGlhdGUoKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGdldCBpc0Nvc21ldGljKCkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBhc3luYyBkZXRlY3RDbXAoKSB7XG4gICAgcmV0dXJuIHRoaXMuZWxlbWVudEV4aXN0cyhcIi5jbXAtcm9vdCAuY21wLXJlY2VwdGFjbGVcIik7XG4gIH1cbiAgYXN5bmMgZGV0ZWN0UG9wdXAoKSB7XG4gICAgcmV0dXJuIHRoaXMuZWxlbWVudFZpc2libGUoXCIuY21wLXJvb3QgLmNtcC1yZWNlcHRhY2xlXCIsIFwiYW55XCIpO1xuICB9XG4gIGFzeW5jIG9wdE91dCgpIHtcbiAgICBpZiAoIWF3YWl0IHRoaXMud2FpdEZvclRoZW5DbGljayhcIi5jbXAtbWFpbi1idXR0b246bm90KC5jbXAtbWFpbi1idXR0b24tLXByaW1hcnkpXCIpKSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIGlmICghYXdhaXQgdGhpcy53YWl0Rm9yRWxlbWVudChcIi5jbXAtdmlldy10YWItdGFic1wiKSkge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBhd2FpdCB0aGlzLndhaXRGb3JUaGVuQ2xpY2soXCIuY21wLXZpZXctdGFiLXRhYnMgPiA6Zmlyc3QtY2hpbGRcIik7XG4gICAgYXdhaXQgdGhpcy53YWl0Rm9yVGhlbkNsaWNrKFwiLmNtcC12aWV3LXRhYi10YWJzID4gLmNtcC12aWV3LXRhYi0tYWN0aXZlOmZpcnN0LWNoaWxkXCIpO1xuICAgIGZvciAoY29uc3QgaXRlbSBvZiBBcnJheS5mcm9tKGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoXCIuY21wLWFjY29yZGlvbi1pdGVtXCIpKSkge1xuICAgICAgaXRlbS5xdWVyeVNlbGVjdG9yKFwiLmNtcC1hY2NvcmRpb24taXRlbS10aXRsZVwiKS5jbGljaygpO1xuICAgICAgYXdhaXQgd2FpdEZvcigoKSA9PiAhIWl0ZW0ucXVlcnlTZWxlY3RvcihcIi5jbXAtYWNjb3JkaW9uLWl0ZW0tY29udGVudC5jbXAtYWN0aXZlXCIpLCAxMCwgNTApO1xuICAgICAgY29uc3QgY29udGVudCA9IGl0ZW0ucXVlcnlTZWxlY3RvcihcIi5jbXAtYWNjb3JkaW9uLWl0ZW0tY29udGVudC5jbXAtYWN0aXZlXCIpO1xuICAgICAgY29udGVudC5xdWVyeVNlbGVjdG9yQWxsKFwiLmNtcC10b2dnbGUtYWN0aW9ucyAuY21wLXRvZ2dsZS1kZW55Om5vdCguY21wLXRvZ2dsZS1kZW55LS1hY3RpdmUpXCIpLmZvckVhY2goKGUpID0+IGUuY2xpY2soKSk7XG4gICAgICBjb250ZW50LnF1ZXJ5U2VsZWN0b3JBbGwoXCIuY21wLXRvZ2dsZS1hY3Rpb25zIC5jbXAtdG9nZ2xlLWNoZWNrYm94Om5vdCguY21wLXRvZ2dsZS1jaGVja2JveC0tYWN0aXZlKVwiKS5mb3JFYWNoKChlKSA9PiBlLmNsaWNrKCkpO1xuICAgIH1cbiAgICBhd2FpdCB0aGlzLmNsaWNrKFwiLmNtcC1tYWluLWJ1dHRvbjpub3QoLmNtcC1tYWluLWJ1dHRvbi0tcHJpbWFyeSlcIik7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbiAgYXN5bmMgb3B0SW4oKSB7XG4gICAgcmV0dXJuIHRoaXMud2FpdEZvclRoZW5DbGljayhcIi5jbXAtbWFpbi1idXR0b24uY21wLW1haW4tYnV0dG9uLS1wcmltYXJ5XCIpO1xuICB9XG4gIGFzeW5jIHRlc3QoKSB7XG4gICAgcmV0dXJuIGRvY3VtZW50LmNvb2tpZS5pbmNsdWRlcyhcImNtcC1kYXRhPTBcIik7XG4gIH1cbn07XG5cbi8vIGxpYi9jbXBzL3Rpa3Rvay50c1xudmFyIFRpa3RvayA9IGNsYXNzIGV4dGVuZHMgQXV0b0NvbnNlbnRDTVBCYXNlIHtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoLi4uYXJndW1lbnRzKTtcbiAgICB0aGlzLm5hbWUgPSBcInRpa3Rvay5jb21cIjtcbiAgICB0aGlzLnJ1bkNvbnRleHQgPSB7XG4gICAgICB1cmxQYXR0ZXJuOiBcInRpa3Rva1wiXG4gICAgfTtcbiAgfVxuICBnZXQgaGFzU2VsZlRlc3QoKSB7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbiAgZ2V0IGlzSW50ZXJtZWRpYXRlKCkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBnZXQgaXNDb3NtZXRpYygpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgZ2V0U2hhZG93Um9vdCgpIHtcbiAgICBjb25zdCBjb250YWluZXIgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwidGlrdG9rLWNvb2tpZS1iYW5uZXJcIik7XG4gICAgaWYgKCFjb250YWluZXIpIHtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICByZXR1cm4gY29udGFpbmVyLnNoYWRvd1Jvb3Q7XG4gIH1cbiAgYXN5bmMgZGV0ZWN0Q21wKCkge1xuICAgIHJldHVybiB0aGlzLmVsZW1lbnRFeGlzdHMoXCJ0aWt0b2stY29va2llLWJhbm5lclwiKTtcbiAgfVxuICBhc3luYyBkZXRlY3RQb3B1cCgpIHtcbiAgICBjb25zdCBiYW5uZXIgPSB0aGlzLmdldFNoYWRvd1Jvb3QoKT8ucXVlcnlTZWxlY3RvcihcIi50aWt0b2stY29va2llLWJhbm5lclwiKTtcbiAgICByZXR1cm4gaXNFbGVtZW50VmlzaWJsZShiYW5uZXIpO1xuICB9XG4gIGFzeW5jIG9wdE91dCgpIHtcbiAgICBjb25zdCBsb2dzQ29uZmlnID0gdGhpcy5hdXRvY29uc2VudC5jb25maWcubG9ncztcbiAgICBjb25zdCBkZWNsaW5lQnV0dG9uID0gdGhpcy5nZXRTaGFkb3dSb290KCk/LnF1ZXJ5U2VsZWN0b3IoXCIuYnV0dG9uLXdyYXBwZXIgYnV0dG9uOmZpcnN0LWNoaWxkXCIpO1xuICAgIGlmIChkZWNsaW5lQnV0dG9uKSB7XG4gICAgICBsb2dzQ29uZmlnLnJ1bGVzdGVwcyAmJiBjb25zb2xlLmxvZyhcIltjbGlja2luZ11cIiwgZGVjbGluZUJ1dHRvbik7XG4gICAgICBkZWNsaW5lQnV0dG9uLmNsaWNrKCk7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9IGVsc2Uge1xuICAgICAgbG9nc0NvbmZpZy5lcnJvcnMgJiYgY29uc29sZS5sb2coXCJubyBkZWNsaW5lIGJ1dHRvbiBmb3VuZFwiKTtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gIH1cbiAgYXN5bmMgb3B0SW4oKSB7XG4gICAgY29uc3QgbG9nc0NvbmZpZyA9IHRoaXMuYXV0b2NvbnNlbnQuY29uZmlnLmxvZ3M7XG4gICAgY29uc3QgYWNjZXB0QnV0dG9uID0gdGhpcy5nZXRTaGFkb3dSb290KCk/LnF1ZXJ5U2VsZWN0b3IoXCIuYnV0dG9uLXdyYXBwZXIgYnV0dG9uOmxhc3QtY2hpbGRcIik7XG4gICAgaWYgKGFjY2VwdEJ1dHRvbikge1xuICAgICAgbG9nc0NvbmZpZy5ydWxlc3RlcHMgJiYgY29uc29sZS5sb2coXCJbY2xpY2tpbmddXCIsIGFjY2VwdEJ1dHRvbik7XG4gICAgICBhY2NlcHRCdXR0b24uY2xpY2soKTtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH0gZWxzZSB7XG4gICAgICBsb2dzQ29uZmlnLmVycm9ycyAmJiBjb25zb2xlLmxvZyhcIm5vIGFjY2VwdCBidXR0b24gZm91bmRcIik7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICB9XG4gIGFzeW5jIHRlc3QoKSB7XG4gICAgY29uc3QgbWF0Y2ggPSBkb2N1bWVudC5jb29raWUubWF0Y2goL2Nvb2tpZS1jb25zZW50PShbXjtdKykvKTtcbiAgICBpZiAoIW1hdGNoKSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIGNvbnN0IHZhbHVlID0gSlNPTi5wYXJzZShkZWNvZGVVUklDb21wb25lbnQobWF0Y2hbMV0pKTtcbiAgICByZXR1cm4gT2JqZWN0LnZhbHVlcyh2YWx1ZSkuZXZlcnkoKHgpID0+IHR5cGVvZiB4ICE9PSBcImJvb2xlYW5cIiB8fCB4ID09PSBmYWxzZSk7XG4gIH1cbn07XG5cbi8vIGxpYi9jbXBzL3R1bWJsci1jb20udHNcbnZhciBUdW1ibHIgPSBjbGFzcyBleHRlbmRzIEF1dG9Db25zZW50Q01QQmFzZSB7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHN1cGVyKC4uLmFyZ3VtZW50cyk7XG4gICAgdGhpcy5uYW1lID0gXCJ0dW1ibHItY29tXCI7XG4gICAgdGhpcy5ydW5Db250ZXh0ID0ge1xuICAgICAgdXJsUGF0dGVybjogXCJeaHR0cHM6Ly8od3d3XFxcXC4pP3R1bWJsclxcXFwuY29tL1wiXG4gICAgfTtcbiAgfVxuICBnZXQgaGFzU2VsZlRlc3QoKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGdldCBpc0ludGVybWVkaWF0ZSgpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgZ2V0IGlzQ29zbWV0aWMoKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGdldCBwcmVoaWRlU2VsZWN0b3JzKCkge1xuICAgIHJldHVybiBbXCIjY21wLWFwcC1jb250YWluZXJcIl07XG4gIH1cbiAgYXN5bmMgZGV0ZWN0Q21wKCkge1xuICAgIHJldHVybiB0aGlzLmVsZW1lbnRFeGlzdHMoXCIjY21wLWFwcC1jb250YWluZXJcIik7XG4gIH1cbiAgYXN5bmMgZGV0ZWN0UG9wdXAoKSB7XG4gICAgcmV0dXJuIHRoaXMuZWxlbWVudFZpc2libGUoXCIjY21wLWFwcC1jb250YWluZXJcIiwgXCJhbnlcIik7XG4gIH1cbiAgYXN5bmMgb3B0T3V0KCkge1xuICAgIGxldCBpZnJhbWUgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiI2NtcC1hcHAtY29udGFpbmVyIGlmcmFtZVwiKTtcbiAgICBsZXQgc2V0dGluZ3NCdXR0b24gPSBpZnJhbWUuY29udGVudERvY3VtZW50Py5xdWVyeVNlbGVjdG9yKFwiLmNtcC1jb21wb25lbnRzLWJ1dHRvbi5pcy1zZWNvbmRhcnlcIik7XG4gICAgaWYgKCFzZXR0aW5nc0J1dHRvbikge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBzZXR0aW5nc0J1dHRvbi5jbGljaygpO1xuICAgIGF3YWl0IHdhaXRGb3IoXG4gICAgICAoKSA9PiB7XG4gICAgICAgIGNvbnN0IGlmcmFtZTIgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiI2NtcC1hcHAtY29udGFpbmVyIGlmcmFtZVwiKTtcbiAgICAgICAgcmV0dXJuICEhaWZyYW1lMi5jb250ZW50RG9jdW1lbnQ/LnF1ZXJ5U2VsZWN0b3IoXCIuY21wX19kaWFsb2cgaW5wdXRcIik7XG4gICAgICB9LFxuICAgICAgNSxcbiAgICAgIDUwMFxuICAgICk7XG4gICAgaWZyYW1lID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIiNjbXAtYXBwLWNvbnRhaW5lciBpZnJhbWVcIik7XG4gICAgc2V0dGluZ3NCdXR0b24gPSBpZnJhbWUuY29udGVudERvY3VtZW50Py5xdWVyeVNlbGVjdG9yKFwiLmNtcC1jb21wb25lbnRzLWJ1dHRvbi5pcy1zZWNvbmRhcnlcIik7XG4gICAgaWYgKCFzZXR0aW5nc0J1dHRvbikge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBzZXR0aW5nc0J1dHRvbi5jbGljaygpO1xuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIGFzeW5jIG9wdEluKCkge1xuICAgIGNvbnN0IGlmcmFtZSA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIjY21wLWFwcC1jb250YWluZXIgaWZyYW1lXCIpO1xuICAgIGNvbnN0IGFjY2VwdEJ1dHRvbiA9IGlmcmFtZS5jb250ZW50RG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIi5jbXAtY29tcG9uZW50cy1idXR0b24uaXMtcHJpbWFyeVwiKTtcbiAgICBpZiAoYWNjZXB0QnV0dG9uKSB7XG4gICAgICBhY2NlcHRCdXR0b24uY2xpY2soKTtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbn07XG5cbi8vIGxpYi9jbXBzL2FkbWlyYWwudHNcbnZhciBBZG1pcmFsID0gY2xhc3MgZXh0ZW5kcyBBdXRvQ29uc2VudENNUEJhc2Uge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlciguLi5hcmd1bWVudHMpO1xuICAgIHRoaXMubmFtZSA9IFwiQWRtaXJhbFwiO1xuICB9XG4gIGdldCBoYXNTZWxmVGVzdCgpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgZ2V0IGlzSW50ZXJtZWRpYXRlKCkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBnZXQgaXNDb3NtZXRpYygpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgYXN5bmMgZGV0ZWN0Q21wKCkge1xuICAgIHJldHVybiB0aGlzLmVsZW1lbnRFeGlzdHMoXCJkaXYgPiBkaXZbY2xhc3MqPUNhcmRdID4gZGl2W2NsYXNzKj1GcmFtZV0gPiBkaXZbY2xhc3MqPVBpbGxzXSA+IGJ1dHRvbltjbGFzcyo9UGlsbHNfX1N0eWxlZFBpbGxdXCIpO1xuICB9XG4gIGFzeW5jIGRldGVjdFBvcHVwKCkge1xuICAgIHJldHVybiB0aGlzLmVsZW1lbnRWaXNpYmxlKFxuICAgICAgXCJkaXYgPiBkaXZbY2xhc3MqPUNhcmRdID4gZGl2W2NsYXNzKj1GcmFtZV0gPiBkaXZbY2xhc3MqPVBpbGxzXSA+IGJ1dHRvbltjbGFzcyo9UGlsbHNfX1N0eWxlZFBpbGxdXCIsXG4gICAgICBcImFueVwiXG4gICAgKTtcbiAgfVxuICBhc3luYyBvcHRPdXQoKSB7XG4gICAgY29uc3QgcmVqZWN0QWxsU2VsZWN0b3IgPSBcInhwYXRoLy8vYnV0dG9uW2NvbnRhaW5zKC4sICdBZnZpcyBhbGxlJykgb3IgY29udGFpbnMoLiwgJ1JlamVjdCBhbGwnKSBvciBjb250YWlucyguLCAnT2RiYWNpIHN2ZScpIG9yIGNvbnRhaW5zKC4sICdSZWNoYXphciB0b2RvJykgb3IgY29udGFpbnMoLiwgJ0F0bWVzdGkgdmlzdXMnKSBvciBjb250YWlucyguLCAnT2RtXFx4RUR0bm91dCB2XFx1MDE2MWUnKSBvciBjb250YWlucyguLCAnXFx1MDM5MVxcdTAzQzBcXHUwM0NDXFx1MDNDMVxcdTAzQzFcXHUwM0I5XFx1MDNDOFxcdTAzQjcgXFx1MDNDQ1xcdTAzQkJcXHUwM0M5XFx1MDNCRCcpIG9yIGNvbnRhaW5zKC4sICdSZWplaXRhciB0dWRvJykgb3IgY29udGFpbnMoLiwgJ1RcXHhGQ21cXHhGQ25cXHhGQyByZWRkZXQnKSBvciBjb250YWlucyguLCAnXFx1MDQxRVxcdTA0NDJcXHUwNDNBXFx1MDQzQlxcdTA0M0VcXHUwNDNEXFx1MDQzOFxcdTA0NDJcXHUwNDRDIFxcdTA0MzJcXHUwNDQxXFx1MDQzNScpIG9yIGNvbnRhaW5zKC4sICdOb3JhaWRcXHUwMTJCdCB2aXN1Jykgb3IgY29udGFpbnMoLiwgJ0F2dmlzYSBhbGxhJykgb3IgY29udGFpbnMoLiwgJ09kcnp1XFx1MDEwNyB3c3p5c3RraWUnKSBvciBjb250YWlucyguLCAnQWxsZXMgYWZ3aWp6ZW4nKSBvciBjb250YWlucyguLCAnXFx1MDQxRVxcdTA0NDJcXHUwNDQ1XFx1MDQzMlxcdTA0NEFcXHUwNDQwXFx1MDQzQlxcdTA0NEZcXHUwNDNEXFx1MDQzNSBcXHUwNDNEXFx1MDQzMCBcXHUwNDMyXFx1MDQ0MVxcdTA0MzhcXHUwNDQ3XFx1MDQzQVxcdTA0MzgnKSBvciBjb250YWlucyguLCAnUmlmaXV0YSB0dXR0bycpIG9yIGNvbnRhaW5zKC4sICdaYXZybmkgdnNlJykgb3IgY29udGFpbnMoLiwgJ0F6IFxceEY2c3N6ZXMgZWx1dGFzXFx4RUR0XFx4RTFzYScpIG9yIGNvbnRhaW5zKC4sICdSZXNwaW5nZVxcdTAyMUJpIHRvdCcpIG9yIGNvbnRhaW5zKC4sICdBbGxlcyBhYmxlaG5lbicpIG9yIGNvbnRhaW5zKC4sICdUb3V0IHJlamV0ZXInKSBvciBjb250YWlucyguLCAnT2RtaWV0bnVcXHUwMTY1IHZcXHUwMTYxZXRrbycpIG9yIGNvbnRhaW5zKC4sICdMXFx4RkNra2Ega1xceEY1aWsgdGFnYXNpJykgb3IgY29udGFpbnMoLiwgJ0h5bGtcXHhFNFxceEU0IGthaWtraScpXVwiO1xuICAgIGlmIChhd2FpdCB0aGlzLndhaXRGb3JFbGVtZW50KHJlamVjdEFsbFNlbGVjdG9yLCA1MDApKSB7XG4gICAgICByZXR1cm4gYXdhaXQgdGhpcy5jbGljayhyZWplY3RBbGxTZWxlY3Rvcik7XG4gICAgfVxuICAgIGNvbnN0IHB1cnBvc2VzQnV0dG9uU2VsZWN0b3IgPSBcInhwYXRoLy8vYnV0dG9uW2NvbnRhaW5zKC4sICdad2Vja2UnKSBvciBjb250YWlucyguLCAnXFx1MDNBM1xcdTAzQkFcXHUwM0JGXFx1MDNDMFxcdTAzQkZcXHUwM0FGJykgb3IgY29udGFpbnMoLiwgJ1B1cnBvc2VzJykgb3IgY29udGFpbnMoLiwgJ1xcdTA0MjZcXHUwNDM1XFx1MDQzQlxcdTA0MzgnKSBvciBjb250YWlucyguLCAnRWVzbVxceEU0cmdpZCcpIG9yIGNvbnRhaW5zKC4sICdUaWtzbGFpJykgb3IgY29udGFpbnMoLiwgJ1N2cmhlJykgb3IgY29udGFpbnMoLiwgJ0NlbGUnKSBvciBjb250YWlucyguLCAnXFx4REFcXHUwMTBEZWx5Jykgb3IgY29udGFpbnMoLiwgJ0ZpbmFsaWRhZGVzJykgb3IgY29udGFpbnMoLiwgJ01cXHUwMTEzclxcdTAxMzdpJykgb3IgY29udGFpbnMoLiwgJ1Njb3B1cmknKSBvciBjb250YWlucyguLCAnRmluZXMnKSBvciBjb250YWlucyguLCAnXFx4QzRuZGFtXFx4RTVsJykgb3IgY29udGFpbnMoLiwgJ0ZpbmFsaXRcXHhFOXMnKSBvciBjb250YWlucyguLCAnRG9lbGVpbmRlbicpIG9yIGNvbnRhaW5zKC4sICdUYXJrb2l0dWtzZXQnKSBvciBjb250YWlucyguLCAnU2NvcGknKSBvciBjb250YWlucyguLCAnQW1hXFx4RTdsYXInKSBvciBjb250YWlucyguLCAnTmFtZW5pJykgb3IgY29udGFpbnMoLiwgJ0NcXHhFOWxvaycpIG9yIGNvbnRhaW5zKC4sICdGb3JtXFx4RTVsJyldXCI7XG4gICAgY29uc3Qgc2F2ZUFuZEV4aXRTZWxlY3RvciA9IFwieHBhdGgvLy9idXR0b25bY29udGFpbnMoLiwgJ1NwYXJhICYgYXZzbHV0YScpIG9yIGNvbnRhaW5zKC4sICdTYXZlICYgZXhpdCcpIG9yIGNvbnRhaW5zKC4sICdVbG9cXHUwMTdFaXQgYSB1a29uXFx1MDEwRGl0Jykgb3IgY29udGFpbnMoLiwgJ0VucmVnaXN0cmVyIGV0IHF1aXR0ZXInKSBvciBjb250YWlucyguLCAnU3BlaWNoZXJuICYgVmVybGFzc2VuJykgb3IgY29udGFpbnMoLiwgJ1RhbGxlbm5hIGphIHBvaXN0dScpIG9yIGNvbnRhaW5zKC4sICdJXFx1MDE2MXNhdWdvdGkgaXIgaVxcdTAxNjFlaXRpJykgb3IgY29udGFpbnMoLiwgJ09wc2xhYW4gJiBhZnNsdWl0ZW4nKSBvciBjb250YWlucyguLCAnR3VhcmRhciB5IHNhbGlyJykgb3IgY29udGFpbnMoLiwgJ1NocmFuaSBpbiB6YXByaScpIG9yIGNvbnRhaW5zKC4sICdVbG9cXHUwMTdFaVxcdTAxNjUgYSB1a29uXFx1MDEwRGlcXHUwMTY1Jykgb3IgY29udGFpbnMoLiwgJ0theWRldCB2ZSBcXHhFN1xcdTAxMzFrXFx1MDEzMVxcdTAxNUYgeWFwJykgb3IgY29udGFpbnMoLiwgJ1xcdTA0MjFcXHUwNDNFXFx1MDQ0NVxcdTA0NDBcXHUwNDMwXFx1MDQzRFxcdTA0MzhcXHUwNDQyXFx1MDQ0QyBcXHUwNDM4IFxcdTA0MzJcXHUwNDRCXFx1MDQzOVxcdTA0NDJcXHUwNDM4Jykgb3IgY29udGFpbnMoLiwgJ1NhbHZlc3RhIGphIHZcXHhFNGxqdScpIG9yIGNvbnRhaW5zKC4sICdTYWx2YSBlZCBlc2NpJykgb3IgY29udGFpbnMoLiwgJ0dlbSAmIGFmc2x1dCcpIG9yIGNvbnRhaW5zKC4sICdcXHUwMzkxXFx1MDNDMFxcdTAzQkZcXHUwM0I4XFx1MDNBRVxcdTAzQkFcXHUwM0I1XFx1MDNDNVxcdTAzQzNcXHUwM0I3IFxcdTAzQkFcXHUwM0IxXFx1MDNCOSBcXHUwM0FEXFx1MDNCRVxcdTAzQkZcXHUwM0I0XFx1MDNCRlxcdTAzQzInKSBvciBjb250YWlucyguLCAnU2FnbGFiXFx1MDEwMXQgdW4gaXppZXQnKSBvciBjb250YWlucyguLCAnTWVudFxceEU5cyBcXHhFOXMga2lsXFx4RTlwXFx4RTlzJykgb3IgY29udGFpbnMoLiwgJ0d1YXJkYXIgZSBzYWlyJykgb3IgY29udGFpbnMoLiwgJ1phcGlzeiAmIHpha29cXHUwMTQ0Y3onKSBvciBjb250YWlucyguLCAnU2FsdmFyZSBcXHUwMjE5aSBpZVxcdTAyMTlpcmUnKSBvciBjb250YWlucyguLCAnU3ByZW1pIGkgaXphXFx1MDExMWknKSBvciBjb250YWlucyguLCAnXFx1MDQxN1xcdTA0MzBcXHUwNDNGXFx1MDQzMFxcdTA0MzdcXHUwNDMyXFx1MDQzMFxcdTA0M0RcXHUwNDM1IFxcdTA0MzggXFx1MDQzOFxcdTA0MzdcXHUwNDQ1XFx1MDQzRVxcdTA0MzQnKV1cIjtcbiAgICBpZiAoYXdhaXQgdGhpcy53YWl0Rm9yVGhlbkNsaWNrKHB1cnBvc2VzQnV0dG9uU2VsZWN0b3IpICYmIGF3YWl0IHRoaXMud2FpdEZvclZpc2libGUoc2F2ZUFuZEV4aXRTZWxlY3RvcikpIHtcbiAgICAgIGNvbnN0IHBvcHVwQm9keSA9IHRoaXMuZWxlbWVudFNlbGVjdG9yKHNhdmVBbmRFeGl0U2VsZWN0b3IpWzBdLnBhcmVudEVsZW1lbnQ/LnBhcmVudEVsZW1lbnQ7XG4gICAgICBjb25zdCBjaGVja2JveGVzID0gcG9wdXBCb2R5Py5xdWVyeVNlbGVjdG9yQWxsKFwiaW5wdXRbdHlwZT1jaGVja2JveF06Y2hlY2tlZFwiKTtcbiAgICAgIGNoZWNrYm94ZXM/LmZvckVhY2goKGNoZWNrYm94KSA9PiBjaGVja2JveC5jbGljaygpKTtcbiAgICAgIHJldHVybiBhd2FpdCB0aGlzLmNsaWNrKHNhdmVBbmRFeGl0U2VsZWN0b3IpO1xuICAgIH1cbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgYXN5bmMgb3B0SW4oKSB7XG4gICAgcmV0dXJuIGF3YWl0IHRoaXMuY2xpY2soXG4gICAgICBcInhwYXRoLy8vYnV0dG9uW2NvbnRhaW5zKC4sICdTcHJlam1pIHZzZScpIG9yIGNvbnRhaW5zKC4sICdQcmlodmF0aSBzdmUnKSBvciBjb250YWlucyguLCAnR29ka1xceEU0bm4gYWxsYScpIG9yIGNvbnRhaW5zKC4sICdQcmlqYVxcdTAxNjUgdlxcdTAxNjFldGtvJykgb3IgY29udGFpbnMoLiwgJ1xcdTA0MUZcXHUwNDQwXFx1MDQzOFxcdTA0M0RcXHUwNDRGXFx1MDQ0MlxcdTA0NEMgXFx1MDQzMlxcdTA0NDFcXHUwNDM1Jykgb3IgY29udGFpbnMoLiwgJ0FjZXB0YXIgdG9kbycpIG9yIGNvbnRhaW5zKC4sICdcXHUwMzkxXFx1MDNDMFxcdTAzQkZcXHUwM0I0XFx1MDNCRlxcdTAzQzdcXHUwM0FFIFxcdTAzQ0NcXHUwM0JCXFx1MDNDOVxcdTAzQkQnKSBvciBjb250YWlucyguLCAnWmFha2NlcHR1aiB3c3p5c3RraWUnKSBvciBjb250YWlucyguLCAnQWNjZXR0YSB0dXR0bycpIG9yIGNvbnRhaW5zKC4sICdQcmlpbXRpIHZpc3VzJykgb3IgY29udGFpbnMoLiwgJ1BpZVxcdTAxNDZlbXQgdmlzdScpIG9yIGNvbnRhaW5zKC4sICdUXFx4RkNtXFx4RkNuXFx4RkMga2FidWwgZXQnKSBvciBjb250YWlucyguLCAnQXogXFx4RjZzc3plcyBlbGZvZ2FkXFx4RTFzYScpIG9yIGNvbnRhaW5zKC4sICdBY2NlcHQgYWxsJykgb3IgY29udGFpbnMoLiwgJ1xcdTA0MUZcXHUwNDQwXFx1MDQzOFxcdTA0MzVcXHUwNDNDXFx1MDQzMFxcdTA0M0RcXHUwNDM1IFxcdTA0M0RcXHUwNDMwIFxcdTA0MzJcXHUwNDQxXFx1MDQzOFxcdTA0NDdcXHUwNDNBXFx1MDQzOCcpIG9yIGNvbnRhaW5zKC4sICdBY2NlcHRlciBhbGxlJykgb3IgY29udGFpbnMoLiwgJ0h5dlxceEU0a3N5IGthaWtraScpIG9yIGNvbnRhaW5zKC4sICdUb3V0IGFjY2VwdGVyJykgb3IgY29udGFpbnMoLiwgJ0FsbGVzIGFjY2VwdGVyZW4nKSBvciBjb250YWlucyguLCAnQWt0c2VwdGVlcmkga1xceEY1aWsnKSBvciBjb250YWlucyguLCAnUFxcdTAxNTlpam1vdXQgdlxcdTAxNjFlJykgb3IgY29udGFpbnMoLiwgJ0FsbGVzIGFremVwdGllcmVuJykgb3IgY29udGFpbnMoLiwgJ0FjZWl0YXIgdHVkbycpIG9yIGNvbnRhaW5zKC4sICdBY2NlcHRhXFx1MDIxQmkgdG90JyldXCJcbiAgICApO1xuICB9XG59O1xuXG4vLyBsaWIvY21wcy9hbGwudHNcbnZhciBkeW5hbWljQ01QcyA9IFtcbiAgVHJ1c3RBcmNUb3AsXG4gIFRydXN0QXJjRnJhbWUsXG4gIENvb2tpZWJvdCxcbiAgU291cmNlUG9pbnQsXG4gIENvbnNlbnRNYW5hZ2VyLFxuICBFdmlkb24sXG4gIE9uZXRydXN0LFxuICBLbGFybyxcbiAgVW5pY29uc2VudCxcbiAgQ29udmVyc2FudCxcbiAgVGlrdG9rLFxuICBUdW1ibHIsXG4gIEFkbWlyYWxcbl07XG5cbi8vIGxpYi9kb20tYWN0aW9ucy50c1xudmFyIERvbUFjdGlvbnMgPSBjbGFzcyB7XG4gIGNvbnN0cnVjdG9yKGF1dG9jb25zZW50SW5zdGFuY2UpIHtcbiAgICB0aGlzLmF1dG9jb25zZW50SW5zdGFuY2UgPSBhdXRvY29uc2VudEluc3RhbmNlO1xuICB9XG4gIGFzeW5jIGNsaWNrRWxlbWVudChlbGVtZW50KSB7XG4gICAgaWYgKCFlbGVtZW50IHx8ICEoZWxlbWVudCBpbnN0YW5jZW9mIEhUTUxFbGVtZW50KSkge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICB0aGlzLmF1dG9jb25zZW50SW5zdGFuY2UuY29uZmlnLmxvZ3MucnVsZXN0ZXBzICYmIGNvbnNvbGUubG9nKFwiW2NsaWNrRWxlbWVudF1cIiwgZWxlbWVudCk7XG4gICAgZWxlbWVudC5jbGljaygpO1xuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIGFzeW5jIGNsaWNrKHNlbGVjdG9yLCBhbGwgPSBmYWxzZSkge1xuICAgIGNvbnN0IGVsZW1lbnRzID0gdGhpcy5lbGVtZW50U2VsZWN0b3Ioc2VsZWN0b3IpO1xuICAgIHRoaXMuYXV0b2NvbnNlbnRJbnN0YW5jZS5jb25maWcubG9ncy5ydWxlc3RlcHMgJiYgY29uc29sZS5sb2coXCJbY2xpY2tdXCIsIHNlbGVjdG9yLCBhbGwsIGVsZW1lbnRzKTtcbiAgICBpZiAoZWxlbWVudHMubGVuZ3RoID4gMCkge1xuICAgICAgaWYgKGFsbCkge1xuICAgICAgICBlbGVtZW50cy5mb3JFYWNoKChlKSA9PiBlLmNsaWNrKCkpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgZWxlbWVudHNbMF0uY2xpY2soKTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIGVsZW1lbnRzLmxlbmd0aCA+IDA7XG4gIH1cbiAgZWxlbWVudEV4aXN0cyhzZWxlY3Rvcikge1xuICAgIGNvbnN0IGV4aXN0cyA9IHRoaXMuZWxlbWVudFNlbGVjdG9yKHNlbGVjdG9yKS5sZW5ndGggPiAwO1xuICAgIHJldHVybiBleGlzdHM7XG4gIH1cbiAgZWxlbWVudFZpc2libGUoc2VsZWN0b3IsIGNoZWNrID0gXCJhbGxcIikge1xuICAgIGNvbnN0IGVsZW0gPSB0aGlzLmVsZW1lbnRTZWxlY3RvcihzZWxlY3Rvcik7XG4gICAgY29uc3QgcmVzdWx0cyA9IG5ldyBBcnJheShlbGVtLmxlbmd0aCk7XG4gICAgZWxlbS5mb3JFYWNoKChlLCBpKSA9PiB7XG4gICAgICByZXN1bHRzW2ldID0gaXNFbGVtZW50VmlzaWJsZShlKTtcbiAgICB9KTtcbiAgICBpZiAoY2hlY2sgPT09IFwibm9uZVwiKSB7XG4gICAgICByZXR1cm4gcmVzdWx0cy5ldmVyeSgocikgPT4gIXIpO1xuICAgIH0gZWxzZSBpZiAocmVzdWx0cy5sZW5ndGggPT09IDApIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9IGVsc2UgaWYgKGNoZWNrID09PSBcImFueVwiKSB7XG4gICAgICByZXR1cm4gcmVzdWx0cy5zb21lKChyKSA9PiByKTtcbiAgICB9XG4gICAgcmV0dXJuIHJlc3VsdHMuZXZlcnkoKHIpID0+IHIpO1xuICB9XG4gIHdhaXRGb3JFbGVtZW50KHNlbGVjdG9yLCB0aW1lb3V0ID0gMWU0KSB7XG4gICAgY29uc3QgaW50ZXJ2YWwgPSAyMDA7XG4gICAgY29uc3QgdGltZXMgPSBNYXRoLmNlaWwodGltZW91dCAvIGludGVydmFsKTtcbiAgICB0aGlzLmF1dG9jb25zZW50SW5zdGFuY2UuY29uZmlnLmxvZ3MucnVsZXN0ZXBzICYmIGNvbnNvbGUubG9nKFwiW3dhaXRGb3JFbGVtZW50XVwiLCBzZWxlY3Rvcik7XG4gICAgcmV0dXJuIHdhaXRGb3IoKCkgPT4gdGhpcy5lbGVtZW50U2VsZWN0b3Ioc2VsZWN0b3IpLmxlbmd0aCA+IDAsIHRpbWVzLCBpbnRlcnZhbCk7XG4gIH1cbiAgd2FpdEZvclZpc2libGUoc2VsZWN0b3IsIHRpbWVvdXQgPSAxZTQsIGNoZWNrID0gXCJhbnlcIikge1xuICAgIGNvbnN0IGludGVydmFsID0gMjAwO1xuICAgIGNvbnN0IHRpbWVzID0gTWF0aC5jZWlsKHRpbWVvdXQgLyBpbnRlcnZhbCk7XG4gICAgdGhpcy5hdXRvY29uc2VudEluc3RhbmNlLmNvbmZpZy5sb2dzLnJ1bGVzdGVwcyAmJiBjb25zb2xlLmxvZyhcIlt3YWl0Rm9yVmlzaWJsZV1cIiwgc2VsZWN0b3IpO1xuICAgIHJldHVybiB3YWl0Rm9yKCgpID0+IHRoaXMuZWxlbWVudFZpc2libGUoc2VsZWN0b3IsIGNoZWNrKSwgdGltZXMsIGludGVydmFsKTtcbiAgfVxuICBhc3luYyB3YWl0Rm9yVGhlbkNsaWNrKHNlbGVjdG9yLCB0aW1lb3V0ID0gMWU0LCBhbGwgPSBmYWxzZSkge1xuICAgIGF3YWl0IHRoaXMud2FpdEZvckVsZW1lbnQoc2VsZWN0b3IsIHRpbWVvdXQpO1xuICAgIHJldHVybiBhd2FpdCB0aGlzLmNsaWNrKHNlbGVjdG9yLCBhbGwpO1xuICB9XG4gIHdhaXQobXMpIHtcbiAgICB0aGlzLmF1dG9jb25zZW50SW5zdGFuY2UuY29uZmlnLmxvZ3MucnVsZXN0ZXBzICYmIHRoaXMuYXV0b2NvbnNlbnRJbnN0YW5jZS5jb25maWcubG9ncy53YWl0cyAmJiBjb25zb2xlLmxvZyhcIlt3YWl0XVwiLCBtcyk7XG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgcmVzb2x2ZSh0cnVlKTtcbiAgICAgIH0sIG1zKTtcbiAgICB9KTtcbiAgfVxuICBjb29raWVDb250YWlucyhzdWJzdHJpbmcpIHtcbiAgICByZXR1cm4gZG9jdW1lbnQuY29va2llLmluY2x1ZGVzKHN1YnN0cmluZyk7XG4gIH1cbiAgaGlkZShzZWxlY3RvciwgbWV0aG9kKSB7XG4gICAgdGhpcy5hdXRvY29uc2VudEluc3RhbmNlLmNvbmZpZy5sb2dzLnJ1bGVzdGVwcyAmJiBjb25zb2xlLmxvZyhcIltoaWRlXVwiLCBzZWxlY3Rvcik7XG4gICAgY29uc3Qgc3R5bGVFbCA9IGdldFN0eWxlRWxlbWVudCgpO1xuICAgIHJldHVybiBoaWRlRWxlbWVudHMoc3R5bGVFbCwgc2VsZWN0b3IsIG1ldGhvZCk7XG4gIH1cbiAgcHJlaGlkZShzZWxlY3Rvcikge1xuICAgIGNvbnN0IHN0eWxlRWwgPSBnZXRTdHlsZUVsZW1lbnQoXCJhdXRvY29uc2VudC1wcmVoaWRlXCIpO1xuICAgIHRoaXMuYXV0b2NvbnNlbnRJbnN0YW5jZS5jb25maWcubG9ncy5saWZlY3ljbGUgJiYgY29uc29sZS5sb2coXCJbcHJlaGlkZV1cIiwgc3R5bGVFbCwgbG9jYXRpb24uaHJlZik7XG4gICAgcmV0dXJuIGhpZGVFbGVtZW50cyhzdHlsZUVsLCBzZWxlY3RvciwgXCJvcGFjaXR5XCIpO1xuICB9XG4gIHVuZG9QcmVoaWRlKCkge1xuICAgIGNvbnN0IGV4aXN0aW5nRWxlbWVudCA9IGdldFN0eWxlRWxlbWVudChcImF1dG9jb25zZW50LXByZWhpZGVcIik7XG4gICAgdGhpcy5hdXRvY29uc2VudEluc3RhbmNlLmNvbmZpZy5sb2dzLmxpZmVjeWNsZSAmJiBjb25zb2xlLmxvZyhcIlt1bmRvcHJlaGlkZV1cIiwgZXhpc3RpbmdFbGVtZW50LCBsb2NhdGlvbi5ocmVmKTtcbiAgICBleGlzdGluZ0VsZW1lbnQucmVtb3ZlKCk7XG4gIH1cbiAgYXN5bmMgY3JlYXRlT3JVcGRhdGVTdHlsZVNoZWV0KGNzc1RleHQsIHN0eWxlU2hlZXQpIHtcbiAgICBpZiAoIXN0eWxlU2hlZXQpIHtcbiAgICAgIHN0eWxlU2hlZXQgPSBuZXcgQ1NTU3R5bGVTaGVldCgpO1xuICAgIH1cbiAgICBzdHlsZVNoZWV0ID0gYXdhaXQgc3R5bGVTaGVldC5yZXBsYWNlKGNzc1RleHQpO1xuICAgIHJldHVybiBzdHlsZVNoZWV0O1xuICB9XG4gIHJlbW92ZVN0eWxlU2hlZXQoc3R5bGVTaGVldCkge1xuICAgIGlmIChzdHlsZVNoZWV0KSB7XG4gICAgICBzdHlsZVNoZWV0LnJlcGxhY2UoXCJcIik7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIHF1ZXJ5U2luZ2xlUmVwbHlTZWxlY3RvcihzZWxlY3RvciwgcGFyZW50ID0gZG9jdW1lbnQpIHtcbiAgICBpZiAoc2VsZWN0b3Iuc3RhcnRzV2l0aChcImFyaWEvXCIpKSB7XG4gICAgICByZXR1cm4gW107XG4gICAgfVxuICAgIGlmIChzZWxlY3Rvci5zdGFydHNXaXRoKFwieHBhdGgvXCIpKSB7XG4gICAgICBjb25zdCB4cGF0aCA9IHNlbGVjdG9yLnNsaWNlKDYpO1xuICAgICAgY29uc3QgcmVzdWx0ID0gZG9jdW1lbnQuZXZhbHVhdGUoeHBhdGgsIHBhcmVudCwgbnVsbCwgWFBhdGhSZXN1bHQuQU5ZX1RZUEUsIG51bGwpO1xuICAgICAgbGV0IG5vZGUgPSBudWxsO1xuICAgICAgY29uc3QgZWxlbWVudHMgPSBbXTtcbiAgICAgIHdoaWxlIChub2RlID0gcmVzdWx0Lml0ZXJhdGVOZXh0KCkpIHtcbiAgICAgICAgZWxlbWVudHMucHVzaChub2RlKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBlbGVtZW50cztcbiAgICB9XG4gICAgaWYgKHNlbGVjdG9yLnN0YXJ0c1dpdGgoXCJ0ZXh0L1wiKSkge1xuICAgICAgcmV0dXJuIFtdO1xuICAgIH1cbiAgICBpZiAoc2VsZWN0b3Iuc3RhcnRzV2l0aChcInBpZXJjZS9cIikpIHtcbiAgICAgIHJldHVybiBbXTtcbiAgICB9XG4gICAgaWYgKHBhcmVudC5zaGFkb3dSb290KSB7XG4gICAgICByZXR1cm4gQXJyYXkuZnJvbShwYXJlbnQuc2hhZG93Um9vdC5xdWVyeVNlbGVjdG9yQWxsKHNlbGVjdG9yKSk7XG4gICAgfVxuICAgIGlmIChwYXJlbnQuY29udGVudERvY3VtZW50Py5xdWVyeVNlbGVjdG9yQWxsKSB7XG4gICAgICByZXR1cm4gQXJyYXkuZnJvbShwYXJlbnQuY29udGVudERvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoc2VsZWN0b3IpKTtcbiAgICB9XG4gICAgcmV0dXJuIEFycmF5LmZyb20ocGFyZW50LnF1ZXJ5U2VsZWN0b3JBbGwoc2VsZWN0b3IpKTtcbiAgfVxuICBxdWVyeVNlbGVjdG9yQ2hhaW4oc2VsZWN0b3JzKSB7XG4gICAgbGV0IHBhcmVudCA9IGRvY3VtZW50O1xuICAgIGxldCBtYXRjaGVzMiA9IFtdO1xuICAgIGZvciAoY29uc3Qgc2VsZWN0b3Igb2Ygc2VsZWN0b3JzKSB7XG4gICAgICBtYXRjaGVzMiA9IHRoaXMucXVlcnlTaW5nbGVSZXBseVNlbGVjdG9yKHNlbGVjdG9yLCBwYXJlbnQpO1xuICAgICAgaWYgKG1hdGNoZXMyLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICByZXR1cm4gW107XG4gICAgICB9XG4gICAgICBwYXJlbnQgPSBtYXRjaGVzMlswXTtcbiAgICB9XG4gICAgcmV0dXJuIG1hdGNoZXMyO1xuICB9XG4gIGVsZW1lbnRTZWxlY3RvcihzZWxlY3Rvcikge1xuICAgIGlmICh0eXBlb2Ygc2VsZWN0b3IgPT09IFwic3RyaW5nXCIpIHtcbiAgICAgIHJldHVybiB0aGlzLnF1ZXJ5U2luZ2xlUmVwbHlTZWxlY3RvcihzZWxlY3Rvcik7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLnF1ZXJ5U2VsZWN0b3JDaGFpbihzZWxlY3Rvcik7XG4gIH1cbiAgd2FpdEZvck11dGF0aW9uKHNlbGVjdG9yLCB0aW1lb3V0ID0gNmU0KSB7XG4gICAgY29uc3Qgbm9kZSA9IHRoaXMuZWxlbWVudFNlbGVjdG9yKHNlbGVjdG9yKTtcbiAgICBpZiAobm9kZS5sZW5ndGggPT09IDApIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihgJHtzZWxlY3Rvcn0gZGlkIG5vdCBtYXRjaCBhbnkgZWxlbWVudHNgKTtcbiAgICB9XG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgIGNvbnN0IHRpbWVyID0gc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgIHJlamVjdChuZXcgRXJyb3IoXCJUaW1lZCBvdXQgd2FpdGluZyBmb3IgbXV0YXRpb25cIikpO1xuICAgICAgICBvYnNlcnZlci5kaXNjb25uZWN0KCk7XG4gICAgICB9LCB0aW1lb3V0KTtcbiAgICAgIGNvbnN0IG9ic2VydmVyID0gbmV3IE11dGF0aW9uT2JzZXJ2ZXIoKCkgPT4ge1xuICAgICAgICBjbGVhclRpbWVvdXQodGltZXIpO1xuICAgICAgICBvYnNlcnZlci5kaXNjb25uZWN0KCk7XG4gICAgICAgIHJlc29sdmUodHJ1ZSk7XG4gICAgICB9KTtcbiAgICAgIG9ic2VydmVyLm9ic2VydmUobm9kZVswXSwge1xuICAgICAgICBzdWJ0cmVlOiB0cnVlLFxuICAgICAgICBjaGlsZExpc3Q6IHRydWUsXG4gICAgICAgIGF0dHJpYnV0ZXM6IHRydWVcbiAgICAgIH0pO1xuICAgIH0pO1xuICB9XG59O1xuXG4vLyBsaWIvZW5jb2RpbmcudHNcbnZhciBjb21wYWN0ZWRSdWxlU3RlcHMgPSBbXG4gIFtcImV4aXN0c1wiLCBcImVcIl0sXG4gIFtcInZpc2libGVcIiwgXCJ2XCJdLFxuICBbXCJ3YWl0Rm9yVGhlbkNsaWNrXCIsIFwiY1wiXSxcbiAgW1wiY2xpY2tcIiwgXCJrXCJdLFxuICBbXCJ3YWl0Rm9yXCIsIFwid1wiXSxcbiAgW1wid2FpdEZvclZpc2libGVcIiwgXCJ3dlwiXSxcbiAgW1wiaGlkZVwiLCBcImhcIl0sXG4gIFtcImNvb2tpZUNvbnRhaW5zXCIsIFwiY2NcIl1cbl07XG5mdW5jdGlvbiBlbmNvZGVOdWxsYWJsZUJvb2xlYW4odmFsdWUpIHtcbiAgaWYgKHZhbHVlID09PSB0cnVlKSB7XG4gICAgcmV0dXJuIDE7XG4gIH1cbiAgaWYgKHZhbHVlID09PSBmYWxzZSkge1xuICAgIHJldHVybiAwO1xuICB9XG4gIHJldHVybiAyO1xufVxuZnVuY3Rpb24gZGVjb2RlTnVsbGFibGVCb29sZWFuKHZhbHVlKSB7XG4gIGlmICh2YWx1ZSA9PT0gMSkge1xuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIGlmICh2YWx1ZSA9PT0gMCkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICByZXR1cm4gdm9pZCAwO1xufVxuZnVuY3Rpb24gYnVpbGRTdHJpbmdzKGV4aXN0aW5nU3RyaW5ncywgcnVsZXMpIHtcbiAgY29uc3QgdXNlZFN0cmluZ3MgPSAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpO1xuICBmdW5jdGlvbiBjb2xsZWN0U3RyaW5ncyhzdGVwKSB7XG4gICAgZm9yIChjb25zdCBbbG9uZ0tleV0gb2YgY29tcGFjdGVkUnVsZVN0ZXBzKSB7XG4gICAgICBpZiAoc3RlcFtsb25nS2V5XSAmJiB0eXBlb2Ygc3RlcFtsb25nS2V5XSA9PT0gXCJzdHJpbmdcIikge1xuICAgICAgICB1c2VkU3RyaW5ncy5hZGQoc3RlcFtsb25nS2V5XSk7XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChzdGVwLmlmKSB7XG4gICAgICBjb2xsZWN0U3RyaW5ncyhzdGVwLmlmKTtcbiAgICAgIHN0ZXAudGhlbj8uZm9yRWFjaChjb2xsZWN0U3RyaW5ncyk7XG4gICAgICBzdGVwLmVsc2U/LmZvckVhY2goY29sbGVjdFN0cmluZ3MpO1xuICAgIH1cbiAgICBpZiAoc3RlcC5hbnkpIHtcbiAgICAgIHN0ZXAuYW55LmZvckVhY2goY29sbGVjdFN0cmluZ3MpO1xuICAgIH1cbiAgfVxuICBydWxlcy5mb3JFYWNoKChydWxlKSA9PiB7XG4gICAgKHJ1bGUucHJlaGlkZVNlbGVjdG9ycyB8fCBbXSkuZm9yRWFjaCgoc2VsZWN0b3IpID0+IHVzZWRTdHJpbmdzLmFkZChzZWxlY3RvcikpO1xuICAgIHJ1bGUuZGV0ZWN0Q21wLmZvckVhY2goY29sbGVjdFN0cmluZ3MpO1xuICAgIHJ1bGUuZGV0ZWN0UG9wdXAuZm9yRWFjaChjb2xsZWN0U3RyaW5ncyk7XG4gICAgcnVsZS5vcHRPdXQuZm9yRWFjaChjb2xsZWN0U3RyaW5ncyk7XG4gICAgKHJ1bGUudGVzdCB8fCBbXSkuZm9yRWFjaChjb2xsZWN0U3RyaW5ncyk7XG4gIH0pO1xuICBjb25zdCBzdHJpbmdzID0gbmV3IEFycmF5KHVzZWRTdHJpbmdzLnNpemUpLmZpbGwodm9pZCAwKTtcbiAgZXhpc3RpbmdTdHJpbmdzLnNsaWNlKDAsIHVzZWRTdHJpbmdzLnNpemUpLmZvckVhY2goKHMsIGkpID0+IHtcbiAgICBpZiAodXNlZFN0cmluZ3MuaGFzKHMpKSB7XG4gICAgICBzdHJpbmdzW2ldID0gcztcbiAgICAgIHVzZWRTdHJpbmdzLmRlbGV0ZShzKTtcbiAgICB9XG4gIH0pO1xuICB1c2VkU3RyaW5ncy5mb3JFYWNoKChzKSA9PiB7XG4gICAgaWYgKHN0cmluZ3MuaW5kZXhPZihzKSA9PT0gLTEpIHtcbiAgICAgIGNvbnN0IG5leHRGcmVlU2xvdCA9IHN0cmluZ3MuaW5kZXhPZih2b2lkIDApO1xuICAgICAgc3RyaW5nc1tuZXh0RnJlZVNsb3RdID0gcztcbiAgICB9XG4gIH0pO1xuICByZXR1cm4gc3RyaW5ncztcbn1cbmZ1bmN0aW9uIGVuY29kZVJ1bGVzKHJ1bGVzLCBleGlzdGluZ0NvbXBhY3RSdWxlcykge1xuICBydWxlcy5zb3J0KChhLCBiKSA9PiB7XG4gICAgY29uc3QgaXNHZW5lcmljID0gKHIpID0+ICFyLnJ1bkNvbnRleHQ/LnVybFBhdHRlcm47XG4gICAgY29uc3QgaXNGcmFtZSA9IChyKSA9PiByLnJ1bkNvbnRleHQ/LmZyYW1lID09PSB0cnVlO1xuICAgIGlmIChpc0dlbmVyaWMoYSkgJiYgIWlzR2VuZXJpYyhiKSkge1xuICAgICAgcmV0dXJuIC0xO1xuICAgIH1cbiAgICBpZiAoIWlzR2VuZXJpYyhhKSAmJiBpc0dlbmVyaWMoYikpIHtcbiAgICAgIHJldHVybiAxO1xuICAgIH1cbiAgICBpZiAoaXNHZW5lcmljKGEpICYmIGlzR2VuZXJpYyhiKSkge1xuICAgICAgaWYgKGlzRnJhbWUoYSkgJiYgIWlzRnJhbWUoYikpIHtcbiAgICAgICAgcmV0dXJuIDE7XG4gICAgICB9XG4gICAgICBpZiAoIWlzRnJhbWUoYSkgJiYgaXNGcmFtZShiKSkge1xuICAgICAgICByZXR1cm4gLTE7XG4gICAgICB9XG4gICAgfVxuICAgIGlmICghaXNHZW5lcmljKGEpICYmICFpc0dlbmVyaWMoYikpIHtcbiAgICAgIGlmIChpc0ZyYW1lKGEpICYmICFpc0ZyYW1lKGIpKSB7XG4gICAgICAgIHJldHVybiAtMTtcbiAgICAgIH1cbiAgICAgIGlmICghaXNGcmFtZShhKSAmJiBpc0ZyYW1lKGIpKSB7XG4gICAgICAgIHJldHVybiAxO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gYS5uYW1lLmxvY2FsZUNvbXBhcmUoYi5uYW1lKTtcbiAgfSk7XG4gIGxldCBnZW5lcmljUnVsZUVuZCA9IHJ1bGVzLmZpbmRJbmRleCgocikgPT4ge1xuICAgIHJldHVybiByLnJ1bkNvbnRleHQ/LnVybFBhdHRlcm47XG4gIH0pO1xuICBpZiAoZ2VuZXJpY1J1bGVFbmQgPT09IC0xKSB7XG4gICAgZ2VuZXJpY1J1bGVFbmQgPSBydWxlcy5sZW5ndGg7XG4gIH1cbiAgbGV0IGZyYW1lUnVsZVN0YXJ0ID0gcnVsZXMuZmluZEluZGV4KChyKSA9PiB7XG4gICAgcmV0dXJuIHIucnVuQ29udGV4dD8uZnJhbWUgPT09IHRydWU7XG4gIH0pO1xuICBpZiAoZnJhbWVSdWxlU3RhcnQgPT09IC0xKSB7XG4gICAgZnJhbWVSdWxlU3RhcnQgPSBnZW5lcmljUnVsZUVuZDtcbiAgfVxuICBsZXQgZnJhbWVSdWxlRW5kID0gcnVsZXMuZmluZEluZGV4KChyLCBpKSA9PiB7XG4gICAgcmV0dXJuICFyLnJ1bkNvbnRleHQ/LmZyYW1lICYmIGkgPj0gZnJhbWVSdWxlU3RhcnQ7XG4gIH0pO1xuICBpZiAoZnJhbWVSdWxlRW5kID09PSAtMSkge1xuICAgIGZyYW1lUnVsZUVuZCA9IHJ1bGVzLmxlbmd0aDtcbiAgfVxuICBjb25zdCBnZW5lcmljU3RyaW5ncyA9IGJ1aWxkU3RyaW5ncyhleGlzdGluZ0NvbXBhY3RSdWxlcz8ucyB8fCBbXSwgcnVsZXMuc2xpY2UoMCwgZ2VuZXJpY1J1bGVFbmQpKTtcbiAgY29uc3QgZnJhbWVTdHJpbmdzID0gYnVpbGRTdHJpbmdzKGdlbmVyaWNTdHJpbmdzLCBydWxlcy5zbGljZSgwLCBmcmFtZVJ1bGVFbmQpKTtcbiAgY29uc3Qgc3RyaW5ncyA9IGJ1aWxkU3RyaW5ncyhmcmFtZVN0cmluZ3MuY29uY2F0KGV4aXN0aW5nQ29tcGFjdFJ1bGVzPy5zLnNsaWNlKGZyYW1lU3RyaW5ncy5sZW5ndGgpIHx8IFtdKSwgcnVsZXMpO1xuICBmdW5jdGlvbiBlbmNvZGVSdWxlU3RlcChzdGVwKSB7XG4gICAgY29uc3QgY2xvbmVkU3RlcCA9IHsgLi4uc3RlcCB9O1xuICAgIGlmIChzdGVwLmNvbW1lbnQpIHtcbiAgICAgIGRlbGV0ZSBjbG9uZWRTdGVwLmNvbW1lbnQ7XG4gICAgfVxuICAgIGZvciAoY29uc3QgW2xvbmdLZXksIHNob3J0S2V5XSBvZiBjb21wYWN0ZWRSdWxlU3RlcHMpIHtcbiAgICAgIGlmIChjbG9uZWRTdGVwW2xvbmdLZXldICYmIHR5cGVvZiBjbG9uZWRTdGVwW2xvbmdLZXldID09PSBcInN0cmluZ1wiKSB7XG4gICAgICAgIGNsb25lZFN0ZXBbc2hvcnRLZXldID0gc3RyaW5ncy5pbmRleE9mKGNsb25lZFN0ZXBbbG9uZ0tleV0pO1xuICAgICAgICBkZWxldGUgY2xvbmVkU3RlcFtsb25nS2V5XTtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKHN0ZXAuaWYpIHtcbiAgICAgIGNsb25lZFN0ZXAuaWYgPSBlbmNvZGVSdWxlU3RlcChzdGVwLmlmKTtcbiAgICAgIGNsb25lZFN0ZXAudGhlbiA9IHN0ZXAudGhlbiAmJiBzdGVwLnRoZW4ubWFwKGVuY29kZVJ1bGVTdGVwKTtcbiAgICAgIGlmIChzdGVwLmVsc2UpIHtcbiAgICAgICAgY2xvbmVkU3RlcC5lbHNlID0gc3RlcC5lbHNlLm1hcChlbmNvZGVSdWxlU3RlcCk7XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChzdGVwLmFueSkge1xuICAgICAgY2xvbmVkU3RlcC5hbnkgPSBzdGVwLmFueS5tYXAoZW5jb2RlUnVsZVN0ZXApO1xuICAgIH1cbiAgICByZXR1cm4gY2xvbmVkU3RlcDtcbiAgfVxuICBjb25zdCBjb21wYWN0UnVsZXMgPSBydWxlcy5tYXAoKHIpID0+IHtcbiAgICByZXR1cm4gW1xuICAgICAgci5taW5pbXVtUnVsZVN0ZXBWZXJzaW9uIHx8IDEsXG4gICAgICByLm5hbWUsXG4gICAgICBlbmNvZGVOdWxsYWJsZUJvb2xlYW4oci5jb3NtZXRpYyksXG4gICAgICByLnJ1bkNvbnRleHQ/LnVybFBhdHRlcm4gfHwgXCJcIixcbiAgICAgIHBhcnNlSW50KGAke2VuY29kZU51bGxhYmxlQm9vbGVhbihyLnJ1bkNvbnRleHQ/Lm1haW4pfSR7ZW5jb2RlTnVsbGFibGVCb29sZWFuKHIucnVuQ29udGV4dD8uZnJhbWUpfWApLFxuICAgICAgKHIucHJlaGlkZVNlbGVjdG9ycyB8fCBbXSkubWFwKChzKSA9PiBzdHJpbmdzLmluZGV4T2YocykpLFxuICAgICAgci5kZXRlY3RDbXAubWFwKGVuY29kZVJ1bGVTdGVwKSxcbiAgICAgIHIuZGV0ZWN0UG9wdXAubWFwKGVuY29kZVJ1bGVTdGVwKSxcbiAgICAgIHIub3B0T3V0Lm1hcChlbmNvZGVSdWxlU3RlcCksXG4gICAgICAoci50ZXN0IHx8IFtdKS5tYXAoZW5jb2RlUnVsZVN0ZXApLFxuICAgICAgci5pbnRlcm1lZGlhdGUgIT09IHZvaWQgMCA/IHsgaW50ZXJtZWRpYXRlOiByLmludGVybWVkaWF0ZSB9IDoge31cbiAgICBdO1xuICB9KTtcbiAgcmV0dXJuIHtcbiAgICB2OiAxLFxuICAgIHM6IHN0cmluZ3MsXG4gICAgcjogY29tcGFjdFJ1bGVzLFxuICAgIGluZGV4OiB7XG4gICAgICBnZW5lcmljUnVsZVJhbmdlOiBbMCwgZ2VuZXJpY1J1bGVFbmRdLFxuICAgICAgZnJhbWVSdWxlUmFuZ2U6IFtmcmFtZVJ1bGVTdGFydCwgZnJhbWVSdWxlRW5kXSxcbiAgICAgIHNwZWNpZmljUnVsZVJhbmdlOiBbZ2VuZXJpY1J1bGVFbmQsIGNvbXBhY3RSdWxlcy5sZW5ndGhdLFxuICAgICAgZ2VuZXJpY1N0cmluZ0VuZDogZ2VuZXJpY1N0cmluZ3MubGVuZ3RoLFxuICAgICAgZnJhbWVTdHJpbmdFbmQ6IGZyYW1lU3RyaW5ncy5sZW5ndGhcbiAgICB9XG4gIH07XG59XG5mdW5jdGlvbiBkZWNvZGVSdWxlcyhlbmNvZGVkKSB7XG4gIGlmIChlbmNvZGVkLnYgPiAxKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFwiVW5zdXBwb3J0ZWQgcnVsZSBmb3JtYXQuXCIpO1xuICB9XG4gIHJldHVybiBlbmNvZGVkLnIuZmlsdGVyKChyKSA9PiByWzBdIDw9IFNVUFBPUlRFRF9SVUxFX1NURVBfVkVSU0lPTikubWFwKChydWxlKSA9PiBuZXcgQ29tcGFjdGVkQ01QUnVsZShydWxlLCBlbmNvZGVkLnMpKTtcbn1cbnZhciBDb21wYWN0ZWRDTVBSdWxlID0gY2xhc3Mge1xuICBjb25zdHJ1Y3RvcihydWxlLCBzdHJpbmdzKSB7XG4gICAgdGhpcy5pbnRlcm1lZGlhdGUgPSBmYWxzZTtcbiAgICB0aGlzLm9wdEluID0gW107XG4gICAgdGhpcy5yID0gcnVsZTtcbiAgICB0aGlzLnMgPSBzdHJpbmdzO1xuICAgIGlmICh0aGlzLnJbMTBdICYmIHRoaXMuclsxMF0uaW50ZXJtZWRpYXRlKSB7XG4gICAgICB0aGlzLmludGVybWVkaWF0ZSA9IHRoaXMuclsxMF0uaW50ZXJtZWRpYXRlO1xuICAgIH1cbiAgfVxuICBfZGVjb2RlUnVsZVN0ZXAoc3RlcCkge1xuICAgIGNvbnN0IGNsb25lZFN0ZXAgPSB7IC4uLnN0ZXAgfTtcbiAgICBjb25zdCBkZWNvZGVSdWxlU3RlcCA9IHRoaXMuX2RlY29kZVJ1bGVTdGVwLmJpbmQodGhpcyk7XG4gICAgZm9yIChjb25zdCBbbG9uZ0tleSwgc2hvcnRLZXldIG9mIGNvbXBhY3RlZFJ1bGVTdGVwcykge1xuICAgICAgaWYgKGNsb25lZFN0ZXBbc2hvcnRLZXldICE9PSB2b2lkIDApIHtcbiAgICAgICAgY2xvbmVkU3RlcFtsb25nS2V5XSA9IHRoaXMuc1tjbG9uZWRTdGVwW3Nob3J0S2V5XV07XG4gICAgICAgIGRlbGV0ZSBjbG9uZWRTdGVwW3Nob3J0S2V5XTtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKHN0ZXAuaWYpIHtcbiAgICAgIGNsb25lZFN0ZXAuaWYgPSBkZWNvZGVSdWxlU3RlcChzdGVwLmlmKTtcbiAgICAgIGNsb25lZFN0ZXAudGhlbiA9IHN0ZXAudGhlbiAmJiBzdGVwLnRoZW4ubWFwKGRlY29kZVJ1bGVTdGVwKTtcbiAgICAgIGlmIChzdGVwLmVsc2UpIHtcbiAgICAgICAgY2xvbmVkU3RlcC5lbHNlID0gc3RlcC5lbHNlLm1hcChkZWNvZGVSdWxlU3RlcCk7XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChzdGVwLmFueSkge1xuICAgICAgY2xvbmVkU3RlcC5hbnkgPSBzdGVwLmFueS5tYXAoZGVjb2RlUnVsZVN0ZXApO1xuICAgIH1cbiAgICByZXR1cm4geyAuLi5jbG9uZWRTdGVwIH07XG4gIH1cbiAgZ2V0IG5hbWUoKSB7XG4gICAgcmV0dXJuIHRoaXMuclsxXTtcbiAgfVxuICBnZXQgY29zbWV0aWMoKSB7XG4gICAgcmV0dXJuIGRlY29kZU51bGxhYmxlQm9vbGVhbih0aGlzLnJbMl0pO1xuICB9XG4gIGdldCBydW5Db250ZXh0KCkge1xuICAgIGNvbnN0IHJ1bkNvbnRleHQgPSB7fTtcbiAgICBjb25zdCB1cmxQYXR0ZXJuID0gdGhpcy5yWzNdO1xuICAgIGNvbnN0IG1haW5GcmFtZSA9IHRoaXMucls0XTtcbiAgICBjb25zdCBydW5Jbk1haW5GcmFtZSA9IGRlY29kZU51bGxhYmxlQm9vbGVhbihNYXRoLmZsb29yKG1haW5GcmFtZSAvIDEwKSAlIDEwKTtcbiAgICBjb25zdCBydW5JblN1YkZyYW1lID0gZGVjb2RlTnVsbGFibGVCb29sZWFuKG1haW5GcmFtZSAlIDEwKTtcbiAgICBpZiAocnVuSW5NYWluRnJhbWUgIT09IHZvaWQgMCkge1xuICAgICAgcnVuQ29udGV4dC5tYWluID0gcnVuSW5NYWluRnJhbWU7XG4gICAgfVxuICAgIGlmIChydW5JblN1YkZyYW1lICE9PSB2b2lkIDApIHtcbiAgICAgIHJ1bkNvbnRleHQuZnJhbWUgPSBydW5JblN1YkZyYW1lO1xuICAgIH1cbiAgICBpZiAodXJsUGF0dGVybiAhPT0gXCJcIikge1xuICAgICAgcnVuQ29udGV4dC51cmxQYXR0ZXJuID0gdXJsUGF0dGVybjtcbiAgICB9XG4gICAgcmV0dXJuIHJ1bkNvbnRleHQ7XG4gIH1cbiAgZ2V0IHByZWhpZGVTZWxlY3RvcnMoKSB7XG4gICAgcmV0dXJuIHRoaXMucls1XS5tYXAoKGkpID0+IHRoaXMuc1tpXS50b1N0cmluZygpKTtcbiAgfVxuICBnZXQgZGV0ZWN0Q21wKCkge1xuICAgIHJldHVybiB0aGlzLnJbNl0ubWFwKHRoaXMuX2RlY29kZVJ1bGVTdGVwLmJpbmQodGhpcykpO1xuICB9XG4gIGdldCBkZXRlY3RQb3B1cCgpIHtcbiAgICByZXR1cm4gdGhpcy5yWzddLm1hcCh0aGlzLl9kZWNvZGVSdWxlU3RlcC5iaW5kKHRoaXMpKTtcbiAgfVxuICBnZXQgb3B0T3V0KCkge1xuICAgIHJldHVybiB0aGlzLnJbOF0ubWFwKHRoaXMuX2RlY29kZVJ1bGVTdGVwLmJpbmQodGhpcykpO1xuICB9XG4gIGdldCB0ZXN0KCkge1xuICAgIHJldHVybiB0aGlzLnJbOV0ubWFwKHRoaXMuX2RlY29kZVJ1bGVTdGVwLmJpbmQodGhpcykpO1xuICB9XG59O1xuZnVuY3Rpb24gY2xlYXJVbnVzZWRTdHJpbmdzKHJ1bGVzZXQsIGlnbm9yZUJlZm9yZUluZGV4ID0gMCkge1xuICBjb25zdCB7IHYsIHMsIHIgfSA9IHJ1bGVzZXQ7XG4gIGNvbnN0IHVzZWRTdHJpbmdJZHMgPSAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpO1xuICBmdW5jdGlvbiBhZGRTdHJpbmdJZHNGcm9tUnVsZVN0ZXBzKHN0ZXBzKSB7XG4gICAgc3RlcHMuZm9yRWFjaCgoc3RlcCkgPT4ge1xuICAgICAgZm9yIChjb25zdCBbLCBzaG9ydEtleV0gb2YgY29tcGFjdGVkUnVsZVN0ZXBzKSB7XG4gICAgICAgIGlmIChzdGVwW3Nob3J0S2V5XSAhPT0gdm9pZCAwKSB7XG4gICAgICAgICAgdXNlZFN0cmluZ0lkcy5hZGQoc3RlcFtzaG9ydEtleV0pO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBpZiAoc3RlcC5pZikge1xuICAgICAgICBhZGRTdHJpbmdJZHNGcm9tUnVsZVN0ZXBzKFtzdGVwLmlmXSk7XG4gICAgICB9XG4gICAgICBpZiAoc3RlcC50aGVuKSB7XG4gICAgICAgIGFkZFN0cmluZ0lkc0Zyb21SdWxlU3RlcHMoc3RlcC50aGVuKTtcbiAgICAgIH1cbiAgICAgIGlmIChzdGVwLmVsc2UpIHtcbiAgICAgICAgYWRkU3RyaW5nSWRzRnJvbVJ1bGVTdGVwcyhzdGVwLmVsc2UpO1xuICAgICAgfVxuICAgICAgaWYgKHN0ZXAuYW55KSB7XG4gICAgICAgIGFkZFN0cmluZ0lkc0Zyb21SdWxlU3RlcHMoc3RlcC5hbnkpO1xuICAgICAgfVxuICAgIH0pO1xuICB9XG4gIHJ1bGVzZXQuci5mb3JFYWNoKChydWxlKSA9PiB7XG4gICAgYWRkU3RyaW5nSWRzRnJvbVJ1bGVTdGVwcyhydWxlWzZdKTtcbiAgICBhZGRTdHJpbmdJZHNGcm9tUnVsZVN0ZXBzKHJ1bGVbN10pO1xuICAgIGFkZFN0cmluZ0lkc0Zyb21SdWxlU3RlcHMocnVsZVs4XSk7XG4gICAgYWRkU3RyaW5nSWRzRnJvbVJ1bGVTdGVwcyhydWxlWzldKTtcbiAgICBydWxlWzVdLmZvckVhY2goKGlkKSA9PiB1c2VkU3RyaW5nSWRzLmFkZChpZCkpO1xuICB9KTtcbiAgcmV0dXJuIHtcbiAgICB2LFxuICAgIHIsXG4gICAgczogcy5zbGljZSgwLCBNYXRoLm1heCguLi51c2VkU3RyaW5nSWRzKSArIDEpLm1hcCgoc3RyLCBpZHgpID0+IHtcbiAgICAgIGlmIChpZHggPCBpZ25vcmVCZWZvcmVJbmRleCB8fCB1c2VkU3RyaW5nSWRzLmhhcyhpZHgpKSB7XG4gICAgICAgIHJldHVybiBzdHI7XG4gICAgICB9XG4gICAgICByZXR1cm4gXCJcIjtcbiAgICB9KVxuICB9O1xufVxuZnVuY3Rpb24gc2hvdWxkUnVuUnVsZUluQ29udGV4dChydWxlLCBtYWluRnJhbWUsIHVybCkge1xuICBjb25zdCBydW5Db250ZXh0ID0gcnVsZVs0XTtcbiAgaWYgKG1haW5GcmFtZSAmJiBydW5Db250ZXh0ID09PSAxKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGlmICghbWFpbkZyYW1lICYmIFsyMCwgMjIsIDEwLCAxMl0uaW5jbHVkZXMocnVuQ29udGV4dCkpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgY29uc3QgdXJsUGF0dGVybiA9IHJ1bGVbM107XG4gIGlmICh1cmxQYXR0ZXJuICYmIHVybFBhdHRlcm4gIT09IFwiXCIgJiYgdXJsLm1hdGNoKHVybFBhdHRlcm4pID09PSBudWxsKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIHJldHVybiB0cnVlO1xufVxuZnVuY3Rpb24gZmlsdGVyQ29tcGFjdFJ1bGVzKHJ1bGVzLCBjb250ZXh0KSB7XG4gIGNvbnN0IHsgdiwgcywgciwgaW5kZXggfSA9IHJ1bGVzO1xuICBjb25zdCB7IHVybCwgbWFpbkZyYW1lIH0gPSBjb250ZXh0O1xuICBjb25zdCBzaG91bGRSdW5JbkNvbnRleHQgPSAocnVsZSkgPT4gc2hvdWxkUnVuUnVsZUluQ29udGV4dChydWxlLCBtYWluRnJhbWUsIHVybCk7XG4gIGlmICghbWFpbkZyYW1lKSB7XG4gICAgY29uc3QgcnVsZXNldCA9IHtcbiAgICAgIHYsXG4gICAgICBzOiBzLnNsaWNlKDAsIGluZGV4LmZyYW1lU3RyaW5nRW5kKSxcbiAgICAgIHI6IHIuc2xpY2UoaW5kZXguZnJhbWVSdWxlUmFuZ2VbMF0sIGluZGV4LmZyYW1lUnVsZVJhbmdlWzFdKS5maWx0ZXIoc2hvdWxkUnVuSW5Db250ZXh0KVxuICAgIH07XG4gICAgcmV0dXJuIGNsZWFyVW51c2VkU3RyaW5ncyhydWxlc2V0KTtcbiAgfVxuICBjb25zdCBnZW5lcmljUnVsZXMgPSByLnNsaWNlKGluZGV4LmdlbmVyaWNSdWxlUmFuZ2VbMF0sIGluZGV4LmdlbmVyaWNSdWxlUmFuZ2VbMV0pO1xuICBjb25zdCBzcGVjaWZpY1J1bGVzID0gci5zbGljZShpbmRleC5zcGVjaWZpY1J1bGVSYW5nZVswXSwgaW5kZXguc3BlY2lmaWNSdWxlUmFuZ2VbMV0pLmZpbHRlcihzaG91bGRSdW5JbkNvbnRleHQpO1xuICBpZiAoc3BlY2lmaWNSdWxlcy5sZW5ndGggPiAwKSB7XG4gICAgY29uc3QgcnVsZXNldCA9IHtcbiAgICAgIHYsXG4gICAgICBzLFxuICAgICAgcjogWy4uLmdlbmVyaWNSdWxlcywgLi4uc3BlY2lmaWNSdWxlc11cbiAgICB9O1xuICAgIHJldHVybiBjbGVhclVudXNlZFN0cmluZ3MocnVsZXNldCk7XG4gIH1cbiAgcmV0dXJuIHtcbiAgICB2LFxuICAgIHM6IHMuc2xpY2UoMCwgaW5kZXguZ2VuZXJpY1N0cmluZ0VuZCksXG4gICAgcjogZ2VuZXJpY1J1bGVzXG4gIH07XG59XG5cbi8vIGxpYi93ZWIudHNcbmZ1bmN0aW9uIGZpbHRlckNNUHMocnVsZXMsIGNvbmZpZykge1xuICByZXR1cm4gcnVsZXMuZmlsdGVyKChjbXApID0+IHtcbiAgICByZXR1cm4gKCFjb25maWcuZGlzYWJsZWRDbXBzIHx8ICFjb25maWcuZGlzYWJsZWRDbXBzLmluY2x1ZGVzKGNtcC5uYW1lKSkgJiYgLy8gQ01QIGlzIG5vdCBkaXNhYmxlZFxuICAgIChjb25maWcuZW5hYmxlQ29zbWV0aWNSdWxlcyB8fCAhY21wLmlzQ29zbWV0aWMpICYmIC8vIENNUCBpcyBub3QgY29zbWV0aWMgb3IgY29zbWV0aWMgcnVsZXMgYXJlIGVuYWJsZWRcbiAgICAoY29uZmlnLmVuYWJsZUdlbmVyYXRlZFJ1bGVzIHx8ICFjbXAubmFtZS5zdGFydHNXaXRoKFwiYXV0b19cIikpO1xuICB9KTtcbn1cbnZhciBfY29uZmlnO1xudmFyIEF1dG9Db25zZW50ID0gY2xhc3Mge1xuICBjb25zdHJ1Y3RvcihzZW5kQ29udGVudE1lc3NhZ2UsIGNvbmZpZyA9IG51bGwsIGRlY2xhcmF0aXZlUnVsZXMgPSBudWxsKSB7XG4gICAgdGhpcy5pZCA9IGdldFJhbmRvbUlEKCk7XG4gICAgdGhpcy5ydWxlcyA9IFtdO1xuICAgIF9fcHJpdmF0ZUFkZCh0aGlzLCBfY29uZmlnKTtcbiAgICB0aGlzLnN0YXRlID0ge1xuICAgICAgY29zbWV0aWNGaWx0ZXJzT246IGZhbHNlLFxuICAgICAgZmlsdGVyTGlzdFJlcG9ydGVkOiBmYWxzZSxcbiAgICAgIGxpZmVjeWNsZTogXCJsb2FkaW5nXCIsXG4gICAgICBwcmVoaWRlT246IGZhbHNlLFxuICAgICAgZmluZENtcEF0dGVtcHRzOiAwLFxuICAgICAgZGV0ZWN0ZWRDbXBzOiBbXSxcbiAgICAgIGRldGVjdGVkUG9wdXBzOiBbXSxcbiAgICAgIGhldXJpc3RpY1BhdHRlcm5zOiBbXSxcbiAgICAgIGhldXJpc3RpY1NuaXBwZXRzOiBbXSxcbiAgICAgIHNlbGZUZXN0OiBudWxsLFxuICAgICAgY2xpY2tzOiAwLFxuICAgICAgc3RhcnRUaW1lOiAwLFxuICAgICAgZW5kVGltZTogMFxuICAgIH07XG4gICAgZXZhbFN0YXRlLnNlbmRDb250ZW50TWVzc2FnZSA9IHNlbmRDb250ZW50TWVzc2FnZTtcbiAgICB0aGlzLnNlbmRDb250ZW50TWVzc2FnZSA9IHNlbmRDb250ZW50TWVzc2FnZTtcbiAgICB0aGlzLnJ1bGVzID0gW107XG4gICAgdGhpcy51cGRhdGVTdGF0ZSh7IGxpZmVjeWNsZTogXCJsb2FkaW5nXCIgfSk7XG4gICAgdGhpcy5hZGREeW5hbWljUnVsZXMoKTtcbiAgICBpZiAoY29uZmlnKSB7XG4gICAgICB0aGlzLmluaXRpYWxpemUoY29uZmlnLCBkZWNsYXJhdGl2ZVJ1bGVzKTtcbiAgICB9IGVsc2Uge1xuICAgICAgaWYgKGRlY2xhcmF0aXZlUnVsZXMpIHtcbiAgICAgICAgdGhpcy5wYXJzZURlY2xhcmF0aXZlUnVsZXMoZGVjbGFyYXRpdmVSdWxlcyk7XG4gICAgICB9XG4gICAgICBjb25zdCBpbml0TXNnID0ge1xuICAgICAgICB0eXBlOiBcImluaXRcIixcbiAgICAgICAgdXJsOiB3aW5kb3cubG9jYXRpb24uaHJlZlxuICAgICAgfTtcbiAgICAgIHNlbmRDb250ZW50TWVzc2FnZShpbml0TXNnKTtcbiAgICAgIHRoaXMudXBkYXRlU3RhdGUoeyBsaWZlY3ljbGU6IFwid2FpdGluZ0ZvckluaXRSZXNwb25zZVwiIH0pO1xuICAgIH1cbiAgICB0aGlzLmRvbUFjdGlvbnMgPSBuZXcgRG9tQWN0aW9ucyh0aGlzKTtcbiAgfVxuICBnZXQgY29uZmlnKCkge1xuICAgIGlmICghX19wcml2YXRlR2V0KHRoaXMsIF9jb25maWcpKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJBdXRvQ29uc2VudCBpcyBub3QgaW5pdGlhbGl6ZWQgeWV0XCIpO1xuICAgIH1cbiAgICByZXR1cm4gX19wcml2YXRlR2V0KHRoaXMsIF9jb25maWcpO1xuICB9XG4gIGluaXRpYWxpemUoY29uZmlnLCBkZWNsYXJhdGl2ZVJ1bGVzKSB7XG4gICAgY29uc3Qgbm9ybWFsaXplZENvbmZpZyA9IG5vcm1hbGl6ZUNvbmZpZyhjb25maWcpO1xuICAgIG5vcm1hbGl6ZWRDb25maWcubG9ncy5saWZlY3ljbGUgJiYgY29uc29sZS5sb2coXCJhdXRvY29uc2VudCBpbml0XCIsIHdpbmRvdy5sb2NhdGlvbi5ocmVmKTtcbiAgICBfX3ByaXZhdGVTZXQodGhpcywgX2NvbmZpZywgbm9ybWFsaXplZENvbmZpZyk7XG4gICAgaWYgKCFub3JtYWxpemVkQ29uZmlnLmVuYWJsZWQpIHtcbiAgICAgIG5vcm1hbGl6ZWRDb25maWcubG9ncy5saWZlY3ljbGUgJiYgY29uc29sZS5sb2coXCJhdXRvY29uc2VudCBpcyBkaXNhYmxlZFwiKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKGRlY2xhcmF0aXZlUnVsZXMpIHtcbiAgICAgIHRoaXMucGFyc2VEZWNsYXJhdGl2ZVJ1bGVzKGRlY2xhcmF0aXZlUnVsZXMpO1xuICAgIH1cbiAgICBpZiAoY29uZmlnLmVuYWJsZUZpbHRlckxpc3QpIHtcbiAgICAgIHRoaXMuaW5pdGlhbGl6ZUZpbHRlckxpc3QoKTtcbiAgICB9XG4gICAgdGhpcy5ydWxlcyA9IGZpbHRlckNNUHModGhpcy5ydWxlcywgbm9ybWFsaXplZENvbmZpZyk7XG4gICAgaWYgKHRoaXMuc2hvdWxkUHJlaGlkZSkge1xuICAgICAgaWYgKGRvY3VtZW50LmRvY3VtZW50RWxlbWVudCkge1xuICAgICAgICB0aGlzLnByZWhpZGVFbGVtZW50cygpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY29uc3QgZGVsYXllZFByZWhpZGUgPSAoKSA9PiB7XG4gICAgICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJET01Db250ZW50TG9hZGVkXCIsIGRlbGF5ZWRQcmVoaWRlKTtcbiAgICAgICAgICB0aGlzLnByZWhpZGVFbGVtZW50cygpO1xuICAgICAgICB9O1xuICAgICAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcIkRPTUNvbnRlbnRMb2FkZWRcIiwgZGVsYXllZFByZWhpZGUpO1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAoZG9jdW1lbnQucmVhZHlTdGF0ZSA9PT0gXCJsb2FkaW5nXCIpIHtcbiAgICAgIGNvbnN0IG9uUmVhZHkgPSAoKSA9PiB7XG4gICAgICAgIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKFwiRE9NQ29udGVudExvYWRlZFwiLCBvblJlYWR5KTtcbiAgICAgICAgdGhpcy5zdGFydCgpO1xuICAgICAgfTtcbiAgICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwiRE9NQ29udGVudExvYWRlZFwiLCBvblJlYWR5KTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5zdGFydCgpO1xuICAgIH1cbiAgICB0aGlzLnVwZGF0ZVN0YXRlKHsgbGlmZWN5Y2xlOiBcImluaXRpYWxpemVkXCIgfSk7XG4gIH1cbiAgaW5pdGlhbGl6ZUZpbHRlckxpc3QoKSB7XG4gIH1cbiAgZ2V0IHNob3VsZFByZWhpZGUoKSB7XG4gICAgcmV0dXJuIHRoaXMuY29uZmlnLmVuYWJsZVByZWhpZGUgJiYgIXRoaXMuY29uZmlnLnZpc3VhbFRlc3Q7XG4gIH1cbiAgc2F2ZUZvY3VzKCkge1xuICAgIHRoaXMuZm9jdXNlZEVsZW1lbnQgPSBkb2N1bWVudC5hY3RpdmVFbGVtZW50O1xuICAgIGlmICh0aGlzLmZvY3VzZWRFbGVtZW50KSB7XG4gICAgICB0aGlzLmNvbmZpZy5sb2dzLmxpZmVjeWNsZSAmJiBjb25zb2xlLmxvZyhcInNhdmluZyBmb2N1c1wiLCB0aGlzLmZvY3VzZWRFbGVtZW50LCBsb2NhdGlvbi5ocmVmKTtcbiAgICB9XG4gIH1cbiAgcmVzdG9yZUZvY3VzKCkge1xuICAgIGlmICh0aGlzLmZvY3VzZWRFbGVtZW50KSB7XG4gICAgICB0aGlzLmNvbmZpZy5sb2dzLmxpZmVjeWNsZSAmJiBjb25zb2xlLmxvZyhcInJlc3RvcmluZyBmb2N1c1wiLCB0aGlzLmZvY3VzZWRFbGVtZW50LCBsb2NhdGlvbi5ocmVmKTtcbiAgICAgIHRyeSB7XG4gICAgICAgIHRoaXMuZm9jdXNlZEVsZW1lbnQuZm9jdXMoeyBwcmV2ZW50U2Nyb2xsOiB0cnVlIH0pO1xuICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICB0aGlzLmNvbmZpZy5sb2dzLmVycm9ycyAmJiBjb25zb2xlLndhcm4oXCJlcnJvciByZXN0b3JpbmcgZm9jdXNcIiwgZSk7XG4gICAgICB9XG4gICAgICB0aGlzLmZvY3VzZWRFbGVtZW50ID0gdm9pZCAwO1xuICAgIH1cbiAgfVxuICBhZGREeW5hbWljUnVsZXMoKSB7XG4gICAgZHluYW1pY0NNUHMuZm9yRWFjaCgoQ21wKSA9PiB7XG4gICAgICB0aGlzLnJ1bGVzLnB1c2gobmV3IENtcCh0aGlzKSk7XG4gICAgfSk7XG4gIH1cbiAgcGFyc2VEZWNsYXJhdGl2ZVJ1bGVzKGRlY2xhcmF0aXZlUnVsZXMpIHtcbiAgICBpZiAoZGVjbGFyYXRpdmVSdWxlcy5jb25zZW50b21hdGljKSB7XG4gICAgICBmb3IgKGNvbnN0IFtuYW1lLCBydWxlXSBvZiBPYmplY3QuZW50cmllcyhkZWNsYXJhdGl2ZVJ1bGVzLmNvbnNlbnRvbWF0aWMpKSB7XG4gICAgICAgIHRoaXMuYWRkQ29uc2VudG9tYXRpY0NNUChuYW1lLCBydWxlKTtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKGRlY2xhcmF0aXZlUnVsZXMuYXV0b2NvbnNlbnQpIHtcbiAgICAgIGRlY2xhcmF0aXZlUnVsZXMuYXV0b2NvbnNlbnQuZm9yRWFjaCgocnVsZXNldCkgPT4ge1xuICAgICAgICB0aGlzLmFkZERlY2xhcmF0aXZlQ01QKHJ1bGVzZXQpO1xuICAgICAgfSk7XG4gICAgfVxuICAgIGlmIChkZWNsYXJhdGl2ZVJ1bGVzLmNvbXBhY3QpIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJ1bGVzID0gZGVjb2RlUnVsZXMoZGVjbGFyYXRpdmVSdWxlcy5jb21wYWN0KTtcbiAgICAgICAgcnVsZXMuZm9yRWFjaCh0aGlzLmFkZERlY2xhcmF0aXZlQ01QLmJpbmQodGhpcykpO1xuICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICB0aGlzLmNvbmZpZy5sb2dzLmVycm9ycyAmJiBjb25zb2xlLmVycm9yKGUpO1xuICAgICAgfVxuICAgIH1cbiAgfVxuICBhZGREZWNsYXJhdGl2ZUNNUChydWxlc2V0KSB7XG4gICAgaWYgKChydWxlc2V0Lm1pbmltdW1SdWxlU3RlcFZlcnNpb24gfHwgMSkgPD0gU1VQUE9SVEVEX1JVTEVfU1RFUF9WRVJTSU9OKSB7XG4gICAgICB0aGlzLnJ1bGVzLnB1c2gobmV3IEF1dG9Db25zZW50Q01QKHJ1bGVzZXQsIHRoaXMpKTtcbiAgICB9XG4gIH1cbiAgYWRkQ29uc2VudG9tYXRpY0NNUChuYW1lLCBjb25maWcpIHtcbiAgICB0aGlzLnJ1bGVzLnB1c2gobmV3IENvbnNlbnRPTWF0aWNDTVAoYGNvbV8ke25hbWV9YCwgY29uZmlnKSk7XG4gIH1cbiAgLy8gc3RhcnQgdGhlIGRldGVjdGlvbiBwcm9jZXNzLCBwb3NzaWJseSB3aXRoIGEgZGVsYXlcbiAgc3RhcnQoKSB7XG4gICAgc2NoZWR1bGVXaGVuSWRsZSgoKSA9PiB0aGlzLl9zdGFydCgpKTtcbiAgfVxuICBhc3luYyBfc3RhcnQoKSB7XG4gICAgY29uc3QgbG9nc0NvbmZpZyA9IHRoaXMuY29uZmlnLmxvZ3M7XG4gICAgbG9nc0NvbmZpZy5saWZlY3ljbGUgJiYgY29uc29sZS5sb2coYERldGVjdGluZyBDTVBzIG9uICR7d2luZG93LmxvY2F0aW9uLmhyZWZ9YCk7XG4gICAgdGhpcy51cGRhdGVTdGF0ZSh7IGxpZmVjeWNsZTogXCJzdGFydGVkXCIgfSk7XG4gICAgY29uc3QgZm91bmRDbXBzID0gYXdhaXQgdGhpcy5maW5kQ21wKHRoaXMuY29uZmlnLmRldGVjdFJldHJpZXMpO1xuICAgIHRoaXMudXBkYXRlU3RhdGUoeyBkZXRlY3RlZENtcHM6IGZvdW5kQ21wcy5tYXAoKGMpID0+IGMubmFtZSkgfSk7XG4gICAgaWYgKGZvdW5kQ21wcy5sZW5ndGggPT09IDApIHtcbiAgICAgIGxvZ3NDb25maWcubGlmZWN5Y2xlICYmIGNvbnNvbGUubG9nKFwibm8gQ01QIGZvdW5kXCIsIGxvY2F0aW9uLmhyZWYpO1xuICAgICAgaWYgKHRoaXMuc2hvdWxkUHJlaGlkZSkge1xuICAgICAgICB0aGlzLnVuZG9QcmVoaWRlKCk7XG4gICAgICB9XG4gICAgICByZXR1cm4gdGhpcy5maWx0ZXJMaXN0RmFsbGJhY2soKTtcbiAgICB9XG4gICAgdGhpcy51cGRhdGVTdGF0ZSh7IGxpZmVjeWNsZTogXCJjbXBEZXRlY3RlZFwiIH0pO1xuICAgIGNvbnN0IHN0YXRpY0NtcHMgPSBbXTtcbiAgICBjb25zdCBjb3NtZXRpY0NtcHMgPSBbXTtcbiAgICBmb3IgKGNvbnN0IGNtcCBvZiBmb3VuZENtcHMpIHtcbiAgICAgIGlmIChjbXAuaXNDb3NtZXRpYykge1xuICAgICAgICBjb3NtZXRpY0NtcHMucHVzaChjbXApO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgc3RhdGljQ21wcy5wdXNoKGNtcCk7XG4gICAgICB9XG4gICAgfVxuICAgIGxldCByZXN1bHQgPSBmYWxzZTtcbiAgICBsZXQgZm91bmRQb3B1cHMgPSBhd2FpdCB0aGlzLmRldGVjdFBvcHVwcyhzdGF0aWNDbXBzLCBhc3luYyAoY21wKSA9PiB7XG4gICAgICByZXN1bHQgPSBhd2FpdCB0aGlzLmhhbmRsZVBvcHVwKGNtcCk7XG4gICAgfSk7XG4gICAgaWYgKGZvdW5kUG9wdXBzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgZm91bmRQb3B1cHMgPSBhd2FpdCB0aGlzLmRldGVjdFBvcHVwcyhjb3NtZXRpY0NtcHMsIGFzeW5jIChjbXApID0+IHtcbiAgICAgICAgcmVzdWx0ID0gYXdhaXQgdGhpcy5oYW5kbGVQb3B1cChjbXApO1xuICAgICAgfSk7XG4gICAgfVxuICAgIGlmIChmb3VuZFBvcHVwcy5sZW5ndGggPT09IDApIHtcbiAgICAgIGxvZ3NDb25maWcubGlmZWN5Y2xlICYmIGNvbnNvbGUubG9nKFwibm8gcG9wdXAgZm91bmRcIik7XG4gICAgICBpZiAodGhpcy5zaG91bGRQcmVoaWRlKSB7XG4gICAgICAgIHRoaXMudW5kb1ByZWhpZGUoKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgaWYgKGZvdW5kUG9wdXBzLmxlbmd0aCA+IDEpIHtcbiAgICAgIGNvbnN0IGVycm9yRGV0YWlscyA9IHtcbiAgICAgICAgbXNnOiBgRm91bmQgbXVsdGlwbGUgQ01QcywgY2hlY2sgdGhlIGRldGVjdGlvbiBydWxlcy5gLFxuICAgICAgICBjbXBzOiBmb3VuZFBvcHVwcy5tYXAoKGNtcCkgPT4gY21wLm5hbWUpXG4gICAgICB9O1xuICAgICAgbG9nc0NvbmZpZy5lcnJvcnMgJiYgY29uc29sZS53YXJuKGVycm9yRGV0YWlscy5tc2csIGVycm9yRGV0YWlscy5jbXBzKTtcbiAgICAgIHRoaXMuc2VuZENvbnRlbnRNZXNzYWdlKHtcbiAgICAgICAgdHlwZTogXCJhdXRvY29uc2VudEVycm9yXCIsXG4gICAgICAgIGRldGFpbHM6IGVycm9yRGV0YWlsc1xuICAgICAgfSk7XG4gICAgfVxuICAgIHJldHVybiByZXN1bHQ7XG4gIH1cbiAgYXN5bmMgZmluZENtcChyZXRyaWVzKSB7XG4gICAgY29uc3QgbG9nc0NvbmZpZyA9IHRoaXMuY29uZmlnLmxvZ3M7XG4gICAgdGhpcy51cGRhdGVTdGF0ZSh7IGZpbmRDbXBBdHRlbXB0czogdGhpcy5zdGF0ZS5maW5kQ21wQXR0ZW1wdHMgKyAxIH0pO1xuICAgIGNvbnN0IGZvdW5kQ01QcyA9IFtdO1xuICAgIGNvbnN0IGlzVG9wID0gaXNUb3BGcmFtZSgpO1xuICAgIGNvbnN0IHNpdGVTcGVjaWZpY1J1bGVzID0gW107XG4gICAgY29uc3QgZ2VuZXJpY1J1bGVzID0gW107XG4gICAgdGhpcy5ydWxlcy5mb3JFYWNoKChjbXApID0+IHtcbiAgICAgIGlmIChjbXAuY2hlY2tGcmFtZUNvbnRleHQoaXNUb3ApKSB7XG4gICAgICAgIGNvbnN0IGlzU2l0ZVNwZWNpZmljID0gISFjbXAucnVuQ29udGV4dC51cmxQYXR0ZXJuO1xuICAgICAgICBpZiAoY21wLmhhc01hdGNoaW5nVXJsUGF0dGVybigpKSB7XG4gICAgICAgICAgc2l0ZVNwZWNpZmljUnVsZXMucHVzaChjbXApO1xuICAgICAgICB9IGVsc2UgaWYgKCFpc1NpdGVTcGVjaWZpYykge1xuICAgICAgICAgIGdlbmVyaWNSdWxlcy5wdXNoKGNtcCk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9KTtcbiAgICBjb25zdCBoZXVyaXN0aWNSdWxlcyA9IGlzVG9wICYmIHRoaXMuY29uZmlnLmVuYWJsZUhldXJpc3RpY0FjdGlvbiA/IFtuZXcgQXV0b0NvbnNlbnRIZXVyaXN0aWNDTVAodGhpcyldIDogW107XG4gICAgY29uc3QgcnVsZXNQcmlvcml0eVN0YWdlcyA9IFtcbiAgICAgIFtcInNpdGUtc3BlY2lmaWNcIiwgc2l0ZVNwZWNpZmljUnVsZXNdLFxuICAgICAgW1wiZ2VuZXJpY1wiLCBnZW5lcmljUnVsZXNdLFxuICAgICAgW1wiaGV1cmlzdGljXCIsIGhldXJpc3RpY1J1bGVzXVxuICAgIF07XG4gICAgY29uc3QgcnVuRGV0ZWN0Q21wID0gYXN5bmMgKGNtcCkgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgY21wLmRldGVjdENtcCgpO1xuICAgICAgICBpZiAocmVzdWx0KSB7XG4gICAgICAgICAgbG9nc0NvbmZpZy5saWZlY3ljbGUgJiYgY29uc29sZS5sb2coYEZvdW5kIENNUDogJHtjbXAubmFtZX0gJHt3aW5kb3cubG9jYXRpb24uaHJlZn1gKTtcbiAgICAgICAgICB0aGlzLnNlbmRDb250ZW50TWVzc2FnZSh7XG4gICAgICAgICAgICB0eXBlOiBcImNtcERldGVjdGVkXCIsXG4gICAgICAgICAgICB1cmw6IGxvY2F0aW9uLmhyZWYsXG4gICAgICAgICAgICBjbXA6IGNtcC5uYW1lXG4gICAgICAgICAgfSk7XG4gICAgICAgICAgZm91bmRDTVBzLnB1c2goY21wKTtcbiAgICAgICAgfVxuICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICBsb2dzQ29uZmlnLmVycm9ycyAmJiBjb25zb2xlLndhcm4oYGVycm9yIGRldGVjdGluZyAke2NtcC5uYW1lfWAsIGUpO1xuICAgICAgfVxuICAgIH07XG4gICAgY29uc3QgbXV0YXRpb25PYnNlcnZlciA9IHRoaXMuZG9tQWN0aW9ucy53YWl0Rm9yTXV0YXRpb24oXCJodG1sXCIpO1xuICAgIG11dGF0aW9uT2JzZXJ2ZXIuY2F0Y2goKCkgPT4ge1xuICAgIH0pO1xuICAgIGZvciAoY29uc3QgW3N0YWdlTmFtZSwgcnVsZUdyb3VwXSBvZiBydWxlc1ByaW9yaXR5U3RhZ2VzKSB7XG4gICAgICBsb2dzQ29uZmlnLmxpZmVjeWNsZSAmJiBydWxlR3JvdXAubGVuZ3RoID4gMCAmJiBjb25zb2xlLmxvZyhcbiAgICAgICAgYFRyeWluZyAke3N0YWdlTmFtZX0gcnVsZXNgLFxuICAgICAgICBydWxlR3JvdXAubWFwKChyKSA9PiByLm5hbWUpXG4gICAgICApO1xuICAgICAgYXdhaXQgUHJvbWlzZS5hbGwocnVsZUdyb3VwLm1hcChydW5EZXRlY3RDbXApKTtcbiAgICAgIGlmIChmb3VuZENNUHMubGVuZ3RoID4gMCkge1xuICAgICAgICBicmVhaztcbiAgICAgIH1cbiAgICB9XG4gICAgdGhpcy5kZXRlY3RIZXVyaXN0aWNzKCk7XG4gICAgaWYgKGZvdW5kQ01Qcy5sZW5ndGggPT09IDAgJiYgcmV0cmllcyA+IDApIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGF3YWl0IFByb21pc2UuYWxsKFt0aGlzLmRvbUFjdGlvbnMud2FpdCg1MDApLCBtdXRhdGlvbk9ic2VydmVyXSk7XG4gICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIHJldHVybiBbXTtcbiAgICAgIH1cbiAgICAgIHJldHVybiB0aGlzLmZpbmRDbXAocmV0cmllcyAtIDEpO1xuICAgIH1cbiAgICByZXR1cm4gZm91bmRDTVBzO1xuICB9XG4gIGRldGVjdEhldXJpc3RpY3MoKSB7XG4gICAgaWYgKHRoaXMuY29uZmlnLmVuYWJsZUhldXJpc3RpY0RldGVjdGlvbikge1xuICAgICAgY29uc3QgeyBwYXR0ZXJucywgc25pcHBldHM6IHNuaXBwZXRzMiB9ID0gY2hlY2tIZXVyaXN0aWNQYXR0ZXJucyhkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQ/LmlubmVyVGV4dCB8fCBcIlwiKTtcbiAgICAgIGlmIChwYXR0ZXJucy5sZW5ndGggPiAwICYmIChwYXR0ZXJucy5sZW5ndGggIT09IHRoaXMuc3RhdGUuaGV1cmlzdGljUGF0dGVybnMubGVuZ3RoIHx8IHRoaXMuc3RhdGUuaGV1cmlzdGljUGF0dGVybnMuc29tZSgocCwgaSkgPT4gcCAhPT0gcGF0dGVybnNbaV0pKSkge1xuICAgICAgICB0aGlzLmNvbmZpZy5sb2dzLmxpZmVjeWNsZSAmJiBjb25zb2xlLmxvZyhcIkhldXJpc3RpYyBwYXR0ZXJucyBmb3VuZFwiLCBwYXR0ZXJucywgc25pcHBldHMyKTtcbiAgICAgICAgdGhpcy51cGRhdGVTdGF0ZSh7IGhldXJpc3RpY1BhdHRlcm5zOiBwYXR0ZXJucywgaGV1cmlzdGljU25pcHBldHM6IHNuaXBwZXRzMiB9KTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgLyoqXG4gICAqIERldGVjdCBpZiBhIENNUCBoYXMgYSBwb3B1cCBvcGVuLiBGdWxsZmlscyB3aXRoIHRoZSBDTVAgaWYgYSBwb3B1cCBpcyBvcGVuLCBvdGhlcndpc2UgcmVqZWN0cy5cbiAgICovXG4gIGFzeW5jIGRldGVjdFBvcHVwKGNtcCkge1xuICAgIGNvbnN0IGlzT3BlbiA9IGF3YWl0IHRoaXMud2FpdEZvclBvcHVwKGNtcCkuY2F0Y2goKGVycm9yKSA9PiB7XG4gICAgICB0aGlzLmNvbmZpZy5sb2dzLmVycm9ycyAmJiBjb25zb2xlLndhcm4oYGVycm9yIHdhaXRpbmcgZm9yIGEgcG9wdXAgZm9yICR7Y21wLm5hbWV9YCwgZXJyb3IpO1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH0pO1xuICAgIGlmIChpc09wZW4pIHtcbiAgICAgIHRoaXMudXBkYXRlU3RhdGUoeyBkZXRlY3RlZFBvcHVwczogdGhpcy5zdGF0ZS5kZXRlY3RlZFBvcHVwcy5jb25jYXQoW2NtcC5uYW1lXSkgfSk7XG4gICAgICB0aGlzLnNlbmRDb250ZW50TWVzc2FnZSh7XG4gICAgICAgIHR5cGU6IFwicG9wdXBGb3VuZFwiLFxuICAgICAgICBjbXA6IGNtcC5uYW1lLFxuICAgICAgICB1cmw6IGxvY2F0aW9uLmhyZWZcbiAgICAgIH0pO1xuICAgICAgcmV0dXJuIGNtcDtcbiAgICB9XG4gICAgdGhyb3cgbmV3IEVycm9yKFwiUG9wdXAgaXMgbm90IHNob3duXCIpO1xuICB9XG4gIC8qKlxuICAgKiBEZXRlY3QgaWYgYW55IG9mIHRoZSBDTVBzIGhhcyBhIHBvcHVwIG9wZW4uIFJldHVybnMgYSBsaXN0IG9mIENNUHMgd2l0aCBvcGVuIHBvcHVwcy5cbiAgICovXG4gIGFzeW5jIGRldGVjdFBvcHVwcyhjbXBzLCBvbkZpcnN0UG9wdXBBcHBlYXJzKSB7XG4gICAgY29uc3QgdGFza3MgPSBjbXBzLm1hcCgoY21wKSA9PiB0aGlzLmRldGVjdFBvcHVwKGNtcCkpO1xuICAgIGF3YWl0IFByb21pc2UuYW55KHRhc2tzKS50aGVuKChjbXApID0+IHtcbiAgICAgIHRoaXMuZGV0ZWN0SGV1cmlzdGljcygpO1xuICAgICAgb25GaXJzdFBvcHVwQXBwZWFycyhjbXApO1xuICAgIH0pLmNhdGNoKCgpID0+IHtcbiAgICB9KTtcbiAgICBjb25zdCByZXN1bHRzID0gYXdhaXQgUHJvbWlzZS5hbGxTZXR0bGVkKHRhc2tzKTtcbiAgICBjb25zdCBwb3B1cHMgPSBbXTtcbiAgICBmb3IgKGNvbnN0IHJlc3VsdCBvZiByZXN1bHRzKSB7XG4gICAgICBpZiAocmVzdWx0LnN0YXR1cyA9PT0gXCJmdWxmaWxsZWRcIikge1xuICAgICAgICBwb3B1cHMucHVzaChyZXN1bHQudmFsdWUpO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gcG9wdXBzO1xuICB9XG4gIGFzeW5jIGhhbmRsZVBvcHVwKGNtcCkge1xuICAgIHRoaXMudXBkYXRlU3RhdGUoeyBsaWZlY3ljbGU6IFwib3BlblBvcHVwRGV0ZWN0ZWRcIiwgc3RhcnRUaW1lOiBEYXRlLm5vdygpIH0pO1xuICAgIGlmICh0aGlzLnNob3VsZFByZWhpZGUgJiYgIXRoaXMuc3RhdGUucHJlaGlkZU9uKSB7XG4gICAgICB0aGlzLnByZWhpZGVFbGVtZW50cygpO1xuICAgIH1cbiAgICBpZiAodGhpcy5zdGF0ZS5jb3NtZXRpY0ZpbHRlcnNPbikge1xuICAgICAgdGhpcy51bmRvQ29zbWV0aWNzKCk7XG4gICAgfVxuICAgIHRoaXMuZm91bmRDbXAgPSBjbXA7XG4gICAgaWYgKHRoaXMuY29uZmlnLmF1dG9BY3Rpb24gPT09IFwib3B0T3V0XCIpIHtcbiAgICAgIHJldHVybiBhd2FpdCB0aGlzLmRvT3B0T3V0KCk7XG4gICAgfSBlbHNlIGlmICh0aGlzLmNvbmZpZy5hdXRvQWN0aW9uID09PSBcIm9wdEluXCIpIHtcbiAgICAgIHJldHVybiBhd2FpdCB0aGlzLmRvT3B0SW4oKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5jb25maWcubG9ncy5saWZlY3ljbGUgJiYgY29uc29sZS5sb2coXCJ3YWl0aW5nIGZvciBvcHQtb3V0IHNpZ25hbC4uLlwiLCBsb2NhdGlvbi5ocmVmKTtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgfVxuICBhc3luYyBkb09wdE91dCgpIHtcbiAgICBjb25zdCBsb2dzQ29uZmlnID0gdGhpcy5jb25maWcubG9ncztcbiAgICB0aGlzLnVwZGF0ZVN0YXRlKHsgbGlmZWN5Y2xlOiBcInJ1bm5pbmdPcHRPdXRcIiB9KTtcbiAgICB0aGlzLnNhdmVGb2N1cygpO1xuICAgIGxldCBvcHRPdXRSZXN1bHQ7XG4gICAgaWYgKCF0aGlzLmZvdW5kQ21wKSB7XG4gICAgICBsb2dzQ29uZmlnLmVycm9ycyAmJiBjb25zb2xlLmxvZyhcIm5vIENNUCB0byBvcHQgb3V0XCIpO1xuICAgICAgb3B0T3V0UmVzdWx0ID0gZmFsc2U7XG4gICAgfSBlbHNlIHtcbiAgICAgIGxvZ3NDb25maWcubGlmZWN5Y2xlICYmIGNvbnNvbGUubG9nKGBDTVAgJHt0aGlzLmZvdW5kQ21wLm5hbWV9OiBvcHQgb3V0IG9uICR7d2luZG93LmxvY2F0aW9uLmhyZWZ9YCk7XG4gICAgICBvcHRPdXRSZXN1bHQgPSBhd2FpdCB0aGlzLmZvdW5kQ21wLm9wdE91dCgpO1xuICAgICAgbG9nc0NvbmZpZy5saWZlY3ljbGUgJiYgY29uc29sZS5sb2coYCR7dGhpcy5mb3VuZENtcC5uYW1lfTogb3B0IG91dCByZXN1bHQgJHtvcHRPdXRSZXN1bHR9YCk7XG4gICAgfVxuICAgIGlmICh0aGlzLnNob3VsZFByZWhpZGUpIHtcbiAgICAgIHRoaXMudW5kb1ByZWhpZGUoKTtcbiAgICB9XG4gICAgdGhpcy5zZW5kQ29udGVudE1lc3NhZ2Uoe1xuICAgICAgdHlwZTogXCJvcHRPdXRSZXN1bHRcIixcbiAgICAgIGNtcDogdGhpcy5mb3VuZENtcCA/IHRoaXMuZm91bmRDbXAubmFtZSA6IFwibm9uZVwiLFxuICAgICAgcmVzdWx0OiBvcHRPdXRSZXN1bHQsXG4gICAgICBzY2hlZHVsZVNlbGZUZXN0OiBCb29sZWFuKHRoaXMuZm91bmRDbXAgJiYgdGhpcy5mb3VuZENtcC5oYXNTZWxmVGVzdCksXG4gICAgICB1cmw6IGxvY2F0aW9uLmhyZWZcbiAgICB9KTtcbiAgICBpZiAob3B0T3V0UmVzdWx0ICYmIHRoaXMuZm91bmRDbXAgJiYgIXRoaXMuZm91bmRDbXAuaXNJbnRlcm1lZGlhdGUpIHtcbiAgICAgIHRoaXMuc3RhdGUuZW5kVGltZSA9IERhdGUubm93KCk7XG4gICAgICBsb2dzQ29uZmlnLmxpZmVjeWNsZSAmJiBjb25zb2xlLmxvZyhcbiAgICAgICAgYCR7dGhpcy5mb3VuZENtcC5uYW1lfTogZG9uZSBpbiAke3RoaXMuc3RhdGUuZW5kVGltZSAtIHRoaXMuc3RhdGUuc3RhcnRUaW1lfW1zIHdpdGggJHt0aGlzLnN0YXRlLmNsaWNrc30gY2xpY2tzYFxuICAgICAgKTtcbiAgICAgIHRoaXMuc2VuZENvbnRlbnRNZXNzYWdlKHtcbiAgICAgICAgdHlwZTogXCJhdXRvY29uc2VudERvbmVcIixcbiAgICAgICAgY21wOiB0aGlzLmZvdW5kQ21wPy5uYW1lLFxuICAgICAgICBpc0Nvc21ldGljOiB0aGlzLmZvdW5kQ21wPy5pc0Nvc21ldGljLFxuICAgICAgICB1cmw6IGxvY2F0aW9uLmhyZWYsXG4gICAgICAgIGR1cmF0aW9uOiB0aGlzLnN0YXRlLmVuZFRpbWUgLSB0aGlzLnN0YXRlLnN0YXJ0VGltZSxcbiAgICAgICAgdG90YWxDbGlja3M6IHRoaXMuc3RhdGUuY2xpY2tzXG4gICAgICB9KTtcbiAgICAgIHRoaXMudXBkYXRlU3RhdGUoeyBsaWZlY3ljbGU6IFwiZG9uZVwiIH0pO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLnVwZGF0ZVN0YXRlKHsgbGlmZWN5Y2xlOiBvcHRPdXRSZXN1bHQgPyBcIm9wdE91dFN1Y2NlZWRlZFwiIDogXCJvcHRPdXRGYWlsZWRcIiB9KTtcbiAgICB9XG4gICAgdGhpcy5yZXN0b3JlRm9jdXMoKTtcbiAgICByZXR1cm4gb3B0T3V0UmVzdWx0O1xuICB9XG4gIGFzeW5jIGRvT3B0SW4oKSB7XG4gICAgY29uc3QgbG9nc0NvbmZpZyA9IHRoaXMuY29uZmlnLmxvZ3M7XG4gICAgdGhpcy51cGRhdGVTdGF0ZSh7IGxpZmVjeWNsZTogXCJydW5uaW5nT3B0SW5cIiB9KTtcbiAgICB0aGlzLnNhdmVGb2N1cygpO1xuICAgIGxldCBvcHRJblJlc3VsdDtcbiAgICBpZiAoIXRoaXMuZm91bmRDbXApIHtcbiAgICAgIGxvZ3NDb25maWcuZXJyb3JzICYmIGNvbnNvbGUubG9nKFwibm8gQ01QIHRvIG9wdCBpblwiKTtcbiAgICAgIG9wdEluUmVzdWx0ID0gZmFsc2U7XG4gICAgfSBlbHNlIHtcbiAgICAgIGxvZ3NDb25maWcubGlmZWN5Y2xlICYmIGNvbnNvbGUubG9nKGBDTVAgJHt0aGlzLmZvdW5kQ21wLm5hbWV9OiBvcHQgaW4gb24gJHt3aW5kb3cubG9jYXRpb24uaHJlZn1gKTtcbiAgICAgIG9wdEluUmVzdWx0ID0gYXdhaXQgdGhpcy5mb3VuZENtcC5vcHRJbigpO1xuICAgICAgbG9nc0NvbmZpZy5saWZlY3ljbGUgJiYgY29uc29sZS5sb2coYCR7dGhpcy5mb3VuZENtcC5uYW1lfTogb3B0IGluIHJlc3VsdCAke29wdEluUmVzdWx0fWApO1xuICAgIH1cbiAgICBpZiAodGhpcy5zaG91bGRQcmVoaWRlKSB7XG4gICAgICB0aGlzLnVuZG9QcmVoaWRlKCk7XG4gICAgfVxuICAgIHRoaXMuc2VuZENvbnRlbnRNZXNzYWdlKHtcbiAgICAgIHR5cGU6IFwib3B0SW5SZXN1bHRcIixcbiAgICAgIGNtcDogdGhpcy5mb3VuZENtcCA/IHRoaXMuZm91bmRDbXAubmFtZSA6IFwibm9uZVwiLFxuICAgICAgcmVzdWx0OiBvcHRJblJlc3VsdCxcbiAgICAgIHNjaGVkdWxlU2VsZlRlc3Q6IGZhbHNlLFxuICAgICAgLy8gc2VsZi10ZXN0cyBhcmUgb25seSBmb3Igb3B0LW91dCBhdCB0aGUgbW9tZW50XG4gICAgICB1cmw6IGxvY2F0aW9uLmhyZWZcbiAgICB9KTtcbiAgICBpZiAob3B0SW5SZXN1bHQgJiYgdGhpcy5mb3VuZENtcCAmJiAhdGhpcy5mb3VuZENtcC5pc0ludGVybWVkaWF0ZSkge1xuICAgICAgdGhpcy5zdGF0ZS5lbmRUaW1lID0gRGF0ZS5ub3coKTtcbiAgICAgIGxvZ3NDb25maWcubGlmZWN5Y2xlICYmIGNvbnNvbGUubG9nKFxuICAgICAgICBgJHt0aGlzLmZvdW5kQ21wLm5hbWV9OiBkb25lIGluICR7dGhpcy5zdGF0ZS5lbmRUaW1lIC0gdGhpcy5zdGF0ZS5zdGFydFRpbWV9bXMgd2l0aCAke3RoaXMuc3RhdGUuY2xpY2tzfSBjbGlja3NgXG4gICAgICApO1xuICAgICAgdGhpcy5zZW5kQ29udGVudE1lc3NhZ2Uoe1xuICAgICAgICB0eXBlOiBcImF1dG9jb25zZW50RG9uZVwiLFxuICAgICAgICBjbXA6IHRoaXMuZm91bmRDbXAubmFtZSxcbiAgICAgICAgaXNDb3NtZXRpYzogdGhpcy5mb3VuZENtcC5pc0Nvc21ldGljLFxuICAgICAgICB1cmw6IGxvY2F0aW9uLmhyZWYsXG4gICAgICAgIGR1cmF0aW9uOiB0aGlzLnN0YXRlLmVuZFRpbWUgLSB0aGlzLnN0YXRlLnN0YXJ0VGltZSxcbiAgICAgICAgdG90YWxDbGlja3M6IHRoaXMuc3RhdGUuY2xpY2tzXG4gICAgICB9KTtcbiAgICAgIHRoaXMudXBkYXRlU3RhdGUoeyBsaWZlY3ljbGU6IFwiZG9uZVwiIH0pO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLnVwZGF0ZVN0YXRlKHsgbGlmZWN5Y2xlOiBvcHRJblJlc3VsdCA/IFwib3B0SW5TdWNjZWVkZWRcIiA6IFwib3B0SW5GYWlsZWRcIiB9KTtcbiAgICB9XG4gICAgdGhpcy5yZXN0b3JlRm9jdXMoKTtcbiAgICByZXR1cm4gb3B0SW5SZXN1bHQ7XG4gIH1cbiAgYXN5bmMgZG9TZWxmVGVzdCgpIHtcbiAgICBjb25zdCBsb2dzQ29uZmlnID0gdGhpcy5jb25maWcubG9ncztcbiAgICBsZXQgc2VsZlRlc3RSZXN1bHQ7XG4gICAgaWYgKCF0aGlzLmZvdW5kQ21wKSB7XG4gICAgICBsb2dzQ29uZmlnLmVycm9ycyAmJiBjb25zb2xlLmxvZyhcIm5vIENNUCB0byBzZWxmIHRlc3RcIik7XG4gICAgICBzZWxmVGVzdFJlc3VsdCA9IGZhbHNlO1xuICAgIH0gZWxzZSB7XG4gICAgICBsb2dzQ29uZmlnLmxpZmVjeWNsZSAmJiBjb25zb2xlLmxvZyhgQ01QICR7dGhpcy5mb3VuZENtcC5uYW1lfTogc2VsZi10ZXN0IG9uICR7d2luZG93LmxvY2F0aW9uLmhyZWZ9YCk7XG4gICAgICBzZWxmVGVzdFJlc3VsdCA9IGF3YWl0IHRoaXMuZm91bmRDbXAudGVzdCgpO1xuICAgIH1cbiAgICB0aGlzLnNlbmRDb250ZW50TWVzc2FnZSh7XG4gICAgICB0eXBlOiBcInNlbGZUZXN0UmVzdWx0XCIsXG4gICAgICBjbXA6IHRoaXMuZm91bmRDbXAgPyB0aGlzLmZvdW5kQ21wLm5hbWUgOiBcIm5vbmVcIixcbiAgICAgIHJlc3VsdDogc2VsZlRlc3RSZXN1bHQsXG4gICAgICB1cmw6IGxvY2F0aW9uLmhyZWZcbiAgICB9KTtcbiAgICB0aGlzLnVwZGF0ZVN0YXRlKHsgc2VsZlRlc3Q6IHNlbGZUZXN0UmVzdWx0IH0pO1xuICAgIHJldHVybiBzZWxmVGVzdFJlc3VsdDtcbiAgfVxuICAvLyBUT0RPOiB1c2UgTXV0YXRpb25PYnNlcnZlciBsaWtlIGluIGZpbmRDbXAoKVxuICBhc3luYyB3YWl0Rm9yUG9wdXAoY21wLCByZXRyaWVzID0gMTAsIGludGVydmFsID0gNTAwKSB7XG4gICAgY29uc3QgbG9nc0NvbmZpZyA9IHRoaXMuY29uZmlnLmxvZ3M7XG4gICAgbG9nc0NvbmZpZy5saWZlY3ljbGUgJiYgY29uc29sZS5sb2coXCJjaGVja2luZyBpZiBwb3B1cCBpcyBvcGVuLi4uXCIsIGNtcC5uYW1lKTtcbiAgICBjb25zdCBpc09wZW4gPSBhd2FpdCBjbXAuZGV0ZWN0UG9wdXAoKS5jYXRjaCgoZSkgPT4ge1xuICAgICAgbG9nc0NvbmZpZy5lcnJvcnMgJiYgY29uc29sZS53YXJuKGBlcnJvciBkZXRlY3RpbmcgcG9wdXAgZm9yICR7Y21wLm5hbWV9YCwgZSk7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfSk7XG4gICAgaWYgKCFpc09wZW4gJiYgcmV0cmllcyA+IDApIHtcbiAgICAgIGF3YWl0IHRoaXMuZG9tQWN0aW9ucy53YWl0KGludGVydmFsKTtcbiAgICAgIHJldHVybiB0aGlzLndhaXRGb3JQb3B1cChjbXAsIHJldHJpZXMgLSAxLCBpbnRlcnZhbCk7XG4gICAgfVxuICAgIGxvZ3NDb25maWcubGlmZWN5Y2xlICYmIGNvbnNvbGUubG9nKGNtcC5uYW1lLCBgcG9wdXAgaXMgJHtpc09wZW4gPyBcIm9wZW5cIiA6IFwibm90IG9wZW5cIn1gKTtcbiAgICByZXR1cm4gaXNPcGVuO1xuICB9XG4gIHByZWhpZGVFbGVtZW50cygpIHtcbiAgICBjb25zdCBsb2dzQ29uZmlnID0gdGhpcy5jb25maWcubG9ncztcbiAgICBjb25zdCBnbG9iYWxIaWRkZW4gPSBbXG4gICAgICBcIiNkaWRvbWktcG9wdXAsLmRpZG9taS1wb3B1cC1jb250YWluZXIsLmRpZG9taS1wb3B1cC1ub3RpY2UsLmRpZG9taS1jb25zZW50LXBvcHVwLXByZWZlcmVuY2VzLCNkaWRvbWktbm90aWNlLC5kaWRvbWktcG9wdXAtYmFja2Ryb3AsLmRpZG9taS1zY3JlZW4tbWVkaXVtXCJcbiAgICBdO1xuICAgIGNvbnN0IHNlbGVjdG9ycyA9IHRoaXMucnVsZXMuZmlsdGVyKChydWxlKSA9PiBydWxlLnByZWhpZGVTZWxlY3RvcnMgJiYgcnVsZS5jaGVja1J1bkNvbnRleHQoKSkucmVkdWNlKChzZWxlY3Rvckxpc3QsIHJ1bGUpID0+IFsuLi5zZWxlY3Rvckxpc3QgfHwgW10sIC4uLnJ1bGUucHJlaGlkZVNlbGVjdG9ycyB8fCBbXV0sIGdsb2JhbEhpZGRlbik7XG4gICAgdGhpcy51cGRhdGVTdGF0ZSh7IHByZWhpZGVPbjogdHJ1ZSB9KTtcbiAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgIGlmICh0aGlzLnNob3VsZFByZWhpZGUgJiYgdGhpcy5zdGF0ZS5wcmVoaWRlT24gJiYgIVtcInJ1bm5pbmdPcHRPdXRcIiwgXCJydW5uaW5nT3B0SW5cIl0uaW5jbHVkZXModGhpcy5zdGF0ZS5saWZlY3ljbGUpKSB7XG4gICAgICAgIGxvZ3NDb25maWcubGlmZWN5Y2xlICYmIGNvbnNvbGUubG9nKFwiUHJvY2VzcyBpcyB0YWtpbmcgdG9vIGxvbmcsIHVuaGlkaW5nIGVsZW1lbnRzXCIpO1xuICAgICAgICB0aGlzLnVuZG9QcmVoaWRlKCk7XG4gICAgICB9XG4gICAgfSwgdGhpcy5jb25maWcucHJlaGlkZVRpbWVvdXQgfHwgMmUzKTtcbiAgICByZXR1cm4gdGhpcy5kb21BY3Rpb25zLnByZWhpZGUoc2VsZWN0b3JzLmpvaW4oXCIsXCIpKTtcbiAgfVxuICB1bmRvUHJlaGlkZSgpIHtcbiAgICB0aGlzLnVwZGF0ZVN0YXRlKHsgcHJlaGlkZU9uOiBmYWxzZSB9KTtcbiAgICB0aGlzLmRvbUFjdGlvbnMudW5kb1ByZWhpZGUoKTtcbiAgfVxuICB1bmRvQ29zbWV0aWNzKCkge1xuICB9XG4gIHJlcG9ydEZpbHRlcmxpc3QoKSB7XG4gICAgdGhpcy5zZW5kQ29udGVudE1lc3NhZ2Uoe1xuICAgICAgdHlwZTogXCJjbXBEZXRlY3RlZFwiLFxuICAgICAgdXJsOiBsb2NhdGlvbi5ocmVmLFxuICAgICAgY21wOiBcImZpbHRlckxpc3RcIlxuICAgIH0pO1xuICAgIHRoaXMuc2VuZENvbnRlbnRNZXNzYWdlKHtcbiAgICAgIHR5cGU6IFwicG9wdXBGb3VuZFwiLFxuICAgICAgY21wOiBcImZpbHRlckxpc3RcIixcbiAgICAgIHVybDogbG9jYXRpb24uaHJlZlxuICAgIH0pO1xuICAgIHRoaXMudXBkYXRlU3RhdGUoeyBmaWx0ZXJMaXN0UmVwb3J0ZWQ6IHRydWUgfSk7XG4gIH1cbiAgZmlsdGVyTGlzdEZhbGxiYWNrKCkge1xuICAgIHRoaXMudXBkYXRlU3RhdGUoeyBsaWZlY3ljbGU6IFwibm90aGluZ0RldGVjdGVkXCIgfSk7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIHVwZGF0ZVN0YXRlKGNoYW5nZSkge1xuICAgIE9iamVjdC5hc3NpZ24odGhpcy5zdGF0ZSwgY2hhbmdlKTtcbiAgICB0aGlzLnNlbmRDb250ZW50TWVzc2FnZSh7XG4gICAgICB0eXBlOiBcInJlcG9ydFwiLFxuICAgICAgaW5zdGFuY2VJZDogdGhpcy5pZCxcbiAgICAgIHVybDogd2luZG93LmxvY2F0aW9uLmhyZWYsXG4gICAgICBtYWluRnJhbWU6IGlzVG9wRnJhbWUoKSxcbiAgICAgIHN0YXRlOiB0aGlzLnN0YXRlXG4gICAgfSk7XG4gIH1cbiAgYXN5bmMgcmVjZWl2ZU1lc3NhZ2VDYWxsYmFjayhtZXNzYWdlKSB7XG4gICAgY29uc3QgbG9nc0NvbmZpZyA9IF9fcHJpdmF0ZUdldCh0aGlzLCBfY29uZmlnKT8ubG9ncztcbiAgICBpZiAobG9nc0NvbmZpZz8ubWVzc2FnZXMpIHtcbiAgICAgIGNvbnNvbGUubG9nKFwicmVjZWl2ZWQgZnJvbSBiYWNrZ3JvdW5kXCIsIG1lc3NhZ2UsIHdpbmRvdy5sb2NhdGlvbi5ocmVmKTtcbiAgICB9XG4gICAgc3dpdGNoIChtZXNzYWdlLnR5cGUpIHtcbiAgICAgIGNhc2UgXCJpbml0UmVzcFwiOlxuICAgICAgICB0aGlzLmluaXRpYWxpemUobWVzc2FnZS5jb25maWcsIG1lc3NhZ2UucnVsZXMpO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgXCJvcHRJblwiOlxuICAgICAgICBhd2FpdCB0aGlzLmRvT3B0SW4oKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlIFwib3B0T3V0XCI6XG4gICAgICAgIGF3YWl0IHRoaXMuZG9PcHRPdXQoKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlIFwic2VsZlRlc3RcIjpcbiAgICAgICAgYXdhaXQgdGhpcy5kb1NlbGZUZXN0KCk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSBcImV2YWxSZXNwXCI6XG4gICAgICAgIHJlc29sdmVFdmFsKG1lc3NhZ2UuaWQsIG1lc3NhZ2UucmVzdWx0KTtcbiAgICAgICAgYnJlYWs7XG4gICAgfVxuICB9XG59O1xuX2NvbmZpZyA9IG5ldyBXZWFrTWFwKCk7XG5leHBvcnQge1xuICBkZWNvZGVSdWxlcyxcbiAgQXV0b0NvbnNlbnQgYXMgZGVmYXVsdCxcbiAgZW5jb2RlUnVsZXMsXG4gIHNuaXBwZXRzIGFzIGV2YWxTbmlwcGV0cyxcbiAgZmlsdGVyQ29tcGFjdFJ1bGVzXG59O1xuIiwgImltcG9ydCB7IGZpbHRlckNvbXBhY3RSdWxlcywgZXZhbFNuaXBwZXRzIH0gZnJvbSAnQGR1Y2tkdWNrZ28vYXV0b2NvbnNlbnQnO1xuaW1wb3J0IGJyb3dzZXIgZnJvbSAnd2ViZXh0ZW5zaW9uLXBvbHlmaWxsJztcbmltcG9ydCB7IHJlZ2lzdGVyQ29udGVudFNjcmlwdHMgfSBmcm9tICcuL212My1jb250ZW50LXNjcmlwdC1pbmplY3Rpb24nO1xuaW1wb3J0IHsgZ2V0RnJvbVNlc3Npb25TdG9yYWdlLCBzZXRUb1Nlc3Npb25TdG9yYWdlLCBjcmVhdGVBbGFybSB9IGZyb20gJy4uL3dyYXBwZXInO1xuaW1wb3J0IHsgcmVnaXN0ZXJNZXNzYWdlSGFuZGxlciB9IGZyb20gJy4uL21lc3NhZ2UtcmVnaXN0cnknO1xuXG4vKipcbiAqIEB0eXBlZGVmIHtpbXBvcnQoJy4uL3RhYi1tYW5hZ2VyLmpzJyl9IFRhYk1hbmFnZXJcbiAqL1xuXG4vKipcbiAqIEB0eXBlZGVmIHtPYmplY3R9IENwbVN0YXRlXG4gKiBAcHJvcGVydHkge1NldDxzdHJpbmc+fSBzaXRlc05vdGlmaWVkQ2FjaGVcbiAqIEBwcm9wZXJ0eSB7e1xuICogIHBhdHRlcm5zOiBTZXQ8c3RyaW5nPixcbiAqICBvbmx5UnVsZXM6IFNldDxzdHJpbmc+LFxuICogIGJvdGg6IFNldDxzdHJpbmc+LFxuICogfX0gZGV0ZWN0aW9uQ2FjaGVcbiAqIEBwcm9wZXJ0eSB7UmVjb3JkPHN0cmluZywgbnVtYmVyPn0gc3VtbWFyeUV2ZW50c1xuICovXG5cbi8qKlxuICogQHR5cGVkZWYge09iamVjdH0gQ3BtRGFzaGJvYXJkU3RhdGVcbiAqIEBwcm9wZXJ0eSB7Ym9vbGVhbn0gY29uc2VudE1hbmFnZWRcbiAqIEBwcm9wZXJ0eSB7Ym9vbGVhbj99IGNvc21ldGljXG4gKiBAcHJvcGVydHkge2Jvb2xlYW4/fSBvcHRvdXRGYWlsZWRcbiAqIEBwcm9wZXJ0eSB7Ym9vbGVhbj99IHNlbGZ0ZXN0RmFpbGVkXG4gKiBAcHJvcGVydHkge2Jvb2xlYW4/fSBjb25zZW50UmVsb2FkTG9vcFxuICogQHByb3BlcnR5IHtzdHJpbmc/fSBjb25zZW50UnVsZVxuICogQHByb3BlcnR5IHtib29sZWFuP30gY29uc2VudEhldXJpc3RpY0VuYWJsZWRcbiAqL1xuXG4vKipcbiAqIEJhc2UgaW50ZXJmYWNlIGZvciBDUE0gY29tbXVuaWNhdGlvbnMgd2l0aCB0aGUgXCJicm93c2VyXCIgc2lkZS5cbiAqIEB0eXBlZGVmIHt7XG4gKiAgbG9nTWVzc2FnZTogKG1lc3NhZ2U6IHN0cmluZykgPT4gUHJvbWlzZTx2b2lkPjtcbiAqICByZWZyZXNoRGFzaGJvYXJkU3RhdGU6ICh0YWJJZDogbnVtYmVyLCB1cmw6IHN0cmluZywgZGFzaGJvYXJkU3RhdGU6IFBhcnRpYWw8Q3BtRGFzaGJvYXJkU3RhdGU+KSA9PiBQcm9taXNlPHZvaWQ+O1xuICogIHNob3dDcG1BbmltYXRpb246ICh0YWJJZDogbnVtYmVyLCB0b3BVcmw6IHN0cmluZywgaXNDb3NtZXRpYzogYm9vbGVhbikgPT4gUHJvbWlzZTx2b2lkPjtcbiAqICBub3RpZnlQb3B1cEhhbmRsZWQ6ICh0YWJJZDogbnVtYmVyLCBtc2c6IGltcG9ydCgnQGR1Y2tkdWNrZ28vYXV0b2NvbnNlbnQnKS5Eb25lTWVzc2FnZSkgPT4gUHJvbWlzZTx2b2lkPjtcbiAqICBjaGVja0F1dG9jb25zZW50U2V0dGluZ0VuYWJsZWQ6ICgpID0+IFByb21pc2U8Ym9vbGVhbj47XG4gKiAgY2hlY2tBdXRvY29uc2VudEVuYWJsZWRGb3JTaXRlOiAodXJsOiBzdHJpbmcpID0+IFByb21pc2U8Ym9vbGVhbj47XG4gKiAgY2hlY2tTdWJmZWF0dXJlRW5hYmxlZDogKHN1YmZlYXR1cmVOYW1lOiBzdHJpbmcpID0+IFByb21pc2U8Ym9vbGVhbj47XG4gKiAgc2VuZFBpeGVsOiAocGl4ZWxOYW1lOiBzdHJpbmcsIHR5cGU6ICdzdGFuZGFyZCcgfCAnZGFpbHknLCBwYXJhbXM6IFJlY29yZDxzdHJpbmcsIGFueT4pID0+IFByb21pc2U8dm9pZD47XG4gKiAgcmVmcmVzaFJlbW90ZUNvbmZpZzogKCkgPT4gUHJvbWlzZTxpbXBvcnQoJ0BkdWNrZHVja2dvL3ByaXZhY3ktY29uZmlndXJhdGlvbi9zY2hlbWEvY29uZmlnLnRzJykuQ3VycmVudEdlbmVyaWNDb25maWc/PjtcbiAqIH19IENQTU1lc3NhZ2luZ0Jhc2VcbiAqL1xuXG4vKiBnbG9iYWwgREVCVUcgKi9cblxuLyoqXG4gKiBAdHlwZSB7aW1wb3J0KCdAZHVja2R1Y2tnby9hdXRvY29uc2VudCcpLkNvbmZpZ1snbG9ncyddfVxuICovXG5jb25zdCBsb2dzQ29uZmlnID0ge1xuICAgIGxpZmVjeWNsZTogdHJ1ZSxcbiAgICBkZXRlY3Rpb25zdGVwczogZmFsc2UsXG4gICAgZXJyb3JzOiB0cnVlLFxuICAgIGV2YWxzOiBmYWxzZSxcbiAgICBtZXNzYWdlczogdHJ1ZSxcbiAgICBydWxlc3RlcHM6IHRydWUsXG4gICAgd2FpdHM6IHRydWUsXG59O1xuXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBDb29raWVQcm9tcHRNYW5hZ2VtZW50IHtcbiAgICBzdGF0aWMgU1VNTUFSWV9BTEFSTV9OQU1FID0gJ2NwbS1zdW1tYXJ5JztcbiAgICBzdGF0aWMgU1VNTUFSWV9ERUxBWV9NSU5VVEVTID0gMjtcblxuICAgIC8qKlxuICAgICAqXG4gICAgICogQHBhcmFtIHt7XG4gICAgICogIGNwbU1lc3NhZ2luZzogQ1BNTWVzc2FnaW5nQmFzZVxuICAgICAqIH19IG9wdHNcbiAgICAgKi9cbiAgICBjb25zdHJ1Y3Rvcih7IGNwbU1lc3NhZ2luZyB9KSB7XG4gICAgICAgIHRoaXMuY3BtTWVzc2FnaW5nID0gY3BtTWVzc2FnaW5nO1xuICAgICAgICB0aGlzLnNjaGVkdWxlQ29uZmlnUmVmcmVzaCgpO1xuXG4gICAgICAgIC8vIEVwaGVtZXJhbCBzdGF0ZSBmb3IgcmVsb2FkIGxvb3AgcHJldmVudGlvbi4gV2UgYXNzdW1lIHRoYXQgc2VydmljZSB3b3JrZXIgbmV2ZXIgc2xlZXBzIGR1cmluZyBhIHJlbG9hZCBsb29wLCBzbyB3ZSBkb24ndCBwZXJzaXN0IHRoZXNlLlxuICAgICAgICAvKiogQHR5cGUge01hcDxudW1iZXIsIFVSTD59ICovXG4gICAgICAgIHRoaXMuX3RhYlVybHNDYWNoZSA9IG5ldyBNYXAoKTsgLy8gdG9wIFVSTCBwZXIgdGFiXG4gICAgICAgIC8qKiBAdHlwZSB7TWFwPG51bWJlciwgc3RyaW5nPn0gKi9cbiAgICAgICAgdGhpcy5fbGFzdEhhbmRsZWRDTVAgPSBuZXcgTWFwKCk7IC8vIGxhc3QgaGFuZGxlZCBDTVAgcGVyIHRhYlxuICAgICAgICAvKiogQHR5cGUge1NldDxudW1iZXI+fSAqL1xuICAgICAgICB0aGlzLl9yZWxvYWRMb29wRGV0ZWN0ZWQgPSBuZXcgU2V0KCk7IC8vIHRhYnMgd2l0aCBkZXRlY3RlZCByZWxvYWQgbG9vcHNcblxuICAgICAgICByZWdpc3RlckNvbnRlbnRTY3JpcHRzKFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBpZDogJ2Nvb2tpZS1wcm9tcHQtbWFuYWdlbWVudC1zY3JpcHQnLFxuICAgICAgICAgICAgICAgIGpzOiBbJ3B1YmxpYy9qcy9jb250ZW50LXNjcmlwdHMvY3BtLmpzJ10sXG4gICAgICAgICAgICAgICAgbWF0Y2hlczogWyc8YWxsX3VybHM+J10sXG4gICAgICAgICAgICAgICAgcnVuQXQ6ICdkb2N1bWVudF9lbmQnLFxuICAgICAgICAgICAgICAgIHdvcmxkOiAnSVNPTEFURUQnLFxuICAgICAgICAgICAgICAgIG1hdGNoT3JpZ2luQXNGYWxsYmFjazogdHJ1ZSxcbiAgICAgICAgICAgICAgICBhbGxGcmFtZXM6IHRydWUsXG4gICAgICAgICAgICB9LFxuICAgICAgICBdKTtcblxuICAgICAgICAvLyBxdWV1ZSBmb3IgQ1BNIHN0YXRlIG11dGF0aW9uc1xuICAgICAgICAvKiogQHR5cGUge1Byb21pc2U8dm9pZD59ICovXG4gICAgICAgIHRoaXMuX3N0YXRlUXVldWUgPSBQcm9taXNlLnJlc29sdmUoKTtcbiAgICAgICAgLy8gcmVzdG9yZSB0aGUgY3VycmVudCBDUE0gc3RhdGUgZnJvbSBzdG9yYWdlXG4gICAgICAgIHRoaXMuZ2V0Q3BtU3RhdGUoKTtcblxuICAgICAgICAvLyBTZXQgdXAgYWxhcm0gbGlzdGVuZXIgZm9yIHN1bW1hcnkgcGl4ZWxcbiAgICAgICAgYnJvd3Nlci5hbGFybXMub25BbGFybS5hZGRMaXN0ZW5lcigoYWxhcm0pID0+IHtcbiAgICAgICAgICAgIHRoaXMuY3BtTWVzc2FnaW5nLmxvZ01lc3NhZ2UoYGFsYXJtIHRyaWdnZXJlZDogJHtKU09OLnN0cmluZ2lmeShhbGFybSl9YCk7XG4gICAgICAgICAgICBpZiAoYWxhcm0ubmFtZSA9PT0gQ29va2llUHJvbXB0TWFuYWdlbWVudC5TVU1NQVJZX0FMQVJNX05BTUUpIHtcbiAgICAgICAgICAgICAgICB0aGlzLnNlbmRTdW1tYXJ5UGl4ZWwoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG5cbiAgICAgICAgLy8gbWFrZSBzdXJlIHdlIHNlbmQgdGhlIHN1bW1hcnkgcGl4ZWxzIGJlZm9yZSB0aGUgZXh0ZW5zaW9uIGlzIHVubG9hZGVkXG4gICAgICAgIC8vIE5vdGU6IGJyb3dzZXIucnVudGltZS5vblN1c3BlbmQgaXMgdW5kZWZpbmVkIGluIFdlYktpdFxuICAgICAgICBicm93c2VyLnJ1bnRpbWUub25TdXNwZW5kPy5hZGRMaXN0ZW5lcigoKSA9PiB7XG4gICAgICAgICAgICB0aGlzLnNlbmRTdW1tYXJ5UGl4ZWwoKTtcbiAgICAgICAgfSk7XG5cbiAgICAgICAgLy8gUmVnaXN0ZXIgYXV0b2NvbnNlbnQgbWVzc2FnZSBoYW5kbGVyIHdpdGggdGhlIHNoYXJlZCBtZXNzYWdlIHJlZ2lzdHJ5LlxuICAgICAgICAvLyBNZXNzYWdlUm91dGVyIChpbiBib3RoIHJlZ3VsYXIgYW5kIGVtYmVkZGVkIGJ1aWxkcykgZGlzcGF0Y2hlcyB0byB0aGlzIGhhbmRsZXIuXG4gICAgICAgIHJlZ2lzdGVyTWVzc2FnZUhhbmRsZXIoJ2F1dG9jb25zZW50JywgKG9wdGlvbnMsIHNlbmRlciwgcmVxKSA9PiB7XG4gICAgICAgICAgICBERUJVRyAmJiBjb25zb2xlLmxvZyhgcmVjZWl2ZWQgYXV0b2NvbnNlbnQgbWVzc2FnZTogJHtyZXEuYXV0b2NvbnNlbnRQYXlsb2FkLnR5cGV9YCk7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5oYW5kbGVBdXRvQ29uc2VudE1lc3NhZ2UocmVxLmF1dG9jb25zZW50UGF5bG9hZCwgc2VuZGVyKS50aGVuKCgpID0+IHtcbiAgICAgICAgICAgICAgICBERUJVRyAmJiBjb25zb2xlLmxvZyhgaGFuZGxlZCBhdXRvY29uc2VudCBtZXNzYWdlOiAke3JlcS5hdXRvY29uc2VudFBheWxvYWQudHlwZX1gKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICBzY2hlZHVsZUNvbmZpZ1JlZnJlc2goKSB7XG4gICAgICAgIC8qKiBAdHlwZSB7UHJvbWlzZTxpbXBvcnQoJ0BkdWNrZHVja2dvL3ByaXZhY3ktY29uZmlndXJhdGlvbi9zY2hlbWEvY29uZmlnLnRzJykuQ3VycmVudEdlbmVyaWNDb25maWc/Pn0gKi9cbiAgICAgICAgdGhpcy5yZW1vdGVDb25maWdKc29uID0gdGhpcy5jcG1NZXNzYWdpbmcucmVmcmVzaFJlbW90ZUNvbmZpZygpLmNhdGNoKChlKSA9PiB7XG4gICAgICAgICAgICAvLyBtYWtlIHN1cmUgcmVtb3RlQ29uZmlnSnNvbiBpcyBuZXZlciByZWplY3RlZFxuICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEBwYXJhbSB7b2JqZWN0fSBqc29uQ3BtU3RhdGVcbiAgICAgKiBAcmV0dXJucyB7Q3BtU3RhdGV9XG4gICAgICovXG4gICAgX2Rlc2VyaWFsaXplQ3BtU3RhdGUoanNvbkNwbVN0YXRlKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBzaXRlc05vdGlmaWVkQ2FjaGU6IG5ldyBTZXQoanNvbkNwbVN0YXRlLnNpdGVzTm90aWZpZWRDYWNoZSB8fCBbXSksXG4gICAgICAgICAgICBkZXRlY3Rpb25DYWNoZToge1xuICAgICAgICAgICAgICAgIHBhdHRlcm5zOiBuZXcgU2V0KGpzb25DcG1TdGF0ZS5kZXRlY3Rpb25DYWNoZT8ucGF0dGVybnMgfHwgW10pLFxuICAgICAgICAgICAgICAgIGJvdGg6IG5ldyBTZXQoanNvbkNwbVN0YXRlLmRldGVjdGlvbkNhY2hlPy5ib3RoIHx8IFtdKSxcbiAgICAgICAgICAgICAgICBvbmx5UnVsZXM6IG5ldyBTZXQoanNvbkNwbVN0YXRlLmRldGVjdGlvbkNhY2hlPy5vbmx5UnVsZXMgfHwgW10pLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHN1bW1hcnlFdmVudHM6IHN0cnVjdHVyZWRDbG9uZShqc29uQ3BtU3RhdGUuc3VtbWFyeUV2ZW50cyB8fCB7fSksXG4gICAgICAgIH07XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQHBhcmFtIHtDcG1TdGF0ZX0gY3BtU3RhdGVcbiAgICAgKiBAcmV0dXJucyB7b2JqZWN0fVxuICAgICAqL1xuICAgIF9zZXJpYWxpemVDcG1TdGF0ZShjcG1TdGF0ZSkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgc2l0ZXNOb3RpZmllZENhY2hlOiBBcnJheS5mcm9tKGNwbVN0YXRlLnNpdGVzTm90aWZpZWRDYWNoZSksXG4gICAgICAgICAgICBkZXRlY3Rpb25DYWNoZToge1xuICAgICAgICAgICAgICAgIHBhdHRlcm5zOiBBcnJheS5mcm9tKGNwbVN0YXRlLmRldGVjdGlvbkNhY2hlLnBhdHRlcm5zKSxcbiAgICAgICAgICAgICAgICBib3RoOiBBcnJheS5mcm9tKGNwbVN0YXRlLmRldGVjdGlvbkNhY2hlLmJvdGgpLFxuICAgICAgICAgICAgICAgIG9ubHlSdWxlczogQXJyYXkuZnJvbShjcG1TdGF0ZS5kZXRlY3Rpb25DYWNoZS5vbmx5UnVsZXMpLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHN1bW1hcnlFdmVudHM6IHN0cnVjdHVyZWRDbG9uZShjcG1TdGF0ZS5zdW1tYXJ5RXZlbnRzKSxcbiAgICAgICAgfTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBAcmV0dXJucyB7UHJvbWlzZTxDcG1TdGF0ZT59XG4gICAgICovXG4gICAgYXN5bmMgZ2V0Q3BtU3RhdGUoKSB7XG4gICAgICAgIGlmICghdGhpcy5fanNvbkNwbVN0YXRlKSB7XG4gICAgICAgICAgICB0aGlzLl9qc29uQ3BtU3RhdGUgPSAoYXdhaXQgZ2V0RnJvbVNlc3Npb25TdG9yYWdlKCdjcG1TdGF0ZScpKSB8fCB7XG4gICAgICAgICAgICAgICAgc2l0ZXNOb3RpZmllZENhY2hlOiBbXSxcbiAgICAgICAgICAgICAgICBkZXRlY3Rpb25DYWNoZToge1xuICAgICAgICAgICAgICAgICAgICBwYXR0ZXJuczogW10sXG4gICAgICAgICAgICAgICAgICAgIGJvdGg6IFtdLFxuICAgICAgICAgICAgICAgICAgICBvbmx5UnVsZXM6IFtdLFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgc3VtbWFyeUV2ZW50czoge30sXG4gICAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzLl9kZXNlcmlhbGl6ZUNwbVN0YXRlKHRoaXMuX2pzb25DcG1TdGF0ZSk7XG4gICAgfVxuXG4gICAgY2hlY2tIZXVyaXN0aWNBY3Rpb25FbmFibGVkKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5jcG1NZXNzYWdpbmcuY2hlY2tTdWJmZWF0dXJlRW5hYmxlZCgnaGV1cmlzdGljQWN0aW9uJyk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQHBhcmFtIHtDcG1TdGF0ZX0gbmV3U3RhdGVcbiAgICAgKi9cbiAgICBhc3luYyB1cGRhdGVDcG1TdGF0ZShuZXdTdGF0ZSkge1xuICAgICAgICB0aGlzLl9qc29uQ3BtU3RhdGUgPSB0aGlzLl9zZXJpYWxpemVDcG1TdGF0ZShuZXdTdGF0ZSk7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBhd2FpdCBzZXRUb1Nlc3Npb25TdG9yYWdlKCdjcG1TdGF0ZScsIHRoaXMuX2pzb25DcG1TdGF0ZSk7XG4gICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgIC8vIHRoaXMgY2FuIGhhcHBlbiBpZiBxdW90YSBpcyBleGNlZWRlZFxuICAgICAgICAgICAgdGhpcy5jcG1NZXNzYWdpbmcubG9nTWVzc2FnZShgZXJyb3Igc2V0dGluZyBjcG1TdGF0ZSB0byBzZXNzaW9uIHN0b3JhZ2U6ICR7ZX1gKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEF0b21pY2FsbHkgcmVhZC1tb2RpZnktd3JpdGUgdGhlIENQTSBzdGF0ZS5cbiAgICAgKiBBbGwgc3RhdGUgbXV0YXRpb25zIGFyZSBzZXJpYWxpemVkIHRocm91Z2ggdGhpcyBtZXRob2QgdG8gcHJldmVudCByYWNlIGNvbmRpdGlvbnNcbiAgICAgKiBiZXR3ZWVuIHBhcmFsbGVsIG1lc3NhZ2UgaGFuZGxlcnMuXG4gICAgICpcbiAgICAgKiBJTVBPUlRBTlQ6IFRoZSBjYWxsYmFjayBtdXN0IE5PVCBhd2FpdCBvdGhlciBtZXRob2RzIHRoYXQgY2FsbFxuICAgICAqIG1vZGlmeUNwbVN0YXRlIChlLmcuIGZpcmVQaXhlbCksIGFzIHRoYXQgd291bGQgZGVhZGxvY2sgdGhlIHF1ZXVlLlxuICAgICAqIE5vbi1hd2FpdGVkIGNhbGxzIGFyZSBmaW5lIC0tIHRoZXkgc2ltcGx5IHF1ZXVlIHVwIGFmdGVyIHRoZSBjdXJyZW50IG9wZXJhdGlvbi5cbiAgICAgKlxuICAgICAqIEBwYXJhbSB7KHN0YXRlOiBDcG1TdGF0ZSkgPT4gdm9pZCB8IFByb21pc2U8dm9pZD59IGZuXG4gICAgICogQHJldHVybnMge1Byb21pc2U8dm9pZD59XG4gICAgICovXG4gICAgbW9kaWZ5Q3BtU3RhdGUoZm4pIHtcbiAgICAgICAgY29uc3Qgb3AgPSB0aGlzLl9zdGF0ZVF1ZXVlLnRoZW4oYXN5bmMgKCkgPT4ge1xuICAgICAgICAgICAgY29uc3Qgc3RhdGUgPSBhd2FpdCB0aGlzLmdldENwbVN0YXRlKCk7XG4gICAgICAgICAgICBhd2FpdCBmbihzdGF0ZSk7XG4gICAgICAgICAgICBhd2FpdCB0aGlzLnVwZGF0ZUNwbVN0YXRlKHN0YXRlKTtcbiAgICAgICAgfSk7XG4gICAgICAgIC8vIGlnbm9yZSBlcnJvcnMgZnJvbSB0aGUgcXVldWVcbiAgICAgICAgdGhpcy5fc3RhdGVRdWV1ZSA9IG9wLmNhdGNoKChlKSA9PiB7XG4gICAgICAgICAgICB0aGlzLmNwbU1lc3NhZ2luZy5sb2dNZXNzYWdlKGBlcnJvciBpbiBzdGF0ZSBxdWV1ZTogJHtlfWApO1xuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIG9wO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEBwYXJhbSB7bnVtYmVyfSB0YWJJZFxuICAgICAqL1xuICAgIGNsZWFyUmVsb2FkTG9vcFN0YXRlKHRhYklkKSB7XG4gICAgICAgIHRoaXMuX2xhc3RIYW5kbGVkQ01QLmRlbGV0ZSh0YWJJZCk7XG4gICAgICAgIHRoaXMuX3JlbG9hZExvb3BEZXRlY3RlZC5kZWxldGUodGFiSWQpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEBwYXJhbSB7bnVtYmVyfSB0YWJJZFxuICAgICAqIEBwYXJhbSB7c3RyaW5nfSB1cmxcbiAgICAgKiBAcmV0dXJucyB7VVJMfVxuICAgICAqL1xuICAgIHVwZGF0ZVRvcFVybCh0YWJJZCwgdXJsKSB7XG4gICAgICAgIGNvbnN0IG9sZFRvcFVybCA9IHRoaXMuX3RhYlVybHNDYWNoZS5nZXQodGFiSWQpIHx8IG5ldyBVUkwoJ2Fib3V0OmJsYW5rJyk7XG4gICAgICAgIGxldCBuZXdUb3BVcmwgPSBudWxsO1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgbmV3VG9wVXJsID0gbmV3IFVSTCh1cmwpO1xuICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgICB0aGlzLmNwbU1lc3NhZ2luZy5sb2dNZXNzYWdlKGBpbnZhbGlkIHRvcCBVUkw6ICR7dXJsfTogJHtlfWApO1xuICAgICAgICAgICAgcmV0dXJuIG9sZFRvcFVybDtcbiAgICAgICAgfVxuXG4gICAgICAgIERFQlVHICYmIHRoaXMuY3BtTWVzc2FnaW5nLmxvZ01lc3NhZ2UoYCR7dGFiSWR9IE1haW4gZnJhbWUgbmF2aWdhdGVkIGZyb20gJHtvbGRUb3BVcmx9IHRvICR7bmV3VG9wVXJsfWApO1xuICAgICAgICBpZiAob2xkVG9wVXJsLmhvc3QgIT09IG5ld1RvcFVybC5ob3N0IHx8IG9sZFRvcFVybC5wYXRobmFtZSAhPT0gbmV3VG9wVXJsLnBhdGhuYW1lIHx8IG9sZFRvcFVybC5wcm90b2NvbCAhPT0gbmV3VG9wVXJsLnByb3RvY29sKSB7XG4gICAgICAgICAgICAvLyB1cmwgaGFzIGNoYW5nZWQgKGFzIGZhciBhcyByZWxvYWQgbG9vcCBwcmV2ZW50aW9uIGlzIGNvbmNlcm5lZClcbiAgICAgICAgICAgIHRoaXMuY2xlYXJSZWxvYWRMb29wU3RhdGUodGFiSWQpO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuX3RhYlVybHNDYWNoZS5zZXQodGFiSWQsIG5ld1RvcFVybCk7XG4gICAgICAgIHJldHVybiBuZXdUb3BVcmw7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQHBhcmFtIHtudW1iZXJ9IHRhYklkXG4gICAgICogQHBhcmFtIHtzdHJpbmd9IGNtcFxuICAgICAqIEBwYXJhbSB7Ym9vbGVhbn0gaXNDb3NtZXRpY1xuICAgICAqL1xuICAgIHJlbWVtYmVyTGFzdEhhbmRsZWRDTVAodGFiSWQsIGNtcCwgaXNDb3NtZXRpYykge1xuICAgICAgICBpZiAoaXNDb3NtZXRpYykge1xuICAgICAgICAgICAgLy8gQ29zbWV0aWMgcnVsZXMgY2FuIHRyaWdnZXIgb24gZXZlcnkgcGFnZSBsb2FkIGFuZCBuZXZlciBjYXVzZSByZWxvYWQgbG9vcHNcbiAgICAgICAgICAgIERFQlVHICYmIGNvbnNvbGUubG9nKCdjb3NtZXRpYyBydWxlIGhhbmRsZWQsIG5vdCBzdG9yaW5nIGZvciByZWxvYWQgbG9vcCBkZXRlY3Rpb24nLCB0YWJJZCwgY21wKTtcbiAgICAgICAgICAgIHRoaXMuY2xlYXJSZWxvYWRMb29wU3RhdGUodGFiSWQpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGxhc3RIYW5kbGVkQ01QID0gdGhpcy5fbGFzdEhhbmRsZWRDTVAuZ2V0KHRhYklkKTtcbiAgICAgICAgaWYgKGxhc3RIYW5kbGVkQ01QICE9PSBjbXApIHtcbiAgICAgICAgICAgIC8vIFRoZSBsYXN0IGhhbmRsZWQgQ01QIGlzIGRpZmZlcmVudCBmcm9tIHRoZSBjdXJyZW50IG9uZSwgc28gd2UgbmVlZCB0byBjbGVhciB0aGUgcmVsb2FkIGxvb3Agc3RhdGVcbiAgICAgICAgICAgIERFQlVHICYmIGNvbnNvbGUubG9nKCdsYXN0IGhhbmRsZWQgQ01QIGlzIGNoYW5nZWQgZnJvbScsIGxhc3RIYW5kbGVkQ01QLCAndG8nLCBjbXAsICdjbGVhcmluZyByZWxvYWQgbG9vcCBzdGF0ZScsIHRhYklkKTtcbiAgICAgICAgICAgIHRoaXMuY2xlYXJSZWxvYWRMb29wU3RhdGUodGFiSWQpO1xuICAgICAgICB9XG4gICAgICAgIERFQlVHICYmIGNvbnNvbGUubG9nKCdyZWNvcmRpbmcgcG9wdXAgaGFuZGxlZDogQ01QJywgY21wLCAnb24nLCB0aGlzLl90YWJVcmxzQ2FjaGUuZ2V0KHRhYklkKSwgJ3RhYklkOicsIHRhYklkKTtcbiAgICAgICAgdGhpcy5fbGFzdEhhbmRsZWRDTVAuc2V0KHRhYklkLCBjbXApO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEBwYXJhbSB7bnVtYmVyfSB0YWJJZFxuICAgICAqIEBwYXJhbSB7c3RyaW5nfSBjbXBcbiAgICAgKi9cbiAgICBkZXRlY3RSZWxvYWRMb29wKHRhYklkLCBjbXApIHtcbiAgICAgICAgLy8gUmVsb2FkIGxvb3AgaXMgd2hlbiB3ZSBjYXRjaCB0aGUgc2FtZSBDTVAgZnJvbSB0aGUgc2FtZSB0b3AgVVJMIHdpdGhvdXQgYSBuYXZpZ2F0aW9uIGluIGJldHdlZW4uXG4gICAgICAgIC8vIEF0IHRoaXMgcG9pbnQgd2Uga25vdyB0aGF0IHRoZSB0b3AgVVJMIGhhc24ndCBjaGFuZ2VkICh0aGF0J3MgdHJhY2tlZCBpbiB1cGRhdGVUb3BVcmwpLCBzbyB3ZSBjYW4ganVzdCBjaGVjayB0aGUgQ01QIG5hbWUuXG4gICAgICAgIGNvbnN0IGxhc3RIYW5kbGVkQ01QID0gdGhpcy5fbGFzdEhhbmRsZWRDTVAuZ2V0KHRhYklkKTtcbiAgICAgICAgaWYgKCF0aGlzLl9yZWxvYWRMb29wRGV0ZWN0ZWQuaGFzKHRhYklkKSAmJiBsYXN0SGFuZGxlZENNUCA9PT0gY21wKSB7XG4gICAgICAgICAgICAvLyBTYW1lIENNUCBkZXRlY3RlZCBvbiBzYW1lIFVSTCBhZnRlciBpdCB3YXMgYWxyZWFkeSBoYW5kbGVkIC0gcmVsb2FkIGxvb3AgZGV0ZWN0ZWRcbiAgICAgICAgICAgIHRoaXMuY3BtTWVzc2FnaW5nLmxvZ01lc3NhZ2UoYHJlbG9hZCBsb29wIGRldGVjdGVkOiAke2NtcH0gb24gJHt0aGlzLl90YWJVcmxzQ2FjaGUuZ2V0KHRhYklkKX0gdGFiSWQ6ICR7dGFiSWR9YCk7XG4gICAgICAgICAgICB0aGlzLl9yZWxvYWRMb29wRGV0ZWN0ZWQuYWRkKHRhYklkKTtcbiAgICAgICAgICAgIHRoaXMuZmlyZVBpeGVsKCdlcnJvcl9yZWxvYWQtbG9vcCcpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICpcbiAgICAgKiBAcGFyYW0ge2ltcG9ydCgnQGR1Y2tkdWNrZ28vYXV0b2NvbnNlbnQnKS5Db250ZW50U2NyaXB0TWVzc2FnZX0gbXNnXG4gICAgICogQHBhcmFtIHticm93c2VyLlJ1bnRpbWUuTWVzc2FnZVNlbmRlcn0gc2VuZGVyXG4gICAgICogQHJldHVybnNcbiAgICAgKi9cbiAgICBhc3luYyBoYW5kbGVBdXRvQ29uc2VudE1lc3NhZ2UobXNnLCBzZW5kZXIpIHtcbiAgICAgICAgY29uc3QgZnJhbWVJZCA9IHNlbmRlci5mcmFtZUlkO1xuICAgICAgICBpZiAoIXNlbmRlci50YWIgfHwgdHlwZW9mIGZyYW1lSWQgIT09ICdudW1iZXInKSB7XG4gICAgICAgICAgICB0aGlzLmNwbU1lc3NhZ2luZy5sb2dNZXNzYWdlKGBJbnZhbGlkIGZyYW1lSWQgJHtmcmFtZUlkfSBvciB0YWIgJHtzZW5kZXIudGFifWApO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHRhYklkID0gc2VuZGVyLnRhYi5pZDtcbiAgICAgICAgaWYgKHR5cGVvZiB0YWJJZCAhPT0gJ251bWJlcicpIHtcbiAgICAgICAgICAgIHRoaXMuY3BtTWVzc2FnaW5nLmxvZ01lc3NhZ2UoYEludmFsaWQgdGFiSWQgJHt0YWJJZH1gKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBpc01haW5GcmFtZSA9IGZyYW1lSWQgPT09IDA7XG4gICAgICAgIC8vIEB0cy1leHBlY3QtZXJyb3IgLSBvcmlnaW4gaXMgbm90IGF2YWlsYWJsZSBpbiB0aGUgdHlwZVxuICAgICAgICBjb25zdCBmcmFtZVVybCA9IHNlbmRlci51cmwgfHwgc2VuZGVyLm9yaWdpbiB8fCAnYWJvdXQ6YmxhbmsnO1xuICAgICAgICBjb25zdCB0YWJVcmwgPSBzZW5kZXIudGFiLnVybCB8fCBzZW5kZXIudGFiLnBlbmRpbmdVcmwgfHwgJ2Fib3V0OmJsYW5rJztcbiAgICAgICAgbGV0IHRhYkRvbWFpbiA9IG51bGw7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICB0YWJEb21haW4gPSBuZXcgVVJMKHRhYlVybCkuaG9zdG5hbWU7XG4gICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgIHRoaXMuY3BtTWVzc2FnaW5nLmxvZ01lc3NhZ2UoYGVycm9yIGdldHRpbmcgdGFiIGRvbWFpbjogJHtlfWApO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gdXNlIHRoZSBjYWNoZWQgY29uZmlnXG4gICAgICAgIGNvbnN0IHJlbW90ZUNvbmZpZyA9IGF3YWl0IHRoaXMucmVtb3RlQ29uZmlnSnNvbjtcbiAgICAgICAgaWYgKCFyZW1vdGVDb25maWcpIHtcbiAgICAgICAgICAgIHRoaXMuY3BtTWVzc2FnaW5nLmxvZ01lc3NhZ2UoJ1JlbW90ZSBjb25maWcgbm90IHJlYWR5LCBzY2hlZHVsaW5nIHJldHJ5Jyk7XG4gICAgICAgICAgICB0aGlzLnNjaGVkdWxlQ29uZmlnUmVmcmVzaCgpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGF1dG9jb25zZW50UmVtb3RlQ29uZmlnID0gcmVtb3RlQ29uZmlnLmZlYXR1cmVzPy5hdXRvY29uc2VudDtcbiAgICAgICAgY29uc3QgYXV0b2NvbnNlbnRTZXR0aW5ncyA9IGF1dG9jb25zZW50UmVtb3RlQ29uZmlnPy5zZXR0aW5ncztcbiAgICAgICAgREVCVUcgJiZcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFxuICAgICAgICAgICAgICAgICdyZWNlaXZlZCBhdXRvY29uc2VudCBtZXNzYWdlJyxcbiAgICAgICAgICAgICAgICBtc2cudHlwZSxcbiAgICAgICAgICAgICAgICBtc2csXG4gICAgICAgICAgICAgICAgJ3NlbmRlcjonLFxuICAgICAgICAgICAgICAgIHNlbmRlcixcbiAgICAgICAgICAgICAgICAnYXV0b2NvbnNlbnRSZW1vdGVDb25maWc6JyxcbiAgICAgICAgICAgICAgICBhdXRvY29uc2VudFJlbW90ZUNvbmZpZyxcbiAgICAgICAgICAgICk7XG5cbiAgICAgICAgaWYgKCFhdXRvY29uc2VudFNldHRpbmdzKSB7XG4gICAgICAgICAgICB0aGlzLmNwbU1lc3NhZ2luZy5sb2dNZXNzYWdlKGBhdXRvY29uc2VudFNldHRpbmdzIG5vdCByZWFkeTogJHthdXRvY29uc2VudFNldHRpbmdzfWApO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGF1dG9jb25zZW50RmVhdHVyZUVuYWJsZWQgPSBhd2FpdCB0aGlzLmNwbU1lc3NhZ2luZy5jaGVja0F1dG9jb25zZW50U2V0dGluZ0VuYWJsZWQoKTtcbiAgICAgICAgaWYgKCFhdXRvY29uc2VudEZlYXR1cmVFbmFibGVkKSB7XG4gICAgICAgICAgICB0aGlzLmNwbU1lc3NhZ2luZy5sb2dNZXNzYWdlKCdhdXRvY29uc2VudCBzZXR0aW5nIG5vdCBlbmFibGVkJyk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgaGV1cmlzdGljQWN0aW9uRW5hYmxlZCA9IGF3YWl0IHRoaXMuY2hlY2tIZXVyaXN0aWNBY3Rpb25FbmFibGVkKCk7XG5cbiAgICAgICAgc3dpdGNoIChtc2cudHlwZSkge1xuICAgICAgICAgICAgY2FzZSAnaW5pdCc6IHtcbiAgICAgICAgICAgICAgICAvLyBkbyB0aGUgbmF2aWdhdGlvbiBjaGVjayBiZWZvcmUgY2hlY2tpbmcgaWYgdGhlIGRvbWFpbiBpcyBhbGxvd2xpc3RlZFxuICAgICAgICAgICAgICAgIGlmIChpc01haW5GcmFtZSkge1xuICAgICAgICAgICAgICAgICAgICAvLyB1cGRhdGUgdGhlIGNhY2hlZCB0b3AgdXJsIGZvciB0aGlzIHRhYlxuICAgICAgICAgICAgICAgICAgICB0aGlzLnVwZGF0ZVRvcFVybCh0YWJJZCwgdGFiVXJsKTtcbiAgICAgICAgICAgICAgICAgICAgLy8gc2NoZWR1bGUgY29uZmlnIHJlZnJlc2ggKHdpbGwgYmUgdXNlZCBuZXh0IHRpbWUpXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc2NoZWR1bGVDb25maWdSZWZyZXNoKCk7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgY29uc3QgaXNFbmFibGVkID0gYXdhaXQgdGhpcy5jcG1NZXNzYWdpbmcuY2hlY2tBdXRvY29uc2VudEVuYWJsZWRGb3JTaXRlKHRhYlVybCk7XG4gICAgICAgICAgICAgICAgaWYgKCFpc0VuYWJsZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5jcG1NZXNzYWdpbmcubG9nTWVzc2FnZShgYXV0b2NvbnNlbnQgZGlzYWJsZWQgZm9yIHNpdGU6ICR7dGFiVXJsfWApO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmZpcmVQaXhlbCgnZGlzYWJsZWQtZm9yLXNpdGUnKTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIGNvbnN0IHZpc3VhbFRlc3QgPSBERUJVRztcblxuICAgICAgICAgICAgICAgIC8qKiBAdHlwZSB7aW1wb3J0KCdAZHVja2R1Y2tnby9hdXRvY29uc2VudCcpLkNvbmZpZ1snYXV0b0FjdGlvbiddfSAqL1xuICAgICAgICAgICAgICAgIGxldCBhdXRvQWN0aW9uID0gJ29wdE91dCc7XG4gICAgICAgICAgICAgICAgLy8gZGlzYWJsZSBhdXRvQWN0aW9uIGluIGNhc2Ugb2YgcmVsb2FkIGxvb3BcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5fcmVsb2FkTG9vcERldGVjdGVkLmhhcyh0YWJJZCkpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5jcG1NZXNzYWdpbmcubG9nTWVzc2FnZShgcmVsb2FkIGxvb3AgZGV0ZWN0ZWQsIGRpc2FibGluZyBhdXRvQWN0aW9uOiAke3RhYklkfWApO1xuICAgICAgICAgICAgICAgICAgICBhdXRvQWN0aW9uID0gbnVsbDtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICBpZiAoaXNNYWluRnJhbWUpIHtcbiAgICAgICAgICAgICAgICAgICAgLy8gbm8gYXdhaXRcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5jcG1NZXNzYWdpbmcucmVmcmVzaERhc2hib2FyZFN0YXRlKHRhYklkLCB0YWJVcmwsIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIGtlZXAgXCJjb29raWVzIG1hbmFnZWRcIiBpZiB3ZSBkaWQgaXQgZm9yIHRoaXMgc2l0ZSBzaW5jZSBhcHAgbGF1bmNoXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zZW50TWFuYWdlZDogKGF3YWl0IHRoaXMuZ2V0Q3BtU3RhdGUoKSkuc2l0ZXNOb3RpZmllZENhY2hlLmhhcyh0YWJEb21haW4pLFxuICAgICAgICAgICAgICAgICAgICAgICAgY29zbWV0aWM6IG51bGwsXG4gICAgICAgICAgICAgICAgICAgICAgICBvcHRvdXRGYWlsZWQ6IG51bGwsXG4gICAgICAgICAgICAgICAgICAgICAgICBzZWxmdGVzdEZhaWxlZDogbnVsbCxcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNlbnRSZWxvYWRMb29wOiB0aGlzLl9yZWxvYWRMb29wRGV0ZWN0ZWQuaGFzKHRhYklkKSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNlbnRSdWxlOiB0aGlzLl9sYXN0SGFuZGxlZENNUC5nZXQodGFiSWQpIHx8IG51bGwsXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zZW50SGV1cmlzdGljRW5hYmxlZDogaGV1cmlzdGljQWN0aW9uRW5hYmxlZCxcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIC8vIG5vIGF3YWl0XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuZmlyZVBpeGVsKCdpbml0Jyk7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgLyoqXG4gICAgICAgICAgICAgICAgICogQHR5cGUge1BhcnRpYWw8aW1wb3J0KCdAZHVja2R1Y2tnby9hdXRvY29uc2VudCcpLkNvbmZpZz59XG4gICAgICAgICAgICAgICAgICovXG4gICAgICAgICAgICAgICAgY29uc3QgYXV0b2NvbnNlbnRDb25maWcgPSB7XG4gICAgICAgICAgICAgICAgICAgIGVuYWJsZWQ6IGlzRW5hYmxlZCxcbiAgICAgICAgICAgICAgICAgICAgYXV0b0FjdGlvbixcbiAgICAgICAgICAgICAgICAgICAgZGV0ZWN0UmV0cmllczogMjAsXG4gICAgICAgICAgICAgICAgICAgIGlzTWFpbldvcmxkOiBmYWxzZSxcbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWRDbXBzOiBhdXRvY29uc2VudFNldHRpbmdzLmRpc2FibGVkQ01QcyB8fCBbXSxcbiAgICAgICAgICAgICAgICAgICAgZW5hYmxlUHJlaGlkZTogdHJ1ZSxcbiAgICAgICAgICAgICAgICAgICAgcHJlaGlkZVRpbWVvdXQ6IDIwMDAsXG4gICAgICAgICAgICAgICAgICAgIGVuYWJsZUNvc21ldGljUnVsZXM6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgIGVuYWJsZUdlbmVyYXRlZFJ1bGVzOiB0cnVlLFxuICAgICAgICAgICAgICAgICAgICBlbmFibGVGaWx0ZXJMaXN0OiBmYWxzZSxcbiAgICAgICAgICAgICAgICAgICAgZW5hYmxlSGV1cmlzdGljRGV0ZWN0aW9uOiB0cnVlLFxuICAgICAgICAgICAgICAgICAgICBlbmFibGVIZXVyaXN0aWNBY3Rpb246IGhldXJpc3RpY0FjdGlvbkVuYWJsZWQsXG4gICAgICAgICAgICAgICAgICAgIHZpc3VhbFRlc3QsXG4gICAgICAgICAgICAgICAgICAgIGxvZ3M6IGxvZ3NDb25maWcsXG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICBjb25zdCBjb21wYWN0UnVsZUxpc3QgPSBhdXRvY29uc2VudFNldHRpbmdzLmNvbXBhY3RSdWxlTGlzdDtcbiAgICAgICAgICAgICAgICBjb25zdCBydWxlcyA9IHtcbiAgICAgICAgICAgICAgICAgICAgYXV0b2NvbnNlbnQ6IFtdLFxuICAgICAgICAgICAgICAgICAgICBjb25zZW50b21hdGljOiBbXSxcbiAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIGlmIChjb21wYWN0UnVsZUxpc3QpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGNvbXBhY3RSdWxlTGlzdC5pbmRleCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcnVsZXMuY29tcGFjdCA9IGZpbHRlckNvbXBhY3RSdWxlcyhcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvKiogQHR5cGUge2ltcG9ydCgnQGR1Y2tkdWNrZ28vYXV0b2NvbnNlbnQnKS5JbmRleGVkQ01QUnVsZXNldH0gKi9cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAoY29tcGFjdFJ1bGVMaXN0KSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHVzZSB0aGUgZnJhbWUgVVJMIGhlcmUgYmVjYXVzZSBydWxlcyBhcmUgZmlsdGVyZWQgYnkgZnJhbWUgY29udGV4dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cmw6IGZyYW1lVXJsLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYWluRnJhbWU6IGlzTWFpbkZyYW1lLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgcnVsZXMuY29tcGFjdCA9IGNvbXBhY3RSdWxlTGlzdDtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBERUJVRyAmJiBjb25zb2xlLmxvZygnYXV0b2NvbnNlbnQgY29uZmlnJywgYXV0b2NvbnNlbnRDb25maWcpO1xuXG4gICAgICAgICAgICAgICAgY2hyb21lLnRhYnMuc2VuZE1lc3NhZ2UoXG4gICAgICAgICAgICAgICAgICAgIHRhYklkLFxuICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlOiAnaW5pdFJlc3AnLFxuICAgICAgICAgICAgICAgICAgICAgICAgcnVsZXMsXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25maWc6IGF1dG9jb25zZW50Q29uZmlnLFxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICBmcmFtZUlkLFxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXNlICdjbXBEZXRlY3RlZCc6IHtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhc2UgJ3BvcHVwRm91bmQnOiB7XG4gICAgICAgICAgICAgICAgdGhpcy5maXJlUGl4ZWwoJ3BvcHVwLWZvdW5kJyk7XG4gICAgICAgICAgICAgICAgLy8gQ2hlY2sgZm9yIHJlbG9hZCBsb29wXG4gICAgICAgICAgICAgICAgdGhpcy5kZXRlY3RSZWxvYWRMb29wKHRhYklkLCBtc2cuY21wKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhc2UgJ29wdE91dFJlc3VsdCc6IHtcbiAgICAgICAgICAgICAgICBpZiAoIW1zZy5yZXN1bHQpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5maXJlUGl4ZWwoJ2Vycm9yX29wdG91dCcpO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmNwbU1lc3NhZ2luZy5yZWZyZXNoRGFzaGJvYXJkU3RhdGUodGFiSWQsIHRhYlVybCwge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc2VudE1hbmFnZWQ6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgICAgICBjb3NtZXRpYzogbnVsbCxcbiAgICAgICAgICAgICAgICAgICAgICAgIG9wdG91dEZhaWxlZDogdHJ1ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHNlbGZ0ZXN0RmFpbGVkOiBudWxsLFxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc2VudFJlbG9hZExvb3A6IHRoaXMuX3JlbG9hZExvb3BEZXRlY3RlZC5oYXModGFiSWQpLFxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc2VudFJ1bGU6IG1zZy5jbXAsXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zZW50SGV1cmlzdGljRW5hYmxlZDogaGV1cmlzdGljQWN0aW9uRW5hYmxlZCxcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgLy8gVE9ETzogaW1wbGVtZW50IHNlbGYtdGVzdHNcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXNlICdhdXRvY29uc2VudERvbmUnOiB7XG4gICAgICAgICAgICAgICAgLy8gUmVtZW1iZXIgdGhlIGxhc3QgaGFuZGxlZCBDTVAgZm9yIHJlbG9hZCBsb29wIGRldGVjdGlvblxuICAgICAgICAgICAgICAgIHRoaXMucmVtZW1iZXJMYXN0SGFuZGxlZENNUCh0YWJJZCwgbXNnLmNtcCwgbXNnLmlzQ29zbWV0aWMpO1xuICAgICAgICAgICAgICAgIHRoaXMuY3BtTWVzc2FnaW5nLnJlZnJlc2hEYXNoYm9hcmRTdGF0ZSh0YWJJZCwgdGFiVXJsLCB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNlbnRNYW5hZ2VkOiB0cnVlLFxuICAgICAgICAgICAgICAgICAgICBjb3NtZXRpYzogbXNnLmlzQ29zbWV0aWMsXG4gICAgICAgICAgICAgICAgICAgIG9wdG91dEZhaWxlZDogZmFsc2UsXG4gICAgICAgICAgICAgICAgICAgIHNlbGZ0ZXN0RmFpbGVkOiBudWxsLFxuICAgICAgICAgICAgICAgICAgICBjb25zZW50UmVsb2FkTG9vcDogdGhpcy5fcmVsb2FkTG9vcERldGVjdGVkLmhhcyh0YWJJZCksXG4gICAgICAgICAgICAgICAgICAgIGNvbnNlbnRSdWxlOiBtc2cuY21wLFxuICAgICAgICAgICAgICAgICAgICBjb25zZW50SGV1cmlzdGljRW5hYmxlZDogaGV1cmlzdGljQWN0aW9uRW5hYmxlZCxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICBpZiAobXNnLmNtcCA9PT0gJ0hFVVJJU1RJQycpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5maXJlUGl4ZWwoJ2RvbmVfaGV1cmlzdGljJyk7XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5maXJlUGl4ZWwobXNnLmlzQ29zbWV0aWMgPyAnZG9uZV9jb3NtZXRpYycgOiAnZG9uZScpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBhd2FpdCB0aGlzLm1vZGlmeUNwbVN0YXRlKChjcG1TdGF0ZSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBjcG1TdGF0ZS5zaXRlc05vdGlmaWVkQ2FjaGUuYWRkKHRhYkRvbWFpbik7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgdGhpcy5jcG1NZXNzYWdpbmcuc2hvd0NwbUFuaW1hdGlvbih0YWJJZCwgdGFiVXJsLCBtc2cuaXNDb3NtZXRpYyk7XG4gICAgICAgICAgICAgICAgdGhpcy5maXJlUGl4ZWwobXNnLmlzQ29zbWV0aWMgPyAnYW5pbWF0aW9uLXNob3duX2Nvc21ldGljJyA6ICdhbmltYXRpb24tc2hvd24nKTtcbiAgICAgICAgICAgICAgICB0aGlzLmNwbU1lc3NhZ2luZy5ub3RpZnlQb3B1cEhhbmRsZWQodGFiSWQsIG1zZyk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXNlICdyZXBvcnQnOiB7XG4gICAgICAgICAgICAgICAgY29uc3Qgc3RhdGUgPSBtc2cuc3RhdGUgfHwge307XG4gICAgICAgICAgICAgICAgY29uc3QgZGV0ZWN0ZWRCeVBhdHRlcm5zID0gc3RhdGUuaGV1cmlzdGljUGF0dGVybnM/Lmxlbmd0aCA+IDA7XG4gICAgICAgICAgICAgICAgY29uc3QgZGV0ZWN0ZWRCeVNuaXBwZXRzID0gc3RhdGUuaGV1cmlzdGljU25pcHBldHM/Lmxlbmd0aCA+IDA7XG4gICAgICAgICAgICAgICAgY29uc3QgZGV0ZWN0ZWRQb3B1cHMgPSBzdGF0ZS5kZXRlY3RlZFBvcHVwcz8ubGVuZ3RoID4gMDtcbiAgICAgICAgICAgICAgICBjb25zdCBoZXVyaXN0aWNNYXRjaCA9IGRldGVjdGVkQnlQYXR0ZXJucyB8fCBkZXRlY3RlZEJ5U25pcHBldHM7XG4gICAgICAgICAgICAgICAgYXdhaXQgdGhpcy5tb2RpZnlDcG1TdGF0ZSgoY3BtU3RhdGUpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGlzTWFpbkZyYW1lICYmIGhldXJpc3RpY01hdGNoICYmICFjcG1TdGF0ZS5kZXRlY3Rpb25DYWNoZS5wYXR0ZXJucy5oYXMobXNnLmluc3RhbmNlSWQpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjcG1TdGF0ZS5kZXRlY3Rpb25DYWNoZS5wYXR0ZXJucy5hZGQobXNnLmluc3RhbmNlSWQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gbm8gYXdhaXQgdG8gYXZvaWQgZGVhZGxvY2tcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZmlyZVBpeGVsKCdkZXRlY3RlZC1ieS1wYXR0ZXJucycpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGlmIChpc01haW5GcmFtZSAmJiBkZXRlY3RlZFBvcHVwcykge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGhldXJpc3RpY01hdGNoICYmICFjcG1TdGF0ZS5kZXRlY3Rpb25DYWNoZS5ib3RoLmhhcyhtc2cuaW5zdGFuY2VJZCkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjcG1TdGF0ZS5kZXRlY3Rpb25DYWNoZS5ib3RoLmFkZChtc2cuaW5zdGFuY2VJZCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gbm8gYXdhaXQgdG8gYXZvaWQgZGVhZGxvY2tcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmZpcmVQaXhlbCgnZGV0ZWN0ZWQtYnktYm90aCcpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIGlmICghaGV1cmlzdGljTWF0Y2ggJiYgIWNwbVN0YXRlLmRldGVjdGlvbkNhY2hlLm9ubHlSdWxlcy5oYXMobXNnLmluc3RhbmNlSWQpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY3BtU3RhdGUuZGV0ZWN0aW9uQ2FjaGUub25seVJ1bGVzLmFkZChtc2cuaW5zdGFuY2VJZCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gbm8gYXdhaXQgdG8gYXZvaWQgZGVhZGxvY2tcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmZpcmVQaXhlbCgnZGV0ZWN0ZWQtb25seS1ydWxlcycpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXNlICdldmFsJzoge1xuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgbXNnLnNuaXBwZXRJZCAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5ldmFsSW5UYWIodGFiSWQsIGZyYW1lSWQsIG1zZy5zbmlwcGV0SWQpLnRoZW4oKFtyZXN1bHRdKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAobG9nc0NvbmZpZy5ldmFscykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUuZ3JvdXBDb2xsYXBzZWQoYGV2YWwgcmVzdWx0IGZvciAke2ZyYW1lVXJsfWApO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKG1zZy5jb2RlLCByZXN1bHQucmVzdWx0KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmdyb3VwRW5kKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBjaHJvbWUudGFicy5zZW5kTWVzc2FnZShcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0YWJJZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkOiBtc2cuaWQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU6ICdldmFsUmVzcCcsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc3VsdDogcmVzdWx0LnJlc3VsdCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZnJhbWVJZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2FzZSAnYXV0b2NvbnNlbnRFcnJvcic6IHtcbiAgICAgICAgICAgICAgICBpZiAobXNnLmRldGFpbHM/Lm1zZz8uaW5jbHVkZXMoJ0ZvdW5kIG11bHRpcGxlIENNUHMnKSkge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmZpcmVQaXhlbCgnZXJyb3JfbXVsdGlwbGUtcG9wdXBzJyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2FzZSAndmlzdWFsRGVsYXknOiB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ3Zpc3VhbERlbGF5JywgbXNnKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgdGhpcy5jcG1NZXNzYWdpbmcubG9nTWVzc2FnZShgVW5oYW5kbGVkIGF1dG9jb25zZW50IG1lc3NhZ2UgdHlwZTogJHttc2cudHlwZX1gKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqXG4gICAgICogQHBhcmFtIHtudW1iZXJ9IHRhYklkXG4gICAgICogQHBhcmFtIHtudW1iZXJ9IGZyYW1lSWRcbiAgICAgKiBAcGFyYW0ge2tleW9mIHR5cGVvZiBldmFsU25pcHBldHN9IHNuaXBwZXRJZFxuICAgICAqIEByZXR1cm5zIHtQcm9taXNlPGNocm9tZS5zY3JpcHRpbmcuSW5qZWN0aW9uUmVzdWx0PGJvb2xlYW4+W10+fVxuICAgICAqL1xuICAgIGFzeW5jIGV2YWxJblRhYih0YWJJZCwgZnJhbWVJZCwgc25pcHBldElkKSB7XG4gICAgICAgIHJldHVybiBjaHJvbWUuc2NyaXB0aW5nLmV4ZWN1dGVTY3JpcHQoe1xuICAgICAgICAgICAgdGFyZ2V0OiB7XG4gICAgICAgICAgICAgICAgdGFiSWQsXG4gICAgICAgICAgICAgICAgZnJhbWVJZHM6IFtmcmFtZUlkXSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB3b3JsZDogJ01BSU4nLFxuICAgICAgICAgICAgZnVuYzogZXZhbFNuaXBwZXRzW3NuaXBwZXRJZF0sXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIGFzeW5jIGZpcmVQaXhlbChldmVudE5hbWUpIHtcbiAgICAgICAgdGhpcy5tb2RpZnlDcG1TdGF0ZSgoY3BtU3RhdGUpID0+IHtcbiAgICAgICAgICAgIGNwbVN0YXRlLnN1bW1hcnlFdmVudHNbZXZlbnROYW1lXSA9IChjcG1TdGF0ZS5zdW1tYXJ5RXZlbnRzW2V2ZW50TmFtZV0gfHwgMCkgKyAxO1xuICAgICAgICB9KTtcblxuICAgICAgICAvLyBzY2hlZHVsZSBzdW1tYXJ5IGFsYXJtIGlmIG5vdCBhbHJlYWR5IHNjaGVkdWxlZCAoY3JlYXRlQWxhcm0gY2hlY2tzIGZvciBleGlzdGluZyBhbGFybSlcbiAgICAgICAgY3JlYXRlQWxhcm0oQ29va2llUHJvbXB0TWFuYWdlbWVudC5TVU1NQVJZX0FMQVJNX05BTUUsIHtcbiAgICAgICAgICAgIGRlbGF5SW5NaW51dGVzOiBDb29raWVQcm9tcHRNYW5hZ2VtZW50LlNVTU1BUllfREVMQVlfTUlOVVRFUyxcbiAgICAgICAgfSk7XG5cbiAgICAgICAgLy8gcmVxdWVzdCBcImRhaWx5XCIgcGl4ZWwgZmlyaW5nXG4gICAgICAgIGNvbnN0IHBpeGVsTmFtZSA9IGBhdXRvY29uc2VudF8ke2V2ZW50TmFtZX1gO1xuICAgICAgICB0aGlzLmNwbU1lc3NhZ2luZy5zZW5kUGl4ZWwocGl4ZWxOYW1lLCAnZGFpbHknLCB7XG4gICAgICAgICAgICBjb25zZW50SGV1cmlzdGljRW5hYmxlZDogKGF3YWl0IHRoaXMuY2hlY2tIZXVyaXN0aWNBY3Rpb25FbmFibGVkKCkpID8gJzEnIDogJzAnLFxuICAgICAgICAgICAgZnJvbUV4dGVuc2lvbjogJzEnLFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICBhc3luYyBzZW5kU3VtbWFyeVBpeGVsKCkge1xuICAgICAgICBsZXQgc3VtbWFyeUV2ZW50cyA9IHt9O1xuICAgICAgICBhd2FpdCB0aGlzLm1vZGlmeUNwbVN0YXRlKChjcG1TdGF0ZSkgPT4ge1xuICAgICAgICAgICAgc3VtbWFyeUV2ZW50cyA9IHN0cnVjdHVyZWRDbG9uZShjcG1TdGF0ZS5zdW1tYXJ5RXZlbnRzKTtcbiAgICAgICAgICAgIGNwbVN0YXRlLnN1bW1hcnlFdmVudHMgPSB7fTtcbiAgICAgICAgICAgIGNwbVN0YXRlLmRldGVjdGlvbkNhY2hlLnBhdHRlcm5zLmNsZWFyKCk7XG4gICAgICAgICAgICBjcG1TdGF0ZS5kZXRlY3Rpb25DYWNoZS5ib3RoLmNsZWFyKCk7XG4gICAgICAgICAgICBjcG1TdGF0ZS5kZXRlY3Rpb25DYWNoZS5vbmx5UnVsZXMuY2xlYXIoKTtcbiAgICAgICAgfSk7XG4gICAgICAgIHRoaXMuY3BtTWVzc2FnaW5nLnNlbmRQaXhlbCgnYXV0b2NvbnNlbnRfc3VtbWFyeScsICdzdGFuZGFyZCcsIHtcbiAgICAgICAgICAgIC4uLnN1bW1hcnlFdmVudHMsXG4gICAgICAgICAgICBjb25zZW50SGV1cmlzdGljRW5hYmxlZDogKGF3YWl0IHRoaXMuY2hlY2tIZXVyaXN0aWNBY3Rpb25FbmFibGVkKCkpID8gJzEnIDogJzAnLFxuICAgICAgICAgICAgZnJvbUV4dGVuc2lvbjogJzEnLFxuICAgICAgICB9KTtcbiAgICB9XG59XG4iLCAiLy8gV2l0aCBNYW5pZmVzdCBWMiB0aGUgY29udGVudCBzY3JpcHRzIGFyZSBydW4gZGlyZWN0bHkgZnJvbSB0aGUgbWFuaWZlc3QgYW5kXG4vLyB0aGV5IGluamVjdCBpbnRvIHRoZSBtYWluIHdvcmxkIG9mIHdlYnNpdGVzIGJ5IGFkZGluZyBhIDxzY3JpcHQ+IGVsZW1lbnQgdG9cbi8vIHRoZSBET00uIFdpdGggTWFuaWZlc3QgVjMgaG93ZXZlciB0aGUgY2hyb21lLnNjcmlwdGluZyBBUEkgbXVzdCBiZSB1c2VkIHRvXG4vLyBpbmplY3Qgc2NyaXB0cyBpbnRvIHRoZSBtYWluIHdvcmxkLlxuLy8gTm90ZTogSXQncyBpbXBvcnRhbnQgdGhhdCB0aGUgaXNvbGF0ZWQgd29ybGQgc2NyaXB0IHJ1bnMgZmlyc3QuIFRoZSBvcmRlciB0aGVcbi8vICAgICAgIHNjcmlwdHMgYXJlIGFkZGVkIGJ5IHJlZ2lzdGVyQ29udGVudFNjcmlwdHMgaXMgYmFzZWQgb24gdGhlIHNjcmlwdCBJRCxcbi8vICAgICAgIGJ1dCBub3RlIHRoYXQncyBhbiBpbXBsZW1lbnRhdGlvbiBkZXRhaWwgKGZyb20gdXNlIG9mIHN0ZDo6c2V0IGZvciBuZXdcbi8vICAgICAgIHNjcmlwdCBJRHNbMV0pIGFuZCBjb3VsZCBjaGFuZ2UgaW4gdGhlIGZ1dHVyZS5cbi8vIDEgLSBodHRwczovL3NvdXJjZS5jaHJvbWl1bS5vcmcvY2hyb21pdW0vY2hyb21pdW0vc3JjLysvbWFpbjpjaHJvbWUvYnJvd3Nlci9leHRlbnNpb25zL2FwaS9zY3JpcHRpbmcvc2NyaXB0aW5nX2FwaS5jYztsPTkyOVxuXG5pbXBvcnQgYnJvd3NlciBmcm9tICd3ZWJleHRlbnNpb24tcG9seWZpbGwnO1xuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcmVnaXN0ZXJDb250ZW50U2NyaXB0cyhzY3JpcHRzKSB7XG4gICAgLy8gY2hlY2sgaWYgc2NyaXB0cyB3ZXJlIGFscmVhZHkgcmVnaXN0ZXJlZCAtIHJlZ2lzdGVyaW5nIGR1cGxpY2F0ZSBzY3JpcHRzIHdpbGwgdGhyb3cgYW4gZXJyb3IuXG4gICAgY29uc3QgZXhpc3RpbmdTY3JpcHRzID0gYXdhaXQgYnJvd3Nlci5zY3JpcHRpbmcuZ2V0UmVnaXN0ZXJlZENvbnRlbnRTY3JpcHRzKCk7XG4gICAgY29uc3QgZHVwbGljYXRlSWRzID0gZXhpc3RpbmdTY3JpcHRzLmZpbHRlcigocykgPT4gc2NyaXB0cy5zb21lKChuZXdTY3JpcHQpID0+IG5ld1NjcmlwdC5pZCA9PT0gcy5pZCkpLm1hcCgocykgPT4gcy5pZCk7XG4gICAgaWYgKGR1cGxpY2F0ZUlkcy5sZW5ndGggPiAwKSB7XG4gICAgICAgIGF3YWl0IHVucmVnaXN0ZXJDb250ZW50U2NyaXB0cyhkdXBsaWNhdGVJZHMpO1xuICAgIH1cbiAgICBhd2FpdCBicm93c2VyLnNjcmlwdGluZy5yZWdpc3RlckNvbnRlbnRTY3JpcHRzKHNjcmlwdHMpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gdW5yZWdpc3RlckNvbnRlbnRTY3JpcHRzKHNjcmlwdElkcykge1xuICAgIGF3YWl0IGJyb3dzZXIuc2NyaXB0aW5nLnVucmVnaXN0ZXJDb250ZW50U2NyaXB0cyh7IGlkczogc2NyaXB0SWRzIH0pO1xufVxuXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBNVjNDb250ZW50U2NyaXB0SW5qZWN0aW9uIHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgdGhpcy5yZWFkeSA9IHRoaXMucmVnaXN0ZXJTY3JpcHRzKCk7XG4gICAgfVxuXG4gICAgYXN5bmMgcmVnaXN0ZXJTY3JpcHRzKCkge1xuICAgICAgICBhd2FpdCByZWdpc3RlckNvbnRlbnRTY3JpcHRzKFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBpZDogJzEtc2NyaXB0LWluamVjdGlvbi1pc29sYXRlZC13b3JsZCcsXG4gICAgICAgICAgICAgICAgYWxsRnJhbWVzOiB0cnVlLFxuICAgICAgICAgICAgICAgIGpzOiBbJ3B1YmxpYy9qcy9jb250ZW50LXNjcmlwdHMvY29udGVudC1zY29wZS1tZXNzYWdpbmcuanMnXSxcbiAgICAgICAgICAgICAgICBydW5BdDogJ2RvY3VtZW50X3N0YXJ0JyxcbiAgICAgICAgICAgICAgICB3b3JsZDogJ0lTT0xBVEVEJyxcbiAgICAgICAgICAgICAgICBtYXRjaGVzOiBbJzxhbGxfdXJscz4nXSxcbiAgICAgICAgICAgICAgICBleGNsdWRlTWF0Y2hlczogWycqOi8vbG9jYWxob3N0LyonLCAnKjovLyoubG9jYWxob3N0LyddLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBpZDogJzItc2NyaXB0LWluamVjdGlvbi1tYWluLXdvcmxkJyxcbiAgICAgICAgICAgICAgICBhbGxGcmFtZXM6IHRydWUsXG4gICAgICAgICAgICAgICAganM6IFsncHVibGljL2pzL2luamVjdC5qcyddLFxuICAgICAgICAgICAgICAgIHJ1bkF0OiAnZG9jdW1lbnRfc3RhcnQnLFxuICAgICAgICAgICAgICAgIHdvcmxkOiAnTUFJTicsXG4gICAgICAgICAgICAgICAgbWF0Y2hlczogWyc8YWxsX3VybHM+J10sXG4gICAgICAgICAgICAgICAgZXhjbHVkZU1hdGNoZXM6IFsnKjovL2xvY2FsaG9zdC8qJywgJyo6Ly8qLmxvY2FsaG9zdC8nXSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIF0pO1xuICAgIH1cbn1cbiIsICIvKipcbiAqIExpZ2h0d2VpZ2h0IG1lc3NhZ2UgaGFuZGxlciByZWdpc3RyeS5cbiAqXG4gKiBDb21wb25lbnRzIHJlZ2lzdGVyIHRoZWlyIGhhbmRsZXJzIGhlcmUgdmlhIGByZWdpc3Rlck1lc3NhZ2VIYW5kbGVyYCwgYW5kXG4gKiBNZXNzYWdlUm91dGVyIHJlYWRzIGZyb20gdGhlIHNhbWUgbWFwIHRvIGRpc3BhdGNoIGluY29taW5nIG1lc3NhZ2VzLlxuICovXG5cbmNvbnN0IG1lc3NhZ2VIYW5kbGVycyA9IHt9O1xuXG4vKipcbiAqIEFkZCBhIG5ldyBtZXNzYWdlIGhhbmRsZXIuXG4gKiBAcGFyYW0ge3N0cmluZ30gbmFtZVxuICogQHBhcmFtIHsob3B0aW9uczogYW55LCBzZW5kZXI6IGFueSwgcmVxOiBhbnkpID0+IGFueX0gZnVuY1xuICovXG5leHBvcnQgZnVuY3Rpb24gcmVnaXN0ZXJNZXNzYWdlSGFuZGxlcihuYW1lLCBmdW5jKSB7XG4gICAgbWVzc2FnZUhhbmRsZXJzW25hbWVdID0gZnVuYztcbn1cblxuZXhwb3J0IGRlZmF1bHQgbWVzc2FnZUhhbmRsZXJzO1xuIiwgImltcG9ydCB7IGdldEZyb21TZXNzaW9uU3RvcmFnZSwgc2V0VG9TZXNzaW9uU3RvcmFnZSB9IGZyb20gJy4uL3dyYXBwZXInO1xuXG4vKiBnbG9iYWwgREVCVUcgKi9cblxuLyoqXG4gKiBAdHlwZWRlZiB7aW1wb3J0KCcuL2Nvb2tpZS1wcm9tcHQtbWFuYWdlbWVudCcpLkNQTU1lc3NhZ2luZ0Jhc2V9IENQTU1lc3NhZ2luZ0Jhc2VcbiAqIEB0eXBlZGVmIHtpbXBvcnQoJy4vbmF0aXZlLW1lc3NhZ2luZycpLk5hdGl2ZU1lc3NhZ2luZ0ludGVyZmFjZX0gTmF0aXZlTWVzc2FnaW5nSW50ZXJmYWNlXG4gKiBAdHlwZWRlZiB7eyB0aW1lOiBudW1iZXIsIHZhbHVlOiBhbnkgfX0gQ2FjaGVFbnRyeVxuICovXG5cbmV4cG9ydCBjb25zdCBTVUJGRUFUVVJFX0NIRUNLX1RUTCA9IDMwICogMTAwMDsgLy8gMzBzXG5leHBvcnQgY29uc3QgU0VUVElOR19DSEVDS19UVEwgPSAxMCAqIDEwMDA7IC8vIDEwc1xuZXhwb3J0IGNvbnN0IFNJVEVfQ0hFQ0tfVFRMID0gMyAqIDEwMDA7IC8vIDNzICh0byBiZSBhYmxlIHRvIHJlc3BvbmQgdG8gUHJvdGVjdGlvbnMgdG9nZ2xlIGNoYW5nZXMpXG5leHBvcnQgY29uc3QgTUFYX0NBQ0hFX1NJWkUgPSAxMDA7XG5cbi8qKlxuICogQ1BNIG1lc3NhZ2luZyBmb3IgZW1iZWRkZWQgZXh0ZW5zaW9uLlxuICogQGltcGxlbWVudHMge0NQTU1lc3NhZ2luZ0Jhc2V9XG4gKi9cbmV4cG9ydCBjbGFzcyBDUE1FbWJlZGRlZE1lc3NhZ2luZyB7XG4gICAgLyoqXG4gICAgICogQHBhcmFtIHtOYXRpdmVNZXNzYWdpbmdJbnRlcmZhY2V9IG5hdGl2ZU1lc3NhZ2luZ1xuICAgICAqL1xuICAgIGNvbnN0cnVjdG9yKG5hdGl2ZU1lc3NhZ2luZykge1xuICAgICAgICB0aGlzLm5hdGl2ZU1lc3NhZ2luZyA9IG5hdGl2ZU1lc3NhZ2luZztcbiAgICAgICAgLyoqIEB0eXBlIHtNYXA8c3RyaW5nLCBDYWNoZUVudHJ5Pn0gKi9cbiAgICAgICAgdGhpcy5fY2FjaGUgPSBuZXcgTWFwKCk7XG4gICAgICAgIC8qKiBAdHlwZSB7UHJvbWlzZTx2b2lkPn0gKi9cbiAgICAgICAgdGhpcy5fcXVldWUgPSBQcm9taXNlLnJlc29sdmUoKTtcbiAgICAgICAgLy8gaW4tbWVtb3J5IGNhY2hlZCBjb25maWcsIHdpbGwgYmUgbG9zdCBvbiBleHRlbnNpb24gc2xlZXAsIGluIHdoaWNoIGNhc2Ugd2UgZmV0Y2ggZnJvbSBzZXNzaW9uIHN0b3JhZ2VcbiAgICAgICAgLyoqIEB0eXBlIHtpbXBvcnQoJ0BkdWNrZHVja2dvL3ByaXZhY3ktY29uZmlndXJhdGlvbi9zY2hlbWEvY29uZmlnLnRzJykuQ3VycmVudEdlbmVyaWNDb25maWcgfCBudWxsfSAqL1xuICAgICAgICB0aGlzLl9jYWNoZWRDb25maWcgPSBudWxsO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEVucXVldWUgYSBub3RpZmljYXRpb24gbWVzc2FnZSB0byBiZSBzZW50IHRvIHRoZSBuYXRpdmUgYXBwLlxuICAgICAqIEBwYXJhbSB7c3RyaW5nfSBtZXRob2RcbiAgICAgKiBAcGFyYW0ge1JlY29yZDxzdHJpbmcsIGFueT59IHBhcmFtc1xuICAgICAqL1xuICAgIGFzeW5jIF9ub3RpZnkobWV0aG9kLCBwYXJhbXMpIHtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gdGhpcy5fcXVldWVcbiAgICAgICAgICAgIC50aGVuKCgpID0+IHtcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5uYXRpdmVNZXNzYWdpbmcubm90aWZ5KG1ldGhvZCwgcGFyYW1zKTtcbiAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAuY2F0Y2goKGUpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKCdlcnJvciBpbiBub3RpZmljYXRpb24gcXVldWUnLCBlKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB0aGlzLl9xdWV1ZSA9IHJlc3VsdDtcbiAgICAgICAgYXdhaXQgcmVzdWx0O1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEVucXVldWUgYSByZXF1ZXN0IHRvIHRoZSBuYXRpdmUgYXBwIGFuZCB3YWl0IGZvciBhIHJlc3BvbnNlLFxuICAgICAqIGJsb2NraW5nIHN1YnNlcXVlbnQgY2FsbGVycyB1bnRpbCB0aGUgcmVxdWVzdCBpcyBjb21wbGV0ZS5cbiAgICAgKiBJZiBjYWNoZUtleSBhbmQgdHRsIGFyZSBwcm92aWRlZCwgdGhlIHJlc3VsdCBpcyBjYWNoZWQgYW5kXG4gICAgICogcmV0dXJuZWQgaW1tZWRpYXRlbHkgb24gc3Vic2VxdWVudCBjYWxscyB3aXRoaW4gdGhlIFRUTC5cbiAgICAgKiBAcGFyYW0ge3N0cmluZ30gbWV0aG9kXG4gICAgICogQHBhcmFtIHtSZWNvcmQ8c3RyaW5nLCBhbnk+fSBwYXJhbXNcbiAgICAgKiBAcGFyYW0ge3N0cmluZ30gW2NhY2hlS2V5XVxuICAgICAqIEBwYXJhbSB7bnVtYmVyfSBbdHRsXVxuICAgICAqIEByZXR1cm5zIHtQcm9taXNlPGFueT59XG4gICAgICovXG4gICAgX3JlcXVlc3QobWV0aG9kLCBwYXJhbXMsIGNhY2hlS2V5LCB0dGwpIHtcbiAgICAgICAgY29uc3Qgam9iID0gdGhpcy5fcXVldWVcbiAgICAgICAgICAgIC50aGVuKGFzeW5jICgpID0+IHtcbiAgICAgICAgICAgICAgICBpZiAoY2FjaGVLZXkgJiYgdHRsKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGNhY2hlZCA9IHRoaXMuX2NhY2hlLmdldChjYWNoZUtleSk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChjYWNoZWQgJiYgRGF0ZS5ub3coKSAtIGNhY2hlZC50aW1lIDwgdHRsKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gY2FjaGVkLnZhbHVlO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHRoaXMubmF0aXZlTWVzc2FnaW5nLnJlcXVlc3QobWV0aG9kLCBwYXJhbXMpO1xuICAgICAgICAgICAgICAgIGlmIChjYWNoZUtleSAmJiB0dGwpIHtcbiAgICAgICAgICAgICAgICAgICAgLy8gZXZpY3QgdGhlIG9sZGVzdCBlbnRyeSBpZiB0aGUgY2FjaGUgaXMgZnVsbFxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5fY2FjaGUuc2l6ZSA+PSBNQVhfQ0FDSEVfU0laRSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gTWFwIGFyZSBpdGVyYXRlZCBpbiBpbnNlcnRpb24gb3JkZXIsIHNvIHRoZSBvbGRlc3QgZW50cnkgaXMgdGhlIGZpcnN0IG9uZVxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3Qgb2xkZXN0ID0gdGhpcy5fY2FjaGUua2V5cygpLm5leHQoKS52YWx1ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChvbGRlc3QgIT09IHVuZGVmaW5lZCkgdGhpcy5fY2FjaGUuZGVsZXRlKG9sZGVzdCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fY2FjaGUuc2V0KGNhY2hlS2V5LCB7IHRpbWU6IERhdGUubm93KCksIHZhbHVlOiByZXN1bHQgfSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgICAgICAgICB9KVxuICAgICAgICAgICAgLmNhdGNoKChlKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihgZXJyb3IgaW4gcmVxdWVzdCBxdWV1ZSBmb3IgJHttZXRob2R9YCwgZSk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgdGhpcy5fcXVldWUgPSBqb2I7XG4gICAgICAgIHJldHVybiBqb2I7XG4gICAgfVxuXG4gICAgYXN5bmMgbG9nTWVzc2FnZShtZXNzYWdlKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKG1lc3NhZ2UpO1xuICAgICAgICBhd2FpdCB0aGlzLl9ub3RpZnkoJ2V4dGVuc2lvbkxvZycsIHtcbiAgICAgICAgICAgIG1lc3NhZ2UsXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIGFzeW5jIHJlZnJlc2hEYXNoYm9hcmRTdGF0ZSh0YWJJZCwgdXJsLCBkYXNoYm9hcmRTdGF0ZSkge1xuICAgICAgICBhd2FpdCB0aGlzLl9ub3RpZnkoJ3JlZnJlc2hDcG1EYXNoYm9hcmRTdGF0ZScsIHtcbiAgICAgICAgICAgIHRhYklkLFxuICAgICAgICAgICAgdXJsLFxuICAgICAgICAgICAgY29uc2VudFN0YXR1czogZGFzaGJvYXJkU3RhdGUsXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIGFzeW5jIHNob3dDcG1BbmltYXRpb24odGFiSWQsIHRvcFVybCwgaXNDb3NtZXRpYykge1xuICAgICAgICBhd2FpdCB0aGlzLl9ub3RpZnkoJ3Nob3dDcG1BbmltYXRpb24nLCB7XG4gICAgICAgICAgICB0YWJJZCxcbiAgICAgICAgICAgIHRvcFVybCxcbiAgICAgICAgICAgIGlzQ29zbWV0aWMsXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIGFzeW5jIG5vdGlmeVBvcHVwSGFuZGxlZCh0YWJJZCwgbXNnKSB7XG4gICAgICAgIGF3YWl0IHRoaXMuX25vdGlmeSgnY29va2llUG9wdXBIYW5kbGVkJywge1xuICAgICAgICAgICAgdGFiSWQsXG4gICAgICAgICAgICBtc2csXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIGFzeW5jIGNoZWNrQXV0b2NvbnNlbnRTZXR0aW5nRW5hYmxlZCgpIHtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgdGhpcy5fcmVxdWVzdCgnaXNBdXRvY29uc2VudFNldHRpbmdFbmFibGVkJywge30sICd1c2VyU2V0dGluZycsIFNFVFRJTkdfQ0hFQ0tfVFRMKTtcbiAgICAgICAgcmV0dXJuIHJlc3VsdD8uZW5hYmxlZCA/PyBmYWxzZTtcbiAgICB9XG5cbiAgICBhc3luYyBjaGVja0F1dG9jb25zZW50RW5hYmxlZEZvclNpdGUodXJsKSB7XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHRoaXMuX3JlcXVlc3QoJ2lzRmVhdHVyZUVuYWJsZWQnLCB7IGZlYXR1cmVOYW1lOiAnYXV0b2NvbnNlbnQnLCB1cmwgfSwgYHNpdGU6JHt1cmx9YCwgU0lURV9DSEVDS19UVEwpO1xuICAgICAgICByZXR1cm4gcmVzdWx0Py5lbmFibGVkID8/IGZhbHNlO1xuICAgIH1cblxuICAgIGFzeW5jIGNoZWNrU3ViZmVhdHVyZUVuYWJsZWQoc3ViZmVhdHVyZU5hbWUpIHtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgdGhpcy5fcmVxdWVzdChcbiAgICAgICAgICAgICdpc1N1YkZlYXR1cmVFbmFibGVkJyxcbiAgICAgICAgICAgIHsgZmVhdHVyZU5hbWU6ICdhdXRvY29uc2VudCcsIHN1YmZlYXR1cmVOYW1lIH0sXG4gICAgICAgICAgICBgc3ViZmVhdHVyZToke3N1YmZlYXR1cmVOYW1lfWAsXG4gICAgICAgICAgICBTVUJGRUFUVVJFX0NIRUNLX1RUTCxcbiAgICAgICAgKTtcbiAgICAgICAgcmV0dXJuIHJlc3VsdD8uZW5hYmxlZCA/PyBmYWxzZTtcbiAgICB9XG5cbiAgICBhc3luYyBzZW5kUGl4ZWwocGl4ZWxOYW1lLCB0eXBlLCBwYXJhbXMpIHtcbiAgICAgICAgYXdhaXQgdGhpcy5fbm90aWZ5KCdzZW5kUGl4ZWwnLCB7XG4gICAgICAgICAgICBwaXhlbE5hbWUsXG4gICAgICAgICAgICB0eXBlLFxuICAgICAgICAgICAgcGFyYW1zLFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICBhc3luYyByZWZyZXNoUmVtb3RlQ29uZmlnKCkge1xuICAgICAgICBjb25zdCBjYWNoZWRDb25maWcgPSB0aGlzLl9jYWNoZWRDb25maWcgfHwgKGF3YWl0IGdldEZyb21TZXNzaW9uU3RvcmFnZSgnY29uZmlnJykpIHx8IHsgdmVyc2lvbjogJ3Vua25vd24nIH07XG4gICAgICAgIGNvbnN0IGNhY2hlZENvbmZpZ1ZlcnNpb24gPSBgJHtjYWNoZWRDb25maWcudmVyc2lvbn1gO1xuICAgICAgICBERUJVRyAmJiBjb25zb2xlLmxvZyhgY2FjaGVkQ29uZmlnOiAke0pTT04uc3RyaW5naWZ5KGNhY2hlZENvbmZpZyl9YCk7XG5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGBmZXRjaGluZyBjb25maWcgZnJvbSBuYXRpdmUsIGNhY2hlZENvbmZpZ1ZlcnNpb246ICR7Y2FjaGVkQ29uZmlnVmVyc2lvbn1gKTtcbiAgICAgICAgICAgIC8vIHdlIGRvbid0IHVzZSB0aGUgcmVxdWVzdCBxdWV1ZSBoZXJlIGJlY2F1c2UgY29uZmlnIGZldGNoaW5nIHNob3VsZCBiZSBhc3luY1xuICAgICAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgdGhpcy5uYXRpdmVNZXNzYWdpbmcucmVxdWVzdCgnZ2V0UmVzb3VyY2VJZk5ldycsIHsgbmFtZTogJ2NvbmZpZycsIHZlcnNpb246IGNhY2hlZENvbmZpZ1ZlcnNpb24gfSk7XG4gICAgICAgICAgICBpZiAocmVzdWx0LnVwZGF0ZWQpIHtcbiAgICAgICAgICAgICAgICB0aGlzLl9jYWNoZWRDb25maWcgPSByZXN1bHQuZGF0YTtcbiAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICBhd2FpdCBzZXRUb1Nlc3Npb25TdG9yYWdlKCdjb25maWcnLCB0aGlzLl9jYWNoZWRDb25maWcpO1xuICAgICAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgICAgICAgICAgLy8gdGhpcyBjYW4gaGFwcGVuIGlmIHF1b3RhIGlzIGV4Y2VlZGVkXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubG9nTWVzc2FnZShgZXJyb3Igc2V0dGluZyBjYWNoZWQgY29uZmlnIHRvIHNlc3Npb24gc3RvcmFnZTogJHtlfWApO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5fY2FjaGVkQ29uZmlnO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIGNhY2hlZENvbmZpZztcbiAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgdGhpcy5sb2dNZXNzYWdlKGBlcnJvciByZWZyZXNoaW5nIHJlbW90ZSBjb25maWc6ICR7ZX1gKTtcbiAgICAgICAgICAgIGlmIChjYWNoZWRDb25maWdWZXJzaW9uICE9PSAndW5rbm93bicpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gY2FjaGVkQ29uZmlnO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGhyb3cgZTtcbiAgICAgICAgfVxuICAgIH1cbn1cbiIsICJpbXBvcnQgYnJvd3NlciBmcm9tICd3ZWJleHRlbnNpb24tcG9seWZpbGwnO1xuXG5pbXBvcnQgbWVzc2FnZUhhbmRsZXJzIGZyb20gJy4uL21lc3NhZ2UtcmVnaXN0cnknO1xuaW1wb3J0IHsgZ2V0RXh0ZW5zaW9uSWQgfSBmcm9tICcuLi93cmFwcGVyJztcbmltcG9ydCB7IGdldEJyb3dzZXJOYW1lIH0gZnJvbSAnLi4vdXRpbHMnO1xuaW1wb3J0IHsgZ2V0QWN0aXZlUG9ydCwgc2V0QWN0aXZlUG9ydCB9IGZyb20gJy4uL3BvcHVwLW1lc3NhZ2luZyc7XG5cbi8qKlxuICogQHR5cGVkZWYge2ltcG9ydCgnd2ViZXh0ZW5zaW9uLXBvbHlmaWxsJykuUnVudGltZS5Qb3J0fSBQb3J0XG4gKiBAdHlwZWRlZiB7aW1wb3J0KCdAZHVja2R1Y2tnby9wcml2YWN5LWRhc2hib2FyZC9zY2hlbWEvX19nZW5lcmF0ZWRfXy9zY2hlbWEudHlwZXMnKS5JbmNvbWluZ0V4dGVuc2lvbk1lc3NhZ2V9IE91dGdvaW5nUG9wdXBNZXNzYWdlXG4gKi9cblxuZXhwb3J0IGNsYXNzIE1lc3NhZ2VSZWNlaXZlZEV2ZW50IGV4dGVuZHMgQ3VzdG9tRXZlbnQge1xuICAgIGNvbnN0cnVjdG9yKG1zZykge1xuICAgICAgICBzdXBlcignbWVzc2FnZVJlY2VpdmVkJywgeyBkZXRhaWw6IG1zZyB9KTtcbiAgICB9XG5cbiAgICBnZXQgbWVzc2FnZVR5cGUoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmRldGFpbC5tZXNzYWdlVHlwZTtcbiAgICB9XG59XG5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIE1lc3NhZ2VSb3V0ZXIgZXh0ZW5kcyBFdmVudFRhcmdldCB7XG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHN1cGVyKCk7XG4gICAgICAgIGNvbnN0IGJyb3dzZXJOYW1lID0gZ2V0QnJvd3Nlck5hbWUoKTtcbiAgICAgICAgLy8gSGFuZGxlIHBvcHVwIFVJIChha2EgcHJpdmFjeSBkYXNoYm9hcmQpIG1lc3NhZ2luZy5cbiAgICAgICAgYnJvd3Nlci5ydW50aW1lLm9uQ29ubmVjdC5hZGRMaXN0ZW5lcigocG9ydCkgPT4ge1xuICAgICAgICAgICAgaWYgKHBvcnQubmFtZSA9PT0gJ3ByaXZhY3ktZGFzaGJvYXJkJykge1xuICAgICAgICAgICAgICAgIHRoaXMucG9wdXBDb25uZWN0aW9uT3BlbmVkKHBvcnQpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcblxuICAgICAgICAvLyBIYW5kbGUgYW55IG1lc3NhZ2VzIHRoYXQgY29tZSBmcm9tIGNvbnRlbnQvVUkgc2NyaXB0c1xuICAgICAgICBicm93c2VyLnJ1bnRpbWUub25NZXNzYWdlLmFkZExpc3RlbmVyKChyZXEsIHNlbmRlcikgPT4ge1xuICAgICAgICAgICAgaWYgKHNlbmRlci5pZCAhPT0gZ2V0RXh0ZW5zaW9uSWQoKSkgcmV0dXJuO1xuXG4gICAgICAgICAgICAvLyBUT0RPIGNsZWFuIHVwIGxlZ2FjeSBvbmJvYXJkaW5nIG1lc3NhZ2luZ1xuICAgICAgICAgICAgaWYgKGJyb3dzZXJOYW1lID09PSAnY2hyb21lJyAmJiAocmVxID09PSAnaGVhbHRoQ2hlY2tSZXF1ZXN0JyB8fCByZXEgPT09ICdyZXNjaGVkdWxlQ291bnRlck1lc3NhZ2luZ1JlcXVlc3QnKSkge1xuICAgICAgICAgICAgICAgIHJlcSA9IHsgbWVzc2FnZVR5cGU6IHJlcSB9O1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAvLyBUT0RPIGNsZWFuIHVwIG1lc3NhZ2UgcGFzc2luZ1xuICAgICAgICAgICAgY29uc3QgbGVnYWN5TWVzc2FnZVR5cGVzID0gW1xuICAgICAgICAgICAgICAgICdhZGRVc2VyRGF0YScsXG4gICAgICAgICAgICAgICAgJ2dldFVzZXJEYXRhJyxcbiAgICAgICAgICAgICAgICAncmVtb3ZlVXNlckRhdGEnLFxuICAgICAgICAgICAgICAgICdnZXRFbWFpbFByb3RlY3Rpb25DYXBhYmlsaXRpZXMnLFxuICAgICAgICAgICAgICAgICdnZXRBZGRyZXNzZXMnLFxuICAgICAgICAgICAgICAgICdyZWZyZXNoQWxpYXMnLFxuICAgICAgICAgICAgICAgICdkZWJ1Z2dlck1lc3NhZ2UnLFxuICAgICAgICAgICAgXTtcbiAgICAgICAgICAgIGZvciAoY29uc3QgbGVnYWN5TWVzc2FnZVR5cGUgb2YgbGVnYWN5TWVzc2FnZVR5cGVzKSB7XG4gICAgICAgICAgICAgICAgaWYgKGxlZ2FjeU1lc3NhZ2VUeXBlIGluIHJlcSkge1xuICAgICAgICAgICAgICAgICAgICByZXEubWVzc2FnZVR5cGUgPSBsZWdhY3lNZXNzYWdlVHlwZTtcbiAgICAgICAgICAgICAgICAgICAgcmVxLm9wdGlvbnMgPSByZXFbbGVnYWN5TWVzc2FnZVR5cGVdO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgaWYgKHJlcS5yZWdpc3RlcmVkVGVtcEF1dG9maWxsQ29udGVudFNjcmlwdCkge1xuICAgICAgICAgICAgICAgIHJlcS5tZXNzYWdlVHlwZSA9ICdyZWdpc3RlcmVkQ29udGVudFNjcmlwdCc7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGlmIChyZXEubWVzc2FnZVR5cGUgJiYgcmVxLm1lc3NhZ2VUeXBlIGluIG1lc3NhZ2VIYW5kbGVycykge1xuICAgICAgICAgICAgICAgIHRoaXMuZGlzcGF0Y2hFdmVudChuZXcgTWVzc2FnZVJlY2VpdmVkRXZlbnQocmVxKSk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZShtZXNzYWdlSGFuZGxlcnNbcmVxLm1lc3NhZ2VUeXBlXShyZXEub3B0aW9ucywgc2VuZGVyLCByZXEpKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgY29uc29sZS5lcnJvcignVW5yZWNvZ25pemVkIG1lc3NhZ2UgdG8gYmFja2dyb3VuZDonLCByZXEsIHNlbmRlcik7XG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFNldCB1cCB0aGUgbWVzc2FnaW5nIGNvbm5lY3Rpb24gd2l0aCB0aGUgcG9wdXAgVUkuXG4gICAgICpcbiAgICAgKiBOb3RlOiBJZiB0aGUgU2VydmljZVdvcmtlciBkaWVzIHdoaWxlIHRoZXJlIGlzIGFuIG9wZW4gY29ubmVjdGlvbiwgdGhlIHBvcHVwXG4gICAgICogICAgICAgd2lsbCB0YWtlIGNhcmUgb2YgcmUtb3BlbmluZyB0aGUgY29ubmVjdGlvbi5cbiAgICAgKlxuICAgICAqIEBwYXJhbSB7UG9ydH0gcG9ydFxuICAgICAqL1xuICAgIHBvcHVwQ29ubmVjdGlvbk9wZW5lZChwb3J0KSB7XG4gICAgICAgIHNldEFjdGl2ZVBvcnQocG9ydCk7XG4gICAgICAgIHBvcnQub25EaXNjb25uZWN0LmFkZExpc3RlbmVyKCgpID0+IHtcbiAgICAgICAgICAgIGlmIChnZXRBY3RpdmVQb3J0KCkgPT09IHBvcnQpIHtcbiAgICAgICAgICAgICAgICBzZXRBY3RpdmVQb3J0KG51bGwpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcblxuICAgICAgICBwb3J0Lm9uTWVzc2FnZS5hZGRMaXN0ZW5lcihhc3luYyAobWVzc2FnZSkgPT4ge1xuICAgICAgICAgICAgY29uc3QgbWVzc2FnZVR5cGUgPSBtZXNzYWdlPy5tZXNzYWdlVHlwZTtcblxuICAgICAgICAgICAgaWYgKCFtZXNzYWdlVHlwZSB8fCAhKG1lc3NhZ2VUeXBlIGluIG1lc3NhZ2VIYW5kbGVycykpIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKCdVbnJlY29nbml6ZWQgbWVzc2FnZSAocHJpdmFjeS1kYXNoYm9hcmQgLT4gYmFja2dyb3VuZCk6JywgbWVzc2FnZSk7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGhpcy5kaXNwYXRjaEV2ZW50KG5ldyBNZXNzYWdlUmVjZWl2ZWRFdmVudChtZXNzYWdlKSk7XG5cbiAgICAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgbWVzc2FnZUhhbmRsZXJzW21lc3NhZ2VUeXBlXShtZXNzYWdlPy5vcHRpb25zLCBwb3J0LCBtZXNzYWdlKTtcbiAgICAgICAgICAgIGlmICh0eXBlb2YgbWVzc2FnZT8uaWQgPT09ICdudW1iZXInKSB7XG4gICAgICAgICAgICAgICAgcG9ydC5wb3N0TWVzc2FnZSh7XG4gICAgICAgICAgICAgICAgICAgIGlkOiBtZXNzYWdlLmlkLFxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlVHlwZTogJ3Jlc3BvbnNlJyxcbiAgICAgICAgICAgICAgICAgICAgb3B0aW9uczogcmVzcG9uc2UsXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH1cbn1cbiIsICJpbXBvcnQgYnJvd3NlciBmcm9tICd3ZWJleHRlbnNpb24tcG9seWZpbGwnO1xuaW1wb3J0IHsgZ2V0RXh0ZW5zaW9uVmVyc2lvbiwgZ2V0RnJvbVNlc3Npb25TdG9yYWdlLCBzZXRUb1Nlc3Npb25TdG9yYWdlIH0gZnJvbSAnLi93cmFwcGVyJztcbmltcG9ydCB0ZHNTdG9yYWdlIGZyb20gJy4vc3RvcmFnZS90ZHMnO1xuaW1wb3J0IHNldHRpbmdzIGZyb20gJy4vc2V0dGluZ3MnO1xuaW1wb3J0IHsgcGFyc2UgYXMgdGxkdHNQYXJzZSB9IGZyb20gJ3RsZHRzJztcbmltcG9ydCBwYXJzZVVzZXJBZ2VudFN0cmluZyBmcm9tICcuLi9zaGFyZWQtdXRpbHMvcGFyc2UtdXNlci1hZ2VudC1zdHJpbmcnO1xuaW1wb3J0IHNoYTEgZnJvbSAnLi4vc2hhcmVkLXV0aWxzL3NoYTEnO1xuY29uc3QgYnJvd3NlckluZm8gPSBwYXJzZVVzZXJBZ2VudFN0cmluZygpO1xuXG4vKipcbiAqIEB0eXBlZGVmIHtpbXBvcnQoJ0BkdWNrZHVja2dvL3ByaXZhY3ktY29uZmlndXJhdGlvbi9zY2hlbWEvY29uZmlnLnRzJykuQ3VycmVudEdlbmVyaWNDb25maWd9IENvbmZpZ1xuICovXG5cbi8qKlxuICogUHJvZHVjZSBhIHJhbmRvbSBmbG9hdCwgbWF0Y2hlcyB0aGUgb3V0cHV0IG9mIE1hdGgucmFuZG9tKCkgYnV0IG11Y2ggbW9yZSBjcnlwdG9ncmFwaGljYWxseSBwc3Vkby1yYW5kb20uXG4gKiBAcmV0dXJucyB7bnVtYmVyfVxuICovXG5mdW5jdGlvbiBnZXRSYW5kb21GbG9hdCgpIHtcbiAgICByZXR1cm4gY3J5cHRvLmdldFJhbmRvbVZhbHVlcyhuZXcgVWludDMyQXJyYXkoMSkpWzBdIC8gMiAqKiAzMjtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFNlc3Npb25LZXkoKSB7XG4gICAgbGV0IHNlc3Npb25LZXkgPSBhd2FpdCBnZXRGcm9tU2Vzc2lvblN0b3JhZ2UoJ3Nlc3Npb25LZXknKTtcbiAgICBpZiAoIXNlc3Npb25LZXkpIHtcbiAgICAgICAgc2Vzc2lvbktleSA9IGF3YWl0IHJlc2V0U2Vzc2lvbktleSgpO1xuICAgIH1cbiAgICByZXR1cm4gc2Vzc2lvbktleTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHJlc2V0U2Vzc2lvbktleSgpIHtcbiAgICBjb25zdCBzZXNzaW9uS2V5ID0gc2hhMShnZXRSYW5kb21GbG9hdCgpLnRvU3RyaW5nKCkpO1xuICAgIGF3YWl0IHNldFRvU2Vzc2lvblN0b3JhZ2UoJ3Nlc3Npb25LZXknLCBzZXNzaW9uS2V5KTtcbiAgICByZXR1cm4gc2Vzc2lvbktleTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNlbmRUYWJNZXNzYWdlKGlkLCBtZXNzYWdlLCBkZXRhaWxzKSB7XG4gICAgdHJ5IHtcbiAgICAgICAgYXdhaXQgYnJvd3Nlci50YWJzLnNlbmRNZXNzYWdlKGlkLCBtZXNzYWdlLCBkZXRhaWxzKTtcbiAgICB9IGNhdGNoIHtcbiAgICAgICAgLy8gSWdub3JlIGVycm9yc1xuICAgIH1cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNlbmRBbGxUYWJzTWVzc2FnZShtZXNzYWdlLCBkZXRhaWxzKSB7XG4gICAgdHJ5IHtcbiAgICAgICAgZm9yIChjb25zdCB7IGlkOiB0YWJJZCB9IG9mIGF3YWl0IGJyb3dzZXIudGFicy5xdWVyeSh7fSkpIHtcbiAgICAgICAgICAgIHNlbmRUYWJNZXNzYWdlKHRhYklkLCBtZXNzYWdlLCBkZXRhaWxzKTtcbiAgICAgICAgfVxuICAgIH0gY2F0Y2gge1xuICAgICAgICAvLyBJZ25vcmUgZXJyb3JzXG4gICAgfVxufVxuXG4vKipcbiAqIEBwYXJhbSB7c3RyaW5nfSB1cmxTdHJpbmdcbiAqIEByZXR1cm5zIHtzdHJpbmcgfCBudWxsfSBldGxkIHBsdXMgb25lIG9mIHRoZSBVUkxcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdldEJhc2VEb21haW4odXJsU3RyaW5nKSB7XG4gICAgY29uc3QgcGFyc2VkVXJsID0gdGxkdHNQYXJzZSh1cmxTdHJpbmcsIHsgYWxsb3dQcml2YXRlRG9tYWluczogdHJ1ZSB9KTtcbiAgICBpZiAocGFyc2VkVXJsLmhvc3RuYW1lID09PSAnbG9jYWxob3N0JyB8fCBwYXJzZWRVcmwuaG9zdG5hbWU/LmVuZHNXaXRoKCcubG9jYWxob3N0JykgfHwgcGFyc2VkVXJsLmlzSXApIHtcbiAgICAgICAgcmV0dXJuIHBhcnNlZFVybC5ob3N0bmFtZTtcbiAgICB9XG4gICAgcmV0dXJuIHBhcnNlZFVybC5kb21haW47XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBleHRyYWN0SG9zdEZyb21VUkwodXJsLCBzaG91bGRLZWVwV1dXKSB7XG4gICAgaWYgKCF1cmwpIHJldHVybiAnJztcblxuICAgIC8vIFR3ZWFrIHRoZSBVUkwgZm9yIEZpcmVmb3ggYWJvdXQ6KiBwYWdlcyB0byBlbnN1cmUgdGhhdCB0aGV5IGFyZSBwYXJzZWRcbiAgICAvLyBjb3JyZWN0bHkuIEZvciBleGFtcGxlLCAnYWJvdXQ6ZXhhbXBsZScgYmVjb21lcyAnYWJvdXQ6Ly9leGFtcGxlJy5cbiAgICBpZiAodXJsLnN0YXJ0c1dpdGgoJ2Fib3V0OicpICYmIHVybFs2XSAhPT0gJy8nKSB7XG4gICAgICAgIHVybCA9ICdhYm91dDovLycgKyB1cmwuc3Vic3RyKDYpO1xuICAgIH1cblxuICAgIGNvbnN0IHVybE9iaiA9IHRsZHRzUGFyc2UodXJsKTtcbiAgICBsZXQgaG9zdG5hbWUgPSB1cmxPYmouaG9zdG5hbWUgfHwgJyc7XG5cbiAgICBpZiAoIXNob3VsZEtlZXBXV1cpIHtcbiAgICAgICAgaG9zdG5hbWUgPSBob3N0bmFtZS5yZXBsYWNlKC9ed3d3XFwuLywgJycpO1xuICAgIH1cblxuICAgIHJldHVybiBob3N0bmFtZTtcbn1cblxuLy8gUmVtb3ZlcyBpbmZvcm1hdGlvbiBmcm9tIGEgVVJMLCBzdWNoIGFzIHBhdGgsIHVzZXIgaW5mb3JtYXRpb24sIGFuZCBvcHRpb25hbGx5IHN1YiBkb21haW5zXG4vLyBAdHMtaWdub3JlXG5leHBvcnQgZnVuY3Rpb24gZXh0cmFjdExpbWl0ZWREb21haW5Gcm9tVVJMKHVybCwgeyBrZWVwU3ViZG9tYWlucyB9ID0ge30pIHtcbiAgICBpZiAoIXVybCkgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCBwYXJzZWRVUkwgPSBuZXcgVVJMKHVybCk7XG4gICAgICAgIGNvbnN0IHRsZCA9IHRsZHRzUGFyc2UodXJsKTtcbiAgICAgICAgaWYgKCFwYXJzZWRVUkwgfHwgIXRsZCkgcmV0dXJuICcnO1xuICAgICAgICAvLyB0bGQuZG9tYWluIGlzIG51bGwgaWYgdGhpcyBpcyBhbiBJUCBvciB0aGUgZG9tYWluIGRvZXMgbm90IHVzZSBhIGtub3duIFRMRCAoZS5nLiBsb2NhbGhvc3QpXG4gICAgICAgIC8vIGluIHRoYXQgY2FzZSB1c2UgdGhlIGhvc3RuYW1lIChubyB0cnVuY2F0aW9uKVxuICAgICAgICBsZXQgZmluYWxVUkwgPSB0bGQuZG9tYWluIHx8IHRsZC5ob3N0bmFtZTtcbiAgICAgICAgaWYgKGtlZXBTdWJkb21haW5zKSB7XG4gICAgICAgICAgICBmaW5hbFVSTCA9IHRsZC5ob3N0bmFtZTtcbiAgICAgICAgfSBlbHNlIGlmICh0bGQuc3ViZG9tYWluICYmIHRsZC5zdWJkb21haW4udG9Mb3dlckNhc2UoKSA9PT0gJ3d3dycpIHtcbiAgICAgICAgICAgIC8vIFRoaXMgaXMgYSBzcGVjaWFsIGNhc2Ugd2hlcmUgaWYgYSBkb21haW4gcmVxdWlyZXMgJ3d3dycgdG8gd29ya1xuICAgICAgICAgICAgLy8gd2Uga2VlcCBpdCwgZXZlbiBpZiB3ZSB3b3VsZG4ndCBub3JtYWxseSBrZWVwIHN1YmRvbWFpbnMuXG4gICAgICAgICAgICAvLyBub3RlIHRoYXQgZXZlbiBtdXRsaXBsZSBzdWJkb21haW5zIGxpa2Ugd3d3LnNvbWV0aGluZy5kb21haW4uY29tIGhhc1xuICAgICAgICAgICAgLy8gc3ViZG9tYWluIG9mIHd3dy5zb21ldGhpbmcsIGFuZCB3b3VsZG4ndCB0cmlnZ2VyIHRoaXMgY2FzZS5cbiAgICAgICAgICAgIGZpbmFsVVJMID0gJ3d3dy4nICsgdGxkLmRvbWFpbjtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBwb3J0ID0gcGFyc2VkVVJMLnBvcnQgPyBgOiR7cGFyc2VkVVJMLnBvcnR9YCA6ICcnO1xuXG4gICAgICAgIHJldHVybiBgJHtwYXJzZWRVUkwucHJvdG9jb2x9Ly8ke2ZpbmFsVVJMfSR7cG9ydH0vYDtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIC8vIHRyaWVkIHRvIHBhcnNlIGludmFsaWQgVVJMLCBzdWNoIGFzIGFuIGV4dGVuc2lvbiBVUkwuIEluIHRoaXMgY2FzZSwgZG9uJ3QgbW9kaWZ5IGFueXRoaW5nXG4gICAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gZXh0cmFjdFRvcFN1YmRvbWFpbkZyb21Ib3N0KGhvc3QpIHtcbiAgICBpZiAodHlwZW9mIGhvc3QgIT09ICdzdHJpbmcnKSByZXR1cm4gZmFsc2U7XG4gICAgY29uc3Qgcmd4ID0gL1xcLi9nO1xuICAgIC8vIEB0cy1pZ25vcmVcbiAgICBpZiAoaG9zdC5tYXRjaChyZ3gpICYmIGhvc3QubWF0Y2gocmd4KS5sZW5ndGggPiAxKSB7XG4gICAgICAgIHJldHVybiBob3N0LnNwbGl0KCcuJylbMF07XG4gICAgfVxuICAgIHJldHVybiBmYWxzZTtcbn1cblxuLy8gcHVsbCBvZmYgc3ViZG9tYWlucyBhbmQgbG9vayBmb3IgcGFyZW50IGNvbXBhbmllc1xuZXhwb3J0IGZ1bmN0aW9uIGZpbmRQYXJlbnQodXJsKSB7XG4gICAgY29uc3QgcGFydHMgPSBleHRyYWN0SG9zdEZyb21VUkwodXJsKS5zcGxpdCgnLicpO1xuXG4gICAgd2hpbGUgKHBhcnRzLmxlbmd0aCA+IDEpIHtcbiAgICAgICAgY29uc3Qgam9pblVSTCA9IHBhcnRzLmpvaW4oJy4nKTtcblxuICAgICAgICAvLyBjaGVjayBpZiB0cmFja2VyIG93bmVyIGhhcyAnb3duZWRCeScgdG8gaW5kaWNhdGUgYSBwYXJlbnQuXG4gICAgICAgIGlmICh0ZHNTdG9yYWdlLnRkcy50cmFja2Vyc1tqb2luVVJMXT8ub3duZXI/Lm93bmVkQnkpIHtcbiAgICAgICAgICAgIHJldHVybiB0ZHNTdG9yYWdlLnRkcy50cmFja2Vyc1tqb2luVVJMXS5vd25lci5vd25lZEJ5O1xuICAgICAgICB9IGVsc2UgaWYgKHRkc1N0b3JhZ2UudGRzLmRvbWFpbnNbam9pblVSTF0pIHtcbiAgICAgICAgICAgIHJldHVybiB0ZHNTdG9yYWdlLnRkcy5kb21haW5zW2pvaW5VUkxdO1xuICAgICAgICB9XG4gICAgICAgIHBhcnRzLnNoaWZ0KCk7XG4gICAgfVxufVxuXG4vKipcbiAqIFRoZXJlIGFyZSBzaXR1YXRpb25zIHdoZXJlIHdlIHdhbnQgdG8gYWNjZXNzIHRoZSBwYXJlbnQncyBkaXNwbGF5TmFtZVxuICogb25seSAtIGZvciBpbnN0YW5jZSBpbiB0aGUgTmV3dGFiVHJhY2tlclN0YXRzIGZlYXR1cmUuXG4gKiBAcGFyYW0ge3N0cmluZ30gdXJsXG4gKiBAcmV0dXJucyB7c3RyaW5nfVxuICovXG5leHBvcnQgZnVuY3Rpb24gZmluZFBhcmVudERpc3BsYXlOYW1lKHVybCkge1xuICAgIGNvbnN0IHBhcmVudCA9IGZpbmRQYXJlbnQodXJsKTtcbiAgICBjb25zdCBlbnRpdHkgPSB0ZHNTdG9yYWdlLnRkcy5lbnRpdGllc1twYXJlbnRdO1xuXG4gICAgaWYgKGVudGl0eSAmJiBlbnRpdHkuZGlzcGxheU5hbWUpIHtcbiAgICAgICAgcmV0dXJuIGVudGl0eS5kaXNwbGF5TmFtZTtcbiAgICB9XG5cbiAgICByZXR1cm4gJ3Vua25vd24nO1xufVxuXG4vKipcbiAqIFJldHVybiB0aGUgZGV0YWlscyBvZiB0aGUgY3VycmVudGx5IGZvY3VzZWQgdGFiLCBpZiBhdmFpbGFibGUuXG4gKlxuICogQHJldHVybnMge1Byb21pc2U8YnJvd3Nlci5UYWJzLlRhYnx1bmRlZmluZWQ+fVxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0Q3VycmVudFRhYigpIHtcbiAgICAvLyBJZiB0aGUgY3VycmVudCB0YWIgSUQgaXMgYWxyZWFkeSBrbm93biwgZmV0Y2ggdGhlIGRldGFpbHMgZm9yIHRoYXQgdGFiLlxuICAgIGNvbnN0IHRhYklkID0gYXdhaXQgZ2V0RnJvbVNlc3Npb25TdG9yYWdlKCdjdXJyZW50VGFiSWQnKTtcblxuICAgIGlmICh0YWJJZCkge1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgcmV0dXJuIGF3YWl0IGJyb3dzZXIudGFicy5nZXQodGFiSWQpO1xuICAgICAgICB9IGNhdGNoIChlKSB7fVxuICAgIH1cblxuICAgIC8vIE90aGVyd2lzZSwgZmV0Y2ggdGhlIGRldGFpbHMgZm9yIHRoZSBjdXJyZW50bHkgZm9jdXNlZCB0YWIuXG4gICAgY29uc3QgdGFiRGF0YSA9IGF3YWl0IGJyb3dzZXIudGFicy5xdWVyeSh7XG4gICAgICAgIGFjdGl2ZTogdHJ1ZSxcbiAgICAgICAgbGFzdEZvY3VzZWRXaW5kb3c6IHRydWUsXG4gICAgfSk7XG4gICAgaWYgKHRhYkRhdGEubGVuZ3RoKSB7XG4gICAgICAgIHJldHVybiB0YWJEYXRhWzBdO1xuICAgIH1cbn1cblxuLy8gQnJvd3NlciAvIFZlcnNpb24gZGV0ZWN0aW9uXG4vLyBHZXQgY29ycmVjdCBuYW1lIGZvciBmZXRjaGluZyBVSSBhc3NldHNcbmV4cG9ydCBmdW5jdGlvbiBnZXRCcm93c2VyTmFtZSgpIHtcbiAgICBpZiAoIWJyb3dzZXJJbmZvIHx8ICFicm93c2VySW5mby5icm93c2VyKSByZXR1cm47XG5cbiAgICBsZXQgYnJvd3Nlck5hbWUgPSBicm93c2VySW5mby5icm93c2VyLnRvTG93ZXJDYXNlKCk7XG4gICAgaWYgKGJyb3dzZXJOYW1lID09PSAnZmlyZWZveCcpIGJyb3dzZXJOYW1lID0gJ21veic7XG5cbiAgICByZXR1cm4gYnJvd3Nlck5hbWU7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBnZXRPc05hbWUoKSB7XG4gICAgaWYgKCFicm93c2VySW5mbyB8fCAhYnJvd3NlckluZm8ub3MpIHJldHVybjtcbiAgICByZXR1cm4gYnJvd3NlckluZm8ub3M7XG59XG5cbi8vIERldGVybWluZSBpZiB1cGdyYWRlVG9TZWN1cmUgc3VwcG9ydGVkIChGaXJlZm94IDU5KylcbmV4cG9ydCBmdW5jdGlvbiBnZXRVcGdyYWRlVG9TZWN1cmVTdXBwb3J0KCkge1xuICAgIGxldCBjYW5VcGdyYWRlID0gZmFsc2U7XG4gICAgaWYgKGdldEJyb3dzZXJOYW1lKCkgIT09ICdtb3onKSByZXR1cm4gY2FuVXBncmFkZTtcblxuICAgIGlmIChicm93c2VySW5mbyAmJiBicm93c2VySW5mby52ZXJzaW9uID49IDU5KSB7XG4gICAgICAgIGNhblVwZ3JhZGUgPSB0cnVlO1xuICAgIH1cblxuICAgIHJldHVybiBjYW5VcGdyYWRlO1xufVxuXG4vLyByZXR1cm4gdHJ1ZSBpZiBicm93c2VyIGFsbG93cyB0byBoYW5kbGUgcmVxdWVzdCBhc3luY1xuZXhwb3J0IGZ1bmN0aW9uIGdldEFzeW5jQmxvY2tpbmdTdXBwb3J0KCkge1xuICAgIGNvbnN0IGJyb3dzZXJOYW1lID0gZ2V0QnJvd3Nlck5hbWUoKTtcblxuICAgIGlmIChicm93c2VyTmFtZSA9PT0gJ21veicgJiYgYnJvd3NlckluZm8gJiYgYnJvd3NlckluZm8udmVyc2lvbiA+PSA1Mikge1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9IGVsc2UgaWYgKFsnZWRnJywgJ2VkZ2UnLCAnYnJhdmUnLCAnY2hyb21lJ10uaW5jbHVkZXMoYnJvd3Nlck5hbWUpKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG5cbiAgICBjb25zb2xlLndhcm4oYFVucmVjb2duaXplZCBicm93c2VyIFwiJHticm93c2VyTmFtZX1cIiAtIGFzeW5jIHJlc3BvbnNlIGRpc2FsbG93ZWRgKTtcbiAgICByZXR1cm4gZmFsc2U7XG59XG5cbi8qKlxuICogQHBhcmFtIHtudW1iZXJ9IHN0YXR1c0NvZGVcbiAqIEByZXR1cm5zIHtib29sZWFufVxuICovXG5leHBvcnQgZnVuY3Rpb24gaXNSZWRpcmVjdChzdGF0dXNDb2RlKSB7XG4gICAgcmV0dXJuIHN0YXR1c0NvZGUgPj0gMzAwICYmIHN0YXR1c0NvZGUgPD0gMzk5O1xufVxuXG4vKlxuICogY2hlY2sgdG8gc2VlIGlmIHRoaXMgaXMgYSBicm9rZW4gc2l0ZSByZXBvcnRlZCBvbiBnaXRodWJcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGlzQnJva2VuKHVybCkge1xuICAgIGlmICghdGRzU3RvcmFnZT8uY29uZmlnLnVucHJvdGVjdGVkVGVtcG9yYXJ5KSByZXR1cm47XG4gICAgcmV0dXJuIGJyb2tlbkxpc3RJbmRleCh1cmwsIHRkc1N0b3JhZ2U/LmNvbmZpZy51bnByb3RlY3RlZFRlbXBvcmFyeSkgIT09IC0xO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gcmVtb3ZlQnJva2VuKGRvbWFpbiwgY29uZmlnID0gdGRzU3RvcmFnZS5jb25maWcpIHtcbiAgICBjb25zdCBpbmRleCA9IGJyb2tlbkxpc3RJbmRleChkb21haW4sIGNvbmZpZy51bnByb3RlY3RlZFRlbXBvcmFyeSk7XG4gICAgaWYgKGluZGV4ICE9PSAtMSkge1xuICAgICAgICBjb25zb2xlLmxvZygncmVtb3ZlJywgY29uZmlnLnVucHJvdGVjdGVkVGVtcG9yYXJ5LnNwbGljZShpbmRleCwgMSkpO1xuICAgIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGdldEVuYWJsZWRGZWF0dXJlc0Fib3V0QmxhbmsodXJsKSB7XG4gICAgaWYgKCF0ZHNTdG9yYWdlLmNvbmZpZy5mZWF0dXJlcykgcmV0dXJuIFtdO1xuICAgIGNvbnN0IGVuYWJsZWRGZWF0dXJlcyA9IFtdO1xuICAgIGZvciAoY29uc3QgZmVhdHVyZSBpbiB0ZHNTdG9yYWdlLmNvbmZpZy5mZWF0dXJlcykge1xuICAgICAgICBjb25zdCBmZWF0dXJlU2V0dGluZ3MgPSBnZXRGZWF0dXJlU2V0dGluZ3MoZmVhdHVyZSk7XG5cbiAgICAgICAgaWYgKGZlYXR1cmVTZXR0aW5ncy5hYm91dEJsYW5rRW5hYmxlZCAhPT0gJ2Rpc2FibGVkJyAmJiBicm9rZW5MaXN0SW5kZXgodXJsLCBmZWF0dXJlU2V0dGluZ3MuYWJvdXRCbGFua1NpdGVzIHx8IFtdKSA9PT0gLTEpIHtcbiAgICAgICAgICAgIGVuYWJsZWRGZWF0dXJlcy5wdXNoKGZlYXR1cmUpO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBlbmFibGVkRmVhdHVyZXM7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBnZXRFbmFibGVkRmVhdHVyZXModXJsKSB7XG4gICAgaWYgKCF0ZHNTdG9yYWdlLmNvbmZpZy5mZWF0dXJlcykgcmV0dXJuIFtdO1xuICAgIGNvbnN0IGVuYWJsZWRGZWF0dXJlcyA9IFtdO1xuICAgIGZvciAoY29uc3QgZmVhdHVyZSBpbiB0ZHNTdG9yYWdlLmNvbmZpZy5mZWF0dXJlcykge1xuICAgICAgICBpZiAoaXNGZWF0dXJlRW5hYmxlZChmZWF0dXJlKSAmJiBicm9rZW5MaXN0SW5kZXgodXJsLCB0ZHNTdG9yYWdlLmNvbmZpZy5mZWF0dXJlc1tmZWF0dXJlXS5leGNlcHRpb25zIHx8IFtdKSA9PT0gLTEpIHtcbiAgICAgICAgICAgIGVuYWJsZWRGZWF0dXJlcy5wdXNoKGZlYXR1cmUpO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBlbmFibGVkRmVhdHVyZXM7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBicm9rZW5MaXN0SW5kZXgodXJsLCBsaXN0KSB7XG4gICAgY29uc3QgcGFyc2VkRG9tYWluID0gdGxkdHNQYXJzZSh1cmwpO1xuICAgIGNvbnN0IGhvc3RuYW1lID0gcGFyc2VkRG9tYWluLmhvc3RuYW1lIHx8IHVybDtcblxuICAgIC8vIElmIHJvb3QgZG9tYWluIGluIHRlbXAgdW5wcm90ZWN0ZWQgbGlzdCwgcmV0dXJuIHRydWVcbiAgICByZXR1cm4gbGlzdC5maW5kSW5kZXgoKGJyb2tlblNpdGVEb21haW4pID0+IHtcbiAgICAgICAgaWYgKGJyb2tlblNpdGVEb21haW4uZG9tYWluKSB7XG4gICAgICAgICAgICByZXR1cm4gaG9zdG5hbWUgPT09IGJyb2tlblNpdGVEb21haW4uZG9tYWluIHx8IGhvc3RuYW1lLmVuZHNXaXRoKGAuJHticm9rZW5TaXRlRG9tYWluLmRvbWFpbn1gKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfSk7XG59XG5cbi8vIFdlIGluamVjdCB0aGlzIGludG8gY29udGVudCBzY3JpcHRzXG5leHBvcnQgZnVuY3Rpb24gZ2V0QnJva2VuU2NyaXB0TGlzdHMoKSB7XG4gICAgY29uc3QgYnJva2VuU2NyaXB0cyA9IHt9O1xuICAgIGZvciAoY29uc3Qga2V5IGluIHRkc1N0b3JhZ2UuY29uZmlnLmZlYXR1cmVzKSB7XG4gICAgICAgIGNvbnN0IGZlYXR1cmVTZXR0aW5ncyA9IGdldEZlYXR1cmVTZXR0aW5ncyhrZXkpO1xuICAgICAgICBicm9rZW5TY3JpcHRzW2tleV0gPSBmZWF0dXJlU2V0dGluZ3Muc2NyaXB0cz8ubWFwKChvYmopID0+IG9iai5kb21haW4pIHx8IFtdO1xuICAgIH1cbiAgICByZXR1cm4gYnJva2VuU2NyaXB0cztcbn1cblxuLy8gcmV0dXJuIHRydWUgaWYgdGhlIGdpdmVuIHVybCBpcyBpbiB0aGUgc2FmZWxpc3QuIEZvciBjaGVja2luZyBpZiB0aGUgY3VycmVudCB0YWIgaXMgaW4gdGhlIHNhZmVsaXN0LFxuLy8gdGFiTWFuYWdlci5zaXRlLmlzUHJvdGVjdGlvbkVuYWJsZWQoKSBpcyB0aGUgcHJlZmVycmVkIG1ldGhvZC5cbmV4cG9ydCBmdW5jdGlvbiBpc1NhZmVMaXN0ZWQodXJsKSB7XG4gICAgY29uc3QgaG9zdG5hbWUgPSBleHRyYWN0SG9zdEZyb21VUkwodXJsKTtcbiAgICBjb25zdCBzYWZlTGlzdCA9IHNldHRpbmdzLmdldFNldHRpbmcoJ2FsbG93bGlzdGVkJyk7XG4gICAgY29uc3Qgc3ViZG9tYWlucyA9IGhvc3RuYW1lLnNwbGl0KCcuJyk7XG4gICAgLy8gQ2hlY2sgdXNlciBzYWZlIGxpc3RcbiAgICAvLyBUT0RPIG1ha2UgdGhlIHNhbWUgYXMgYnJva2VuTGlzdEluZGV4IG1hdGNoaW5nXG4gICAgd2hpbGUgKHN1YmRvbWFpbnMubGVuZ3RoID4gMSkge1xuICAgICAgICBpZiAoc2FmZUxpc3QgJiYgc2FmZUxpc3Rbc3ViZG9tYWlucy5qb2luKCcuJyldKSB7XG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgICBzdWJkb21haW5zLnNoaWZ0KCk7XG4gICAgfVxuXG4gICAgLy8gQ2hlY2sgYnJva2VuIHNpdGVzXG4gICAgaWYgKGlzQnJva2VuKGhvc3RuYW1lKSkge1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG5cbiAgICByZXR1cm4gZmFsc2U7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBpc0Nvb2tpZUV4Y2x1ZGVkKHVybCkge1xuICAgIGNvbnN0IGRvbWFpbiA9IG5ldyBVUkwodXJsKS5ob3N0O1xuICAgIHJldHVybiBpc0RvbWFpbkNvb2tpZUV4Y2x1ZGVkKGRvbWFpbik7XG59XG5cbmZ1bmN0aW9uIGlzRG9tYWluQ29va2llRXhjbHVkZWQoZG9tYWluKSB7XG4gICAgY29uc3QgY29va2llU2V0dGluZ3MgPSBnZXRGZWF0dXJlU2V0dGluZ3MoJ2Nvb2tpZScpO1xuICAgIGlmICghY29va2llU2V0dGluZ3MgfHwgIWNvb2tpZVNldHRpbmdzLmV4Y2x1ZGVkQ29va2llRG9tYWlucykge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuXG4gICAgaWYgKGNvb2tpZVNldHRpbmdzLmV4Y2x1ZGVkQ29va2llRG9tYWlucy5maW5kKChlbGVtKSA9PiBlbGVtLmRvbWFpbiA9PT0gZG9tYWluKSkge1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG5cbiAgICBjb25zdCBjb21wcyA9IGRvbWFpbi5zcGxpdCgnLicpO1xuICAgIGlmIChjb21wcy5sZW5ndGggPiAyKSB7XG4gICAgICAgIGNvbXBzLnNoaWZ0KCk7XG4gICAgICAgIHJldHVybiBpc0RvbWFpbkNvb2tpZUV4Y2x1ZGVkKGNvbXBzLmpvaW4oJy4nKSk7XG4gICAgfVxuXG4gICAgcmV0dXJuIGZhbHNlO1xufVxuXG4vKipcbiAqIFRlc3RzIHdoZXRoZXIgdGhlIHR3byBVUkwncyBiZWxvbmcgdG8gdGhlIHNhbWVcbiAqIHRvcCBsZXZlbCBkb21haW4uXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBpc1NhbWVUb3BMZXZlbERvbWFpbih1cmwxLCB1cmwyKSB7XG4gICAgY29uc3QgZmlyc3QgPSBnZXRCYXNlRG9tYWluKHVybDEpO1xuICAgIGNvbnN0IHNlY29uZCA9IGdldEJhc2VEb21haW4odXJsMik7XG5cbiAgICBpZiAoIWZpcnN0IHx8ICFzZWNvbmQpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cblxuICAgIHJldHVybiBmaXJzdCA9PT0gc2Vjb25kO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gcGFyc2VWZXJzaW9uU3RyaW5nKHZlcnNpb25TdHJpbmcpIHtcbiAgICByZXR1cm4gdmVyc2lvblN0cmluZy5zcGxpdCgnLicpLm1hcChOdW1iZXIpO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gc2F0aXNmaWVzTWluVmVyc2lvbihtaW5WZXJzaW9uU3RyaW5nLCBleHRlbnNpb25WZXJzaW9uU3RyaW5nKSB7XG4gICAgY29uc3QgbWluVmVyc2lvbnMgPSBwYXJzZVZlcnNpb25TdHJpbmcobWluVmVyc2lvblN0cmluZyk7XG4gICAgY29uc3QgY3VycmVudFZlcnNpb25zID0gcGFyc2VWZXJzaW9uU3RyaW5nKGV4dGVuc2lvblZlcnNpb25TdHJpbmcpO1xuICAgIGNvbnN0IG1heExlbmd0aCA9IE1hdGgubWF4KG1pblZlcnNpb25zLmxlbmd0aCwgY3VycmVudFZlcnNpb25zLmxlbmd0aCk7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBtYXhMZW5ndGg7IGkrKykge1xuICAgICAgICBjb25zdCBtaW5OdW1iZXJQYXJ0ID0gbWluVmVyc2lvbnNbaV0gfHwgMDtcbiAgICAgICAgY29uc3QgY3VycmVudFZlcnNpb25QYXJ0ID0gY3VycmVudFZlcnNpb25zW2ldIHx8IDA7XG4gICAgICAgIGlmIChjdXJyZW50VmVyc2lvblBhcnQgPiBtaW5OdW1iZXJQYXJ0KSB7XG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoY3VycmVudFZlcnNpb25QYXJ0IDwgbWluTnVtYmVyUGFydCkge1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiB0cnVlO1xufVxuXG4vKipcbiAqIENoZWNrcyB0aGUgY29uZmlnIHRvIHNlZSBpZiBhIGZlYXR1cmUgaXMgZW5hYmxlZC4gWW91IGNhbiBvcHRpb25hbGx5IHBhc3MgYSBzZWNvbmQgXCJjdXN0b21TdGF0ZVwiXG4gKiBwYXJhbWV0ZXIgdG8gY2hlY2sgaWYgdGhlIHN0YXRlIGlzIGVxdWVhbCB0byBvdGhlciBzdGF0ZXMgKGkuZS4gc3RhdGUgPT09ICdiZXRhJykuXG4gKlxuICogQHBhcmFtIHtTdHJpbmd9IGZlYXR1cmVOYW1lIC0gdGhlIG5hbWUgb2YgdGhlIGZlYXR1cmVcbiAqIEBwYXJhbSB7Q29uZmlnfSBjb25maWdcbiAqIEByZXR1cm5zIHtib29sZWFufSAtIGlmIGZlYXR1cmUgaXMgZW5hYmxlZFxuICovXG5leHBvcnQgZnVuY3Rpb24gaXNGZWF0dXJlRW5hYmxlZChmZWF0dXJlTmFtZSwgY29uZmlnID0gdGRzU3RvcmFnZS5jb25maWcpIHtcbiAgICBjb25zdCBmZWF0dXJlID0gY29uZmlnLmZlYXR1cmVzW2ZlYXR1cmVOYW1lXTtcbiAgICBpZiAoIWZlYXR1cmUpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cblxuICAgIC8vIElmIHdlIGhhdmUgYSBzdXBwbGllZCBtaW4gdmVyc2lvbiBmb3IgdGhlIGZlYXR1cmUgZW5zdXJlIHRoZSBleHRlbnNpb24gbWVldHMgaXRcbiAgICBpZiAoJ21pblN1cHBvcnRlZFZlcnNpb24nIGluIGZlYXR1cmUpIHtcbiAgICAgICAgY29uc3QgZXh0ZW5zaW9uVmVyc2lvblN0cmluZyA9IGdldEV4dGVuc2lvblZlcnNpb24oKTtcbiAgICAgICAgaWYgKCFzYXRpc2ZpZXNNaW5WZXJzaW9uKGZlYXR1cmUubWluU3VwcG9ydGVkVmVyc2lvbiwgZXh0ZW5zaW9uVmVyc2lvblN0cmluZykpIHtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiBmZWF0dXJlLnN0YXRlID09PSAnZW5hYmxlZCc7XG59XG5cbi8qKlxuICogUmV0dXJucyB0aGUgc2V0dGluZ3Mgb2JqZWN0IGFzc29jaWF0ZWQgd2l0aCBmZWF0dXJlTmFtZSBpbiB0aGUgY29uZmlnXG4gKlxuICogQHBhcmFtIHtTdHJpbmd9IGZlYXR1cmVOYW1lIC0gdGhlIG5hbWUgb2YgdGhlIGZlYXR1cmVcbiAqIEBwYXJhbSB7Q29uZmlnfSBjb25maWdcbiAqIEByZXR1cm5zIHtPYmplY3R9IC0gU2V0dGluZ3MgYXNzb2NpYXRlZCBpbiB0aGUgY29uZmlnIHdpdGggZmVhdHVyZU5hbWVcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdldEZlYXR1cmVTZXR0aW5ncyhmZWF0dXJlTmFtZSwgY29uZmlnID0gdGRzU3RvcmFnZS5jb25maWcpIHtcbiAgICBjb25zdCBmZWF0dXJlID0gY29uZmlnLmZlYXR1cmVzW2ZlYXR1cmVOYW1lXTtcbiAgICBpZiAodHlwZW9mIGZlYXR1cmUgIT09ICdvYmplY3QnIHx8IGZlYXR1cmUgPT09IG51bGwgfHwgIWZlYXR1cmUuc2V0dGluZ3MpIHtcbiAgICAgICAgcmV0dXJuIHt9O1xuICAgIH1cblxuICAgIHJldHVybiBmZWF0dXJlLnNldHRpbmdzO1xufVxuXG4vKipcbiAqIFN0cmlwcyBvZmYgYSBxdWVyeSBzdHJpbmcgZnJvbSB0aGUgVVJMXG4gKiBAcGFyYW0ge3N0cmluZ30gdXJsU3RyaW5nXG4gKiBAcmV0dXJucyB7c3RyaW5nfVxuICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0VVJMV2l0aG91dFF1ZXJ5U3RyaW5nKHVybFN0cmluZykge1xuICAgIHJldHVybiB1cmxTdHJpbmc/LnNwbGl0KCc/JylbMF07XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiByZWxvYWRDdXJyZW50VGFiKCkge1xuICAgIGNvbnN0IHRhYiA9IGF3YWl0IGdldEN1cnJlbnRUYWIoKTtcbiAgICBpZiAodGFiICYmIHRhYi5pZCkge1xuICAgICAgICBhd2FpdCBicm93c2VyLnRhYnMucmVsb2FkKHRhYi5pZCk7XG4gICAgfVxufVxuXG5jb25zdCBkYXlNdWx0aXBsaWVyID0gMjQgKiA2MCAqIDYwICogMTAwMDtcblxuLyoqXG4gKiBDb252ZXJ0cyBBVEIgdmFsdWUgaW50byBkYXRlXG4gKiBAcGFyYW0ge3N0cmluZ30gYXRiXG4gKiBAcmV0dXJucyB7bnVtYmVyfG51bGx9XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZXRJbnN0YWxsVGltZXN0YW1wKGF0Yikge1xuICAgIGNvbnN0IG1hdGNoID0gYXRiLm1hdGNoKC9edj8oXFxkKyktKFxcZCkoLispPyQvaSk7XG4gICAgaWYgKCFtYXRjaCkgcmV0dXJuIG51bGw7XG5cbiAgICBjb25zdCBzdGFydERhdGUgPSAxNDU2MjcyMDAwMDAwO1xuICAgIGNvbnN0IHdlZWtzU2luY2UgPSAocGFyc2VJbnQobWF0Y2hbMV0sIDEwKSAtIDEpICogNyAqIGRheU11bHRpcGxpZXI7XG4gICAgY29uc3QgZGF5c1NpbmNlID0gKHBhcnNlSW50KG1hdGNoWzJdLCAxMCkgLSAxKSAqIGRheU11bHRpcGxpZXI7XG4gICAgY29uc3QgaW5zdGFsbFRpbWVzdGFtcCA9IG5ldyBEYXRlKHN0YXJ0RGF0ZSArIHdlZWtzU2luY2UgKyBkYXlzU2luY2UpLmdldFRpbWUoKTtcbiAgICByZXR1cm4gaXNOYU4oaW5zdGFsbFRpbWVzdGFtcCkgPyBudWxsIDogaW5zdGFsbFRpbWVzdGFtcDtcbn1cblxuLyoqXG4gKiBDaGVja3MgaWYgdGhlIGV4dGVuc2lvbiB3YXMgaW5zdGFsbGVkIHdpdGhpbiBkYXlzIG9mIHRoZSBmcm9tIGRhdGVcbiAqIEBwYXJhbSB7bnVtYmVyfSBudW1iZXJPZkRheXNcbiAqIEBwYXJhbSB7bnVtYmVyfSBbZnJvbURhdGVdXG4gKiBAcGFyYW0ge3N0cmluZ30gW2F0Yl1cbiAqIEByZXR1cm5zIHtib29sZWFufVxuICovXG5leHBvcnQgZnVuY3Rpb24gaXNJbnN0YWxsZWRXaXRoaW5EYXlzKG51bWJlck9mRGF5cywgZnJvbURhdGUgPSBEYXRlLm5vdygpLCBhdGIgPSBzZXR0aW5ncy5nZXRTZXR0aW5nKCdhdGInKSkge1xuICAgIHJldHVybiBkYXlzSW5zdGFsbGVkKGZyb21EYXRlLCBhdGIpIDw9IG51bWJlck9mRGF5cztcbn1cblxuLyoqXG4gKiBSZXR1cm5zIHRoZSBkYXlzIHNpbmNlIGluc3RhbGxlZCB1c2luZyBhdGJcbiAqIEBwYXJhbSB7bnVtYmVyfSBbZnJvbURhdGVdXG4gKiBAcGFyYW0ge3N0cmluZ30gW2F0Yl1cbiAqIEByZXR1cm5zIHtudW1iZXJ9XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBkYXlzSW5zdGFsbGVkKGZyb21EYXRlID0gRGF0ZS5ub3coKSwgYXRiID0gc2V0dGluZ3MuZ2V0U2V0dGluZygnYXRiJykpIHtcbiAgICBpZiAoIWF0YikgcmV0dXJuIE5hTjtcblxuICAgIGNvbnN0IGluc3RhbGxUaW1lc3RhbXAgPSBnZXRJbnN0YWxsVGltZXN0YW1wKGF0Yik7XG4gICAgLy8gSWYgd2UgY2FuJ3QgZ2V0IHRoZSBpbnN0YWxsIGRhdGUsIGFzc3VtZSBpdCB3YXNuJ3QgaW5zdGFsbGVkIGluIHRpbWUgcGVyaW9kXG4gICAgaWYgKCFpbnN0YWxsVGltZXN0YW1wKSByZXR1cm4gTmFOO1xuXG4gICAgcmV0dXJuIChmcm9tRGF0ZSAtIGluc3RhbGxUaW1lc3RhbXApIC8gZGF5TXVsdGlwbGllcjtcbn1cblxuLyoqXG4gKiBSZXR1cm5zIGEgUHJvbWlzZSB0aGF0IHJlc29sdmVzIGFmdGVyIHRoZSBnaXZlbiBudW1iZXIgb2YgbWlsbGlzZWNvbmRzLlxuICogTm90ZTogVGhlIGJhY2tncm91bmQgU2VydmljZVdvcmtlciBtaWdodCBiZSByZXN0YXJ0ZWQgYmVmb3JlIHRoZSByZXR1cm5lZFxuICogICAgICAgUHJvbWlzZSBpcyByZXNvbHZlZC4gQ29uc2lkZXIgdGhlIGltcGxpY2F0aW9ucyBvZiB0aGF0IGhhcHBlbmluZyB3aGVuXG4gKiAgICAgICB1c2luZyB0aGlzIGZ1bmN0aW9uLlxuICpcbiAqIHtudW1iZXJ9IGRlbGF5IChtaWxsaXNlY29uZHMpXG4gKiB7cmV0dXJuc30gUHJvbWlzZTx2b2lkPlxuICovXG5leHBvcnQgZnVuY3Rpb24gcmVzb2x2ZUFmdGVyRGVsYXkoZGVsYXkpIHtcbiAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcbiAgICAgICAgc2V0VGltZW91dChyZXNvbHZlLCBkZWxheSk7XG4gICAgfSk7XG59XG4iLCAiY29uc3Qgc2V0dGluZ3MgPSByZXF1aXJlKCcuLi9zZXR0aW5ncycpO1xuXG4vKipcbiAqIEB0eXBlZGVmIHtpbXBvcnQoJy4uL2NvbXBvbmVudHMvdGRzJykuZGVmYXVsdH0gVERTU3RvcmFnZVxuICovXG5cbi8qKiBAdHlwZSB7aW1wb3J0KCcuLi9jb21wb25lbnRzL3Jlc291cmNlLWxvYWRlcicpLlJlc291cmNlTmFtZVtdfSAqL1xuY29uc3QgbGlzdE5hbWVzID0gWyd0ZHMnLCAnc3Vycm9nYXRlcycsICdjb25maWcnXTtcblxuLyoqXG4gKiBUaGlzIG9iamVjdCBlbXVsYXRlcyB0aGUgbGVnYWN5IHRkc1N0b3JhZ2UgZ2xvYmFsIGNsYXNzLCBkZWxpZ2F0aW5nIGNhbGxzIHRvIDMgaW5zdGFuY2VzIG9mXG4gKiBSZXNvdXJjZUxvYWRlciAoZm9yIHRkcywgc3Vycm9nYXRlcyBhbmQgY29uZmlnIHJlc3BlY3RpdmVseSksIGRlZmluZWQgaW4gYmFja2dyb3VuZC5qc1xuICovXG5leHBvcnQgZGVmYXVsdCB7XG4gICAgX2NvbmZpZzogeyBmZWF0dXJlczoge30gfSxcbiAgICBfdGRzOiB7IGVudGl0aWVzOiB7fSwgdHJhY2tlcnM6IHt9LCBkb21haW5zOiB7fSwgY25hbWVzOiB7fSB9LFxuICAgIF9zdXJyb2dhdGVzOiAnJyxcbiAgICAvKiogQHR5cGUge2ltcG9ydCgnQGR1Y2tkdWNrZ28vcHJpdmFjeS1jb25maWd1cmF0aW9uL3NjaGVtYS9jb25maWcudHMnKS5DdXJyZW50R2VuZXJpY0NvbmZpZ30gKi9cbiAgICBnZXQgY29uZmlnKCkge1xuICAgICAgICByZXR1cm4gZ2xvYmFsVGhpcy5jb21wb25lbnRzPy5yZW1vdGVDb25maWcuY29uZmlnIHx8IHRoaXMuX2NvbmZpZztcbiAgICB9LFxuICAgIGdldCB0ZHMoKSB7XG4gICAgICAgIHJldHVybiBnbG9iYWxUaGlzLmNvbXBvbmVudHM/LnRkcy50ZHMuZGF0YSB8fCB0aGlzLl90ZHM7XG4gICAgfSxcbiAgICBnZXQgc3Vycm9nYXRlcygpIHtcbiAgICAgICAgcmV0dXJuIGdsb2JhbFRoaXMuY29tcG9uZW50cz8udGRzLnN1cnJvZ2F0ZXMuZGF0YSB8fCB0aGlzLl9zdXJyb2dhdGVzO1xuICAgIH0sXG4gICAgLy8gdGhlc2Ugc2V0dGVycyBhcmUgdG8gYWxsb3cgbGVnYWN5IHRlc3RzIHRvIG92ZXJyaWRlIHRoZSB2YWx1ZXMgaGVyZS4gSW4gYSBydW5uaW5nIGV4dGVuc2lvblxuICAgIC8vIHRoZXNlIHdpbGwgaGF2ZSBubyBlZmZlY3RcbiAgICBzZXQgY29uZmlnKGZhbGxiYWNrVmFsdWUpIHtcbiAgICAgICAgdGhpcy5fY29uZmlnID0gZmFsbGJhY2tWYWx1ZTtcbiAgICB9LFxuICAgIHNldCB0ZHMoZmFsbGJhY2tWYWx1ZSkge1xuICAgICAgICB0aGlzLl90ZHMgPSBmYWxsYmFja1ZhbHVlO1xuICAgIH0sXG4gICAgc2V0IHN1cnJvZ2F0ZXMoZmFsbGJhY2tWYWx1ZSkge1xuICAgICAgICB0aGlzLl9zdXJyb2dhdGVzID0gZmFsbGJhY2tWYWx1ZTtcbiAgICB9LFxuICAgIC8qKiBAdHlwZSB7VERTU3RvcmFnZT99ICovXG4gICAgZ2V0IHRkc1N0b3JhZ2UoKSB7XG4gICAgICAgIHJldHVybiBnbG9iYWxUaGlzLmNvbXBvbmVudHM/LnRkcztcbiAgICB9LFxuICAgIC8qKlxuICAgICAqIEBwYXJhbSB7aW1wb3J0KCcuLi9jb21wb25lbnRzL3Jlc291cmNlLWxvYWRlcicpLlJlc291cmNlTmFtZX0gY29uZmlnTmFtZVxuICAgICAqIEBwYXJhbSB7aW1wb3J0KCcuLi9jb21wb25lbnRzL3Jlc291cmNlLWxvYWRlcicpLk9uVXBkYXRlZENhbGxiYWNrfSBjYlxuICAgICAqL1xuICAgIGFzeW5jIG9uVXBkYXRlKGNvbmZpZ05hbWUsIGNiKSB7XG4gICAgICAgIGF3YWl0IHNldHRpbmdzLnJlYWR5KCk7XG4gICAgICAgIGlmIChsaXN0TmFtZXMuaW5jbHVkZXMoY29uZmlnTmFtZSkgJiYgdGhpcy50ZHNTdG9yYWdlICYmIHRoaXMudGRzU3RvcmFnZVtjb25maWdOYW1lXSkge1xuICAgICAgICAgICAgdGhpcy50ZHNTdG9yYWdlW2NvbmZpZ05hbWVdLm9uVXBkYXRlKGNiKTtcbiAgICAgICAgfVxuICAgIH0sXG4gICAgLyoqXG4gICAgICogQHBhcmFtIHtpbXBvcnQoJy4uL2NvbXBvbmVudHMvcmVzb3VyY2UtbG9hZGVyJykuUmVzb3VyY2VOYW1lfSBbY29uZmlnTmFtZV1cbiAgICAgKiBAcmV0dXJucyB7UHJvbWlzZX1cbiAgICAgKi9cbiAgICBhc3luYyByZWFkeShjb25maWdOYW1lKSB7XG4gICAgICAgIGF3YWl0IHNldHRpbmdzLnJlYWR5KCk7XG4gICAgICAgIGNvbnN0IHRkc1N0b3JhZ2UgPSB0aGlzLnRkc1N0b3JhZ2U7XG4gICAgICAgIGlmICghdGRzU3RvcmFnZSkge1xuICAgICAgICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZSgpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChjb25maWdOYW1lICYmIGxpc3ROYW1lcy5pbmNsdWRlcyhjb25maWdOYW1lKSkge1xuICAgICAgICAgICAgcmV0dXJuIHRkc1N0b3JhZ2VbY29uZmlnTmFtZV0uYWxsTG9hZGluZ0ZpbmlzaGVkO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBQcm9taXNlLmFsbChsaXN0TmFtZXMubWFwKChuKSA9PiB0ZHNTdG9yYWdlW25dLnJlYWR5KSk7XG4gICAgfSxcbiAgICBnZXRTZXJpYWxpemFibGVMaXN0KG5hbWUpIHtcbiAgICAgICAgLy8gVE9ETzogVGhpcyBzaG91bGQgYmUgbW92ZWQgdG8gYSAnZGV2dG9vbHMnIGNvbXBvbmVudFxuICAgICAgICBpZiAobmFtZSA9PT0gJ3RkcycpIHtcbiAgICAgICAgICAgIGNvbnN0IHRkcyA9IGdsb2JhbFRoaXMuY29tcG9uZW50cy50ZHMudGRzO1xuICAgICAgICAgICAgLy8gY29weSBhbmQgY29udmVydCByZWdleGVzIHRvIHN0cmluZ1xuICAgICAgICAgICAgY29uc3QgbGlzdENvcHkgPSBKU09OLnBhcnNlKEpTT04uc3RyaW5naWZ5KHRkcy5kYXRhKSk7XG4gICAgICAgICAgICBPYmplY3QudmFsdWVzKGxpc3RDb3B5LnRyYWNrZXJzKS5mb3JFYWNoKCh0cmFja2VyKSA9PiB7XG4gICAgICAgICAgICAgICAgdHJhY2tlci5ydWxlcz8uZm9yRWFjaCgocnVsZSwgaSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAvLyBjb252ZXJ0IFJlZ2V4IHRvIHN0cmluZyBhbmQgY3V0IHNsYXNoZXMgYW5kIGZsYWdzXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHJ1bGVSZWdleFN0ciA9IHRkcy5kYXRhLnRyYWNrZXJzW3RyYWNrZXIuZG9tYWluXS5ydWxlc1tpXS5ydWxlLnRvU3RyaW5nKCk7XG4gICAgICAgICAgICAgICAgICAgIHJ1bGUucnVsZSA9IHJ1bGVSZWdleFN0ci5zbGljZSgxLCBydWxlUmVnZXhTdHIubGVuZ3RoIC0gMyk7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHJldHVybiBsaXN0Q29weTtcbiAgICAgICAgfSBlbHNlIGlmIChbJ3N1cnJvZ2F0ZXMnLCAnY29uZmlnJ10uaW5jbHVkZXMobmFtZSkpIHtcbiAgICAgICAgICAgIHJldHVybiBnbG9iYWxUaGlzLmNvbXBvbmVudHMudGRzW25hbWVdLmRhdGE7XG4gICAgICAgIH1cbiAgICB9LFxuICAgIGFzeW5jIGdldExpc3RzKCkge1xuICAgICAgICBhd2FpdCB0aGlzLnJlYWR5KCk7XG4gICAgICAgIHJldHVybiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgbmFtZTogJ3RkcycsXG4gICAgICAgICAgICAgICAgZGF0YTogdGhpcy50ZHMsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIG5hbWU6ICdjb25maWcnLFxuICAgICAgICAgICAgICAgIGRhdGE6IHRoaXMuY29uZmlnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBuYW1lOiAnc3Vycm9nYXRlcycsXG4gICAgICAgICAgICAgICAgZGF0YTogdGhpcy5zdXJyb2dhdGVzLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgXTtcbiAgICB9LFxufTtcbiIsICJleHBvcnQgaW50ZXJmYWNlIElPcHRpb25zIHtcbiAgYWxsb3dJY2FubkRvbWFpbnM6IGJvb2xlYW47XG4gIGFsbG93UHJpdmF0ZURvbWFpbnM6IGJvb2xlYW47XG4gIGRldGVjdElwOiBib29sZWFuO1xuICBleHRyYWN0SG9zdG5hbWU6IGJvb2xlYW47XG4gIG1peGVkSW5wdXRzOiBib29sZWFuO1xuICB2YWxpZEhvc3RzOiBzdHJpbmdbXSB8IG51bGw7XG4gIHZhbGlkYXRlSG9zdG5hbWU6IGJvb2xlYW47XG59XG5cbmZ1bmN0aW9uIHNldERlZmF1bHRzSW1wbCh7XG4gIGFsbG93SWNhbm5Eb21haW5zID0gdHJ1ZSxcbiAgYWxsb3dQcml2YXRlRG9tYWlucyA9IGZhbHNlLFxuICBkZXRlY3RJcCA9IHRydWUsXG4gIGV4dHJhY3RIb3N0bmFtZSA9IHRydWUsXG4gIG1peGVkSW5wdXRzID0gdHJ1ZSxcbiAgdmFsaWRIb3N0cyA9IG51bGwsXG4gIHZhbGlkYXRlSG9zdG5hbWUgPSB0cnVlLFxufTogUGFydGlhbDxJT3B0aW9ucz4pOiBJT3B0aW9ucyB7XG4gIHJldHVybiB7XG4gICAgYWxsb3dJY2FubkRvbWFpbnMsXG4gICAgYWxsb3dQcml2YXRlRG9tYWlucyxcbiAgICBkZXRlY3RJcCxcbiAgICBleHRyYWN0SG9zdG5hbWUsXG4gICAgbWl4ZWRJbnB1dHMsXG4gICAgdmFsaWRIb3N0cyxcbiAgICB2YWxpZGF0ZUhvc3RuYW1lLFxuICB9O1xufVxuXG5jb25zdCBERUZBVUxUX09QVElPTlMgPSAvKkBfX0lOTElORV9fKi8gc2V0RGVmYXVsdHNJbXBsKHt9KTtcblxuZXhwb3J0IGZ1bmN0aW9uIHNldERlZmF1bHRzKG9wdGlvbnM/OiBQYXJ0aWFsPElPcHRpb25zPik6IElPcHRpb25zIHtcbiAgaWYgKG9wdGlvbnMgPT09IHVuZGVmaW5lZCkge1xuICAgIHJldHVybiBERUZBVUxUX09QVElPTlM7XG4gIH1cblxuICByZXR1cm4gLypAX19JTkxJTkVfXyovIHNldERlZmF1bHRzSW1wbChvcHRpb25zKTtcbn1cbiIsICIvKipcbiAqIEltcGxlbWVudCBhIGZhY3RvcnkgYWxsb3dpbmcgdG8gcGx1ZyBkaWZmZXJlbnQgaW1wbGVtZW50YXRpb25zIG9mIHN1ZmZpeFxuICogbG9va3VwIChlLmcuOiB1c2luZyBhIHRyaWUgb3IgdGhlIHBhY2tlZCBoYXNoZXMgZGF0YXN0cnVjdHVyZXMpLiBUaGlzIGlzIHVzZWRcbiAqIGFuZCBleHBvc2VkIGluIGB0bGR0cy50c2AgYW5kIGB0bGR0cy1leHBlcmltZW50YWwudHNgIGJ1bmRsZSBlbnRyeXBvaW50cy5cbiAqL1xuXG5pbXBvcnQgZ2V0RG9tYWluIGZyb20gJy4vZG9tYWluJztcbmltcG9ydCBnZXREb21haW5XaXRob3V0U3VmZml4IGZyb20gJy4vZG9tYWluLXdpdGhvdXQtc3VmZml4JztcbmltcG9ydCBleHRyYWN0SG9zdG5hbWUgZnJvbSAnLi9leHRyYWN0LWhvc3RuYW1lJztcbmltcG9ydCBpc0lwIGZyb20gJy4vaXMtaXAnO1xuaW1wb3J0IGlzVmFsaWRIb3N0bmFtZSBmcm9tICcuL2lzLXZhbGlkJztcbmltcG9ydCB7IElQdWJsaWNTdWZmaXgsIElTdWZmaXhMb29rdXBPcHRpb25zIH0gZnJvbSAnLi9sb29rdXAvaW50ZXJmYWNlJztcbmltcG9ydCB7IElPcHRpb25zLCBzZXREZWZhdWx0cyB9IGZyb20gJy4vb3B0aW9ucyc7XG5pbXBvcnQgZ2V0U3ViZG9tYWluIGZyb20gJy4vc3ViZG9tYWluJztcblxuZXhwb3J0IGludGVyZmFjZSBJUmVzdWx0IHtcbiAgLy8gYGhvc3RuYW1lYCBpcyBlaXRoZXIgYSByZWdpc3RlcmVkIG5hbWUgKGluY2x1ZGluZyBidXQgbm90IGxpbWl0ZWQgdG8gYVxuICAvLyBob3N0bmFtZSksIG9yIGFuIElQIGFkZHJlc3MuIElQdjQgYWRkcmVzc2VzIG11c3QgYmUgaW4gZG90LWRlY2ltYWxcbiAgLy8gbm90YXRpb24sIGFuZCBJUHY2IGFkZHJlc3NlcyBtdXN0IGJlIGVuY2xvc2VkIGluIGJyYWNrZXRzIChbXSkuIFRoaXMgaXNcbiAgLy8gZGlyZWN0bHkgZXh0cmFjdGVkIGZyb20gdGhlIGlucHV0IFVSTC5cbiAgaG9zdG5hbWU6IHN0cmluZyB8IG51bGw7XG5cbiAgLy8gSXMgYGhvc3RuYW1lYCBhbiBJUD8gKElQdjQgb3IgSVB2NilcbiAgaXNJcDogYm9vbGVhbiB8IG51bGw7XG5cbiAgLy8gYGhvc3RuYW1lYCBzcGxpdCBiZXR3ZWVuIHN1YmRvbWFpbiwgZG9tYWluIGFuZCBpdHMgcHVibGljIHN1ZmZpeCAoaWYgYW55KVxuICBzdWJkb21haW46IHN0cmluZyB8IG51bGw7XG4gIGRvbWFpbjogc3RyaW5nIHwgbnVsbDtcbiAgcHVibGljU3VmZml4OiBzdHJpbmcgfCBudWxsO1xuICBkb21haW5XaXRob3V0U3VmZml4OiBzdHJpbmcgfCBudWxsO1xuXG4gIC8vIFNwZWNpZmllcyBpZiBgcHVibGljU3VmZml4YCBjb21lcyBmcm9tIHRoZSBJQ0FOTiBvciBQUklWQVRFIHNlY3Rpb24gb2YgdGhlIGxpc3RcbiAgaXNJY2FubjogYm9vbGVhbiB8IG51bGw7XG4gIGlzUHJpdmF0ZTogYm9vbGVhbiB8IG51bGw7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBnZXRFbXB0eVJlc3VsdCgpOiBJUmVzdWx0IHtcbiAgcmV0dXJuIHtcbiAgICBkb21haW46IG51bGwsXG4gICAgZG9tYWluV2l0aG91dFN1ZmZpeDogbnVsbCxcbiAgICBob3N0bmFtZTogbnVsbCxcbiAgICBpc0ljYW5uOiBudWxsLFxuICAgIGlzSXA6IG51bGwsXG4gICAgaXNQcml2YXRlOiBudWxsLFxuICAgIHB1YmxpY1N1ZmZpeDogbnVsbCxcbiAgICBzdWJkb21haW46IG51bGwsXG4gIH07XG59XG5cbmV4cG9ydCBmdW5jdGlvbiByZXNldFJlc3VsdChyZXN1bHQ6IElSZXN1bHQpOiB2b2lkIHtcbiAgcmVzdWx0LmRvbWFpbiA9IG51bGw7XG4gIHJlc3VsdC5kb21haW5XaXRob3V0U3VmZml4ID0gbnVsbDtcbiAgcmVzdWx0Lmhvc3RuYW1lID0gbnVsbDtcbiAgcmVzdWx0LmlzSWNhbm4gPSBudWxsO1xuICByZXN1bHQuaXNJcCA9IG51bGw7XG4gIHJlc3VsdC5pc1ByaXZhdGUgPSBudWxsO1xuICByZXN1bHQucHVibGljU3VmZml4ID0gbnVsbDtcbiAgcmVzdWx0LnN1YmRvbWFpbiA9IG51bGw7XG59XG5cbi8vIEZsYWdzIHJlcHJlc2VudGluZyBzdGVwcyBpbiB0aGUgYHBhcnNlYCBmdW5jdGlvbi4gVGhleSBhcmUgdXNlZCB0byBpbXBsZW1lbnRcbi8vIGFuIGVhcmx5IHN0b3AgbWVjaGFuaXNtIChzaW11bGF0aW5nIHNvbWUgZm9ybSBvZiBsYXppbmVzcykgdG8gYXZvaWQgZG9pbmdcbi8vIG1vcmUgd29yayB0aGFuIG5lY2Vzc2FyeSB0byBwZXJmb3JtIGEgZ2l2ZW4gYWN0aW9uIChlLmcuOiB3ZSBkb24ndCBuZWVkIHRvXG4vLyBleHRyYWN0IHRoZSBkb21haW4gYW5kIHN1YmRvbWFpbiBpZiB3ZSBhcmUgb25seSBpbnRlcmVzdGVkIGluIHB1YmxpYyBzdWZmaXgpLlxuZXhwb3J0IGNvbnN0IGVudW0gRkxBRyB7XG4gIEhPU1ROQU1FLFxuICBJU19WQUxJRCxcbiAgUFVCTElDX1NVRkZJWCxcbiAgRE9NQUlOLFxuICBTVUJfRE9NQUlOLFxuICBBTEwsXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZUltcGwoXG4gIHVybDogc3RyaW5nLFxuICBzdGVwOiBGTEFHLFxuICBzdWZmaXhMb29rdXA6IChcbiAgICBfMTogc3RyaW5nLFxuICAgIF8yOiBJU3VmZml4TG9va3VwT3B0aW9ucyxcbiAgICBfMzogSVB1YmxpY1N1ZmZpeCxcbiAgKSA9PiB2b2lkLFxuICBwYXJ0aWFsT3B0aW9uczogUGFydGlhbDxJT3B0aW9ucz4sXG4gIHJlc3VsdDogSVJlc3VsdCxcbik6IElSZXN1bHQge1xuICBjb25zdCBvcHRpb25zOiBJT3B0aW9ucyA9IC8qQF9fSU5MSU5FX18qLyBzZXREZWZhdWx0cyhwYXJ0aWFsT3B0aW9ucyk7XG5cbiAgLy8gVmVyeSBmYXN0IGFwcHJveGltYXRlIGNoZWNrIHRvIG1ha2Ugc3VyZSBgdXJsYCBpcyBhIHN0cmluZy4gVGhpcyBpcyBuZWVkZWRcbiAgLy8gYmVjYXVzZSB0aGUgbGlicmFyeSB3aWxsIG5vdCBuZWNlc3NhcmlseSBiZSB1c2VkIGluIGEgdHlwZWQgc2V0dXAgYW5kXG4gIC8vIHZhbHVlcyBvZiBhcmJpdHJhcnkgdHlwZXMgbWlnaHQgYmUgZ2l2ZW4gYXMgYXJndW1lbnQuXG4gIGlmICh0eXBlb2YgdXJsICE9PSAnc3RyaW5nJykge1xuICAgIHJldHVybiByZXN1bHQ7XG4gIH1cblxuICAvLyBFeHRyYWN0IGhvc3RuYW1lIGZyb20gYHVybGAgb25seSBpZiBuZWVkZWQuIFRoaXMgY2FuIGJlIG1hZGUgb3B0aW9uYWxcbiAgLy8gdXNpbmcgYG9wdGlvbnMuZXh0cmFjdEhvc3RuYW1lYC4gVGhpcyBvcHRpb24gd2lsbCB0eXBpY2FsbHkgYmUgdXNlZFxuICAvLyB3aGVuZXZlciB3ZSBhcmUgc3VyZSB0aGUgaW5wdXRzIHRvIGBwYXJzZWAgYXJlIGFscmVhZHkgaG9zdG5hbWVzIGFuZCBub3RcbiAgLy8gYXJiaXRyYXJ5IFVSTHMuXG4gIC8vXG4gIC8vIGBtaXhlZElucHV0YCBhbGxvd3MgdG8gc3BlY2lmeSBpZiB3ZSBleHBlY3QgYSBtaXggb2YgVVJMcyBhbmQgaG9zdG5hbWVzXG4gIC8vIGFzIGlucHV0LiBJZiBvbmx5IGhvc3RuYW1lcyBhcmUgZXhwZWN0ZWQgdGhlbiBgZXh0cmFjdEhvc3RuYW1lYCBjYW4gYmVcbiAgLy8gc2V0IHRvIGBmYWxzZWAgdG8gc3BlZWQtdXAgcGFyc2luZy4gSWYgb25seSBVUkxzIGFyZSBleHBlY3RlZCB0aGVuXG4gIC8vIGBtaXhlZElucHV0c2AgY2FuIGJlIHNldCB0byBgZmFsc2VgLiBUaGUgYG1peGVkSW5wdXRzYCBpcyBvbmx5IGEgaGludFxuICAvLyBhbmQgd2lsbCBub3QgY2hhbmdlIHRoZSBiZWhhdmlvciBvZiB0aGUgbGlicmFyeS5cbiAgaWYgKCFvcHRpb25zLmV4dHJhY3RIb3N0bmFtZSkge1xuICAgIHJlc3VsdC5ob3N0bmFtZSA9IHVybDtcbiAgfSBlbHNlIGlmIChvcHRpb25zLm1peGVkSW5wdXRzKSB7XG4gICAgcmVzdWx0Lmhvc3RuYW1lID0gZXh0cmFjdEhvc3RuYW1lKHVybCwgaXNWYWxpZEhvc3RuYW1lKHVybCkpO1xuICB9IGVsc2Uge1xuICAgIHJlc3VsdC5ob3N0bmFtZSA9IGV4dHJhY3RIb3N0bmFtZSh1cmwsIGZhbHNlKTtcbiAgfVxuXG4gIC8vIENoZWNrIGlmIGBob3N0bmFtZWAgaXMgYSB2YWxpZCBpcCBhZGRyZXNzXG4gIGlmIChvcHRpb25zLmRldGVjdElwICYmIHJlc3VsdC5ob3N0bmFtZSAhPT0gbnVsbCkge1xuICAgIHJlc3VsdC5pc0lwID0gaXNJcChyZXN1bHQuaG9zdG5hbWUpO1xuICAgIGlmIChyZXN1bHQuaXNJcCkge1xuICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9XG4gIH1cblxuICAvLyBQZXJmb3JtIGhvc3RuYW1lIHZhbGlkYXRpb24gaWYgZW5hYmxlZC4gSWYgaG9zdG5hbWUgaXMgbm90IHZhbGlkLCBubyBuZWVkIHRvXG4gIC8vIGdvIGZ1cnRoZXIgYXMgdGhlcmUgd2lsbCBiZSBubyB2YWxpZCBkb21haW4gb3Igc3ViLWRvbWFpbi4gVGhpcyB2YWxpZGF0aW9uXG4gIC8vIGlzIGFwcGxpZWQgYmVmb3JlIGFueSBlYXJseSByZXR1cm5zIHRvIGVuc3VyZSBjb25zaXN0ZW50IGJlaGF2aW9yIGFjcm9zc1xuICAvLyBhbGwgQVBJIG1ldGhvZHMgaW5jbHVkaW5nIGdldEhvc3RuYW1lKCkuXG4gIGlmIChcbiAgICBvcHRpb25zLnZhbGlkYXRlSG9zdG5hbWUgJiZcbiAgICBvcHRpb25zLmV4dHJhY3RIb3N0bmFtZSAmJlxuICAgIHJlc3VsdC5ob3N0bmFtZSAhPT0gbnVsbCAmJlxuICAgICFpc1ZhbGlkSG9zdG5hbWUocmVzdWx0Lmhvc3RuYW1lKVxuICApIHtcbiAgICByZXN1bHQuaG9zdG5hbWUgPSBudWxsO1xuICAgIHJldHVybiByZXN1bHQ7XG4gIH1cblxuICBpZiAoc3RlcCA9PT0gRkxBRy5IT1NUTkFNRSB8fCByZXN1bHQuaG9zdG5hbWUgPT09IG51bGwpIHtcbiAgICByZXR1cm4gcmVzdWx0O1xuICB9XG5cbiAgLy8gRXh0cmFjdCBwdWJsaWMgc3VmZml4XG4gIHN1ZmZpeExvb2t1cChyZXN1bHQuaG9zdG5hbWUsIG9wdGlvbnMsIHJlc3VsdCk7XG4gIGlmIChzdGVwID09PSBGTEFHLlBVQkxJQ19TVUZGSVggfHwgcmVzdWx0LnB1YmxpY1N1ZmZpeCA9PT0gbnVsbCkge1xuICAgIHJldHVybiByZXN1bHQ7XG4gIH1cblxuICAvLyBFeHRyYWN0IGRvbWFpblxuICByZXN1bHQuZG9tYWluID0gZ2V0RG9tYWluKHJlc3VsdC5wdWJsaWNTdWZmaXgsIHJlc3VsdC5ob3N0bmFtZSwgb3B0aW9ucyk7XG4gIGlmIChzdGVwID09PSBGTEFHLkRPTUFJTiB8fCByZXN1bHQuZG9tYWluID09PSBudWxsKSB7XG4gICAgcmV0dXJuIHJlc3VsdDtcbiAgfVxuXG4gIC8vIEV4dHJhY3Qgc3ViZG9tYWluXG4gIHJlc3VsdC5zdWJkb21haW4gPSBnZXRTdWJkb21haW4ocmVzdWx0Lmhvc3RuYW1lLCByZXN1bHQuZG9tYWluKTtcbiAgaWYgKHN0ZXAgPT09IEZMQUcuU1VCX0RPTUFJTikge1xuICAgIHJldHVybiByZXN1bHQ7XG4gIH1cblxuICAvLyBFeHRyYWN0IGRvbWFpbiB3aXRob3V0IHN1ZmZpeFxuICByZXN1bHQuZG9tYWluV2l0aG91dFN1ZmZpeCA9IGdldERvbWFpbldpdGhvdXRTdWZmaXgoXG4gICAgcmVzdWx0LmRvbWFpbixcbiAgICByZXN1bHQucHVibGljU3VmZml4LFxuICApO1xuXG4gIHJldHVybiByZXN1bHQ7XG59XG4iLCAiaW1wb3J0IHtcbiAgRkxBRyxcbiAgZ2V0RW1wdHlSZXN1bHQsXG4gIElPcHRpb25zLFxuICBJUmVzdWx0LFxuICBwYXJzZUltcGwsXG4gIHJlc2V0UmVzdWx0LFxufSBmcm9tICd0bGR0cy1jb3JlJztcblxuaW1wb3J0IHN1ZmZpeExvb2t1cCBmcm9tICcuL3NyYy9zdWZmaXgtdHJpZSc7XG5cbi8vIEZvciBhbGwgbWV0aG9kcyBidXQgJ3BhcnNlJywgaXQgZG9lcyBub3QgbWFrZSBzZW5zZSB0byBhbGxvY2F0ZSBhbiBvYmplY3Rcbi8vIGV2ZXJ5IHNpbmdsZSB0aW1lIHRvIG9ubHkgcmV0dXJuIHRoZSB2YWx1ZSBvZiBhIHNwZWNpZmljIGF0dHJpYnV0ZS4gVG8gYXZvaWRcbi8vIHRoaXMgdW4tbmVjZXNzYXJ5IGFsbG9jYXRpb24sIHdlIHVzZSBhIGdsb2JhbCBvYmplY3Qgd2hpY2ggaXMgcmUtdXNlZC5cbmNvbnN0IFJFU1VMVDogSVJlc3VsdCA9IGdldEVtcHR5UmVzdWx0KCk7XG5cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZSh1cmw6IHN0cmluZywgb3B0aW9uczogUGFydGlhbDxJT3B0aW9ucz4gPSB7fSk6IElSZXN1bHQge1xuICByZXR1cm4gcGFyc2VJbXBsKHVybCwgRkxBRy5BTEwsIHN1ZmZpeExvb2t1cCwgb3B0aW9ucywgZ2V0RW1wdHlSZXN1bHQoKSk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBnZXRIb3N0bmFtZShcbiAgdXJsOiBzdHJpbmcsXG4gIG9wdGlvbnM6IFBhcnRpYWw8SU9wdGlvbnM+ID0ge30sXG4pOiBzdHJpbmcgfCBudWxsIHtcbiAgLypAX19JTkxJTkVfXyovIHJlc2V0UmVzdWx0KFJFU1VMVCk7XG4gIHJldHVybiBwYXJzZUltcGwodXJsLCBGTEFHLkhPU1ROQU1FLCBzdWZmaXhMb29rdXAsIG9wdGlvbnMsIFJFU1VMVCkuaG9zdG5hbWU7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBnZXRQdWJsaWNTdWZmaXgoXG4gIHVybDogc3RyaW5nLFxuICBvcHRpb25zOiBQYXJ0aWFsPElPcHRpb25zPiA9IHt9LFxuKTogc3RyaW5nIHwgbnVsbCB7XG4gIC8qQF9fSU5MSU5FX18qLyByZXNldFJlc3VsdChSRVNVTFQpO1xuICByZXR1cm4gcGFyc2VJbXBsKHVybCwgRkxBRy5QVUJMSUNfU1VGRklYLCBzdWZmaXhMb29rdXAsIG9wdGlvbnMsIFJFU1VMVClcbiAgICAucHVibGljU3VmZml4O1xufVxuXG5leHBvcnQgZnVuY3Rpb24gZ2V0RG9tYWluKFxuICB1cmw6IHN0cmluZyxcbiAgb3B0aW9uczogUGFydGlhbDxJT3B0aW9ucz4gPSB7fSxcbik6IHN0cmluZyB8IG51bGwge1xuICAvKkBfX0lOTElORV9fKi8gcmVzZXRSZXN1bHQoUkVTVUxUKTtcbiAgcmV0dXJuIHBhcnNlSW1wbCh1cmwsIEZMQUcuRE9NQUlOLCBzdWZmaXhMb29rdXAsIG9wdGlvbnMsIFJFU1VMVCkuZG9tYWluO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gZ2V0U3ViZG9tYWluKFxuICB1cmw6IHN0cmluZyxcbiAgb3B0aW9uczogUGFydGlhbDxJT3B0aW9ucz4gPSB7fSxcbik6IHN0cmluZyB8IG51bGwge1xuICAvKkBfX0lOTElORV9fKi8gcmVzZXRSZXN1bHQoUkVTVUxUKTtcbiAgcmV0dXJuIHBhcnNlSW1wbCh1cmwsIEZMQUcuU1VCX0RPTUFJTiwgc3VmZml4TG9va3VwLCBvcHRpb25zLCBSRVNVTFQpXG4gICAgLnN1YmRvbWFpbjtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGdldERvbWFpbldpdGhvdXRTdWZmaXgoXG4gIHVybDogc3RyaW5nLFxuICBvcHRpb25zOiBQYXJ0aWFsPElPcHRpb25zPiA9IHt9LFxuKTogc3RyaW5nIHwgbnVsbCB7XG4gIC8qQF9fSU5MSU5FX18qLyByZXNldFJlc3VsdChSRVNVTFQpO1xuICByZXR1cm4gcGFyc2VJbXBsKHVybCwgRkxBRy5BTEwsIHN1ZmZpeExvb2t1cCwgb3B0aW9ucywgUkVTVUxUKVxuICAgIC5kb21haW5XaXRob3V0U3VmZml4O1xufVxuIiwgIi8qKlxuICogQHR5cGVkZWYge2ltcG9ydCgnd2ViZXh0ZW5zaW9uLXBvbHlmaWxsJykuUnVudGltZS5Qb3J0fSBQb3J0XG4gKiBAdHlwZWRlZiB7aW1wb3J0KCdAZHVja2R1Y2tnby9wcml2YWN5LWRhc2hib2FyZC9zY2hlbWEvX19nZW5lcmF0ZWRfXy9zY2hlbWEudHlwZXMnKS5JbmNvbWluZ0V4dGVuc2lvbk1lc3NhZ2V9IE91dGdvaW5nUG9wdXBNZXNzYWdlXG4gKi9cblxuLy8gTWVzc2FnaW5nIGNvbm5lY3Rpb24gd2l0aCB0aGUgcG9wdXAgVUkgKHdoZW4gYWN0aXZlKS5cbi8qKiBAdHlwZSB7UG9ydD99ICovXG5sZXQgYWN0aXZlUG9ydCA9IG51bGw7XG5cbmV4cG9ydCBmdW5jdGlvbiBnZXRBY3RpdmVQb3J0KCkge1xuICAgIHJldHVybiBhY3RpdmVQb3J0O1xufVxuXG4vKipcbiAqXG4gKiBAcGFyYW0ge1BvcnQ/fSBwb3J0XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBzZXRBY3RpdmVQb3J0KHBvcnQpIHtcbiAgICBhY3RpdmVQb3J0ID0gcG9ydDtcbn1cblxuLyoqXG4gKiBQb3N0IGEgbWVzc2FnZSB0byB0aGUgcG9wdXAgVUksIGlmIGl0J3Mgb3Blbi5cbiAqXG4gKiBAcGFyYW0ge091dGdvaW5nUG9wdXBNZXNzYWdlfSBtZXNzYWdlXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBwb3N0UG9wdXBNZXNzYWdlKG1lc3NhZ2UpIHtcbiAgICBhY3RpdmVQb3J0Py5wb3N0TWVzc2FnZShtZXNzYWdlKTtcbn1cbiIsICIvKipcbiAqIFJlbG9hZHMgdGhlIGV4dGVuc2lvbiB3aGVuIGNoYW5nZXMgYXJlIGRldGVjdGVkLiBPbmx5IGluY2x1ZGVkIGZvciBkZXZlbG9wZXJcbiAqIGJ1aWxkcy4gKFBhc3MgdGhlIHJlbG9hZGVyPTAgYnVpbGQgcGFyYW1ldGVyIHRvIGRpc2FibGUuKVxuICovXG5cbmltcG9ydCBicm93c2VyIGZyb20gJ3dlYmV4dGVuc2lvbi1wb2x5ZmlsbCc7XG5pbXBvcnQgeyBjcmVhdGVBbGFybSwgZ2V0RnJvbVNlc3Npb25TdG9yYWdlLCBzZXRUb1Nlc3Npb25TdG9yYWdlIH0gZnJvbSAnLi93cmFwcGVyJztcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gaW5pdFJlbG9hZGVyKCkge1xuICAgIGZ1bmN0aW9uIGNyZWF0ZUFsYXJtVGltZXIoKSB7XG4gICAgICAgIGNyZWF0ZUFsYXJtKCdjaGVja0J1aWxkVGltZScsIHsgd2hlbjogRGF0ZS5ub3coKSArIDUwMDAgfSk7XG4gICAgfVxuXG4gICAgYnJvd3Nlci5hbGFybXMub25BbGFybS5hZGRMaXN0ZW5lcihhc3luYyAoYWxhcm1FdmVudCkgPT4ge1xuICAgICAgICBpZiAoYWxhcm1FdmVudC5uYW1lICE9PSAnY2hlY2tCdWlsZFRpbWUnKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICBsZXQgYnVpbGRUaW1lID0gbnVsbDtcblxuICAgICAgICB0cnkge1xuICAgICAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaCgnL2J1aWxkdGltZS50eHQnLCB7IGNhY2hlOiAnbm8tc3RvcmUnIH0pO1xuICAgICAgICAgICAgYnVpbGRUaW1lID0gYXdhaXQgcmVzcG9uc2UudGV4dCgpO1xuICAgICAgICB9IGNhdGNoIChlKSB7fVxuXG4gICAgICAgIGlmIChidWlsZFRpbWUpIHtcbiAgICAgICAgICAgIGNvbnN0IHByZXZpb3VzQnVpbGRUaW1lID0gYXdhaXQgZ2V0RnJvbVNlc3Npb25TdG9yYWdlKCdidWlsZFRpbWUnKTtcbiAgICAgICAgICAgIGlmICghcHJldmlvdXNCdWlsZFRpbWUpIHtcbiAgICAgICAgICAgICAgICBhd2FpdCBzZXRUb1Nlc3Npb25TdG9yYWdlKCdidWlsZFRpbWUnLCBidWlsZFRpbWUpO1xuICAgICAgICAgICAgfSBlbHNlIGlmIChidWlsZFRpbWUgIT09IHByZXZpb3VzQnVpbGRUaW1lKSB7XG4gICAgICAgICAgICAgICAgYnJvd3Nlci5ydW50aW1lLnJlbG9hZCgpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgY3JlYXRlQWxhcm1UaW1lcigpO1xuICAgIH0pO1xuXG4gICAgY3JlYXRlQWxhcm1UaW1lcigpO1xufVxuIiwgImltcG9ydCBicm93c2VyIGZyb20gJ3dlYmV4dGVuc2lvbi1wb2x5ZmlsbCc7XG4vKiBnbG9iYWwgREVCVUcgKi9cblxuY29uc3QgREVGQVVMVF9OQVRJVkVfQVBQX0lEID0gJ2NvbS5kdWNrZHVja2dvLm1hY29zLmJyb3dzZXInO1xuXG4vKipcbiAqIEB0eXBlZGVmIHtpbXBvcnQoJ0BkdWNrZHVja2dvL2NvbnRlbnQtc2NvcGUtc2NyaXB0cy9tZXNzYWdpbmcvc2NoZW1hLmpzJykuUmVxdWVzdE1lc3NhZ2V9IFJlcXVlc3RNZXNzYWdlXG4gKiBAdHlwZWRlZiB7aW1wb3J0KCdAZHVja2R1Y2tnby9jb250ZW50LXNjb3BlLXNjcmlwdHMvbWVzc2FnaW5nL3NjaGVtYS5qcycpLk5vdGlmaWNhdGlvbk1lc3NhZ2V9IE5vdGlmaWNhdGlvbk1lc3NhZ2VcbiAqIEB0eXBlZGVmIHtpbXBvcnQoJ0BkdWNrZHVja2dvL2NvbnRlbnQtc2NvcGUtc2NyaXB0cy9tZXNzYWdpbmcvc2NoZW1hLmpzJykuTWVzc2FnZVJlc3BvbnNlfSBNZXNzYWdlUmVzcG9uc2VcbiAqL1xuXG4vKipcbiAqIEB0eXBlZGVmIHt7XG4gKiAgbm90aWZ5OiAobWV0aG9kOiBzdHJpbmcsIHBhcmFtczogUmVjb3JkPHN0cmluZywgYW55PikgPT4gUHJvbWlzZTx2b2lkPjtcbiAqICByZXF1ZXN0OiAobWV0aG9kOiBzdHJpbmcsIHBhcmFtczogUmVjb3JkPHN0cmluZywgYW55PikgPT4gUHJvbWlzZTxhbnk+O1xuICogIHN1YnNjcmliZTogKG1zZzogYW55LCBjYWxsYmFjazogKG1zZzogYW55KSA9PiB2b2lkKSA9PiB2b2lkO1xuICogfX0gTmF0aXZlTWVzc2FnaW5nSW50ZXJmYWNlXG4gKi9cblxuLyoqXG4gKiBNZXNzYWdpbmcgZm9yIGNvbW11bmljYXRpb24gd2l0aCB0aGUgbmF0aXZlIGFwcCBiYXNlZCBvbiBOYXRpdmUgTWVzc2FnaW5nIEFQSS5cbiAqIEl0IG1pbWljcyB0aGUgQy1TLVMgbWVzc2FnaW5nIEFQSS5cbiAqXG4gKiBVc2VzIGBicm93c2VyLnJ1bnRpbWUuc2VuZE5hdGl2ZU1lc3NhZ2VgIGluc3RlYWQgb2YgYGJyb3dzZXIucnVudGltZS5jb25uZWN0TmF0aXZlYCBiZWNhdXNlIHRoYXQgaXMgdW5yZWxpYWJsZVxuICogc2VlIGh0dHBzOi8vYXBwLmFzYW5hLmNvbS8xLzEzNzI0OTU1Njk0NS90YXNrLzEyMTI0NjM4NTA0NjYwMTAvY29tbWVudC8xMjEzMjAwMjI4OTgxMzY2P2ZvY3VzPXRydWVcbiAqXG4gKiBOb3RlOiBTdWJzY3JpcHRpb25zIGFyZSBub3Qgc3VwcG9ydGVkIGJlY2F1c2Ugc2VydmljZSB3b3JrZXJzIGNhbiBzbGVlcCxcbiAqIGNhdXNpbmcgdGhlIHBvcnQgY29ubmVjdGlvbiB0byBiZSBsb3N0LiBVc2UgcmVxdWVzdC9yZXNwb25zZSBwYXR0ZXJucyBpbnN0ZWFkLlxuICovXG4vKipcbiAqIEBpbXBsZW1lbnRzIHtOYXRpdmVNZXNzYWdpbmdJbnRlcmZhY2V9XG4gKi9cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIE5hdGl2ZU1lc3NhZ2luZyB7XG4gICAgLyoqXG4gICAgICogQHBhcmFtIHtzdHJpbmd9IGNvbnRleHRcbiAgICAgKiBAcGFyYW0ge3N0cmluZ30gZmVhdHVyZU5hbWVcbiAgICAgKiBAcGFyYW0ge3N0cmluZ30gW2FwcElkXVxuICAgICAqL1xuICAgIGNvbnN0cnVjdG9yKGNvbnRleHQsIGZlYXR1cmVOYW1lLCBhcHBJZCA9IERFRkFVTFRfTkFUSVZFX0FQUF9JRCkge1xuICAgICAgICB0aGlzLl9hcHBJZCA9IGFwcElkO1xuICAgICAgICB0aGlzLl9jb250ZXh0ID0gY29udGV4dDtcbiAgICAgICAgdGhpcy5fZmVhdHVyZU5hbWUgPSBmZWF0dXJlTmFtZTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBTZW5kIGEgZmlyZS1hbmQtZm9yZ2V0IG5vdGlmaWNhdGlvbiB0byB0aGUgbmF0aXZlIGFwcC5cbiAgICAgKlxuICAgICAqIEBwYXJhbSB7c3RyaW5nfSBtZXRob2QgLSBUaGUgbWV0aG9kIG5hbWUgdG8gY2FsbCBvbiB0aGUgbmF0aXZlIHNpZGVcbiAgICAgKiBAcGFyYW0ge1JlY29yZDxzdHJpbmcsIGFueT59IFtwYXJhbXNdIC0gT3B0aW9uYWwgcGFyYW1ldGVycyB0byBzZW5kXG4gICAgICovXG4gICAgYXN5bmMgbm90aWZ5KG1ldGhvZCwgcGFyYW1zID0ge30pIHtcbiAgICAgICAgY29uc3QgbXNnID0gLyoqIEB0eXBlIHtOb3RpZmljYXRpb25NZXNzYWdlfSAqLyAoe1xuICAgICAgICAgICAgY29udGV4dDogdGhpcy5fY29udGV4dCxcbiAgICAgICAgICAgIGZlYXR1cmVOYW1lOiB0aGlzLl9mZWF0dXJlTmFtZSxcbiAgICAgICAgICAgIG1ldGhvZCxcbiAgICAgICAgICAgIHBhcmFtcyxcbiAgICAgICAgfSk7XG4gICAgICAgIERFQlVHICYmIGNvbnNvbGUubG9nKCdbTmF0aXZlTWVzc2FnaW5nXSBOT1RJRlknLCBgJHt0aGlzLl9jb250ZXh0fS4ke3RoaXMuX2ZlYXR1cmVOYW1lfS4ke21ldGhvZH1gLCBwYXJhbXMpO1xuICAgICAgICBhd2FpdCBicm93c2VyLnJ1bnRpbWUuc2VuZE5hdGl2ZU1lc3NhZ2UodGhpcy5fYXBwSWQsIG1zZykuY2F0Y2goKGUpID0+IHtcbiAgICAgICAgICAgIERFQlVHICYmIGNvbnNvbGUuZXJyb3IoJ1tOYXRpdmVNZXNzYWdpbmddIG5vdGlmaWNhdGlvbiBlcnJvcjonLCBlKTtcbiAgICAgICAgICAgIHRocm93IGU7XG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFNlbmQgYSByZXF1ZXN0IHRvIHRoZSBuYXRpdmUgYXBwIGFuZCB3YWl0IGZvciBhIHJlc3BvbnNlLlxuICAgICAqXG4gICAgICogQHBhcmFtIHtzdHJpbmd9IG1ldGhvZCAtIFRoZSBtZXRob2QgbmFtZSB0byBjYWxsIG9uIHRoZSBuYXRpdmUgc2lkZVxuICAgICAqIEBwYXJhbSB7UmVjb3JkPHN0cmluZywgYW55Pn0gW3BhcmFtc10gLSBPcHRpb25hbCBwYXJhbWV0ZXJzIHRvIHNlbmRcbiAgICAgKiBAcmV0dXJucyB7UHJvbWlzZTxhbnk+fVxuICAgICAqL1xuICAgIGFzeW5jIHJlcXVlc3QobWV0aG9kLCBwYXJhbXMgPSB7fSkge1xuICAgICAgICBjb25zdCBpZCA9IGNyeXB0by5yYW5kb21VVUlEKCk7XG4gICAgICAgIGNvbnN0IG1zZyA9IC8qKiBAdHlwZSB7UmVxdWVzdE1lc3NhZ2V9ICovICh7XG4gICAgICAgICAgICBjb250ZXh0OiB0aGlzLl9jb250ZXh0LFxuICAgICAgICAgICAgZmVhdHVyZU5hbWU6IHRoaXMuX2ZlYXR1cmVOYW1lLFxuICAgICAgICAgICAgaWQsXG4gICAgICAgICAgICBtZXRob2QsXG4gICAgICAgICAgICBwYXJhbXMsXG4gICAgICAgIH0pO1xuICAgICAgICBERUJVRyAmJiBjb25zb2xlLmxvZygnW05hdGl2ZU1lc3NhZ2luZ10gUkVRVUVTVCcsIGAke3RoaXMuX2NvbnRleHR9LiR7dGhpcy5fZmVhdHVyZU5hbWV9LiR7bWV0aG9kfWAsIGBpZD0ke2lkfWAsIHBhcmFtcyk7XG5cbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSAvKiogQHR5cGUge01lc3NhZ2VSZXNwb25zZX0gKi8gKFxuICAgICAgICAgICAgYXdhaXQgYnJvd3Nlci5ydW50aW1lLnNlbmROYXRpdmVNZXNzYWdlKHRoaXMuX2FwcElkLCBtc2cpLmNhdGNoKChlKSA9PiB7XG4gICAgICAgICAgICAgICAgREVCVUcgJiYgY29uc29sZS5lcnJvcignW05hdGl2ZU1lc3NhZ2luZ10gZXJyb3I6JywgZSk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgaWQsXG4gICAgICAgICAgICAgICAgICAgIGNvbnRleHQ6IHRoaXMuX2NvbnRleHQsXG4gICAgICAgICAgICAgICAgICAgIGZlYXR1cmVOYW1lOiB0aGlzLl9mZWF0dXJlTmFtZSxcbiAgICAgICAgICAgICAgICAgICAgZXJyb3I6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IGBOYXRpdmVNZXNzYWdpbmcgcmVxdWVzdC1yZXNwb25zZSBlcnJvcjogJHtlfWAsXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIH0pXG4gICAgICAgICk7XG4gICAgICAgIERFQlVHICYmIGNvbnNvbGUubG9nKCdbTmF0aXZlTWVzc2FnaW5nXSBSZWNlaXZlZCBmcm9tIG5hdGl2ZTonLCBKU09OLnN0cmluZ2lmeShyZXNwb25zZSkpO1xuXG4gICAgICAgIGlmICghcmVzcG9uc2UgfHwgdHlwZW9mIHJlc3BvbnNlICE9PSAnb2JqZWN0Jykge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBOYXRpdmVNZXNzYWdpbmc6IHVuZXhwZWN0ZWQgcmVzcG9uc2UgdHlwZTogJHt0eXBlb2YgcmVzcG9uc2V9YCk7XG4gICAgICAgIH1cblxuICAgICAgICBpZiAoJ2Vycm9yJyBpbiByZXNwb25zZSAmJiByZXNwb25zZS5lcnJvcikge1xuICAgICAgICAgICAgREVCVUcgJiYgY29uc29sZS5sb2coJ1tOYXRpdmVNZXNzYWdpbmddIFJFU1BPTlNFIEVSUk9SJywgYGlkPSR7aWR9YCwgcmVzcG9uc2UuZXJyb3IpO1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKHJlc3BvbnNlLmVycm9yLm1lc3NhZ2UgfHwgJ1Vua25vd24gZXJyb3InKTtcbiAgICAgICAgfVxuXG4gICAgICAgIERFQlVHICYmIGNvbnNvbGUubG9nKCdbTmF0aXZlTWVzc2FnaW5nXSBSRVNQT05TRSBPSycsIGBpZD0ke2lkfWAsIHJlc3BvbnNlLnJlc3VsdCk7XG4gICAgICAgIHJldHVybiByZXNwb25zZS5yZXN1bHQgfHwge307XG4gICAgfVxuXG4gICAgc3Vic2NyaWJlKF9tc2csIF9jYWxsYmFjaykge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1N1YnNjcmlwdGlvbnMgYXJlIG5vdCBzdXBwb3J0ZWQgb3ZlciBOYXRpdmUgTWVzc2FnaW5nIEFQSScpO1xuICAgIH1cbn1cbiJdLAogICJtYXBwaW5ncyI6ICI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFNQTtBQUVBLFlBQUksRUFBRUEsV0FBV0MsVUFBVUQsV0FBV0MsT0FBT0MsV0FBV0YsV0FBV0MsT0FBT0MsUUFBUUMsS0FBSztBQUNyRixnQkFBTSxJQUFJQyxNQUFNLDJEQUEyRDtRQUM3RTtBQUVBLFlBQUksRUFBRUosV0FBV0ssV0FBV0wsV0FBV0ssUUFBUUgsV0FBV0YsV0FBV0ssUUFBUUgsUUFBUUMsS0FBSztBQUN4RixnQkFBTUcsbURBQW1EO0FBT3pELGdCQUFNQyxXQUFXQyxtQkFBaUI7QUFJaEMsa0JBQU1DLGNBQWM7Y0FDbEIsVUFBVTtnQkFDUixTQUFTO2tCQUNQLFdBQVc7a0JBQ1gsV0FBVztnQkFDYjtnQkFDQSxZQUFZO2tCQUNWLFdBQVc7a0JBQ1gsV0FBVztnQkFDYjtnQkFDQSxPQUFPO2tCQUNMLFdBQVc7a0JBQ1gsV0FBVztnQkFDYjtnQkFDQSxVQUFVO2tCQUNSLFdBQVc7a0JBQ1gsV0FBVztnQkFDYjtjQUNGO2NBQ0EsYUFBYTtnQkFDWCxVQUFVO2tCQUNSLFdBQVc7a0JBQ1gsV0FBVztnQkFDYjtnQkFDQSxPQUFPO2tCQUNMLFdBQVc7a0JBQ1gsV0FBVztnQkFDYjtnQkFDQSxlQUFlO2tCQUNiLFdBQVc7a0JBQ1gsV0FBVztnQkFDYjtnQkFDQSxhQUFhO2tCQUNYLFdBQVc7a0JBQ1gsV0FBVztnQkFDYjtnQkFDQSxjQUFjO2tCQUNaLFdBQVc7a0JBQ1gsV0FBVztnQkFDYjtnQkFDQSxXQUFXO2tCQUNULFdBQVc7a0JBQ1gsV0FBVztnQkFDYjtnQkFDQSxRQUFRO2tCQUNOLFdBQVc7a0JBQ1gsV0FBVztnQkFDYjtnQkFDQSxVQUFVO2tCQUNSLFdBQVc7a0JBQ1gsV0FBVztnQkFDYjtnQkFDQSxjQUFjO2tCQUNaLFdBQVc7a0JBQ1gsV0FBVztnQkFDYjtnQkFDQSxVQUFVO2tCQUNSLFdBQVc7a0JBQ1gsV0FBVztnQkFDYjtnQkFDQSxVQUFVO2tCQUNSLFdBQVc7a0JBQ1gsV0FBVztnQkFDYjtjQUNGO2NBQ0EsaUJBQWlCO2dCQUNmLFdBQVc7a0JBQ1QsV0FBVztrQkFDWCxXQUFXO2tCQUNYLHdCQUF3QjtnQkFDMUI7Z0JBQ0EsVUFBVTtrQkFDUixXQUFXO2tCQUNYLFdBQVc7a0JBQ1gsd0JBQXdCO2dCQUMxQjtnQkFDQSwyQkFBMkI7a0JBQ3pCLFdBQVc7a0JBQ1gsV0FBVztnQkFDYjtnQkFDQSxnQkFBZ0I7a0JBQ2QsV0FBVztrQkFDWCxXQUFXO2dCQUNiO2dCQUNBLFlBQVk7a0JBQ1YsV0FBVztrQkFDWCxXQUFXO2dCQUNiO2dCQUNBLFlBQVk7a0JBQ1YsV0FBVztrQkFDWCxXQUFXO2dCQUNiO2dCQUNBLGFBQWE7a0JBQ1gsV0FBVztrQkFDWCxXQUFXO2dCQUNiO2dCQUNBLDJCQUEyQjtrQkFDekIsV0FBVztrQkFDWCxXQUFXO2tCQUNYLHdCQUF3QjtnQkFDMUI7Z0JBQ0EsZ0JBQWdCO2tCQUNkLFdBQVc7a0JBQ1gsV0FBVztrQkFDWCx3QkFBd0I7Z0JBQzFCO2dCQUNBLFdBQVc7a0JBQ1QsV0FBVztrQkFDWCxXQUFXO2dCQUNiO2dCQUNBLFlBQVk7a0JBQ1YsV0FBVztrQkFDWCxXQUFXO2tCQUNYLHdCQUF3QjtnQkFDMUI7Z0JBQ0EsWUFBWTtrQkFDVixXQUFXO2tCQUNYLFdBQVc7a0JBQ1gsd0JBQXdCO2dCQUMxQjtjQUNGO2NBQ0EsZ0JBQWdCO2dCQUNkLFVBQVU7a0JBQ1IsV0FBVztrQkFDWCxXQUFXO2dCQUNiO2dCQUNBLGVBQWU7a0JBQ2IsV0FBVztrQkFDWCxXQUFXO2dCQUNiO2dCQUNBLGlCQUFpQjtrQkFDZixXQUFXO2tCQUNYLFdBQVc7Z0JBQ2I7Z0JBQ0EsbUJBQW1CO2tCQUNqQixXQUFXO2tCQUNYLFdBQVc7Z0JBQ2I7Z0JBQ0Esa0JBQWtCO2tCQUNoQixXQUFXO2tCQUNYLFdBQVc7Z0JBQ2I7Z0JBQ0EsaUJBQWlCO2tCQUNmLFdBQVc7a0JBQ1gsV0FBVztnQkFDYjtnQkFDQSxzQkFBc0I7a0JBQ3BCLFdBQVc7a0JBQ1gsV0FBVztnQkFDYjtnQkFDQSxtQkFBbUI7a0JBQ2pCLFdBQVc7a0JBQ1gsV0FBVztnQkFDYjtnQkFDQSxvQkFBb0I7a0JBQ2xCLFdBQVc7a0JBQ1gsV0FBVztnQkFDYjtnQkFDQSxZQUFZO2tCQUNWLFdBQVc7a0JBQ1gsV0FBVztnQkFDYjtjQUNGO2NBQ0EsWUFBWTtnQkFDVixVQUFVO2tCQUNSLFdBQVc7a0JBQ1gsV0FBVztnQkFDYjtjQUNGO2NBQ0EsZ0JBQWdCO2dCQUNkLFVBQVU7a0JBQ1IsV0FBVztrQkFDWCxXQUFXO2dCQUNiO2dCQUNBLGFBQWE7a0JBQ1gsV0FBVztrQkFDWCxXQUFXO2dCQUNiO2dCQUNBLFVBQVU7a0JBQ1IsV0FBVztrQkFDWCxXQUFXO2dCQUNiO2NBQ0Y7Y0FDQSxXQUFXO2dCQUNULE9BQU87a0JBQ0wsV0FBVztrQkFDWCxXQUFXO2dCQUNiO2dCQUNBLFVBQVU7a0JBQ1IsV0FBVztrQkFDWCxXQUFXO2dCQUNiO2dCQUNBLHNCQUFzQjtrQkFDcEIsV0FBVztrQkFDWCxXQUFXO2dCQUNiO2dCQUNBLFVBQVU7a0JBQ1IsV0FBVztrQkFDWCxXQUFXO2dCQUNiO2dCQUNBLE9BQU87a0JBQ0wsV0FBVztrQkFDWCxXQUFXO2dCQUNiO2NBQ0Y7Y0FDQSxZQUFZO2dCQUNWLG1CQUFtQjtrQkFDakIsUUFBUTtvQkFDTixXQUFXO29CQUNYLFdBQVc7b0JBQ1gscUJBQXFCO2tCQUN2QjtnQkFDRjtnQkFDQSxVQUFVO2tCQUNSLFVBQVU7b0JBQ1IsV0FBVztvQkFDWCxXQUFXO29CQUNYLHFCQUFxQjtrQkFDdkI7a0JBQ0EsWUFBWTtvQkFDVixxQkFBcUI7c0JBQ25CLFdBQVc7c0JBQ1gsV0FBVztvQkFDYjtrQkFDRjtnQkFDRjtjQUNGO2NBQ0EsYUFBYTtnQkFDWCxVQUFVO2tCQUNSLFdBQVc7a0JBQ1gsV0FBVztnQkFDYjtnQkFDQSxZQUFZO2tCQUNWLFdBQVc7a0JBQ1gsV0FBVztnQkFDYjtnQkFDQSxTQUFTO2tCQUNQLFdBQVc7a0JBQ1gsV0FBVztnQkFDYjtnQkFDQSxlQUFlO2tCQUNiLFdBQVc7a0JBQ1gsV0FBVztnQkFDYjtnQkFDQSxRQUFRO2tCQUNOLFdBQVc7a0JBQ1gsV0FBVztrQkFDWCx3QkFBd0I7Z0JBQzFCO2dCQUNBLFNBQVM7a0JBQ1AsV0FBVztrQkFDWCxXQUFXO2dCQUNiO2dCQUNBLGNBQWM7a0JBQ1osV0FBVztrQkFDWCxXQUFXO2dCQUNiO2dCQUNBLFVBQVU7a0JBQ1IsV0FBVztrQkFDWCxXQUFXO2dCQUNiO2dCQUNBLFVBQVU7a0JBQ1IsV0FBVztrQkFDWCxXQUFXO2dCQUNiO2dCQUNBLFFBQVE7a0JBQ04sV0FBVztrQkFDWCxXQUFXO2tCQUNYLHdCQUF3QjtnQkFDMUI7Y0FDRjtjQUNBLGFBQWE7Z0JBQ1gsNkJBQTZCO2tCQUMzQixXQUFXO2tCQUNYLFdBQVc7Z0JBQ2I7Z0JBQ0EsNEJBQTRCO2tCQUMxQixXQUFXO2tCQUNYLFdBQVc7Z0JBQ2I7Y0FDRjtjQUNBLFdBQVc7Z0JBQ1QsVUFBVTtrQkFDUixXQUFXO2tCQUNYLFdBQVc7Z0JBQ2I7Z0JBQ0EsYUFBYTtrQkFDWCxXQUFXO2tCQUNYLFdBQVc7Z0JBQ2I7Z0JBQ0EsZUFBZTtrQkFDYixXQUFXO2tCQUNYLFdBQVc7Z0JBQ2I7Z0JBQ0EsYUFBYTtrQkFDWCxXQUFXO2tCQUNYLFdBQVc7Z0JBQ2I7Z0JBQ0EsYUFBYTtrQkFDWCxXQUFXO2tCQUNYLFdBQVc7Z0JBQ2I7Z0JBQ0EsVUFBVTtrQkFDUixXQUFXO2tCQUNYLFdBQVc7Z0JBQ2I7Y0FDRjtjQUNBLFFBQVE7Z0JBQ04sa0JBQWtCO2tCQUNoQixXQUFXO2tCQUNYLFdBQVc7Z0JBQ2I7Z0JBQ0Esc0JBQXNCO2tCQUNwQixXQUFXO2tCQUNYLFdBQVc7Z0JBQ2I7Y0FDRjtjQUNBLFlBQVk7Z0JBQ1YscUJBQXFCO2tCQUNuQixXQUFXO2tCQUNYLFdBQVc7Z0JBQ2I7Y0FDRjtjQUNBLFFBQVE7Z0JBQ04sY0FBYztrQkFDWixXQUFXO2tCQUNYLFdBQVc7Z0JBQ2I7Y0FDRjtjQUNBLGNBQWM7Z0JBQ1osT0FBTztrQkFDTCxXQUFXO2tCQUNYLFdBQVc7Z0JBQ2I7Z0JBQ0EsVUFBVTtrQkFDUixXQUFXO2tCQUNYLFdBQVc7Z0JBQ2I7Z0JBQ0EsV0FBVztrQkFDVCxXQUFXO2tCQUNYLFdBQVc7Z0JBQ2I7Z0JBQ0EsY0FBYztrQkFDWixXQUFXO2tCQUNYLFdBQVc7Z0JBQ2I7Z0JBQ0EsaUJBQWlCO2tCQUNmLFdBQVc7a0JBQ1gsV0FBVztnQkFDYjtjQUNGO2NBQ0EsaUJBQWlCO2dCQUNmLFNBQVM7a0JBQ1AsV0FBVztrQkFDWCxXQUFXO2dCQUNiO2dCQUNBLFVBQVU7a0JBQ1IsV0FBVztrQkFDWCxXQUFXO2dCQUNiO2dCQUNBLFVBQVU7a0JBQ1IsV0FBVztrQkFDWCxXQUFXO2dCQUNiO2dCQUNBLHNCQUFzQjtrQkFDcEIsV0FBVztrQkFDWCxXQUFXO2dCQUNiO2dCQUNBLFVBQVU7a0JBQ1IsV0FBVztrQkFDWCxXQUFXO2dCQUNiO2NBQ0Y7Y0FDQSxjQUFjO2dCQUNaLFlBQVk7a0JBQ1YsV0FBVztrQkFDWCxXQUFXO2dCQUNiO2dCQUNBLFlBQVk7a0JBQ1YsV0FBVztrQkFDWCxXQUFXO2dCQUNiO2dCQUNBLFFBQVE7a0JBQ04sV0FBVztrQkFDWCxXQUFXO2tCQUNYLHdCQUF3QjtnQkFDMUI7Z0JBQ0EsV0FBVztrQkFDVCxXQUFXO2tCQUNYLFdBQVc7Z0JBQ2I7Z0JBQ0EsWUFBWTtrQkFDVixXQUFXO2tCQUNYLFdBQVc7a0JBQ1gsd0JBQXdCO2dCQUMxQjtnQkFDQSxZQUFZO2tCQUNWLFdBQVc7a0JBQ1gsV0FBVztrQkFDWCx3QkFBd0I7Z0JBQzFCO2dCQUNBLFFBQVE7a0JBQ04sV0FBVztrQkFDWCxXQUFXO2tCQUNYLHdCQUF3QjtnQkFDMUI7Y0FDRjtjQUNBLGVBQWU7Z0JBQ2IsWUFBWTtrQkFDVixXQUFXO2tCQUNYLFdBQVc7Z0JBQ2I7Z0JBQ0EsVUFBVTtrQkFDUixXQUFXO2tCQUNYLFdBQVc7Z0JBQ2I7Z0JBQ0EsVUFBVTtrQkFDUixXQUFXO2tCQUNYLFdBQVc7Z0JBQ2I7Z0JBQ0EsV0FBVztrQkFDVCxXQUFXO2tCQUNYLFdBQVc7Z0JBQ2I7Y0FDRjtjQUNBLFdBQVc7Z0JBQ1QscUJBQXFCO2tCQUNuQixXQUFXO2tCQUNYLFdBQVc7Z0JBQ2I7Z0JBQ0EsbUJBQW1CO2tCQUNqQixXQUFXO2tCQUNYLFdBQVc7Z0JBQ2I7Z0JBQ0EsbUJBQW1CO2tCQUNqQixXQUFXO2tCQUNYLFdBQVc7Z0JBQ2I7Z0JBQ0Esc0JBQXNCO2tCQUNwQixXQUFXO2tCQUNYLFdBQVc7Z0JBQ2I7Z0JBQ0EsZUFBZTtrQkFDYixXQUFXO2tCQUNYLFdBQVc7Z0JBQ2I7Z0JBQ0EscUJBQXFCO2tCQUNuQixXQUFXO2tCQUNYLFdBQVc7Z0JBQ2I7Z0JBQ0EsbUJBQW1CO2tCQUNqQixXQUFXO2tCQUNYLFdBQVc7Z0JBQ2I7Y0FDRjtjQUNBLFlBQVk7Z0JBQ1YsY0FBYztrQkFDWixXQUFXO2tCQUNYLFdBQVc7Z0JBQ2I7Z0JBQ0EscUJBQXFCO2tCQUNuQixXQUFXO2tCQUNYLFdBQVc7Z0JBQ2I7Z0JBQ0EsV0FBVztrQkFDVCxXQUFXO2tCQUNYLFdBQVc7Z0JBQ2I7Y0FDRjtjQUNBLFdBQVc7Z0JBQ1QsU0FBUztrQkFDUCxTQUFTO29CQUNQLFdBQVc7b0JBQ1gsV0FBVztrQkFDYjtrQkFDQSxPQUFPO29CQUNMLFdBQVc7b0JBQ1gsV0FBVztrQkFDYjtrQkFDQSxpQkFBaUI7b0JBQ2YsV0FBVztvQkFDWCxXQUFXO2tCQUNiO2tCQUNBLFVBQVU7b0JBQ1IsV0FBVztvQkFDWCxXQUFXO2tCQUNiO2tCQUNBLE9BQU87b0JBQ0wsV0FBVztvQkFDWCxXQUFXO2tCQUNiO2dCQUNGO2dCQUNBLFdBQVc7a0JBQ1QsT0FBTztvQkFDTCxXQUFXO29CQUNYLFdBQVc7a0JBQ2I7a0JBQ0EsaUJBQWlCO29CQUNmLFdBQVc7b0JBQ1gsV0FBVztrQkFDYjtnQkFDRjtnQkFDQSxRQUFRO2tCQUNOLFNBQVM7b0JBQ1AsV0FBVztvQkFDWCxXQUFXO2tCQUNiO2tCQUNBLE9BQU87b0JBQ0wsV0FBVztvQkFDWCxXQUFXO2tCQUNiO2tCQUNBLGlCQUFpQjtvQkFDZixXQUFXO29CQUNYLFdBQVc7a0JBQ2I7a0JBQ0EsVUFBVTtvQkFDUixXQUFXO29CQUNYLFdBQVc7a0JBQ2I7a0JBQ0EsT0FBTztvQkFDTCxXQUFXO29CQUNYLFdBQVc7a0JBQ2I7Z0JBQ0Y7Y0FDRjtjQUNBLFFBQVE7Z0JBQ04scUJBQXFCO2tCQUNuQixXQUFXO2tCQUNYLFdBQVc7Z0JBQ2I7Z0JBQ0EsVUFBVTtrQkFDUixXQUFXO2tCQUNYLFdBQVc7Z0JBQ2I7Z0JBQ0Esa0JBQWtCO2tCQUNoQixXQUFXO2tCQUNYLFdBQVc7Z0JBQ2I7Z0JBQ0EsV0FBVztrQkFDVCxXQUFXO2tCQUNYLFdBQVc7Z0JBQ2I7Z0JBQ0EsYUFBYTtrQkFDWCxXQUFXO2tCQUNYLFdBQVc7Z0JBQ2I7Z0JBQ0EsaUJBQWlCO2tCQUNmLFdBQVc7a0JBQ1gsV0FBVztnQkFDYjtnQkFDQSxPQUFPO2tCQUNMLFdBQVc7a0JBQ1gsV0FBVztnQkFDYjtnQkFDQSxjQUFjO2tCQUNaLFdBQVc7a0JBQ1gsV0FBVztnQkFDYjtnQkFDQSxXQUFXO2tCQUNULFdBQVc7a0JBQ1gsV0FBVztnQkFDYjtnQkFDQSxtQkFBbUI7a0JBQ2pCLFdBQVc7a0JBQ1gsV0FBVztnQkFDYjtnQkFDQSxVQUFVO2tCQUNSLFdBQVc7a0JBQ1gsV0FBVztnQkFDYjtnQkFDQSxhQUFhO2tCQUNYLFdBQVc7a0JBQ1gsV0FBVztnQkFDYjtnQkFDQSxhQUFhO2tCQUNYLFdBQVc7a0JBQ1gsV0FBVztnQkFDYjtnQkFDQSxhQUFhO2tCQUNYLFdBQVc7a0JBQ1gsV0FBVztnQkFDYjtnQkFDQSxRQUFRO2tCQUNOLFdBQVc7a0JBQ1gsV0FBVztnQkFDYjtnQkFDQSxTQUFTO2tCQUNQLFdBQVc7a0JBQ1gsV0FBVztnQkFDYjtnQkFDQSxVQUFVO2tCQUNSLFdBQVc7a0JBQ1gsV0FBVztnQkFDYjtnQkFDQSxVQUFVO2tCQUNSLFdBQVc7a0JBQ1gsV0FBVztnQkFDYjtnQkFDQSxhQUFhO2tCQUNYLFdBQVc7a0JBQ1gsV0FBVztnQkFDYjtnQkFDQSxlQUFlO2tCQUNiLFdBQVc7a0JBQ1gsV0FBVztnQkFDYjtnQkFDQSxXQUFXO2tCQUNULFdBQVc7a0JBQ1gsV0FBVztnQkFDYjtnQkFDQSxtQkFBbUI7a0JBQ2pCLFdBQVc7a0JBQ1gsV0FBVztnQkFDYjtnQkFDQSxVQUFVO2tCQUNSLFdBQVc7a0JBQ1gsV0FBVztnQkFDYjtjQUNGO2NBQ0EsWUFBWTtnQkFDVixPQUFPO2tCQUNMLFdBQVc7a0JBQ1gsV0FBVztnQkFDYjtjQUNGO2NBQ0EsaUJBQWlCO2dCQUNmLGdCQUFnQjtrQkFDZCxXQUFXO2tCQUNYLFdBQVc7Z0JBQ2I7Z0JBQ0EsWUFBWTtrQkFDVixXQUFXO2tCQUNYLFdBQVc7Z0JBQ2I7Y0FDRjtjQUNBLGNBQWM7Z0JBQ1osMEJBQTBCO2tCQUN4QixXQUFXO2tCQUNYLFdBQVc7Z0JBQ2I7Y0FDRjtjQUNBLFdBQVc7Z0JBQ1QsVUFBVTtrQkFDUixXQUFXO2tCQUNYLFdBQVc7Z0JBQ2I7Z0JBQ0EsT0FBTztrQkFDTCxXQUFXO2tCQUNYLFdBQVc7Z0JBQ2I7Z0JBQ0EsVUFBVTtrQkFDUixXQUFXO2tCQUNYLFdBQVc7Z0JBQ2I7Z0JBQ0EsY0FBYztrQkFDWixXQUFXO2tCQUNYLFdBQVc7Z0JBQ2I7Z0JBQ0Esa0JBQWtCO2tCQUNoQixXQUFXO2tCQUNYLFdBQVc7Z0JBQ2I7Z0JBQ0EsVUFBVTtrQkFDUixXQUFXO2tCQUNYLFdBQVc7Z0JBQ2I7Z0JBQ0EsVUFBVTtrQkFDUixXQUFXO2tCQUNYLFdBQVc7Z0JBQ2I7Y0FDRjtZQUNGO0FBRUEsZ0JBQUlDLE9BQU9DLEtBQUtGLFdBQVcsRUFBRUcsV0FBVyxHQUFHO0FBQ3pDLG9CQUFNLElBQUlSLE1BQU0sNkRBQTZEO1lBQy9FO1lBWUEsTUFBTVMsdUJBQXVCQyxRQUFRO2NBQ25DQyxZQUFZQyxZQUFZQyxRQUFRQyxRQUFXO0FBQ3pDLHNCQUFNRCxLQUFLO0FBQ1gscUJBQUtELGFBQWFBO2NBQ3BCO2NBRUFHLElBQUlDLEtBQUs7QUFDUCxvQkFBSSxDQUFDLEtBQUtDLElBQUlELEdBQUcsR0FBRztBQUNsQix1QkFBS0UsSUFBSUYsS0FBSyxLQUFLSixXQUFXSSxHQUFHLENBQUM7Z0JBQ3BDO0FBRUEsdUJBQU8sTUFBTUQsSUFBSUMsR0FBRztjQUN0QjtZQUNGO0FBU0Esa0JBQU1HLGFBQWFDLFdBQVM7QUFDMUIscUJBQU9BLFNBQVMsT0FBT0EsVUFBVSxZQUFZLE9BQU9BLE1BQU1DLFNBQVM7WUFDckU7QUFpQ0Esa0JBQU1DLGVBQWVBLENBQUNDLFNBQVNDLGFBQWE7QUFDMUMscUJBQU8sSUFBSUMsaUJBQWlCO0FBQzFCLG9CQUFJckIsY0FBY04sUUFBUTRCLFdBQVc7QUFDbkNILDBCQUFRSSxPQUFPLElBQUkzQixNQUFNSSxjQUFjTixRQUFRNEIsVUFBVUUsT0FBTyxDQUFDO2dCQUNuRSxXQUFXSixTQUFTSyxxQkFDUkosYUFBYWpCLFVBQVUsS0FBS2dCLFNBQVNLLHNCQUFzQixPQUFRO0FBQzdFTiwwQkFBUU8sUUFBUUwsYUFBYSxDQUFDLENBQUM7Z0JBQ2pDLE9BQU87QUFDTEYsMEJBQVFPLFFBQVFMLFlBQVk7Z0JBQzlCO2NBQ0Y7WUFDRjtBQUVBLGtCQUFNTSxxQkFBc0JDLGFBQVlBLFdBQVcsSUFBSSxhQUFhO0FBNEJwRSxrQkFBTUMsb0JBQW9CQSxDQUFDQyxNQUFNVixhQUFhO0FBQzVDLHFCQUFPLFNBQVNXLHFCQUFxQkMsV0FBV0MsTUFBTTtBQUNwRCxvQkFBSUEsS0FBSzdCLFNBQVNnQixTQUFTYyxTQUFTO0FBQ2xDLHdCQUFNLElBQUl0QyxNQUFPLHFCQUFvQndCLFNBQVNjLE9BQVEsSUFBR1AsbUJBQW1CUCxTQUFTYyxPQUFPLENBQUUsUUFBT0osSUFBSyxXQUFVRyxLQUFLN0IsTUFBTyxFQUFDO2dCQUNuSTtBQUVBLG9CQUFJNkIsS0FBSzdCLFNBQVNnQixTQUFTZSxTQUFTO0FBQ2xDLHdCQUFNLElBQUl2QyxNQUFPLG9CQUFtQndCLFNBQVNlLE9BQVEsSUFBR1IsbUJBQW1CUCxTQUFTZSxPQUFPLENBQUUsUUFBT0wsSUFBSyxXQUFVRyxLQUFLN0IsTUFBTyxFQUFDO2dCQUNsSTtBQUVBLHVCQUFPLElBQUlnQyxRQUFRLENBQUNWLFNBQVNILFdBQVc7QUFDdEMsc0JBQUlILFNBQVNpQixzQkFBc0I7QUFJakMsd0JBQUk7QUFDRkwsNkJBQU9GLElBQUksRUFBRSxHQUFHRyxNQUFNZixhQUFhO3dCQUFDUTt3QkFBU0g7c0JBQU0sR0FBR0gsUUFBUSxDQUFDO29CQUNqRSxTQUFTa0IsU0FBUztBQUNoQkMsOEJBQVFDLEtBQU0sR0FBRVYsSUFBSyw0R0FDd0NRLE9BQU87QUFFcEVOLDZCQUFPRixJQUFJLEVBQUUsR0FBR0csSUFBSTtBQUlwQmIsK0JBQVNpQix1QkFBdUI7QUFDaENqQiwrQkFBU3FCLGFBQWE7QUFFdEJmLDhCQUFRO29CQUNWO2tCQUNGLFdBQVdOLFNBQVNxQixZQUFZO0FBQzlCVCwyQkFBT0YsSUFBSSxFQUFFLEdBQUdHLElBQUk7QUFDcEJQLDRCQUFRO2tCQUNWLE9BQU87QUFDTE0sMkJBQU9GLElBQUksRUFBRSxHQUFHRyxNQUFNZixhQUFhO3NCQUFDUTtzQkFBU0g7b0JBQU0sR0FBR0gsUUFBUSxDQUFDO2tCQUNqRTtnQkFDRixDQUFDO2NBQ0g7WUFDRjtBQXFCQSxrQkFBTXNCLGFBQWFBLENBQUNWLFFBQVFXLFNBQVFDLFlBQVk7QUFDOUMscUJBQU8sSUFBSUMsTUFBTUYsU0FBUTtnQkFDdkJHLE1BQU1DLGNBQWNDLFNBQVNmLE1BQU07QUFDakMseUJBQU9XLFFBQVFLLEtBQUtELFNBQVNoQixRQUFRLEdBQUdDLElBQUk7Z0JBQzlDO2NBQ0YsQ0FBQztZQUNIO0FBRUEsZ0JBQUlpQixpQkFBaUJDLFNBQVNGLEtBQUtHLEtBQUtsRCxPQUFPbUQsVUFBVUgsY0FBYztBQXlCdkUsa0JBQU1JLGFBQWFBLENBQUN0QixRQUFRdUIsV0FBVyxDQUFDLEdBQUduQyxXQUFXLENBQUMsTUFBTTtBQUMzRCxrQkFBSW9DLFFBQVF0RCx1QkFBT3VELE9BQU8sSUFBSTtBQUM5QixrQkFBSUMsV0FBVztnQkFDYjdDLElBQUk4QyxjQUFhQyxNQUFNO0FBQ3JCLHlCQUFPQSxRQUFRNUIsVUFBVTRCLFFBQVFKO2dCQUNuQztnQkFFQTdDLElBQUlnRCxjQUFhQyxNQUFNQyxVQUFVO0FBQy9CLHNCQUFJRCxRQUFRSixPQUFPO0FBQ2pCLDJCQUFPQSxNQUFNSSxJQUFJO2tCQUNuQjtBQUVBLHNCQUFJLEVBQUVBLFFBQVE1QixTQUFTO0FBQ3JCLDJCQUFPdEI7a0JBQ1Q7QUFFQSxzQkFBSU0sUUFBUWdCLE9BQU80QixJQUFJO0FBRXZCLHNCQUFJLE9BQU81QyxVQUFVLFlBQVk7QUFJL0Isd0JBQUksT0FBT3VDLFNBQVNLLElBQUksTUFBTSxZQUFZO0FBRXhDNUMsOEJBQVEwQixXQUFXVixRQUFRQSxPQUFPNEIsSUFBSSxHQUFHTCxTQUFTSyxJQUFJLENBQUM7b0JBQ3pELFdBQVdWLGVBQWU5QixVQUFVd0MsSUFBSSxHQUFHO0FBR3pDLDBCQUFJaEIsVUFBVWYsa0JBQWtCK0IsTUFBTXhDLFNBQVN3QyxJQUFJLENBQUM7QUFDcEQ1Qyw4QkFBUTBCLFdBQVdWLFFBQVFBLE9BQU80QixJQUFJLEdBQUdoQixPQUFPO29CQUNsRCxPQUFPO0FBR0w1Qiw4QkFBUUEsTUFBTW9DLEtBQUtwQixNQUFNO29CQUMzQjtrQkFDRixXQUFXLE9BQU9oQixVQUFVLFlBQVlBLFVBQVUsU0FDdENrQyxlQUFlSyxVQUFVSyxJQUFJLEtBQzdCVixlQUFlOUIsVUFBVXdDLElBQUksSUFBSTtBQUkzQzVDLDRCQUFRc0MsV0FBV3RDLE9BQU91QyxTQUFTSyxJQUFJLEdBQUd4QyxTQUFTd0MsSUFBSSxDQUFDO2tCQUMxRCxXQUFXVixlQUFlOUIsVUFBVSxHQUFHLEdBQUc7QUFFeENKLDRCQUFRc0MsV0FBV3RDLE9BQU91QyxTQUFTSyxJQUFJLEdBQUd4QyxTQUFTLEdBQUcsQ0FBQztrQkFDekQsT0FBTztBQUdMbEIsMkJBQU80RCxlQUFlTixPQUFPSSxNQUFNO3NCQUNqQ0csY0FBYztzQkFDZEMsWUFBWTtzQkFDWnJELE1BQU07QUFDSiwrQkFBT3FCLE9BQU80QixJQUFJO3NCQUNwQjtzQkFDQTlDLElBQUlFLFFBQU87QUFDVGdCLCtCQUFPNEIsSUFBSSxJQUFJNUM7c0JBQ2pCO29CQUNGLENBQUM7QUFFRCwyQkFBT0E7a0JBQ1Q7QUFFQXdDLHdCQUFNSSxJQUFJLElBQUk1QztBQUNkLHlCQUFPQTtnQkFDVDtnQkFFQUYsSUFBSTZDLGNBQWFDLE1BQU01QyxPQUFPNkMsVUFBVTtBQUN0QyxzQkFBSUQsUUFBUUosT0FBTztBQUNqQkEsMEJBQU1JLElBQUksSUFBSTVDO2tCQUNoQixPQUFPO0FBQ0xnQiwyQkFBTzRCLElBQUksSUFBSTVDO2tCQUNqQjtBQUNBLHlCQUFPO2dCQUNUO2dCQUVBOEMsZUFBZUgsY0FBYUMsTUFBTUssTUFBTTtBQUN0Qyx5QkFBT0MsUUFBUUosZUFBZU4sT0FBT0ksTUFBTUssSUFBSTtnQkFDakQ7Z0JBRUFFLGVBQWVSLGNBQWFDLE1BQU07QUFDaEMseUJBQU9NLFFBQVFDLGVBQWVYLE9BQU9JLElBQUk7Z0JBQzNDO2NBQ0Y7QUFZQSxrQkFBSUQsY0FBY3pELE9BQU91RCxPQUFPekIsTUFBTTtBQUN0QyxxQkFBTyxJQUFJYSxNQUFNYyxhQUFhRCxRQUFRO1lBQ3hDO0FBa0JBLGtCQUFNVSxZQUFZQyxpQkFBZTtjQUMvQkMsWUFBWXRDLFFBQVF1QyxhQUFhdEMsTUFBTTtBQUNyQ0QsdUJBQU9zQyxZQUFZRCxXQUFXMUQsSUFBSTRELFFBQVEsR0FBRyxHQUFHdEMsSUFBSTtjQUN0RDtjQUVBdUMsWUFBWXhDLFFBQVF1QyxVQUFVO0FBQzVCLHVCQUFPdkMsT0FBT3dDLFlBQVlILFdBQVcxRCxJQUFJNEQsUUFBUSxDQUFDO2NBQ3BEO2NBRUFFLGVBQWV6QyxRQUFRdUMsVUFBVTtBQUMvQnZDLHVCQUFPeUMsZUFBZUosV0FBVzFELElBQUk0RCxRQUFRLENBQUM7Y0FDaEQ7WUFDRjtBQUVBLGtCQUFNRyw0QkFBNEIsSUFBSXJFLGVBQWVrRSxjQUFZO0FBQy9ELGtCQUFJLE9BQU9BLGFBQWEsWUFBWTtBQUNsQyx1QkFBT0E7Y0FDVDtBQVVBLHFCQUFPLFNBQVNJLGtCQUFrQkMsS0FBSztBQUNyQyxzQkFBTUMsYUFBYXZCLFdBQVdzQixLQUFLLENBQUMsR0FBa0I7a0JBQ3BERSxZQUFZO29CQUNWNUMsU0FBUztvQkFDVEMsU0FBUztrQkFDWDtnQkFDRixDQUFDO0FBQ0RvQyx5QkFBU00sVUFBVTtjQUNyQjtZQUNGLENBQUM7QUFFRCxrQkFBTUUsb0JBQW9CLElBQUkxRSxlQUFla0UsY0FBWTtBQUN2RCxrQkFBSSxPQUFPQSxhQUFhLFlBQVk7QUFDbEMsdUJBQU9BO2NBQ1Q7QUFtQkEscUJBQU8sU0FBU1MsVUFBVXhELFNBQVN5RCxRQUFRQyxjQUFjO0FBQ3ZELG9CQUFJQyxzQkFBc0I7QUFFMUIsb0JBQUlDO0FBQ0osb0JBQUlDLHNCQUFzQixJQUFJakQsUUFBUVYsYUFBVztBQUMvQzBELHdDQUFzQixTQUFTRSxVQUFVO0FBQ3ZDSCwwQ0FBc0I7QUFDdEJ6RCw0QkFBUTRELFFBQVE7a0JBQ2xCO2dCQUNGLENBQUM7QUFFRCxvQkFBSUM7QUFDSixvQkFBSTtBQUNGQSwyQkFBU2hCLFNBQVMvQyxTQUFTeUQsUUFBUUcsbUJBQW1CO2dCQUN4RCxTQUFTSSxLQUFLO0FBQ1pELDJCQUFTbkQsUUFBUWIsT0FBT2lFLEdBQUc7Z0JBQzdCO0FBRUEsc0JBQU1DLG1CQUFtQkYsV0FBVyxRQUFReEUsV0FBV3dFLE1BQU07QUFLN0Qsb0JBQUlBLFdBQVcsUUFBUSxDQUFDRSxvQkFBb0IsQ0FBQ04scUJBQXFCO0FBQ2hFLHlCQUFPO2dCQUNUO0FBTUEsc0JBQU1PLHFCQUFzQnZFLGFBQVk7QUFDdENBLDBCQUFRRixLQUFLMEUsU0FBTztBQUVsQlQsaUNBQWFTLEdBQUc7a0JBQ2xCLEdBQUdDLFdBQVM7QUFHVix3QkFBSXBFO0FBQ0osd0JBQUlvRSxVQUFVQSxpQkFBaUJoRyxTQUMzQixPQUFPZ0csTUFBTXBFLFlBQVksV0FBVztBQUN0Q0Esc0JBQUFBLFdBQVVvRSxNQUFNcEU7b0JBQ2xCLE9BQU87QUFDTEEsc0JBQUFBLFdBQVU7b0JBQ1o7QUFFQTBELGlDQUFhO3NCQUNYVyxtQ0FBbUM7c0JBQ25DckUsU0FBQUE7b0JBQ0YsQ0FBQztrQkFDSCxDQUFDLEVBQUVzRSxNQUFNTixTQUFPO0FBRWRqRCw0QkFBUXFELE1BQU0sMkNBQTJDSixHQUFHO2tCQUM5RCxDQUFDO2dCQUNIO0FBS0Esb0JBQUlDLGtCQUFrQjtBQUNwQkMscUNBQW1CSCxNQUFNO2dCQUMzQixPQUFPO0FBQ0xHLHFDQUFtQkwsbUJBQW1CO2dCQUN4QztBQUdBLHVCQUFPO2NBQ1Q7WUFDRixDQUFDO0FBRUQsa0JBQU1VLDZCQUE2QkEsQ0FBQztjQUFDeEU7Y0FBUUc7WUFBTyxHQUFHc0UsVUFBVTtBQUMvRCxrQkFBSWhHLGNBQWNOLFFBQVE0QixXQUFXO0FBSW5DLG9CQUFJdEIsY0FBY04sUUFBUTRCLFVBQVVFLFlBQVkxQixrREFBa0Q7QUFDaEc0QiwwQkFBUTtnQkFDVixPQUFPO0FBQ0xILHlCQUFPLElBQUkzQixNQUFNSSxjQUFjTixRQUFRNEIsVUFBVUUsT0FBTyxDQUFDO2dCQUMzRDtjQUNGLFdBQVd3RSxTQUFTQSxNQUFNSCxtQ0FBbUM7QUFHM0R0RSx1QkFBTyxJQUFJM0IsTUFBTW9HLE1BQU14RSxPQUFPLENBQUM7Y0FDakMsT0FBTztBQUNMRSx3QkFBUXNFLEtBQUs7Y0FDZjtZQUNGO0FBRUEsa0JBQU1DLHFCQUFxQkEsQ0FBQ25FLE1BQU1WLFVBQVU4RSxvQkFBb0JqRSxTQUFTO0FBQ3ZFLGtCQUFJQSxLQUFLN0IsU0FBU2dCLFNBQVNjLFNBQVM7QUFDbEMsc0JBQU0sSUFBSXRDLE1BQU8scUJBQW9Cd0IsU0FBU2MsT0FBUSxJQUFHUCxtQkFBbUJQLFNBQVNjLE9BQU8sQ0FBRSxRQUFPSixJQUFLLFdBQVVHLEtBQUs3QixNQUFPLEVBQUM7Y0FDbkk7QUFFQSxrQkFBSTZCLEtBQUs3QixTQUFTZ0IsU0FBU2UsU0FBUztBQUNsQyxzQkFBTSxJQUFJdkMsTUFBTyxvQkFBbUJ3QixTQUFTZSxPQUFRLElBQUdSLG1CQUFtQlAsU0FBU2UsT0FBTyxDQUFFLFFBQU9MLElBQUssV0FBVUcsS0FBSzdCLE1BQU8sRUFBQztjQUNsSTtBQUVBLHFCQUFPLElBQUlnQyxRQUFRLENBQUNWLFNBQVNILFdBQVc7QUFDdEMsc0JBQU00RSxZQUFZSiwyQkFBMkIzQyxLQUFLLE1BQU07a0JBQUMxQjtrQkFBU0g7Z0JBQU0sQ0FBQztBQUN6RVUscUJBQUttRSxLQUFLRCxTQUFTO0FBQ25CRCxnQ0FBZ0JHLFlBQVksR0FBR3BFLElBQUk7Y0FDckMsQ0FBQztZQUNIO0FBRUEsa0JBQU1xRSxpQkFBaUI7Y0FDckJDLFVBQVU7Z0JBQ1JDLFNBQVM7a0JBQ1A3QixtQkFBbUJQLFVBQVVNLHlCQUF5QjtnQkFDeEQ7Y0FDRjtjQUNBaEYsU0FBUztnQkFDUHNGLFdBQVdaLFVBQVVXLGlCQUFpQjtnQkFDdEMwQixtQkFBbUJyQyxVQUFVVyxpQkFBaUI7Z0JBQzlDc0IsYUFBYUosbUJBQW1CN0MsS0FBSyxNQUFNLGVBQWU7a0JBQUNsQixTQUFTO2tCQUFHQyxTQUFTO2dCQUFDLENBQUM7Y0FDcEY7Y0FDQXVFLE1BQU07Z0JBQ0pMLGFBQWFKLG1CQUFtQjdDLEtBQUssTUFBTSxlQUFlO2tCQUFDbEIsU0FBUztrQkFBR0MsU0FBUztnQkFBQyxDQUFDO2NBQ3BGO1lBQ0Y7QUFDQSxrQkFBTXdFLGtCQUFrQjtjQUN0QkMsT0FBTztnQkFBQzFFLFNBQVM7Z0JBQUdDLFNBQVM7Y0FBQztjQUM5QnhCLEtBQUs7Z0JBQUN1QixTQUFTO2dCQUFHQyxTQUFTO2NBQUM7Y0FDNUJyQixLQUFLO2dCQUFDb0IsU0FBUztnQkFBR0MsU0FBUztjQUFDO1lBQzlCO0FBQ0FsQyx3QkFBWTRHLFVBQVU7Y0FDcEJMLFNBQVM7Z0JBQUMsS0FBS0c7Y0FBZTtjQUM5QkcsVUFBVTtnQkFBQyxLQUFLSDtjQUFlO2NBQy9CSSxVQUFVO2dCQUFDLEtBQUtKO2NBQWU7WUFDakM7QUFFQSxtQkFBT3JELFdBQVd0RCxlQUFlc0csZ0JBQWdCckcsV0FBVztVQUM5RDtBQUlBK0csVUFBQUEsUUFBT0MsVUFBVWxILFNBQVNOLE1BQU07UUFDbEMsT0FBTztBQUNMdUgsVUFBQUEsUUFBT0MsVUFBVXpILFdBQVdLO1FBQzlCO01BQUMsQ0FBQTs7Ozs7QUM5ckNEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUVPLFdBQVMsZ0JBQWdCLE1BQU07QUFDbEMsV0FBTyw4QkFBQXFILFFBQVEsUUFBUSxPQUFPLElBQUk7QUFBQSxFQUN0QztBQUVPLFdBQVMsc0JBQXNCO0FBQ2xDLFVBQU0sV0FBVyw4QkFBQUEsUUFBUSxRQUFRLFlBQVk7QUFDN0MsV0FBTyxTQUFTO0FBQUEsRUFDcEI7QUFFTyxXQUFTLGtCQUFrQixNQUFNO0FBQ3BDLGtDQUFBQSxRQUFRLEtBQUssT0FBTyxFQUFFLEtBQUssZ0JBQWdCLElBQUksRUFBRSxDQUFDO0FBQUEsRUFDdEQ7QUFPQSxpQkFBc0IsY0FBYyxVQUFVLE9BQU87QUFDakQsUUFBSSxPQUFPLDhCQUFBQSxRQUFRLFdBQVcsYUFBYTtBQUN2QyxhQUFPLDhCQUFBQSxRQUFRLGNBQWMsUUFBUSxFQUFFLE1BQU0sVUFBVSxNQUFNLENBQUM7QUFBQSxJQUNsRTtBQUNBLFdBQU8sOEJBQUFBLFFBQVEsT0FBTyxRQUFRLEVBQUUsTUFBTSxVQUFVLE1BQU0sQ0FBQztBQUFBLEVBQzNEO0FBQ08sV0FBUyxxQkFBcUI7QUFDakMsVUFBTSxXQUFXLDhCQUFBQSxRQUFRLFFBQVEsWUFBWTtBQUM3QyxXQUFPLFNBQVM7QUFBQSxFQUNwQjtBQUVPLFdBQVMsY0FBYyxNQUFNO0FBQ2hDLFdBQU8sOEJBQUFBLFFBQVEsUUFBUSxNQUFNLElBQUksSUFBSTtBQUFBLEVBQ3pDO0FBR0EsaUJBQXNCLGVBQWUsS0FBSyxJQUFJO0FBQzFDLFVBQU0sU0FBUyxNQUFNLDhCQUFBQSxRQUFRLFFBQVEsTUFBTSxJQUFJLEdBQUc7QUFDbEQsV0FBTyxPQUFPLEdBQUc7QUFBQSxFQUNyQjtBQUdBLGlCQUFzQixzQkFBc0IsTUFBTSxJQUFJO0FBQ2xELFFBQUk7QUFDQSxhQUFPLE1BQU0sOEJBQUFBLFFBQVEsUUFBUSxRQUFRLElBQUksSUFBSTtBQUFBLElBQ2pELFNBQVMsR0FBRztBQUNSLGNBQVEsSUFBSSxzQkFBc0IsQ0FBQztBQUFBLElBQ3ZDO0FBQ0EsV0FBTyxDQUFDO0FBQUEsRUFDWjtBQUVPLFdBQVMsaUJBQWlCO0FBQzdCLFdBQU8sOEJBQUFBLFFBQVEsUUFBUTtBQUFBLEVBQzNCO0FBTU8sV0FBUyxpQkFBaUIsU0FBUztBQUV0QyxVQUFNLFFBQVEsV0FBVyxVQUFVLFFBQVEsUUFBUSxRQUFRO0FBQzNELFVBQU0sTUFBTSxRQUFRO0FBQ3BCLFVBQU0sU0FBUyxZQUFZLFVBQVUsUUFBUSxTQUFTO0FBQ3RELFVBQU0sWUFBWSxlQUFlLFVBQVUsUUFBUSxZQUFZO0FBQy9ELFdBQU87QUFBQSxNQUNIO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsSUFDSjtBQUFBLEVBQ0o7QUFFTyxXQUFTLG1CQUFtQkMsV0FBVSxTQUFTO0FBQ2xELFdBQU8sT0FBTyxPQUFPQSxXQUFVLE9BQU87QUFBQSxFQUMxQztBQUVBLGlCQUFzQixnQkFBZ0I7QUFDbEMsVUFBTSxPQUFRLE1BQU0sOEJBQUFELFFBQVEsS0FBSyxNQUFNLEVBQUUsS0FBSyw2QkFBNkIsQ0FBQyxLQUFNLENBQUM7QUFDbkYsV0FBTyxLQUFLLElBQUksQ0FBQyxRQUFRLElBQUksR0FBRztBQUFBLEVBQ3BDO0FBRU8sV0FBUyxnQkFBZ0IsS0FBSztBQUNqQyxrQ0FBQUEsUUFBUSxRQUFRLGdCQUFnQixHQUFHO0FBQUEsRUFDdkM7QUFFTyxXQUFTLGFBQWEsT0FBTyxLQUFLO0FBQ3JDLFdBQU8sOEJBQUFBLFFBQVEsS0FBSyxPQUFPLE9BQU8sRUFBRSxJQUFJLENBQUM7QUFBQSxFQUM3QztBQUVBLFdBQVMscUNBQXFDLFNBQVM7QUFDbkQsUUFBSSxPQUFPLFlBQVksVUFBVTtBQUM3QixZQUFNLElBQUksTUFBTSxpQ0FBaUM7QUFBQSxJQUNyRDtBQUVBLFFBQ0ksT0FBTyxRQUFRLFNBQVMsZUFDeEIsT0FBTyxRQUFRLFlBQVksZUFDM0IsT0FBTyxRQUFRLFVBQVUsZUFDekIsT0FBTyxRQUFRLGNBQWMsZUFDN0IsT0FBTyxRQUFRLFNBQVMsYUFDMUI7QUFDRSxZQUFNLElBQUksTUFBTSxnR0FBcUc7QUFBQSxJQUN6SDtBQUVBLFFBQUksT0FBTyxRQUFRLFVBQVUsYUFBYTtBQUN0QyxZQUFNLElBQUksTUFBTSx3Q0FBd0M7QUFBQSxJQUM1RDtBQUVBLFVBQU0sRUFBRSxXQUFXLFVBQVUsTUFBTSxJQUFJLFFBQVE7QUFDL0MsV0FBTyxRQUFRO0FBRWYsUUFBSSxNQUFNLFFBQVEsUUFBUSxLQUFLLFNBQVMsU0FBUyxHQUFHO0FBQ2hELFVBQUksU0FBUyxTQUFTLEdBQUc7QUFDckIsY0FBTSxJQUFJLE1BQU0sd0RBQXdEO0FBQUEsTUFDNUU7QUFFQSxjQUFRLFVBQVUsU0FBUyxDQUFDO0FBQUEsSUFDaEM7QUFFQSxRQUFJLE9BQU8sUUFBUSxVQUFVLGFBQWE7QUFDdEMsVUFBSSxNQUFNLFFBQVEsUUFBUSxLQUFLLEtBQUssUUFBUSxNQUFNLFNBQVMsR0FBRztBQUMxRCxZQUFJLFFBQVEsTUFBTSxTQUFTLEdBQUc7QUFDMUIsZ0JBQU0sSUFBSSxNQUFNLHdFQUF3RTtBQUFBLFFBQzVGO0FBQ0EsZ0JBQVEsT0FBTyxRQUFRLE1BQU0sQ0FBQztBQUFBLE1BQ2xDO0FBQ0EsYUFBTyxRQUFRO0FBQUEsSUFDbkI7QUFFQSxRQUFJLE9BQU8sY0FBYyxhQUFhO0FBQ2xDLGNBQVEsWUFBWTtBQUFBLElBQ3hCO0FBRUEsUUFBSSxPQUFPLFFBQVEsc0JBQXNCLGFBQWE7QUFDbEQsVUFBSSxRQUFRLG1CQUFtQjtBQUMzQixnQkFBUSxRQUFRO0FBQUEsTUFDcEI7QUFDQSxhQUFPLFFBQVE7QUFBQSxJQUNuQjtBQUVBLFFBQUksa0JBQWtCO0FBQ3RCLFFBQUksT0FBTyxRQUFRLFNBQVMsYUFBYTtBQUNyQyxVQUFJLE1BQU0sUUFBUSxRQUFRLElBQUksR0FBRztBQUM3QiwwQkFBa0IsUUFBUSxLQUFLLFVBQVUsUUFBUSxJQUFJO0FBQUEsTUFDekQ7QUFDQSxhQUFPLFFBQVE7QUFBQSxJQUNuQjtBQUVBLFFBQUksT0FBTyxRQUFRLFNBQVMsYUFBYTtBQUNyQyxVQUFJLE9BQU8sUUFBUSxTQUFTLFlBQVk7QUFDcEMsZ0JBQVEsT0FBTyxNQUFNLFFBQVEsS0FBSyxTQUFTLElBQUksT0FBTyxrQkFBa0I7QUFBQSxNQUM1RTtBQUNBLGFBQU8sUUFBUTtBQUFBLElBQ25CO0FBRUEsV0FBTyxDQUFDLE9BQU8sT0FBTztBQUFBLEVBQzFCO0FBaUJBLGlCQUFzQixjQUFjLFNBQVM7QUFDekMsUUFBSSxPQUFPLDhCQUFBQSxRQUFRLGNBQWMsYUFBYTtBQUMxQyxhQUFPLE1BQU0sOEJBQUFBLFFBQVEsS0FBSztBQUFBLFFBRXRCLEdBQUcscUNBQXFDLE9BQU87QUFBQSxNQUNuRDtBQUFBLElBQ0o7QUFFQSxXQUFPLE1BQU0sOEJBQUFBLFFBQVEsVUFBVSxjQUFjLE9BQU87QUFBQSxFQUN4RDtBQWFBLGlCQUFzQixVQUFVLFNBQVM7QUFDckMsUUFBSSxPQUFPLDhCQUFBQSxRQUFRLGNBQWMsYUFBYTtBQUMxQyxhQUFPLE1BQU0sOEJBQUFBLFFBQVEsS0FBSztBQUFBLFFBRXRCLEdBQUcscUNBQXFDLE9BQU87QUFBQSxNQUNuRDtBQUFBLElBQ0o7QUFFQSxXQUFPLE1BQU0sOEJBQUFBLFFBQVEsVUFBVSxVQUFVLE9BQU87QUFBQSxFQUNwRDtBQXFCQSxpQkFBc0Isb0JBQW9CLEtBQUssTUFBTTtBQUNqRCxRQUFJLE9BQU8sUUFBUSxVQUFVO0FBQ3pCLFlBQU0sSUFBSSxNQUFNLHVDQUF1QztBQUFBLElBQzNEO0FBRUEsUUFBSSx5QkFBeUI7QUFFekIsYUFBTyxNQUFNLDhCQUFBQSxRQUFRLFFBQVEsUUFBUSxJQUFJLEVBQUUsQ0FBQyxHQUFHLEdBQUcsS0FBSyxDQUFDO0FBQUEsSUFDNUQ7QUFHQSwyQkFBdUIsSUFBSSxLQUFLLElBQUk7QUFBQSxFQUN4QztBQVNBLGlCQUFzQixzQkFBc0IsS0FBSztBQUM3QyxRQUFJLE9BQU8sUUFBUSxVQUFVO0FBQ3pCLFlBQU0sSUFBSSxNQUFNLHVDQUF1QztBQUFBLElBQzNEO0FBRUEsUUFBSSx5QkFBeUI7QUFFekIsWUFBTSxTQUFTLE1BQU0sOEJBQUFBLFFBQVEsUUFBUSxRQUFRLElBQUksQ0FBQyxHQUFHLENBQUM7QUFDdEQsYUFBTyxPQUFPLEdBQUc7QUFBQSxJQUNyQjtBQUdBLFdBQU8sdUJBQXVCLElBQUksR0FBRztBQUFBLEVBQ3pDO0FBUUEsaUJBQXNCLHlCQUF5QixLQUFLO0FBQ2hELFFBQUksT0FBTyxRQUFRLFVBQVU7QUFDekIsWUFBTSxJQUFJLE1BQU0sdUNBQXVDO0FBQUEsSUFDM0Q7QUFFQSxRQUFJLHlCQUF5QjtBQUV6QixhQUFPLE1BQU0sOEJBQUFBLFFBQVEsUUFBUSxRQUFRLE9BQU8sR0FBRztBQUFBLElBQ25EO0FBR0EsV0FBTyx1QkFBdUIsT0FBTyxHQUFHO0FBQUEsRUFDNUM7QUFZQSxpQkFBc0IsWUFBWSxNQUFNLFdBQVc7QUFDL0MsVUFBTSxnQkFBZ0IsTUFBTSw4QkFBQUEsUUFBUSxPQUFPLElBQUksSUFBSTtBQUNuRCxRQUFJLENBQUMsZUFBZTtBQUNoQixhQUFPLE1BQU0sOEJBQUFBLFFBQVEsT0FBTyxPQUFPLE1BQU0sU0FBUztBQUFBLElBQ3REO0FBQUEsRUFDSjtBQXpTQSxNQUFBRSwrQkFpTk0seUJBQ087QUFsTmI7QUFBQTtBQUFBO0FBQUEsTUFBQUEsZ0NBQW9CO0FBaU5wQixNQUFNLDBCQUEwQixPQUFPLDhCQUFBRixRQUFRLFFBQVEsWUFBWTtBQUM1RCxNQUFNLHlCQUF5QiwwQkFBMEIsT0FBTyxvQkFBSSxJQUFJO0FBQUE7QUFBQTs7O0FDbE4vRTtBQUFBLHFDQUFBRyxVQUFBQyxTQUFBO0FBQUE7QUFBQSxNQUFBQSxRQUFPLFVBQVU7QUFBQSxRQUNiLHdCQUF3QjtBQUFBLFFBQ3hCLHVCQUF1QjtBQUFBLFFBQ3ZCLEtBQUs7QUFBQSxRQUNMLHdCQUF3QjtBQUFBLFFBQ3hCLEtBQUs7QUFBQSxRQUNMLFNBQVM7QUFBQSxRQUNULGVBQWU7QUFBQSxRQUNmLGdDQUFnQztBQUFBLFFBQ2hDLHFDQUFxQztBQUFBLFFBQ3JDLHlCQUF5QjtBQUFBLFFBQ3pCLDZCQUE2QjtBQUFBLFFBQzdCLG9CQUFvQjtBQUFBLFFBQ3BCLFVBQVU7QUFBQSxRQUNWLFlBQVk7QUFBQSxRQUNaLGVBQWU7QUFBQSxRQUNmLCtCQUErQjtBQUFBLFFBQy9CLDJCQUEyQjtBQUFBLE1BQy9CO0FBQUE7QUFBQTs7O0FDbEJBO0FBQUEsdUNBQUFDLFVBQUFDLFNBQUE7QUFBQTtBQUFBLFVBQU0sa0JBQWtCO0FBQ3hCLFVBQU0saUJBQWlCO0FBRXZCLFVBQU0sa0JBQWtCLElBQUksWUFBWTtBQUd4QyxVQUFJLE9BQU8sZ0JBQWdCLFlBQWEsWUFBVyxjQUFjO0FBS2pFLFVBQU0sbUJBQW1CLENBQUMsb0JBQW9CO0FBTzlDLFVBQUlDLFlBQVcsQ0FBQztBQUNoQixVQUFJLFVBQVU7QUFDZCxVQUFNLFNBQVMsS0FBSyxFQUFFLEtBQUssTUFBTTtBQUM3QixrQkFBVTtBQUNWLGdCQUFRLElBQUkscUJBQXFCO0FBQUEsTUFDckMsQ0FBQztBQUVELHFCQUFlLE9BQU87QUFDbEIsa0NBQTBCO0FBQzFCLGNBQU0sZ0NBQWdDO0FBQ3RDLGNBQU0sOEJBQThCO0FBQUEsTUFDeEM7QUFFQSxlQUFTLFFBQVE7QUFDYixlQUFPO0FBQUEsTUFDWDtBQUdBLGVBQVMscUJBQXFCO0FBQzFCLGNBQU0sYUFBYTtBQUFBO0FBQUEsVUFFZixhQUFhO0FBQUEsVUFDYixnQkFBZ0I7QUFBQTtBQUFBLFVBR2hCLGtCQUFrQjtBQUFBLFVBQ2xCLG1CQUFtQjtBQUFBLFVBQ25CLG1CQUFtQjtBQUFBLFVBQ25CLEtBQUs7QUFBQSxVQUNMLE9BQU87QUFBQSxVQUNQLG9CQUFvQjtBQUFBLFVBQ3BCLGdCQUFnQjtBQUFBLFVBQ2hCLGFBQWE7QUFBQSxVQUNiLG9CQUFvQjtBQUFBLFVBQ3BCLFVBQVU7QUFBQSxVQUNWLFlBQVk7QUFBQSxVQUNaLHlCQUF5QjtBQUFBLFVBQ3pCLGVBQWU7QUFBQSxVQUNmLHdCQUF3QjtBQUFBLFVBQ3hCLFVBQVU7QUFBQSxVQUNWLFNBQVM7QUFBQSxVQUNULHdCQUF3QjtBQUFBLFVBRXhCLG1CQUFtQjtBQUFBLFVBQ25CLHVCQUF1QjtBQUFBLFVBQ3ZCLHNCQUFzQjtBQUFBLFVBQ3RCLDBCQUEwQjtBQUFBLFVBQzFCLG1DQUFtQztBQUFBLFFBQ3ZDO0FBQ0EsWUFBSSxhQUFhO0FBQ2pCLG1CQUFXLGFBQWEsWUFBWTtBQUNoQyxnQkFBTSxNQUFNLFdBQVcsU0FBUztBQUNoQyxjQUFJLEVBQUUsYUFBYUEsWUFBVztBQUMxQjtBQUFBLFVBQ0o7QUFDQSx1QkFBYTtBQUNiLGdCQUFNLGNBQWNBLFVBQVMsU0FBUztBQUN0QyxjQUFJLE9BQU8sYUFBYTtBQUNwQixZQUFBQSxVQUFTLEdBQUcsSUFBSTtBQUFBLFVBQ3BCO0FBQ0EsaUJBQU9BLFVBQVMsU0FBUztBQUFBLFFBQzdCO0FBQ0EsWUFBSSxZQUFZO0FBQ1osb0NBQTBCO0FBQUEsUUFDOUI7QUFBQSxNQUNKO0FBRUEscUJBQWUsZ0NBQWdDO0FBQzNDLGNBQU0sVUFBVSxNQUFNLGVBQWUsZUFBZSxDQUFDLFVBQVUsQ0FBQztBQUVoRSxZQUFJLENBQUMsUUFBUztBQUNkLFFBQUFBLFlBQVcsZUFBZSxtQkFBbUJBLFdBQVUsT0FBTztBQUM5RCwyQkFBbUI7QUFBQSxNQUN2QjtBQUVBLHFCQUFlLGtDQUFrQztBQUM3QyxjQUFNLFVBQVUsTUFBTSxlQUFlLHNCQUFzQixnQkFBZ0I7QUFDM0UsUUFBQUEsWUFBVyxlQUFlLG1CQUFtQkEsV0FBVSxPQUFPO0FBQUEsTUFDbEU7QUFFQSxlQUFTLDRCQUE0QjtBQUVqQyxRQUFBQSxZQUFXLE9BQU8sT0FBTyxDQUFDLEdBQUcsZUFBZTtBQUFBLE1BQ2hEO0FBRUEsZUFBUyw0QkFBNEI7QUFDakMsZUFBTyxlQUFlLGNBQWMsRUFBRSxVQUFBQSxVQUFTLENBQUM7QUFBQSxNQUNwRDtBQUVBLGVBQVMsV0FBVyxNQUFNO0FBQ3RCLFlBQUksQ0FBQyxTQUFTO0FBQ1Ysa0JBQVEsS0FBSywrQ0FBK0MsSUFBSSxFQUFFO0FBQ2xFO0FBQUEsUUFDSjtBQUdBLFlBQUksU0FBUyxNQUFPLFFBQU87QUFFM0IsWUFBSSxNQUFNO0FBQ04saUJBQU9BLFVBQVMsSUFBSTtBQUFBLFFBQ3hCLE9BQU87QUFDSCxpQkFBT0E7QUFBQSxRQUNYO0FBQUEsTUFDSjtBQUVBLGVBQVMsY0FBYyxNQUFNLE9BQU87QUFDaEMsWUFBSSxDQUFDLFNBQVM7QUFDVixrQkFBUSxLQUFLLGlEQUFpRCxJQUFJLEVBQUU7QUFDcEU7QUFBQSxRQUNKO0FBRUEsUUFBQUEsVUFBUyxJQUFJLElBQUk7QUFDakIsa0NBQTBCLEVBQUUsS0FBSyxNQUFNO0FBQ25DLDBCQUFnQixjQUFjLElBQUksWUFBWSxNQUFNLEVBQUUsUUFBUSxNQUFNLENBQUMsQ0FBQztBQUFBLFFBQzFFLENBQUM7QUFBQSxNQUNMO0FBRUEsZUFBUyx3QkFBd0IsTUFBTSxZQUFZLEdBQUc7QUFDbEQsWUFBSSxDQUFDLFNBQVM7QUFDVixrQkFBUSxLQUFLLDJEQUEyRCxJQUFJO0FBQzVFO0FBQUEsUUFDSjtBQUVBLFlBQUksUUFBUUEsVUFBUyxJQUFJO0FBQ3pCLFlBQUksT0FBTyxVQUFVLFlBQVksTUFBTSxLQUFLLEdBQUc7QUFDM0Msa0JBQVE7QUFBQSxRQUNaO0FBRUEsc0JBQWMsTUFBTSxRQUFRLFNBQVM7QUFBQSxNQUN6QztBQUVBLGVBQVMsY0FBYyxNQUFNO0FBQ3pCLFlBQUksQ0FBQyxTQUFTO0FBQ1Ysa0JBQVEsS0FBSyxpREFBaUQsSUFBSSxFQUFFO0FBQ3BFO0FBQUEsUUFDSjtBQUNBLFlBQUlBLFVBQVMsSUFBSSxHQUFHO0FBQ2hCLGlCQUFPQSxVQUFTLElBQUk7QUFDcEIsb0NBQTBCO0FBQUEsUUFDOUI7QUFBQSxNQUNKO0FBRUEsZUFBUyxjQUFjO0FBQ25CLHVCQUFlLGVBQWUsQ0FBQyxVQUFVLENBQUMsRUFBRSxLQUFLLENBQUMsTUFBTTtBQUNwRCxrQkFBUSxJQUFJLEVBQUUsUUFBUTtBQUFBLFFBQzFCLENBQUM7QUFBQSxNQUNMO0FBRUEsTUFBQUQsUUFBTyxVQUFVO0FBQUEsUUFDYjtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLE1BQ0o7QUFBQTtBQUFBOzs7QUM5S0E7QUFBQSx3REFBQUUsVUFBQUMsU0FBQTtBQUFBO0FBQUEsTUFBQUEsUUFBTyxVQUFVLENBQUMsYUFBYTtBQUMzQixZQUFJLENBQUMsV0FBVyxVQUFXLFFBQU8sQ0FBQztBQUVuQyxZQUFJLENBQUMsU0FBVSxZQUFXLFdBQVcsVUFBVTtBQUUvQyxZQUFJQztBQUNKLFlBQUk7QUFFSixZQUFJO0FBQ0EsY0FBSSxnQkFBZ0IsU0FBUyxNQUFNLGdDQUFnQztBQUNuRSxnQkFBTSxTQUFTO0FBQ2YsZ0JBQU0sVUFBVTtBQUVoQixjQUFJLFNBQVMsTUFBTSxNQUFNLEdBQUc7QUFDeEIsNEJBQWdCLFNBQVMsTUFBTSxNQUFNO0FBQUEsVUFDekMsV0FBVyxTQUFTLE1BQU0sT0FBTyxHQUFHO0FBQ2hDLDRCQUFnQixTQUFTLE1BQU0sT0FBTztBQUN0QywwQkFBYyxDQUFDLElBQUk7QUFBQSxVQUN2QjtBQUNBLFVBQUFBLFdBQVUsY0FBYyxDQUFDO0FBQ3pCLG9CQUFVLGNBQWMsQ0FBQztBQUl6QixjQUFJLFdBQVcsVUFBVSxPQUFPO0FBQzVCLFlBQUFBLFdBQVU7QUFBQSxVQUNkO0FBQUEsUUFDSixTQUFTLEdBQUc7QUFFUixVQUFBQSxXQUFVLFVBQVU7QUFBQSxRQUN4QjtBQUVBLFlBQUksS0FBSztBQUNULFlBQUksV0FBVyxVQUFVLFVBQVUsUUFBUSxTQUFTLE1BQU0sR0FBSSxNQUFLO0FBQ25FLFlBQUksV0FBVyxVQUFVLFVBQVUsUUFBUSxLQUFLLE1BQU0sR0FBSSxNQUFLO0FBQy9ELFlBQUksV0FBVyxVQUFVLFVBQVUsUUFBUSxPQUFPLE1BQU0sR0FBSSxNQUFLO0FBRWpFLGVBQU87QUFBQSxVQUNIO0FBQUEsVUFDQSxTQUFBQTtBQUFBLFVBQ0E7QUFBQSxRQUNKO0FBQUEsTUFDSjtBQUFBO0FBQUE7OztBQzFDQTtBQUFBO0FBQUE7QUFXQSxPQUFDLFdBQVk7QUFDVDtBQUVBLFlBQUksT0FBTyxPQUFPLFdBQVcsV0FBVyxTQUFTLENBQUM7QUFDbEQsWUFBSSxVQUFVLENBQUMsS0FBSyxzQkFBc0IsT0FBTyxZQUFZLFlBQVksUUFBUSxZQUFZLFFBQVEsU0FBUztBQUM5RyxZQUFJLFNBQVM7QUFDVCxpQkFBTztBQUFBLFFBQ1g7QUFDQSxZQUFJLFlBQVksQ0FBQyxLQUFLLHdCQUF3QixPQUFPLFdBQVcsWUFBWSxPQUFPO0FBQ25GLFlBQUksTUFBTSxPQUFPLFdBQVcsY0FBYyxPQUFPO0FBQ2pELFlBQUksWUFBWSxtQkFBbUIsTUFBTSxFQUFFO0FBQzNDLFlBQUksUUFBUSxDQUFDLGFBQWEsU0FBUyxPQUFPLEdBQUc7QUFDN0MsWUFBSSxRQUFRLENBQUMsSUFBSSxJQUFJLEdBQUcsQ0FBQztBQUN6QixZQUFJLGVBQWUsQ0FBQyxPQUFPLFNBQVMsVUFBVSxhQUFhO0FBRTNELFlBQUksU0FBUyxDQUFDO0FBRWQsWUFBSSxxQkFBcUIsU0FBVSxZQUFZO0FBQzNDLGlCQUFPLFNBQVUsU0FBUztBQUN0QixtQkFBTyxJQUFJLEtBQUssSUFBSSxFQUFFLE9BQU8sT0FBTyxFQUFFLFVBQVUsRUFBRTtBQUFBLFVBQ3REO0FBQUEsUUFDSjtBQUVBLFlBQUksZUFBZSxXQUFZO0FBQzNCLGNBQUlDLFVBQVMsbUJBQW1CLEtBQUs7QUFDckMsY0FBSSxTQUFTO0FBQ1QsWUFBQUEsVUFBUyxTQUFTQSxPQUFNO0FBQUEsVUFDNUI7QUFDQSxVQUFBQSxRQUFPLFNBQVMsV0FBWTtBQUN4QixtQkFBTyxJQUFJLEtBQUs7QUFBQSxVQUNwQjtBQUNBLFVBQUFBLFFBQU8sU0FBUyxTQUFVLFNBQVM7QUFDL0IsbUJBQU9BLFFBQU8sT0FBTyxFQUFFLE9BQU8sT0FBTztBQUFBLFVBQ3pDO0FBQ0EsbUJBQVMsSUFBSSxHQUFHLElBQUksYUFBYSxRQUFRLEVBQUUsR0FBRztBQUMxQyxnQkFBSSxPQUFPLGFBQWEsQ0FBQztBQUN6QixZQUFBQSxRQUFPLElBQUksSUFBSSxtQkFBbUIsSUFBSTtBQUFBLFVBQzFDO0FBQ0EsaUJBQU9BO0FBQUEsUUFDWDtBQUVBLFlBQUksV0FBVyxTQUFVLFFBQVE7QUFDN0IsY0FBSSxTQUFTLEtBQUssbUJBQW1CO0FBQ3JDLGNBQUksU0FBUyxLQUFLLDBCQUEwQjtBQUM1QyxjQUFJLGFBQWEsU0FBVSxTQUFTO0FBQ2hDLGdCQUFJLE9BQU8sWUFBWSxVQUFVO0FBQzdCLHFCQUFPLE9BQU8sV0FBVyxNQUFNLEVBQUUsT0FBTyxTQUFTLE1BQU0sRUFBRSxPQUFPLEtBQUs7QUFBQSxZQUN6RSxXQUFXLFFBQVEsZ0JBQWdCLGFBQWE7QUFDNUMsd0JBQVUsSUFBSSxXQUFXLE9BQU87QUFBQSxZQUNwQyxXQUFXLFFBQVEsV0FBVyxRQUFXO0FBQ3JDLHFCQUFPLE9BQU8sT0FBTztBQUFBLFlBQ3pCO0FBQ0EsbUJBQU8sT0FBTyxXQUFXLE1BQU0sRUFBRSxPQUFPLElBQUksT0FBTyxPQUFPLENBQUMsRUFBRSxPQUFPLEtBQUs7QUFBQSxVQUM3RTtBQUNBLGlCQUFPO0FBQUEsUUFDWDtBQUVBLGlCQUFTLEtBQUssY0FBYztBQUN4QixjQUFJLGNBQWM7QUFDZCxtQkFBTyxDQUFDLElBQ0osT0FBTyxFQUFFLElBQ1QsT0FBTyxDQUFDLElBQ1IsT0FBTyxDQUFDLElBQ1IsT0FBTyxDQUFDLElBQ1IsT0FBTyxDQUFDLElBQ1IsT0FBTyxDQUFDLElBQ1IsT0FBTyxDQUFDLElBQ1IsT0FBTyxDQUFDLElBQ1IsT0FBTyxDQUFDLElBQ1IsT0FBTyxDQUFDLElBQ1IsT0FBTyxFQUFFLElBQ1QsT0FBTyxFQUFFLElBQ1QsT0FBTyxFQUFFLElBQ1QsT0FBTyxFQUFFLElBQ1QsT0FBTyxFQUFFLElBQ1QsT0FBTyxFQUFFLElBQ0w7QUFDUixpQkFBSyxTQUFTO0FBQUEsVUFDbEIsT0FBTztBQUNILGlCQUFLLFNBQVMsQ0FBQyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLENBQUM7QUFBQSxVQUNwRTtBQUVBLGVBQUssS0FBSztBQUNWLGVBQUssS0FBSztBQUNWLGVBQUssS0FBSztBQUNWLGVBQUssS0FBSztBQUNWLGVBQUssS0FBSztBQUVWLGVBQUssUUFBUSxLQUFLLFFBQVEsS0FBSyxRQUFRLEtBQUssU0FBUztBQUNyRCxlQUFLLFlBQVksS0FBSyxTQUFTO0FBQy9CLGVBQUssUUFBUTtBQUFBLFFBQ2pCO0FBRUEsYUFBSyxVQUFVLFNBQVMsU0FBVSxTQUFTO0FBQ3ZDLGNBQUksS0FBSyxXQUFXO0FBQ2hCO0FBQUEsVUFDSjtBQUNBLGNBQUksWUFBWSxPQUFPLFlBQVk7QUFDbkMsY0FBSSxhQUFhLFFBQVEsZ0JBQWdCLEtBQUssYUFBYTtBQUN2RCxzQkFBVSxJQUFJLFdBQVcsT0FBTztBQUFBLFVBQ3BDO0FBQ0EsY0FBSSxNQUNBLFFBQVEsR0FDUixHQUNBLFNBQVMsUUFBUSxVQUFVLEdBQzNCQyxVQUFTLEtBQUs7QUFFbEIsaUJBQU8sUUFBUSxRQUFRO0FBQ25CLGdCQUFJLEtBQUssUUFBUTtBQUNiLG1CQUFLLFNBQVM7QUFDZCxjQUFBQSxRQUFPLENBQUMsSUFBSSxLQUFLO0FBQ2pCLGNBQUFBLFFBQU8sRUFBRSxJQUNMQSxRQUFPLENBQUMsSUFDUkEsUUFBTyxDQUFDLElBQ1JBLFFBQU8sQ0FBQyxJQUNSQSxRQUFPLENBQUMsSUFDUkEsUUFBTyxDQUFDLElBQ1JBLFFBQU8sQ0FBQyxJQUNSQSxRQUFPLENBQUMsSUFDUkEsUUFBTyxDQUFDLElBQ1JBLFFBQU8sQ0FBQyxJQUNSQSxRQUFPLEVBQUUsSUFDVEEsUUFBTyxFQUFFLElBQ1RBLFFBQU8sRUFBRSxJQUNUQSxRQUFPLEVBQUUsSUFDVEEsUUFBTyxFQUFFLElBQ1RBLFFBQU8sRUFBRSxJQUNMO0FBQUEsWUFDWjtBQUVBLGdCQUFJLFdBQVc7QUFDWCxtQkFBSyxJQUFJLEtBQUssT0FBTyxRQUFRLFVBQVUsSUFBSSxJQUFJLEVBQUUsT0FBTztBQUNwRCxnQkFBQUEsUUFBTyxLQUFLLENBQUMsS0FBSyxRQUFRLEtBQUssS0FBSyxNQUFNLE1BQU0sQ0FBQztBQUFBLGNBQ3JEO0FBQUEsWUFDSixPQUFPO0FBQ0gsbUJBQUssSUFBSSxLQUFLLE9BQU8sUUFBUSxVQUFVLElBQUksSUFBSSxFQUFFLE9BQU87QUFDcEQsdUJBQU8sUUFBUSxXQUFXLEtBQUs7QUFDL0Isb0JBQUksT0FBTyxLQUFNO0FBQ2Isa0JBQUFBLFFBQU8sS0FBSyxDQUFDLEtBQUssUUFBUSxNQUFNLE1BQU0sQ0FBQztBQUFBLGdCQUMzQyxXQUFXLE9BQU8sTUFBTztBQUNyQixrQkFBQUEsUUFBTyxLQUFLLENBQUMsTUFBTSxNQUFRLFFBQVEsTUFBTyxNQUFNLE1BQU0sQ0FBQztBQUN2RCxrQkFBQUEsUUFBTyxLQUFLLENBQUMsTUFBTSxNQUFRLE9BQU8sT0FBVSxNQUFNLE1BQU0sQ0FBQztBQUFBLGdCQUM3RCxXQUFXLE9BQU8sU0FBVSxRQUFRLE9BQVE7QUFDeEMsa0JBQUFBLFFBQU8sS0FBSyxDQUFDLE1BQU0sTUFBUSxRQUFRLE9BQVEsTUFBTSxNQUFNLENBQUM7QUFDeEQsa0JBQUFBLFFBQU8sS0FBSyxDQUFDLE1BQU0sTUFBUyxRQUFRLElBQUssT0FBVSxNQUFNLE1BQU0sQ0FBQztBQUNoRSxrQkFBQUEsUUFBTyxLQUFLLENBQUMsTUFBTSxNQUFRLE9BQU8sT0FBVSxNQUFNLE1BQU0sQ0FBQztBQUFBLGdCQUM3RCxPQUFPO0FBQ0gseUJBQU8sVUFBYSxPQUFPLFNBQVUsS0FBTyxRQUFRLFdBQVcsRUFBRSxLQUFLLElBQUk7QUFDMUUsa0JBQUFBLFFBQU8sS0FBSyxDQUFDLE1BQU0sTUFBUSxRQUFRLE9BQVEsTUFBTSxNQUFNLENBQUM7QUFDeEQsa0JBQUFBLFFBQU8sS0FBSyxDQUFDLE1BQU0sTUFBUyxRQUFRLEtBQU0sT0FBVSxNQUFNLE1BQU0sQ0FBQztBQUNqRSxrQkFBQUEsUUFBTyxLQUFLLENBQUMsTUFBTSxNQUFTLFFBQVEsSUFBSyxPQUFVLE1BQU0sTUFBTSxDQUFDO0FBQ2hFLGtCQUFBQSxRQUFPLEtBQUssQ0FBQyxNQUFNLE1BQVEsT0FBTyxPQUFVLE1BQU0sTUFBTSxDQUFDO0FBQUEsZ0JBQzdEO0FBQUEsY0FDSjtBQUFBLFlBQ0o7QUFFQSxpQkFBSyxnQkFBZ0I7QUFDckIsaUJBQUssU0FBUyxJQUFJLEtBQUs7QUFDdkIsZ0JBQUksS0FBSyxJQUFJO0FBQ1QsbUJBQUssUUFBUUEsUUFBTyxFQUFFO0FBQ3RCLG1CQUFLLFFBQVEsSUFBSTtBQUNqQixtQkFBSyxLQUFLO0FBQ1YsbUJBQUssU0FBUztBQUFBLFlBQ2xCLE9BQU87QUFDSCxtQkFBSyxRQUFRO0FBQUEsWUFDakI7QUFBQSxVQUNKO0FBQ0EsY0FBSSxLQUFLLFFBQVEsWUFBWTtBQUN6QixpQkFBSyxVQUFXLEtBQUssUUFBUSxjQUFlO0FBQzVDLGlCQUFLLFFBQVEsS0FBSyxRQUFRO0FBQUEsVUFDOUI7QUFDQSxpQkFBTztBQUFBLFFBQ1g7QUFFQSxhQUFLLFVBQVUsV0FBVyxXQUFZO0FBQ2xDLGNBQUksS0FBSyxXQUFXO0FBQ2hCO0FBQUEsVUFDSjtBQUNBLGVBQUssWUFBWTtBQUNqQixjQUFJQSxVQUFTLEtBQUssUUFDZCxJQUFJLEtBQUs7QUFDYixVQUFBQSxRQUFPLEVBQUUsSUFBSSxLQUFLO0FBQ2xCLFVBQUFBLFFBQU8sS0FBSyxDQUFDLEtBQUssTUFBTSxJQUFJLENBQUM7QUFDN0IsZUFBSyxRQUFRQSxRQUFPLEVBQUU7QUFDdEIsY0FBSSxLQUFLLElBQUk7QUFDVCxnQkFBSSxDQUFDLEtBQUssUUFBUTtBQUNkLG1CQUFLLEtBQUs7QUFBQSxZQUNkO0FBQ0EsWUFBQUEsUUFBTyxDQUFDLElBQUksS0FBSztBQUNqQixZQUFBQSxRQUFPLEVBQUUsSUFDTEEsUUFBTyxDQUFDLElBQ1JBLFFBQU8sQ0FBQyxJQUNSQSxRQUFPLENBQUMsSUFDUkEsUUFBTyxDQUFDLElBQ1JBLFFBQU8sQ0FBQyxJQUNSQSxRQUFPLENBQUMsSUFDUkEsUUFBTyxDQUFDLElBQ1JBLFFBQU8sQ0FBQyxJQUNSQSxRQUFPLENBQUMsSUFDUkEsUUFBTyxFQUFFLElBQ1RBLFFBQU8sRUFBRSxJQUNUQSxRQUFPLEVBQUUsSUFDVEEsUUFBTyxFQUFFLElBQ1RBLFFBQU8sRUFBRSxJQUNUQSxRQUFPLEVBQUUsSUFDTDtBQUFBLFVBQ1o7QUFDQSxVQUFBQSxRQUFPLEVBQUUsSUFBSyxLQUFLLFVBQVUsSUFBTSxLQUFLLFVBQVU7QUFDbEQsVUFBQUEsUUFBTyxFQUFFLElBQUksS0FBSyxTQUFTO0FBQzNCLGVBQUssS0FBSztBQUFBLFFBQ2Q7QUFFQSxhQUFLLFVBQVUsT0FBTyxXQUFZO0FBQzlCLGNBQUksSUFBSSxLQUFLLElBQ1QsSUFBSSxLQUFLLElBQ1QsSUFBSSxLQUFLLElBQ1QsSUFBSSxLQUFLLElBQ1QsSUFBSSxLQUFLO0FBQ2IsY0FBSSxHQUNBLEdBQ0EsR0FDQUEsVUFBUyxLQUFLO0FBRWxCLGVBQUssSUFBSSxJQUFJLElBQUksSUFBSSxFQUFFLEdBQUc7QUFDdEIsZ0JBQUlBLFFBQU8sSUFBSSxDQUFDLElBQUlBLFFBQU8sSUFBSSxDQUFDLElBQUlBLFFBQU8sSUFBSSxFQUFFLElBQUlBLFFBQU8sSUFBSSxFQUFFO0FBQ2xFLFlBQUFBLFFBQU8sQ0FBQyxJQUFLLEtBQUssSUFBTSxNQUFNO0FBQUEsVUFDbEM7QUFFQSxlQUFLLElBQUksR0FBRyxJQUFJLElBQUksS0FBSyxHQUFHO0FBQ3hCLGdCQUFLLElBQUksSUFBTSxDQUFDLElBQUk7QUFDcEIsZ0JBQUssS0FBSyxJQUFNLE1BQU07QUFDdEIsZ0JBQUssSUFBSSxJQUFJLElBQUksYUFBYUEsUUFBTyxDQUFDLEtBQU07QUFDNUMsZ0JBQUssS0FBSyxLQUFPLE1BQU07QUFFdkIsZ0JBQUssSUFBSSxJQUFNLENBQUMsSUFBSTtBQUNwQixnQkFBSyxLQUFLLElBQU0sTUFBTTtBQUN0QixnQkFBSyxJQUFJLElBQUksSUFBSSxhQUFhQSxRQUFPLElBQUksQ0FBQyxLQUFNO0FBQ2hELGdCQUFLLEtBQUssS0FBTyxNQUFNO0FBRXZCLGdCQUFLLElBQUksSUFBTSxDQUFDLElBQUk7QUFDcEIsZ0JBQUssS0FBSyxJQUFNLE1BQU07QUFDdEIsZ0JBQUssSUFBSSxJQUFJLElBQUksYUFBYUEsUUFBTyxJQUFJLENBQUMsS0FBTTtBQUNoRCxnQkFBSyxLQUFLLEtBQU8sTUFBTTtBQUV2QixnQkFBSyxJQUFJLElBQU0sQ0FBQyxJQUFJO0FBQ3BCLGdCQUFLLEtBQUssSUFBTSxNQUFNO0FBQ3RCLGdCQUFLLElBQUksSUFBSSxJQUFJLGFBQWFBLFFBQU8sSUFBSSxDQUFDLEtBQU07QUFDaEQsZ0JBQUssS0FBSyxLQUFPLE1BQU07QUFFdkIsZ0JBQUssSUFBSSxJQUFNLENBQUMsSUFBSTtBQUNwQixnQkFBSyxLQUFLLElBQU0sTUFBTTtBQUN0QixnQkFBSyxJQUFJLElBQUksSUFBSSxhQUFhQSxRQUFPLElBQUksQ0FBQyxLQUFNO0FBQ2hELGdCQUFLLEtBQUssS0FBTyxNQUFNO0FBQUEsVUFDM0I7QUFFQSxpQkFBTyxJQUFJLElBQUksS0FBSyxHQUFHO0FBQ25CLGdCQUFJLElBQUksSUFBSTtBQUNaLGdCQUFLLEtBQUssSUFBTSxNQUFNO0FBQ3RCLGdCQUFLLElBQUksSUFBSSxJQUFJLGFBQWFBLFFBQU8sQ0FBQyxLQUFNO0FBQzVDLGdCQUFLLEtBQUssS0FBTyxNQUFNO0FBRXZCLGdCQUFJLElBQUksSUFBSTtBQUNaLGdCQUFLLEtBQUssSUFBTSxNQUFNO0FBQ3RCLGdCQUFLLElBQUksSUFBSSxJQUFJLGFBQWFBLFFBQU8sSUFBSSxDQUFDLEtBQU07QUFDaEQsZ0JBQUssS0FBSyxLQUFPLE1BQU07QUFFdkIsZ0JBQUksSUFBSSxJQUFJO0FBQ1osZ0JBQUssS0FBSyxJQUFNLE1BQU07QUFDdEIsZ0JBQUssSUFBSSxJQUFJLElBQUksYUFBYUEsUUFBTyxJQUFJLENBQUMsS0FBTTtBQUNoRCxnQkFBSyxLQUFLLEtBQU8sTUFBTTtBQUV2QixnQkFBSSxJQUFJLElBQUk7QUFDWixnQkFBSyxLQUFLLElBQU0sTUFBTTtBQUN0QixnQkFBSyxJQUFJLElBQUksSUFBSSxhQUFhQSxRQUFPLElBQUksQ0FBQyxLQUFNO0FBQ2hELGdCQUFLLEtBQUssS0FBTyxNQUFNO0FBRXZCLGdCQUFJLElBQUksSUFBSTtBQUNaLGdCQUFLLEtBQUssSUFBTSxNQUFNO0FBQ3RCLGdCQUFLLElBQUksSUFBSSxJQUFJLGFBQWFBLFFBQU8sSUFBSSxDQUFDLEtBQU07QUFDaEQsZ0JBQUssS0FBSyxLQUFPLE1BQU07QUFBQSxVQUMzQjtBQUVBLGlCQUFPLElBQUksSUFBSSxLQUFLLEdBQUc7QUFDbkIsZ0JBQUssSUFBSSxJQUFNLElBQUksSUFBTSxJQUFJO0FBQzdCLGdCQUFLLEtBQUssSUFBTSxNQUFNO0FBQ3RCLGdCQUFLLElBQUksSUFBSSxJQUFJLGFBQWFBLFFBQU8sQ0FBQyxLQUFNO0FBQzVDLGdCQUFLLEtBQUssS0FBTyxNQUFNO0FBRXZCLGdCQUFLLElBQUksSUFBTSxJQUFJLElBQU0sSUFBSTtBQUM3QixnQkFBSyxLQUFLLElBQU0sTUFBTTtBQUN0QixnQkFBSyxJQUFJLElBQUksSUFBSSxhQUFhQSxRQUFPLElBQUksQ0FBQyxLQUFNO0FBQ2hELGdCQUFLLEtBQUssS0FBTyxNQUFNO0FBRXZCLGdCQUFLLElBQUksSUFBTSxJQUFJLElBQU0sSUFBSTtBQUM3QixnQkFBSyxLQUFLLElBQU0sTUFBTTtBQUN0QixnQkFBSyxJQUFJLElBQUksSUFBSSxhQUFhQSxRQUFPLElBQUksQ0FBQyxLQUFNO0FBQ2hELGdCQUFLLEtBQUssS0FBTyxNQUFNO0FBRXZCLGdCQUFLLElBQUksSUFBTSxJQUFJLElBQU0sSUFBSTtBQUM3QixnQkFBSyxLQUFLLElBQU0sTUFBTTtBQUN0QixnQkFBSyxJQUFJLElBQUksSUFBSSxhQUFhQSxRQUFPLElBQUksQ0FBQyxLQUFNO0FBQ2hELGdCQUFLLEtBQUssS0FBTyxNQUFNO0FBRXZCLGdCQUFLLElBQUksSUFBTSxJQUFJLElBQU0sSUFBSTtBQUM3QixnQkFBSyxLQUFLLElBQU0sTUFBTTtBQUN0QixnQkFBSyxJQUFJLElBQUksSUFBSSxhQUFhQSxRQUFPLElBQUksQ0FBQyxLQUFNO0FBQ2hELGdCQUFLLEtBQUssS0FBTyxNQUFNO0FBQUEsVUFDM0I7QUFFQSxpQkFBTyxJQUFJLElBQUksS0FBSyxHQUFHO0FBQ25CLGdCQUFJLElBQUksSUFBSTtBQUNaLGdCQUFLLEtBQUssSUFBTSxNQUFNO0FBQ3RCLGdCQUFLLElBQUksSUFBSSxJQUFJLFlBQVlBLFFBQU8sQ0FBQyxLQUFNO0FBQzNDLGdCQUFLLEtBQUssS0FBTyxNQUFNO0FBRXZCLGdCQUFJLElBQUksSUFBSTtBQUNaLGdCQUFLLEtBQUssSUFBTSxNQUFNO0FBQ3RCLGdCQUFLLElBQUksSUFBSSxJQUFJLFlBQVlBLFFBQU8sSUFBSSxDQUFDLEtBQU07QUFDL0MsZ0JBQUssS0FBSyxLQUFPLE1BQU07QUFFdkIsZ0JBQUksSUFBSSxJQUFJO0FBQ1osZ0JBQUssS0FBSyxJQUFNLE1BQU07QUFDdEIsZ0JBQUssSUFBSSxJQUFJLElBQUksWUFBWUEsUUFBTyxJQUFJLENBQUMsS0FBTTtBQUMvQyxnQkFBSyxLQUFLLEtBQU8sTUFBTTtBQUV2QixnQkFBSSxJQUFJLElBQUk7QUFDWixnQkFBSyxLQUFLLElBQU0sTUFBTTtBQUN0QixnQkFBSyxJQUFJLElBQUksSUFBSSxZQUFZQSxRQUFPLElBQUksQ0FBQyxLQUFNO0FBQy9DLGdCQUFLLEtBQUssS0FBTyxNQUFNO0FBRXZCLGdCQUFJLElBQUksSUFBSTtBQUNaLGdCQUFLLEtBQUssSUFBTSxNQUFNO0FBQ3RCLGdCQUFLLElBQUksSUFBSSxJQUFJLFlBQVlBLFFBQU8sSUFBSSxDQUFDLEtBQU07QUFDL0MsZ0JBQUssS0FBSyxLQUFPLE1BQU07QUFBQSxVQUMzQjtBQUVBLGVBQUssS0FBTSxLQUFLLEtBQUssS0FBTTtBQUMzQixlQUFLLEtBQU0sS0FBSyxLQUFLLEtBQU07QUFDM0IsZUFBSyxLQUFNLEtBQUssS0FBSyxLQUFNO0FBQzNCLGVBQUssS0FBTSxLQUFLLEtBQUssS0FBTTtBQUMzQixlQUFLLEtBQU0sS0FBSyxLQUFLLEtBQU07QUFBQSxRQUMvQjtBQUVBLGFBQUssVUFBVSxNQUFNLFdBQVk7QUFDN0IsZUFBSyxTQUFTO0FBRWQsY0FBSSxLQUFLLEtBQUssSUFDVixLQUFLLEtBQUssSUFDVixLQUFLLEtBQUssSUFDVixLQUFLLEtBQUssSUFDVixLQUFLLEtBQUs7QUFFZCxpQkFDSSxVQUFXLE1BQU0sS0FBTSxFQUFJLElBQzNCLFVBQVcsTUFBTSxLQUFNLEVBQUksSUFDM0IsVUFBVyxNQUFNLEtBQU0sRUFBSSxJQUMzQixVQUFXLE1BQU0sS0FBTSxFQUFJLElBQzNCLFVBQVcsTUFBTSxLQUFNLEVBQUksSUFDM0IsVUFBVyxNQUFNLElBQUssRUFBSSxJQUMxQixVQUFXLE1BQU0sSUFBSyxFQUFJLElBQzFCLFVBQVUsS0FBSyxFQUFJLElBQ25CLFVBQVcsTUFBTSxLQUFNLEVBQUksSUFDM0IsVUFBVyxNQUFNLEtBQU0sRUFBSSxJQUMzQixVQUFXLE1BQU0sS0FBTSxFQUFJLElBQzNCLFVBQVcsTUFBTSxLQUFNLEVBQUksSUFDM0IsVUFBVyxNQUFNLEtBQU0sRUFBSSxJQUMzQixVQUFXLE1BQU0sSUFBSyxFQUFJLElBQzFCLFVBQVcsTUFBTSxJQUFLLEVBQUksSUFDMUIsVUFBVSxLQUFLLEVBQUksSUFDbkIsVUFBVyxNQUFNLEtBQU0sRUFBSSxJQUMzQixVQUFXLE1BQU0sS0FBTSxFQUFJLElBQzNCLFVBQVcsTUFBTSxLQUFNLEVBQUksSUFDM0IsVUFBVyxNQUFNLEtBQU0sRUFBSSxJQUMzQixVQUFXLE1BQU0sS0FBTSxFQUFJLElBQzNCLFVBQVcsTUFBTSxJQUFLLEVBQUksSUFDMUIsVUFBVyxNQUFNLElBQUssRUFBSSxJQUMxQixVQUFVLEtBQUssRUFBSSxJQUNuQixVQUFXLE1BQU0sS0FBTSxFQUFJLElBQzNCLFVBQVcsTUFBTSxLQUFNLEVBQUksSUFDM0IsVUFBVyxNQUFNLEtBQU0sRUFBSSxJQUMzQixVQUFXLE1BQU0sS0FBTSxFQUFJLElBQzNCLFVBQVcsTUFBTSxLQUFNLEVBQUksSUFDM0IsVUFBVyxNQUFNLElBQUssRUFBSSxJQUMxQixVQUFXLE1BQU0sSUFBSyxFQUFJLElBQzFCLFVBQVUsS0FBSyxFQUFJLElBQ25CLFVBQVcsTUFBTSxLQUFNLEVBQUksSUFDM0IsVUFBVyxNQUFNLEtBQU0sRUFBSSxJQUMzQixVQUFXLE1BQU0sS0FBTSxFQUFJLElBQzNCLFVBQVcsTUFBTSxLQUFNLEVBQUksSUFDM0IsVUFBVyxNQUFNLEtBQU0sRUFBSSxJQUMzQixVQUFXLE1BQU0sSUFBSyxFQUFJLElBQzFCLFVBQVcsTUFBTSxJQUFLLEVBQUksSUFDMUIsVUFBVSxLQUFLLEVBQUk7QUFBQSxRQUUzQjtBQUVBLGFBQUssVUFBVSxXQUFXLEtBQUssVUFBVTtBQUV6QyxhQUFLLFVBQVUsU0FBUyxXQUFZO0FBQ2hDLGVBQUssU0FBUztBQUVkLGNBQUksS0FBSyxLQUFLLElBQ1YsS0FBSyxLQUFLLElBQ1YsS0FBSyxLQUFLLElBQ1YsS0FBSyxLQUFLLElBQ1YsS0FBSyxLQUFLO0FBRWQsaUJBQU87QUFBQSxZQUNGLE1BQU0sS0FBTTtBQUFBLFlBQ1osTUFBTSxLQUFNO0FBQUEsWUFDWixNQUFNLElBQUs7QUFBQSxZQUNaLEtBQUs7QUFBQSxZQUNKLE1BQU0sS0FBTTtBQUFBLFlBQ1osTUFBTSxLQUFNO0FBQUEsWUFDWixNQUFNLElBQUs7QUFBQSxZQUNaLEtBQUs7QUFBQSxZQUNKLE1BQU0sS0FBTTtBQUFBLFlBQ1osTUFBTSxLQUFNO0FBQUEsWUFDWixNQUFNLElBQUs7QUFBQSxZQUNaLEtBQUs7QUFBQSxZQUNKLE1BQU0sS0FBTTtBQUFBLFlBQ1osTUFBTSxLQUFNO0FBQUEsWUFDWixNQUFNLElBQUs7QUFBQSxZQUNaLEtBQUs7QUFBQSxZQUNKLE1BQU0sS0FBTTtBQUFBLFlBQ1osTUFBTSxLQUFNO0FBQUEsWUFDWixNQUFNLElBQUs7QUFBQSxZQUNaLEtBQUs7QUFBQSxVQUNUO0FBQUEsUUFDSjtBQUVBLGFBQUssVUFBVSxRQUFRLEtBQUssVUFBVTtBQUV0QyxhQUFLLFVBQVUsY0FBYyxXQUFZO0FBQ3JDLGVBQUssU0FBUztBQUVkLGNBQUksU0FBUyxJQUFJLFlBQVksRUFBRTtBQUMvQixjQUFJLFdBQVcsSUFBSSxTQUFTLE1BQU07QUFDbEMsbUJBQVMsVUFBVSxHQUFHLEtBQUssRUFBRTtBQUM3QixtQkFBUyxVQUFVLEdBQUcsS0FBSyxFQUFFO0FBQzdCLG1CQUFTLFVBQVUsR0FBRyxLQUFLLEVBQUU7QUFDN0IsbUJBQVMsVUFBVSxJQUFJLEtBQUssRUFBRTtBQUM5QixtQkFBUyxVQUFVLElBQUksS0FBSyxFQUFFO0FBQzlCLGlCQUFPO0FBQUEsUUFDWDtBQUVBLFlBQUksVUFBVSxhQUFhO0FBRTNCLFlBQUksV0FBVztBQUNYLGlCQUFPLFVBQVU7QUFBQSxRQUNyQixPQUFPO0FBQ0gsZUFBSyxPQUFPO0FBQ1osY0FBSSxLQUFLO0FBQ0wsbUJBQU8sV0FBWTtBQUNmLHFCQUFPO0FBQUEsWUFDWCxDQUFDO0FBQUEsVUFDTDtBQUFBLFFBQ0o7QUFBQSxNQUNKLEdBQUc7QUFBQTtBQUFBOzs7QUMvYkgsTUFBQUMsZ0NBQW9COzs7QUNicEIsTUFBSSxTQUFTLE1BQU1DLFFBQU87QUFBQSxJQUN4QixPQUFPLFFBQVEsTUFBTTtBQUNuQixNQUFBQSxRQUFPLE9BQU87QUFBQSxJQUNoQjtBQUFBLElBQ0EsT0FBTyxZQUFZLFNBQVMsU0FBUyxNQUFNLFdBQVcsT0FBTztBQUMzRCxVQUFJLGtCQUFrQjtBQUN0QixVQUFJLFVBQVUsTUFBTTtBQUNsQiwwQkFBa0IsTUFBTSxLQUFLLE9BQU8saUJBQWlCLFFBQVEsUUFBUSxDQUFDO0FBQUEsTUFDeEUsT0FBTztBQUNMLFlBQUlBLFFBQU8sUUFBUSxNQUFNO0FBQ3ZCLDRCQUFrQixNQUFNO0FBQUEsWUFDdEJBLFFBQU8sS0FBSyxpQkFBaUIsUUFBUSxRQUFRO0FBQUEsVUFDL0M7QUFBQSxRQUNGLE9BQU87QUFDTCw0QkFBa0IsTUFBTTtBQUFBLFlBQ3RCLFNBQVMsaUJBQWlCLFFBQVEsUUFBUTtBQUFBLFVBQzVDO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFDQSxVQUFJLFFBQVEsY0FBYyxNQUFNO0FBQzlCLDBCQUFrQixnQkFBZ0IsT0FBTyxDQUFDLG1CQUFtQjtBQUMzRCxnQkFBTSxjQUFjLGVBQWUsWUFBWSxZQUFZO0FBQzNELGNBQUksTUFBTSxRQUFRLFFBQVEsVUFBVSxHQUFHO0FBQ3JDLGdCQUFJLFlBQVk7QUFDaEIsdUJBQVcsUUFBUSxRQUFRLFlBQVk7QUFDckMsa0JBQUksWUFBWSxRQUFRLEtBQUssWUFBWSxDQUFDLE1BQU0sSUFBSTtBQUNsRCw0QkFBWTtBQUNaO0FBQUEsY0FDRjtBQUFBLFlBQ0Y7QUFDQSxtQkFBTztBQUFBLFVBQ1QsV0FBVyxRQUFRLGNBQWMsTUFBTTtBQUNyQyxtQkFBTyxZQUFZLFFBQVEsUUFBUSxXQUFXLFlBQVksQ0FBQyxNQUFNO0FBQUEsVUFDbkU7QUFDQSxpQkFBTztBQUFBLFFBQ1QsQ0FBQztBQUFBLE1BQ0g7QUFDQSxVQUFJLFFBQVEsZ0JBQWdCLE1BQU07QUFDaEMsMEJBQWtCLGdCQUFnQixPQUFPLENBQUMsbUJBQW1CO0FBQzNELGdCQUFNLFNBQVMsT0FBTyxpQkFBaUIsY0FBYztBQUNyRCxjQUFJLE9BQU87QUFDWCxxQkFBVyxlQUFlLFFBQVEsY0FBYztBQUM5QyxrQkFBTSxTQUFTLE9BQU8sWUFBWSxNQUFNO0FBQ3hDLGdCQUFJLFlBQVksU0FBUztBQUN2QixxQkFBTyxRQUFRLFdBQVcsWUFBWTtBQUFBLFlBQ3hDLE9BQU87QUFDTCxxQkFBTyxRQUFRLFdBQVcsWUFBWTtBQUFBLFlBQ3hDO0FBQUEsVUFDRjtBQUNBLGlCQUFPO0FBQUEsUUFDVCxDQUFDO0FBQUEsTUFDSDtBQUNBLFVBQUksUUFBUSxpQkFBaUIsTUFBTTtBQUNqQywwQkFBa0IsZ0JBQWdCLE9BQU8sQ0FBQyxtQkFBbUI7QUFDM0QsY0FBSSxRQUFRLGVBQWU7QUFDekIsbUJBQU8sZUFBZSxpQkFBaUI7QUFBQSxVQUN6QyxPQUFPO0FBQ0wsbUJBQU8sZUFBZSxpQkFBaUI7QUFBQSxVQUN6QztBQUFBLFFBQ0YsQ0FBQztBQUFBLE1BQ0g7QUFDQSxVQUFJLFFBQVEsZ0JBQWdCLE1BQU07QUFDaEMsMEJBQWtCLGdCQUFnQixPQUFPLE1BQU07QUFDN0MsY0FBSSxRQUFRLGNBQWM7QUFDeEIsbUJBQU8sT0FBTyxhQUFhLE9BQU8sT0FBTztBQUFBLFVBQzNDLE9BQU87QUFDTCxtQkFBTyxPQUFPLGFBQWEsT0FBTyxPQUFPO0FBQUEsVUFDM0M7QUFBQSxRQUNGLENBQUM7QUFBQSxNQUNIO0FBQ0EsVUFBSSxRQUFRLGVBQWUsTUFBTTtBQUMvQiwwQkFBa0IsZ0JBQWdCLE9BQU8sQ0FBQyxtQkFBbUI7QUFDM0QsZ0JBQU0sVUFBVUEsUUFBTztBQUN2QixVQUFBQSxRQUFPLFFBQVEsY0FBYztBQUM3QixnQkFBTSxlQUFlQSxRQUFPLEtBQUssUUFBUSxXQUFXO0FBQ3BELFVBQUFBLFFBQU8sUUFBUSxPQUFPO0FBQ3RCLGlCQUFPLGFBQWEsVUFBVTtBQUFBLFFBQ2hDLENBQUM7QUFBQSxNQUNIO0FBQ0EsVUFBSSxVQUFVO0FBQ1osZUFBTztBQUFBLE1BQ1QsT0FBTztBQUNMLFlBQUksZ0JBQWdCLFNBQVMsR0FBRztBQUM5QixrQkFBUTtBQUFBLFlBQ047QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUNBLGVBQU8sZ0JBQWdCLENBQUM7QUFBQSxNQUMxQjtBQUFBLElBQ0Y7QUFBQSxJQUNBLE9BQU8sS0FBSyxTQUFTLFdBQVcsT0FBTztBQUNyQyxZQUFNLFVBQVUsQ0FBQztBQUNqQixVQUFJLFFBQVEsVUFBVSxNQUFNO0FBQzFCLGNBQU0sU0FBU0EsUUFBTyxZQUFZLFFBQVEsUUFBUSxNQUFNLFFBQVE7QUFDaEUsWUFBSSxVQUFVLE1BQU07QUFDbEIsY0FBSSxrQkFBa0IsT0FBTztBQUMzQixtQkFBTyxRQUFRLENBQUMsTUFBTTtBQUNwQixvQkFBTSxVQUFVQSxRQUFPLFlBQVksUUFBUSxRQUFRLEdBQUcsUUFBUTtBQUM5RCxrQkFBSSxtQkFBbUIsT0FBTztBQUM1Qix3QkFBUSxRQUFRLENBQUMsV0FBVztBQUMxQiwwQkFBUSxLQUFLO0FBQUEsb0JBQ1gsUUFBUTtBQUFBLG9CQUNSO0FBQUEsa0JBQ0YsQ0FBQztBQUFBLGdCQUNILENBQUM7QUFBQSxjQUNILE9BQU87QUFDTCx3QkFBUSxLQUFLO0FBQUEsa0JBQ1gsUUFBUTtBQUFBLGtCQUNSLFFBQVE7QUFBQSxnQkFDVixDQUFDO0FBQUEsY0FDSDtBQUFBLFlBQ0YsQ0FBQztBQUNELG1CQUFPO0FBQUEsVUFDVCxPQUFPO0FBQ0wsa0JBQU0sVUFBVUEsUUFBTyxZQUFZLFFBQVEsUUFBUSxRQUFRLFFBQVE7QUFDbkUsZ0JBQUksbUJBQW1CLE9BQU87QUFDNUIsc0JBQVEsUUFBUSxDQUFDLFdBQVc7QUFDMUIsd0JBQVEsS0FBSztBQUFBLGtCQUNYO0FBQUEsa0JBQ0E7QUFBQSxnQkFDRixDQUFDO0FBQUEsY0FDSCxDQUFDO0FBQUEsWUFDSCxPQUFPO0FBQ0wsc0JBQVEsS0FBSztBQUFBLGdCQUNYO0FBQUEsZ0JBQ0EsUUFBUTtBQUFBLGNBQ1YsQ0FBQztBQUFBLFlBQ0g7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUFBLE1BQ0YsT0FBTztBQUNMLGNBQU0sVUFBVUEsUUFBTyxZQUFZLFFBQVEsUUFBUSxNQUFNLFFBQVE7QUFDakUsWUFBSSxtQkFBbUIsT0FBTztBQUM1QixrQkFBUSxRQUFRLENBQUMsV0FBVztBQUMxQixvQkFBUSxLQUFLO0FBQUEsY0FDWCxRQUFRO0FBQUEsY0FDUjtBQUFBLFlBQ0YsQ0FBQztBQUFBLFVBQ0gsQ0FBQztBQUFBLFFBQ0gsT0FBTztBQUNMLGtCQUFRLEtBQUs7QUFBQSxZQUNYLFFBQVE7QUFBQSxZQUNSLFFBQVE7QUFBQSxVQUNWLENBQUM7QUFBQSxRQUNIO0FBQUEsTUFDRjtBQUNBLFVBQUksUUFBUSxXQUFXLEdBQUc7QUFDeEIsZ0JBQVEsS0FBSztBQUFBLFVBQ1gsUUFBUTtBQUFBLFVBQ1IsUUFBUTtBQUFBLFFBQ1YsQ0FBQztBQUFBLE1BQ0g7QUFDQSxVQUFJLFVBQVU7QUFDWixlQUFPO0FBQUEsTUFDVCxPQUFPO0FBQ0wsWUFBSSxRQUFRLFdBQVcsR0FBRztBQUN4QixrQkFBUTtBQUFBLFlBQ047QUFBQSxZQUNBO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFDQSxlQUFPLFFBQVEsQ0FBQztBQUFBLE1BQ2xCO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDQSxTQUFPLE9BQU87QUF1UmQsTUFBSSxXQUFXO0FBQUE7QUFBQSxJQUViLFFBQVEsTUFBTSxRQUFRLElBQUksQ0FBQztBQUFBLElBQzNCLHVCQUF1QixNQUFNLE9BQU8sU0FBUyxPQUFPLE1BQU0sWUFBWSxNQUFNO0FBQUEsSUFDNUUsdUJBQXVCLE1BQU0sQ0FBQyxNQUFNLGVBQWUsRUFBRTtBQUFBLElBQ3JELHVCQUF1QixNQUFNLE1BQU0sY0FBYyxDQUFDO0FBQUEsSUFDbEQsdUJBQXVCLE1BQU0sTUFBTSxjQUFjLENBQUM7QUFBQSxJQUNsRCx1QkFBdUIsTUFBTSxNQUFNLGVBQWUsRUFBRTtBQUFBLElBQ3BELGtCQUFrQixNQUFNLENBQUMsQ0FBQyxPQUFPO0FBQUEsSUFDakMsa0JBQWtCLE1BQU0sQ0FBQyxPQUFPLFVBQVUsZUFBZSxPQUFPLFVBQVUsUUFBUSxZQUFZO0FBQUEsSUFDOUYsa0JBQWtCLE1BQU0sT0FBTyxVQUFVLFNBQVMsS0FBSztBQUFBLElBQ3ZELGtCQUFrQixNQUFNLE9BQU8sVUFBVSxLQUFLLEtBQUs7QUFBQSxJQUNuRCxrQkFBa0IsTUFBTSxPQUFPLFVBQVUsYUFBYTtBQUFBLElBQ3RELGNBQWMsTUFBTTtBQUNsQixZQUFNLFNBQVMsV0FBVyxlQUFlLFdBQVcsT0FBTyxjQUFjLFdBQVcsTUFBTSxXQUFXLEVBQUU7QUFDdkcsVUFBSSxDQUFDLFFBQVE7QUFDWCxlQUFPO0FBQUEsTUFDVDtBQUNBLFlBQU0sb0JBQW9CLE9BQU8sWUFBWSxPQUFPLE1BQU0sT0FBTyxDQUFDLE1BQU0sQ0FBQyxFQUFFLFFBQVEsRUFBRSxJQUFJLENBQUMsTUFBTSxFQUFFLElBQUk7QUFDdEcsVUFBSSxTQUFTLE1BQU0sWUFBWTtBQUM3QixjQUFNLFVBQVUsTUFBTSxXQUFXO0FBQ2pDLGVBQU8saUJBQWlCLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxTQUFTLElBQUksQ0FBQztBQUFBLE1BQ2pFLFdBQVcsZUFBZSxZQUFZLGtCQUFrQixVQUFVO0FBQ2hFLGNBQU0sYUFBYSxZQUFZLGNBQWMsWUFBWTtBQUN6RCxjQUFNLFdBQVcsS0FBSztBQUFBLFVBQ3BCO0FBQUEsWUFDRSxTQUFTLE9BQU8sTUFBTSxHQUFHLEVBQUUsS0FBSyxDQUFDLE1BQU0sRUFBRSxLQUFLLEVBQUUsV0FBVyxVQUFVLENBQUMsRUFBRSxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsVUFDdEY7QUFBQSxRQUNGO0FBQ0EsZUFBTyxPQUFPLEtBQUssUUFBUSxFQUFFLE9BQU8sQ0FBQyxNQUFNLGlCQUFpQixTQUFTLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxNQUFNLFNBQVMsQ0FBQyxNQUFNLEtBQUs7QUFBQSxNQUM3RztBQUFBLElBQ0Y7QUFBQSxJQUNBLHVCQUF1QixNQUFNO0FBQzNCLFlBQU0sS0FBSyxRQUFRLElBQUk7QUFBQSxJQUN6QjtBQUFBLElBQ0EsNEJBQTRCLE1BQU07QUFDaEMsVUFBSSxPQUFPLFNBQVMsT0FBTyxNQUFNLFNBQVMsY0FBYyxPQUFPLE1BQU0sZUFBZSxZQUFZO0FBQzlGLFlBQUk7QUFDRixnQkFBTSxXQUFXLEVBQUUsVUFBVSxLQUFLO0FBQ2xDLGdCQUFNLFdBQVcsRUFBRSxxQkFBcUI7QUFDeEMsaUJBQU87QUFBQSxRQUNULFNBQVMsR0FBRztBQUNWLGtCQUFRLEtBQUssQ0FBQztBQUNkLGlCQUFPO0FBQUEsUUFDVDtBQUFBLE1BQ0Y7QUFDQSxhQUFPO0FBQUEsSUFDVDtBQUFBLElBQ0EsaUJBQWlCLE1BQU0sT0FBTyxxQkFBcUIsTUFBTSxHQUFHLEVBQUUsT0FBTyxDQUFDLE1BQU0sRUFBRSxTQUFTLENBQUMsRUFBRSxVQUFVO0FBQUEsSUFDcEcsbUJBQW1CLE1BQU0sVUFBVSxPQUFPLFVBQVUsT0FBTyxPQUFPLEdBQUcsUUFBUSxlQUFlO0FBQUEsSUFDNUYsMEJBQTBCLE1BQU0sVUFBVSxPQUFPLGVBQWUsT0FBTyxZQUFZLGdCQUFnQjtBQUFBLElBQ25HLHlCQUF5QixNQUFNLFVBQVUsT0FBTyxlQUFlLE9BQU8sWUFBWSxRQUFRO0FBQUE7QUFBQSxJQUUxRixpQkFBaUIsTUFBTSxDQUFDLENBQUMsYUFBYSxRQUFRLGtCQUFrQjtBQUFBLElBQ2hFLDZCQUE2QixNQUFNLENBQUMsQ0FBQyxhQUFhLFFBQVEsZUFBZTtBQUFBLElBQ3pFLGdCQUFnQixNQUFNLEtBQUssS0FBSyxzQkFBc0IsRUFBRSxXQUFXO0FBQUEsSUFDbkUseUNBQXlDLE1BQU0sQ0FBQyxFQUFFLE9BQU8sa0JBQWtCLE9BQU8sZUFBZTtBQUFBLElBQ2pHLGdCQUFnQixNQUFNLENBQUMsS0FBSztBQUFBLE1BQzFCO0FBQUEsUUFDRSxTQUFTLE9BQU8sTUFBTSxHQUFHLEVBQUUsS0FBSyxDQUFDLE1BQU0sRUFBRSxRQUFRLGdCQUFnQixNQUFNLEVBQUUsRUFBRSxNQUFNLEtBQUssQ0FBQyxFQUFFLENBQUM7QUFBQSxNQUM1RjtBQUFBLElBQ0YsRUFBRSxTQUFTO0FBQUEsSUFDWCxtQkFBbUIsTUFBTSxDQUFDLENBQUMsU0FBUyxPQUFPLE1BQU0sb0JBQW9CO0FBQUEsSUFDckUsaUJBQWlCLE1BQU0sS0FBSyxNQUFNLG1CQUFtQixTQUFTLE9BQU8sTUFBTSw0REFBNEQsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLFFBQVEsVUFBVTtBQUFBLElBQ2hLLHdCQUF3QixNQUFNO0FBQzVCLFVBQUksSUFBSSxrQkFBbUIsS0FBSSxrQkFBa0I7QUFDakQsVUFBSSxJQUFJLGFBQWMsS0FBSSxhQUFhO0FBQ3ZDLGVBQVMsS0FBSyxVQUFVLE9BQU8sbUJBQW1CO0FBQ2xELGFBQU87QUFBQSxJQUNUO0FBQUEsSUFDQSw2QkFBNkIsTUFBTSxDQUFDLENBQUMsT0FBTztBQUFBLElBQzVDLDZCQUE2QixNQUFNLEtBQUs7QUFBQSxNQUN0QyxTQUFTLE9BQU8sTUFBTSxHQUFHLEVBQUUsS0FBSyxDQUFDLE1BQU0sRUFBRSxLQUFLLEVBQUUsV0FBVyxhQUFhLENBQUMsRUFBRSxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsSUFDekYsRUFBRSxXQUFXO0FBQUEsSUFDYixvQkFBb0IsTUFBTSxTQUFTLGNBQWMsTUFBTSxFQUFFLGdCQUFnQixPQUFPLEtBQUs7QUFBQSxJQUNyRixvQkFBb0IsTUFBTSxTQUFTLGNBQWMsTUFBTSxFQUFFLGdCQUFnQixPQUFPLEtBQUs7QUFBQSxJQUNyRixvQkFBb0IsTUFBTSxPQUFPLGNBQWMsYUFBYTtBQUFBLElBQzVELG9CQUFvQixPQUFPLENBQUMsTUFBTSxFQUFFLGdCQUFnQixTQUFTLEVBQUUsZUFBZSxTQUFTLEVBQUUsZ0JBQWdCO0FBQUEsTUFDdkcsS0FBSztBQUFBLFFBQ0g7QUFBQSxVQUNFLFNBQVMsT0FBTyxNQUFNLEdBQUcsRUFBRSxLQUFLLENBQUMsTUFBTSxFQUFFLFFBQVEsYUFBYSxNQUFNLEVBQUUsRUFBRSxLQUFLO0FBQUEsUUFDL0UsRUFBRSxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsTUFDaEI7QUFBQSxJQUNGO0FBQUEsSUFDQSxvQkFBb0IsTUFBTSxTQUFTLGlCQUFpQiwyRUFBMkUsRUFBRSxRQUFRLENBQUMsTUFBTSxFQUFFLGFBQWEsY0FBYyxNQUFNLFVBQVUsRUFBRSxNQUFNLENBQUMsS0FBSztBQUFBLElBQzNNLDBCQUEwQixNQUFNLGtCQUFrQixxQkFBcUIsS0FBSztBQUFBLElBQzVFLDBCQUEwQixNQUFNLGtCQUFrQixvQkFBb0IsS0FBSztBQUFBLElBQzNFLGFBQWEsTUFBTSxTQUFTLGlCQUFpQiwwQkFBMEIsRUFBRSxRQUFRLENBQUMsV0FBVztBQUMzRixhQUFPLFVBQVU7QUFBQSxJQUNuQixDQUFDLEtBQUs7QUFBQSxJQUNOLGFBQWEsTUFBTSxTQUFTLGNBQWMsa0RBQWtELEVBQUUsTUFBTSxLQUFLO0FBQUEsSUFDekcsY0FBYyxNQUFNLE1BQU0scUJBQXFCO0FBQUEsSUFDL0MseUJBQXlCLE1BQU0sT0FBTyxPQUFPO0FBQUEsSUFDN0MsbUNBQW1DLE1BQU0sQ0FBQyxDQUFDLE9BQU87QUFBQSxJQUNsRCw2QkFBNkIsTUFBTSxDQUFDLENBQUMsT0FBTyxTQUFTO0FBQUEsSUFDckQsZ0JBQWdCLE1BQU0sU0FBUyxpQkFBaUIscURBQXFELEVBQUUsUUFBUSxDQUFDLE1BQU07QUFDcEgsVUFBSSxFQUFFLFFBQVMsR0FBRSxNQUFNO0FBQUEsSUFDekIsQ0FBQyxLQUFLO0FBQUEsSUFDTixnQkFBZ0IsTUFBTSxDQUFDLENBQUMsU0FBUyxPQUFPLE1BQU0sY0FBYztBQUFBLElBQzVELGtCQUFrQixNQUFNLFNBQVMsaUJBQWlCLHVEQUF1RCxFQUFFLFFBQVEsQ0FBQyxNQUFNLEVBQUUsV0FBVyxFQUFFLE1BQU0sQ0FBQyxLQUFLO0FBQUEsSUFDckosa0JBQWtCLE1BQU0sTUFBTSxLQUFLLFNBQVMsaUJBQWlCLGNBQWMsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxPQUFPLEdBQUcsVUFBVSxNQUFNLGlCQUFpQixDQUFDLEVBQUUsQ0FBQyxFQUFFLE1BQU0sS0FBSztBQUFBLElBQ2xKLGtCQUFrQixNQUFNLE1BQU0sS0FBSyxTQUFTLGlCQUFpQixjQUFjLENBQUMsRUFBRSxPQUFPLENBQUMsT0FBTyxHQUFHLFVBQVUsTUFBTSxpQkFBaUIsQ0FBQyxFQUFFLENBQUMsRUFBRSxNQUFNLEtBQUs7QUFBQSxJQUNsSixrQkFBa0IsTUFBTSxDQUFDLENBQUMsU0FBUyxPQUFPLE1BQU0sV0FBVztBQUFBLElBQzNELGNBQWMsTUFBTSxTQUFTLGlCQUFpQixnQ0FBZ0MsRUFBRSxRQUFRLENBQUMsTUFBTTtBQUM3RixVQUFJLENBQUMsRUFBRSxTQUFVLEdBQUUsVUFBVSxFQUFFLFNBQVMsK0JBQStCLEVBQUUsT0FBTztBQUFBLElBQ2xGLENBQUMsS0FBSztBQUFBLElBQ04sb0JBQW9CLE1BQU0sQ0FBQyxDQUFDLGFBQWEsUUFBUSxrQkFBa0I7QUFBQSxJQUNuRSxtQkFBbUIsTUFBTSxDQUFDLENBQUMsT0FBTyxPQUFPLElBQUk7QUFBQSxJQUM3QyxxQkFBcUIsTUFBTSxTQUFTLE9BQU8sU0FBUyxrQkFBa0IsS0FBSyxLQUFLO0FBQUEsTUFDOUU7QUFBQSxRQUNFLFNBQVMsT0FBTyxNQUFNLEdBQUcsRUFBRSxLQUFLLENBQUMsTUFBTSxFQUFFLEtBQUssRUFBRSxXQUFXLGlCQUFpQixDQUFDLEVBQUUsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLE1BQzdGO0FBQUEsSUFDRixFQUFFLFdBQVc7QUFBQSxJQUNiLGtCQUFrQixNQUFNLE9BQU8sUUFBUSxLQUFLLEtBQUs7QUFBQSxJQUNqRCxnQkFBZ0IsTUFBTSxTQUFTLE9BQU8sU0FBUyxjQUFjLE1BQU0sU0FBUyxPQUFPLE1BQU0sZUFBZSxLQUFLLFNBQVMsT0FBTyxNQUFNLGVBQWUsS0FBSyxTQUFTLE9BQU8sTUFBTSxlQUFlO0FBQUEsSUFDNUwsc0JBQXNCLE1BQU0sQ0FBQyxDQUFDLGFBQWEsUUFBUSxpQkFBaUI7QUFBQSxJQUNwRSxtQkFBbUIsTUFBTSxTQUFTLE9BQU8sU0FBUyx1QkFBdUIsS0FBSyxTQUFTLE9BQU8sU0FBUyxvQkFBb0IsS0FBSyxLQUFLO0FBQUEsTUFDbkk7QUFBQSxRQUNFLFNBQVMsT0FBTyxNQUFNLEdBQUcsRUFBRSxLQUFLLENBQUMsTUFBTSxFQUFFLEtBQUssRUFBRSxXQUFXLG1CQUFtQixDQUFDLEVBQUUsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLE1BQy9GO0FBQUEsSUFDRixFQUFFLFNBQVMsTUFBTTtBQUFBLElBQ2pCLHNCQUFzQixNQUFNLFNBQVMsT0FBTyxNQUFNLDJCQUEyQixLQUFLLENBQUMsU0FBUyxPQUFPLE1BQU0sdUJBQXVCO0FBQUEsSUFDaEksNkJBQTZCLE1BQU07QUFDakMsZUFBUyxnQkFBZ0IsVUFBVSxRQUFRLENBQUMsUUFBUTtBQUNsRCxZQUFJLElBQUksV0FBVyxTQUFTLEVBQUcsVUFBUyxnQkFBZ0IsVUFBVSxPQUFPLEdBQUc7QUFBQSxNQUM5RSxDQUFDO0FBQ0QsYUFBTztBQUFBLElBQ1Q7QUFBQSxJQUNBLHFCQUFxQixNQUFNLEtBQUs7QUFBQSxNQUM5QjtBQUFBLFFBQ0UsU0FBUyxPQUFPLE1BQU0sR0FBRyxFQUFFLEtBQUssQ0FBQyxNQUFNLEVBQUUsS0FBSyxFQUFFLFdBQVcsZ0JBQWdCLENBQUMsRUFBRSxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsTUFDNUY7QUFBQSxJQUNGLEVBQUUscUJBQXFCO0FBQUEsSUFDdkIsaUJBQWlCLE1BQU0sU0FBUyxLQUFLLFVBQVUsT0FBTyxRQUFRLE1BQU0sU0FBUyxLQUFLLFFBQVEsT0FBTztBQUFBLElBQ2pHLHNCQUFzQixNQUFNLGNBQWMsY0FBYyxXQUFXLEtBQUssS0FBSztBQUFBLElBQzdFLHNCQUFzQixNQUFNLGNBQWMsY0FBYyxXQUFXLElBQUksS0FBSztBQUFBLElBQzVFLHNCQUFzQixNQUFNLFNBQVMsT0FBTyxNQUFNLHFCQUFxQixJQUFJLENBQUMsRUFBRSxTQUFTLE9BQU87QUFBQSxJQUM5RixnQkFBZ0IsTUFBTSxPQUFPLE9BQU8sU0FBUyxlQUFlLE9BQU8sS0FBSyxTQUFTO0FBQUEsSUFDakYsZ0JBQWdCLE1BQU0sS0FBSyxLQUFLLGdCQUFnQixLQUFLLEtBQUs7QUFBQSxJQUMxRCx3QkFBd0IsTUFBTSxLQUFLLEtBQUssS0FBSyxZQUFZLEtBQUssS0FBSztBQUFBLElBQ25FLGdCQUFnQixNQUFNLEtBQUssS0FBSyxnQkFBZ0IsSUFBSSxLQUFLO0FBQUEsSUFDekQsZ0JBQWdCLE1BQU0sS0FBSyxLQUFLLGdCQUFnQixNQUFNO0FBQUEsSUFDdEQsOEJBQThCLE1BQU0sS0FBSyxLQUFLLEtBQUssWUFBWSxNQUFNO0FBQUEsSUFDckUsbUJBQW1CLE1BQU0sQ0FBQyxDQUFDLFNBQVMsY0FBYyxhQUFhO0FBQUEsSUFDL0QsZ0JBQWdCLE1BQU0sT0FBTyxRQUFRLFFBQVEsQ0FBQyxNQUFNO0FBQUEsSUFDcEQseUJBQXlCLE1BQU0sT0FBTyxRQUFRLFFBQVEsQ0FBQyxNQUFNO0FBQUEsSUFDN0QsMEJBQTBCLE1BQU0sTUFBTSxhQUFhLEtBQUssTUFBTSxVQUFVLEtBQUs7QUFBQSxJQUM3RSwwQkFBMEIsTUFBTSxNQUFNLFNBQVMsS0FBSztBQUFBLElBQ3BELHlCQUF5QixNQUFNLE9BQU8sVUFBVTtBQUFBLElBQ2hELHlCQUF5QixNQUFNLENBQUMsQ0FBQyxNQUFNLFNBQVM7QUFBQSxJQUNoRCx5QkFBeUIsTUFBTSxDQUFDLENBQUMsTUFBTSxnQkFBZ0I7QUFBQSxJQUN2RCx5QkFBeUIsTUFBTSxDQUFDLENBQUMsTUFBTSxrQkFBa0I7QUFBQSxJQUN6RCx5QkFBeUIsTUFBTSxDQUFDLENBQUMsTUFBTSxTQUFTO0FBQUEsSUFDaEQseUJBQXlCLE1BQU0sTUFBTSx1QkFBdUIsTUFBTTtBQUFBLElBQ2xFLHlCQUF5QixNQUFNLE1BQU0sdUJBQXVCLE1BQU07QUFBQSxJQUNsRSw0QkFBNEIsTUFBTSxLQUFLLE1BQU0sYUFBYSxRQUFRLGNBQWMsQ0FBQyxFQUFFLFNBQVMsTUFBTSxDQUFDLE1BQU0sRUFBRSxlQUFlLENBQUMsRUFBRSxhQUFhO0FBQUEsSUFDMUksaUJBQWlCLE1BQU0sTUFBTSxLQUFLLFNBQVMsaUJBQWlCLCtCQUErQixDQUFDLEVBQUUsUUFBUSxDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUMsS0FBSztBQUFBLEVBQzdIO0FBMk9BLE1BQUksMEJBQTBCO0FBQUE7QUFBQTtBQUFBLElBRzVCO0FBQUE7QUFBQSxJQUVBO0FBQUE7QUFBQSxJQUVBO0FBQUE7QUFBQTtBQUFBLElBR0E7QUFBQTtBQUFBO0FBQUEsSUFHQTtBQUFBO0FBQUE7QUFBQSxJQUdBO0FBQUE7QUFBQTtBQUFBLElBR0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFNRjtBQUNBLE1BQUksd0JBQXdCO0FBQUEsSUFDMUI7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLEVBQ0Y7QUFDQSxNQUFJLHlCQUF5QjtBQUFBLElBQzNCO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxFQUNGO0FBQ0EsTUFBSSx5QkFBeUI7QUFBQSxJQUMzQjtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsRUFDRjtBQUNBLE1BQUksMEJBQTBCO0FBQUEsSUFDNUI7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsRUFDRjtBQUNBLE1BQUksdUNBQXVDO0FBQUE7QUFBQSxJQUV6QztBQUFBO0FBQUEsSUFFQTtBQUFBO0FBQUEsSUFFQTtBQUFBO0FBQUEsSUFFQTtBQUFBO0FBQUEsSUFFQTtBQUFBO0FBQUEsSUFFQTtBQUFBLEVBQ0Y7QUFDQSxNQUFJLDBCQUEwQjtBQUFBLElBQzVCO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsRUFDRjtBQUNBLE1BQUksMEJBQTBCO0FBQUEsSUFDNUI7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxFQUNGO0FBQ0EsTUFBSSxrQkFBa0I7QUFBQSxJQUNwQixHQUFHO0FBQUEsSUFDSCxHQUFHO0FBQUEsSUFDSCxHQUFHO0FBQUEsSUFDSCxHQUFHO0FBQUEsSUFDSCxHQUFHO0FBQUEsSUFDSCxHQUFHO0FBQUEsSUFDSCxHQUFHO0FBQUEsSUFDSCxHQUFHO0FBQUEsRUFDTDtBQXNtREEsTUFBSSxxQkFBcUI7QUFBQSxJQUN2QixDQUFDLFVBQVUsR0FBRztBQUFBLElBQ2QsQ0FBQyxXQUFXLEdBQUc7QUFBQSxJQUNmLENBQUMsb0JBQW9CLEdBQUc7QUFBQSxJQUN4QixDQUFDLFNBQVMsR0FBRztBQUFBLElBQ2IsQ0FBQyxXQUFXLEdBQUc7QUFBQSxJQUNmLENBQUMsa0JBQWtCLElBQUk7QUFBQSxJQUN2QixDQUFDLFFBQVEsR0FBRztBQUFBLElBQ1osQ0FBQyxrQkFBa0IsSUFBSTtBQUFBLEVBQ3pCO0FBME9BLFdBQVMsbUJBQW1CLFNBQVMsb0JBQW9CLEdBQUc7QUFDMUQsVUFBTSxFQUFFLEdBQUcsR0FBRyxFQUFFLElBQUk7QUFDcEIsVUFBTSxnQkFBZ0Msb0JBQUksSUFBSTtBQUM5QyxhQUFTLDBCQUEwQixPQUFPO0FBQ3hDLFlBQU0sUUFBUSxDQUFDLFNBQVM7QUFDdEIsbUJBQVcsQ0FBQyxFQUFFLFFBQVEsS0FBSyxvQkFBb0I7QUFDN0MsY0FBSSxLQUFLLFFBQVEsTUFBTSxRQUFRO0FBQzdCLDBCQUFjLElBQUksS0FBSyxRQUFRLENBQUM7QUFBQSxVQUNsQztBQUFBLFFBQ0Y7QUFDQSxZQUFJLEtBQUssSUFBSTtBQUNYLG9DQUEwQixDQUFDLEtBQUssRUFBRSxDQUFDO0FBQUEsUUFDckM7QUFDQSxZQUFJLEtBQUssTUFBTTtBQUNiLG9DQUEwQixLQUFLLElBQUk7QUFBQSxRQUNyQztBQUNBLFlBQUksS0FBSyxNQUFNO0FBQ2Isb0NBQTBCLEtBQUssSUFBSTtBQUFBLFFBQ3JDO0FBQ0EsWUFBSSxLQUFLLEtBQUs7QUFDWixvQ0FBMEIsS0FBSyxHQUFHO0FBQUEsUUFDcEM7QUFBQSxNQUNGLENBQUM7QUFBQSxJQUNIO0FBQ0EsWUFBUSxFQUFFLFFBQVEsQ0FBQyxTQUFTO0FBQzFCLGdDQUEwQixLQUFLLENBQUMsQ0FBQztBQUNqQyxnQ0FBMEIsS0FBSyxDQUFDLENBQUM7QUFDakMsZ0NBQTBCLEtBQUssQ0FBQyxDQUFDO0FBQ2pDLGdDQUEwQixLQUFLLENBQUMsQ0FBQztBQUNqQyxXQUFLLENBQUMsRUFBRSxRQUFRLENBQUMsT0FBTyxjQUFjLElBQUksRUFBRSxDQUFDO0FBQUEsSUFDL0MsQ0FBQztBQUNELFdBQU87QUFBQSxNQUNMO0FBQUEsTUFDQTtBQUFBLE1BQ0EsR0FBRyxFQUFFLE1BQU0sR0FBRyxLQUFLLElBQUksR0FBRyxhQUFhLElBQUksQ0FBQyxFQUFFLElBQUksQ0FBQyxLQUFLLFFBQVE7QUFDOUQsWUFBSSxNQUFNLHFCQUFxQixjQUFjLElBQUksR0FBRyxHQUFHO0FBQ3JELGlCQUFPO0FBQUEsUUFDVDtBQUNBLGVBQU87QUFBQSxNQUNULENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRjtBQUNBLFdBQVMsdUJBQXVCLE1BQU0sV0FBVyxLQUFLO0FBQ3BELFVBQU0sYUFBYSxLQUFLLENBQUM7QUFDekIsUUFBSSxhQUFhLGVBQWUsR0FBRztBQUNqQyxhQUFPO0FBQUEsSUFDVDtBQUNBLFFBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxJQUFJLElBQUksRUFBRSxFQUFFLFNBQVMsVUFBVSxHQUFHO0FBQ3ZELGFBQU87QUFBQSxJQUNUO0FBQ0EsVUFBTSxhQUFhLEtBQUssQ0FBQztBQUN6QixRQUFJLGNBQWMsZUFBZSxNQUFNLElBQUksTUFBTSxVQUFVLE1BQU0sTUFBTTtBQUNyRSxhQUFPO0FBQUEsSUFDVDtBQUNBLFdBQU87QUFBQSxFQUNUO0FBQ0EsV0FBUyxtQkFBbUJDLFFBQU8sU0FBUztBQUMxQyxVQUFNLEVBQUUsR0FBRyxHQUFHLEdBQUcsTUFBTSxJQUFJQTtBQUMzQixVQUFNLEVBQUUsS0FBSyxVQUFVLElBQUk7QUFDM0IsVUFBTSxxQkFBcUIsQ0FBQyxTQUFTLHVCQUF1QixNQUFNLFdBQVcsR0FBRztBQUNoRixRQUFJLENBQUMsV0FBVztBQUNkLFlBQU0sVUFBVTtBQUFBLFFBQ2Q7QUFBQSxRQUNBLEdBQUcsRUFBRSxNQUFNLEdBQUcsTUFBTSxjQUFjO0FBQUEsUUFDbEMsR0FBRyxFQUFFLE1BQU0sTUFBTSxlQUFlLENBQUMsR0FBRyxNQUFNLGVBQWUsQ0FBQyxDQUFDLEVBQUUsT0FBTyxrQkFBa0I7QUFBQSxNQUN4RjtBQUNBLGFBQU8sbUJBQW1CLE9BQU87QUFBQSxJQUNuQztBQUNBLFVBQU0sZUFBZSxFQUFFLE1BQU0sTUFBTSxpQkFBaUIsQ0FBQyxHQUFHLE1BQU0saUJBQWlCLENBQUMsQ0FBQztBQUNqRixVQUFNLGdCQUFnQixFQUFFLE1BQU0sTUFBTSxrQkFBa0IsQ0FBQyxHQUFHLE1BQU0sa0JBQWtCLENBQUMsQ0FBQyxFQUFFLE9BQU8sa0JBQWtCO0FBQy9HLFFBQUksY0FBYyxTQUFTLEdBQUc7QUFDNUIsWUFBTSxVQUFVO0FBQUEsUUFDZDtBQUFBLFFBQ0E7QUFBQSxRQUNBLEdBQUcsQ0FBQyxHQUFHLGNBQWMsR0FBRyxhQUFhO0FBQUEsTUFDdkM7QUFDQSxhQUFPLG1CQUFtQixPQUFPO0FBQUEsSUFDbkM7QUFDQSxXQUFPO0FBQUEsTUFDTDtBQUFBLE1BQ0EsR0FBRyxFQUFFLE1BQU0sR0FBRyxNQUFNLGdCQUFnQjtBQUFBLE1BQ3BDLEdBQUc7QUFBQSxJQUNMO0FBQUEsRUFDRjtBQVVBLE1BQUk7QUFvZ0JKLFlBQVUsb0JBQUksUUFBUTs7O0FDOTBIdEIsTUFBQUMsZ0NBQW9COzs7QUNTcEIscUNBQW9CO0FBRXBCLGlCQUFzQix1QkFBdUIsU0FBUztBQUVsRCxVQUFNLGtCQUFrQixNQUFNLDZCQUFBQyxRQUFRLFVBQVUsNEJBQTRCO0FBQzVFLFVBQU0sZUFBZSxnQkFBZ0IsT0FBTyxDQUFDLE1BQU0sUUFBUSxLQUFLLENBQUMsY0FBYyxVQUFVLE9BQU8sRUFBRSxFQUFFLENBQUMsRUFBRSxJQUFJLENBQUMsTUFBTSxFQUFFLEVBQUU7QUFDdEgsUUFBSSxhQUFhLFNBQVMsR0FBRztBQUN6QixZQUFNLHlCQUF5QixZQUFZO0FBQUEsSUFDL0M7QUFDQSxVQUFNLDZCQUFBQSxRQUFRLFVBQVUsdUJBQXVCLE9BQU87QUFBQSxFQUMxRDtBQUVBLGlCQUFzQix5QkFBeUIsV0FBVztBQUN0RCxVQUFNLDZCQUFBQSxRQUFRLFVBQVUseUJBQXlCLEVBQUUsS0FBSyxVQUFVLENBQUM7QUFBQSxFQUN2RTs7O0FEckJBOzs7QUVJQSxNQUFNLGtCQUFrQixDQUFDO0FBT2xCLFdBQVMsdUJBQXVCLE1BQU0sTUFBTTtBQUMvQyxvQkFBZ0IsSUFBSSxJQUFJO0FBQUEsRUFDNUI7QUFFQSxNQUFPLDJCQUFROzs7QUZrQ2YsTUFBTSxhQUFhO0FBQUEsSUFDZixXQUFXO0FBQUEsSUFDWCxnQkFBZ0I7QUFBQSxJQUNoQixRQUFRO0FBQUEsSUFDUixPQUFPO0FBQUEsSUFDUCxVQUFVO0FBQUEsSUFDVixXQUFXO0FBQUEsSUFDWCxPQUFPO0FBQUEsRUFDWDtBQUVBLE1BQXFCLHlCQUFyQixNQUFxQix3QkFBdUI7QUFBQSxJQUN4QyxPQUFPLHFCQUFxQjtBQUFBLElBQzVCLE9BQU8sd0JBQXdCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFRL0IsWUFBWSxFQUFFLGNBQUFDLGNBQWEsR0FBRztBQUMxQixXQUFLLGVBQWVBO0FBQ3BCLFdBQUssc0JBQXNCO0FBSTNCLFdBQUssZ0JBQWdCLG9CQUFJLElBQUk7QUFFN0IsV0FBSyxrQkFBa0Isb0JBQUksSUFBSTtBQUUvQixXQUFLLHNCQUFzQixvQkFBSSxJQUFJO0FBRW5DLDZCQUF1QjtBQUFBLFFBQ25CO0FBQUEsVUFDSSxJQUFJO0FBQUEsVUFDSixJQUFJLENBQUMsa0NBQWtDO0FBQUEsVUFDdkMsU0FBUyxDQUFDLFlBQVk7QUFBQSxVQUN0QixPQUFPO0FBQUEsVUFDUCxPQUFPO0FBQUEsVUFDUCx1QkFBdUI7QUFBQSxVQUN2QixXQUFXO0FBQUEsUUFDZjtBQUFBLE1BQ0osQ0FBQztBQUlELFdBQUssY0FBYyxRQUFRLFFBQVE7QUFFbkMsV0FBSyxZQUFZO0FBR2pCLG9DQUFBQyxRQUFRLE9BQU8sUUFBUSxZQUFZLENBQUMsVUFBVTtBQUMxQyxhQUFLLGFBQWEsV0FBVyxvQkFBb0IsS0FBSyxVQUFVLEtBQUssQ0FBQyxFQUFFO0FBQ3hFLFlBQUksTUFBTSxTQUFTLHdCQUF1QixvQkFBb0I7QUFDMUQsZUFBSyxpQkFBaUI7QUFBQSxRQUMxQjtBQUFBLE1BQ0osQ0FBQztBQUlELG9DQUFBQSxRQUFRLFFBQVEsV0FBVyxZQUFZLE1BQU07QUFDekMsYUFBSyxpQkFBaUI7QUFBQSxNQUMxQixDQUFDO0FBSUQsNkJBQXVCLGVBQWUsQ0FBQyxTQUFTLFFBQVEsUUFBUTtBQUM1RCxRQUFTLFFBQVEsSUFBSSxpQ0FBaUMsSUFBSSxtQkFBbUIsSUFBSSxFQUFFO0FBQ25GLGVBQU8sS0FBSyx5QkFBeUIsSUFBSSxvQkFBb0IsTUFBTSxFQUFFLEtBQUssTUFBTTtBQUM1RSxVQUFTLFFBQVEsSUFBSSxnQ0FBZ0MsSUFBSSxtQkFBbUIsSUFBSSxFQUFFO0FBQUEsUUFDdEYsQ0FBQztBQUFBLE1BQ0wsQ0FBQztBQUFBLElBQ0w7QUFBQSxJQUVBLHdCQUF3QjtBQUVwQixXQUFLLG1CQUFtQixLQUFLLGFBQWEsb0JBQW9CLEVBQUUsTUFBTSxDQUFDLE1BQU07QUFFekUsZUFBTztBQUFBLE1BQ1gsQ0FBQztBQUFBLElBQ0w7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBTUEscUJBQXFCLGNBQWM7QUFDL0IsYUFBTztBQUFBLFFBQ0gsb0JBQW9CLElBQUksSUFBSSxhQUFhLHNCQUFzQixDQUFDLENBQUM7QUFBQSxRQUNqRSxnQkFBZ0I7QUFBQSxVQUNaLFVBQVUsSUFBSSxJQUFJLGFBQWEsZ0JBQWdCLFlBQVksQ0FBQyxDQUFDO0FBQUEsVUFDN0QsTUFBTSxJQUFJLElBQUksYUFBYSxnQkFBZ0IsUUFBUSxDQUFDLENBQUM7QUFBQSxVQUNyRCxXQUFXLElBQUksSUFBSSxhQUFhLGdCQUFnQixhQUFhLENBQUMsQ0FBQztBQUFBLFFBQ25FO0FBQUEsUUFDQSxlQUFlLGdCQUFnQixhQUFhLGlCQUFpQixDQUFDLENBQUM7QUFBQSxNQUNuRTtBQUFBLElBQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBTUEsbUJBQW1CLFVBQVU7QUFDekIsYUFBTztBQUFBLFFBQ0gsb0JBQW9CLE1BQU0sS0FBSyxTQUFTLGtCQUFrQjtBQUFBLFFBQzFELGdCQUFnQjtBQUFBLFVBQ1osVUFBVSxNQUFNLEtBQUssU0FBUyxlQUFlLFFBQVE7QUFBQSxVQUNyRCxNQUFNLE1BQU0sS0FBSyxTQUFTLGVBQWUsSUFBSTtBQUFBLFVBQzdDLFdBQVcsTUFBTSxLQUFLLFNBQVMsZUFBZSxTQUFTO0FBQUEsUUFDM0Q7QUFBQSxRQUNBLGVBQWUsZ0JBQWdCLFNBQVMsYUFBYTtBQUFBLE1BQ3pEO0FBQUEsSUFDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLElBS0EsTUFBTSxjQUFjO0FBQ2hCLFVBQUksQ0FBQyxLQUFLLGVBQWU7QUFDckIsYUFBSyxnQkFBaUIsTUFBTSxzQkFBc0IsVUFBVSxLQUFNO0FBQUEsVUFDOUQsb0JBQW9CLENBQUM7QUFBQSxVQUNyQixnQkFBZ0I7QUFBQSxZQUNaLFVBQVUsQ0FBQztBQUFBLFlBQ1gsTUFBTSxDQUFDO0FBQUEsWUFDUCxXQUFXLENBQUM7QUFBQSxVQUNoQjtBQUFBLFVBQ0EsZUFBZSxDQUFDO0FBQUEsUUFDcEI7QUFBQSxNQUNKO0FBQ0EsYUFBTyxLQUFLLHFCQUFxQixLQUFLLGFBQWE7QUFBQSxJQUN2RDtBQUFBLElBRUEsOEJBQThCO0FBQzFCLGFBQU8sS0FBSyxhQUFhLHVCQUF1QixpQkFBaUI7QUFBQSxJQUNyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBS0EsTUFBTSxlQUFlLFVBQVU7QUFDM0IsV0FBSyxnQkFBZ0IsS0FBSyxtQkFBbUIsUUFBUTtBQUNyRCxVQUFJO0FBQ0EsY0FBTSxvQkFBb0IsWUFBWSxLQUFLLGFBQWE7QUFBQSxNQUM1RCxTQUFTLEdBQUc7QUFFUixhQUFLLGFBQWEsV0FBVyw4Q0FBOEMsQ0FBQyxFQUFFO0FBQUEsTUFDbEY7QUFBQSxJQUNKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFjQSxlQUFlLElBQUk7QUFDZixZQUFNLEtBQUssS0FBSyxZQUFZLEtBQUssWUFBWTtBQUN6QyxjQUFNLFFBQVEsTUFBTSxLQUFLLFlBQVk7QUFDckMsY0FBTSxHQUFHLEtBQUs7QUFDZCxjQUFNLEtBQUssZUFBZSxLQUFLO0FBQUEsTUFDbkMsQ0FBQztBQUVELFdBQUssY0FBYyxHQUFHLE1BQU0sQ0FBQyxNQUFNO0FBQy9CLGFBQUssYUFBYSxXQUFXLHlCQUF5QixDQUFDLEVBQUU7QUFBQSxNQUM3RCxDQUFDO0FBQ0QsYUFBTztBQUFBLElBQ1g7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUtBLHFCQUFxQixPQUFPO0FBQ3hCLFdBQUssZ0JBQWdCLE9BQU8sS0FBSztBQUNqQyxXQUFLLG9CQUFvQixPQUFPLEtBQUs7QUFBQSxJQUN6QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQU9BLGFBQWEsT0FBTyxLQUFLO0FBQ3JCLFlBQU0sWUFBWSxLQUFLLGNBQWMsSUFBSSxLQUFLLEtBQUssSUFBSSxJQUFJLGFBQWE7QUFDeEUsVUFBSSxZQUFZO0FBQ2hCLFVBQUk7QUFDQSxvQkFBWSxJQUFJLElBQUksR0FBRztBQUFBLE1BQzNCLFNBQVMsR0FBRztBQUNSLGFBQUssYUFBYSxXQUFXLG9CQUFvQixHQUFHLEtBQUssQ0FBQyxFQUFFO0FBQzVELGVBQU87QUFBQSxNQUNYO0FBRUEsTUFBUyxLQUFLLGFBQWEsV0FBVyxHQUFHLEtBQUssOEJBQThCLFNBQVMsT0FBTyxTQUFTLEVBQUU7QUFDdkcsVUFBSSxVQUFVLFNBQVMsVUFBVSxRQUFRLFVBQVUsYUFBYSxVQUFVLFlBQVksVUFBVSxhQUFhLFVBQVUsVUFBVTtBQUU3SCxhQUFLLHFCQUFxQixLQUFLO0FBQUEsTUFDbkM7QUFDQSxXQUFLLGNBQWMsSUFBSSxPQUFPLFNBQVM7QUFDdkMsYUFBTztBQUFBLElBQ1g7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFPQSx1QkFBdUIsT0FBTyxLQUFLLFlBQVk7QUFDM0MsVUFBSSxZQUFZO0FBRVosUUFBUyxRQUFRLElBQUksZ0VBQWdFLE9BQU8sR0FBRztBQUMvRixhQUFLLHFCQUFxQixLQUFLO0FBQy9CO0FBQUEsTUFDSjtBQUNBLFlBQU0saUJBQWlCLEtBQUssZ0JBQWdCLElBQUksS0FBSztBQUNyRCxVQUFJLG1CQUFtQixLQUFLO0FBRXhCLFFBQVMsUUFBUSxJQUFJLG9DQUFvQyxnQkFBZ0IsTUFBTSxLQUFLLDhCQUE4QixLQUFLO0FBQ3ZILGFBQUsscUJBQXFCLEtBQUs7QUFBQSxNQUNuQztBQUNBLE1BQVMsUUFBUSxJQUFJLGdDQUFnQyxLQUFLLE1BQU0sS0FBSyxjQUFjLElBQUksS0FBSyxHQUFHLFVBQVUsS0FBSztBQUM5RyxXQUFLLGdCQUFnQixJQUFJLE9BQU8sR0FBRztBQUFBLElBQ3ZDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQU1BLGlCQUFpQixPQUFPLEtBQUs7QUFHekIsWUFBTSxpQkFBaUIsS0FBSyxnQkFBZ0IsSUFBSSxLQUFLO0FBQ3JELFVBQUksQ0FBQyxLQUFLLG9CQUFvQixJQUFJLEtBQUssS0FBSyxtQkFBbUIsS0FBSztBQUVoRSxhQUFLLGFBQWEsV0FBVyx5QkFBeUIsR0FBRyxPQUFPLEtBQUssY0FBYyxJQUFJLEtBQUssQ0FBQyxXQUFXLEtBQUssRUFBRTtBQUMvRyxhQUFLLG9CQUFvQixJQUFJLEtBQUs7QUFDbEMsYUFBSyxVQUFVLG1CQUFtQjtBQUFBLE1BQ3RDO0FBQUEsSUFDSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBUUEsTUFBTSx5QkFBeUIsS0FBSyxRQUFRO0FBQ3hDLFlBQU0sVUFBVSxPQUFPO0FBQ3ZCLFVBQUksQ0FBQyxPQUFPLE9BQU8sT0FBTyxZQUFZLFVBQVU7QUFDNUMsYUFBSyxhQUFhLFdBQVcsbUJBQW1CLE9BQU8sV0FBVyxPQUFPLEdBQUcsRUFBRTtBQUM5RTtBQUFBLE1BQ0o7QUFDQSxZQUFNLFFBQVEsT0FBTyxJQUFJO0FBQ3pCLFVBQUksT0FBTyxVQUFVLFVBQVU7QUFDM0IsYUFBSyxhQUFhLFdBQVcsaUJBQWlCLEtBQUssRUFBRTtBQUNyRDtBQUFBLE1BQ0o7QUFDQSxZQUFNLGNBQWMsWUFBWTtBQUVoQyxZQUFNLFdBQVcsT0FBTyxPQUFPLE9BQU8sVUFBVTtBQUNoRCxZQUFNLFNBQVMsT0FBTyxJQUFJLE9BQU8sT0FBTyxJQUFJLGNBQWM7QUFDMUQsVUFBSSxZQUFZO0FBQ2hCLFVBQUk7QUFDQSxvQkFBWSxJQUFJLElBQUksTUFBTSxFQUFFO0FBQUEsTUFDaEMsU0FBUyxHQUFHO0FBQ1IsYUFBSyxhQUFhLFdBQVcsNkJBQTZCLENBQUMsRUFBRTtBQUM3RDtBQUFBLE1BQ0o7QUFHQSxZQUFNLGVBQWUsTUFBTSxLQUFLO0FBQ2hDLFVBQUksQ0FBQyxjQUFjO0FBQ2YsYUFBSyxhQUFhLFdBQVcsMkNBQTJDO0FBQ3hFLGFBQUssc0JBQXNCO0FBQzNCO0FBQUEsTUFDSjtBQUNBLFlBQU0sMEJBQTBCLGFBQWEsVUFBVTtBQUN2RCxZQUFNLHNCQUFzQix5QkFBeUI7QUFDckQsTUFDSSxRQUFRO0FBQUEsUUFDSjtBQUFBLFFBQ0EsSUFBSTtBQUFBLFFBQ0o7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsTUFDSjtBQUVKLFVBQUksQ0FBQyxxQkFBcUI7QUFDdEIsYUFBSyxhQUFhLFdBQVcsa0NBQWtDLG1CQUFtQixFQUFFO0FBQ3BGO0FBQUEsTUFDSjtBQUNBLFlBQU0sNEJBQTRCLE1BQU0sS0FBSyxhQUFhLCtCQUErQjtBQUN6RixVQUFJLENBQUMsMkJBQTJCO0FBQzVCLGFBQUssYUFBYSxXQUFXLGlDQUFpQztBQUM5RDtBQUFBLE1BQ0o7QUFDQSxZQUFNLHlCQUF5QixNQUFNLEtBQUssNEJBQTRCO0FBRXRFLGNBQVEsSUFBSSxNQUFNO0FBQUEsUUFDZCxLQUFLLFFBQVE7QUFFVCxjQUFJLGFBQWE7QUFFYixpQkFBSyxhQUFhLE9BQU8sTUFBTTtBQUUvQixpQkFBSyxzQkFBc0I7QUFBQSxVQUMvQjtBQUVBLGdCQUFNLFlBQVksTUFBTSxLQUFLLGFBQWEsK0JBQStCLE1BQU07QUFDL0UsY0FBSSxDQUFDLFdBQVc7QUFDWixpQkFBSyxhQUFhLFdBQVcsa0NBQWtDLE1BQU0sRUFBRTtBQUN2RSxpQkFBSyxVQUFVLG1CQUFtQjtBQUNsQztBQUFBLFVBQ0o7QUFFQSxnQkFBTSxhQUFhO0FBR25CLGNBQUksYUFBYTtBQUVqQixjQUFJLEtBQUssb0JBQW9CLElBQUksS0FBSyxHQUFHO0FBQ3JDLGlCQUFLLGFBQWEsV0FBVywrQ0FBK0MsS0FBSyxFQUFFO0FBQ25GLHlCQUFhO0FBQUEsVUFDakI7QUFFQSxjQUFJLGFBQWE7QUFFYixpQkFBSyxhQUFhLHNCQUFzQixPQUFPLFFBQVE7QUFBQTtBQUFBLGNBRW5ELGlCQUFpQixNQUFNLEtBQUssWUFBWSxHQUFHLG1CQUFtQixJQUFJLFNBQVM7QUFBQSxjQUMzRSxVQUFVO0FBQUEsY0FDVixjQUFjO0FBQUEsY0FDZCxnQkFBZ0I7QUFBQSxjQUNoQixtQkFBbUIsS0FBSyxvQkFBb0IsSUFBSSxLQUFLO0FBQUEsY0FDckQsYUFBYSxLQUFLLGdCQUFnQixJQUFJLEtBQUssS0FBSztBQUFBLGNBQ2hELHlCQUF5QjtBQUFBLFlBQzdCLENBQUM7QUFFRCxpQkFBSyxVQUFVLE1BQU07QUFBQSxVQUN6QjtBQUtBLGdCQUFNLG9CQUFvQjtBQUFBLFlBQ3RCLFNBQVM7QUFBQSxZQUNUO0FBQUEsWUFDQSxlQUFlO0FBQUEsWUFDZixhQUFhO0FBQUEsWUFDYixjQUFjLG9CQUFvQixnQkFBZ0IsQ0FBQztBQUFBLFlBQ25ELGVBQWU7QUFBQSxZQUNmLGdCQUFnQjtBQUFBLFlBQ2hCLHFCQUFxQjtBQUFBLFlBQ3JCLHNCQUFzQjtBQUFBLFlBQ3RCLGtCQUFrQjtBQUFBLFlBQ2xCLDBCQUEwQjtBQUFBLFlBQzFCLHVCQUF1QjtBQUFBLFlBQ3ZCO0FBQUEsWUFDQSxNQUFNO0FBQUEsVUFDVjtBQUNBLGdCQUFNLGtCQUFrQixvQkFBb0I7QUFDNUMsZ0JBQU1DLFNBQVE7QUFBQSxZQUNWLGFBQWEsQ0FBQztBQUFBLFlBQ2QsZUFBZSxDQUFDO0FBQUEsVUFDcEI7QUFDQSxjQUFJLGlCQUFpQjtBQUNqQixnQkFBSSxnQkFBZ0IsT0FBTztBQUN2QixjQUFBQSxPQUFNLFVBQVU7QUFBQTtBQUFBLGdCQUVYO0FBQUEsZ0JBQ0Q7QUFBQTtBQUFBLGtCQUVJLEtBQUs7QUFBQSxrQkFDTCxXQUFXO0FBQUEsZ0JBQ2Y7QUFBQSxjQUNKO0FBQUEsWUFDSixPQUFPO0FBQ0gsY0FBQUEsT0FBTSxVQUFVO0FBQUEsWUFDcEI7QUFBQSxVQUNKO0FBQ0EsVUFBUyxRQUFRLElBQUksc0JBQXNCLGlCQUFpQjtBQUU1RCxpQkFBTyxLQUFLO0FBQUEsWUFDUjtBQUFBLFlBQ0E7QUFBQSxjQUNJLE1BQU07QUFBQSxjQUNOLE9BQUFBO0FBQUEsY0FDQSxRQUFRO0FBQUEsWUFDWjtBQUFBLFlBQ0E7QUFBQSxjQUNJO0FBQUEsWUFDSjtBQUFBLFVBQ0o7QUFDQTtBQUFBLFFBQ0o7QUFBQSxRQUNBLEtBQUssZUFBZTtBQUNoQjtBQUFBLFFBQ0o7QUFBQSxRQUNBLEtBQUssY0FBYztBQUNmLGVBQUssVUFBVSxhQUFhO0FBRTVCLGVBQUssaUJBQWlCLE9BQU8sSUFBSSxHQUFHO0FBQ3BDO0FBQUEsUUFDSjtBQUFBLFFBQ0EsS0FBSyxnQkFBZ0I7QUFDakIsY0FBSSxDQUFDLElBQUksUUFBUTtBQUNiLGlCQUFLLFVBQVUsY0FBYztBQUM3QixpQkFBSyxhQUFhLHNCQUFzQixPQUFPLFFBQVE7QUFBQSxjQUNuRCxnQkFBZ0I7QUFBQSxjQUNoQixVQUFVO0FBQUEsY0FDVixjQUFjO0FBQUEsY0FDZCxnQkFBZ0I7QUFBQSxjQUNoQixtQkFBbUIsS0FBSyxvQkFBb0IsSUFBSSxLQUFLO0FBQUEsY0FDckQsYUFBYSxJQUFJO0FBQUEsY0FDakIseUJBQXlCO0FBQUEsWUFDN0IsQ0FBQztBQUFBLFVBQ0wsT0FBTztBQUFBLFVBRVA7QUFDQTtBQUFBLFFBQ0o7QUFBQSxRQUNBLEtBQUssbUJBQW1CO0FBRXBCLGVBQUssdUJBQXVCLE9BQU8sSUFBSSxLQUFLLElBQUksVUFBVTtBQUMxRCxlQUFLLGFBQWEsc0JBQXNCLE9BQU8sUUFBUTtBQUFBLFlBQ25ELGdCQUFnQjtBQUFBLFlBQ2hCLFVBQVUsSUFBSTtBQUFBLFlBQ2QsY0FBYztBQUFBLFlBQ2QsZ0JBQWdCO0FBQUEsWUFDaEIsbUJBQW1CLEtBQUssb0JBQW9CLElBQUksS0FBSztBQUFBLFlBQ3JELGFBQWEsSUFBSTtBQUFBLFlBQ2pCLHlCQUF5QjtBQUFBLFVBQzdCLENBQUM7QUFDRCxjQUFJLElBQUksUUFBUSxhQUFhO0FBQ3pCLGlCQUFLLFVBQVUsZ0JBQWdCO0FBQUEsVUFDbkMsT0FBTztBQUNILGlCQUFLLFVBQVUsSUFBSSxhQUFhLGtCQUFrQixNQUFNO0FBQUEsVUFDNUQ7QUFDQSxnQkFBTSxLQUFLLGVBQWUsQ0FBQyxhQUFhO0FBQ3BDLHFCQUFTLG1CQUFtQixJQUFJLFNBQVM7QUFBQSxVQUM3QyxDQUFDO0FBQ0QsZUFBSyxhQUFhLGlCQUFpQixPQUFPLFFBQVEsSUFBSSxVQUFVO0FBQ2hFLGVBQUssVUFBVSxJQUFJLGFBQWEsNkJBQTZCLGlCQUFpQjtBQUM5RSxlQUFLLGFBQWEsbUJBQW1CLE9BQU8sR0FBRztBQUMvQztBQUFBLFFBQ0o7QUFBQSxRQUNBLEtBQUssVUFBVTtBQUNYLGdCQUFNLFFBQVEsSUFBSSxTQUFTLENBQUM7QUFDNUIsZ0JBQU0scUJBQXFCLE1BQU0sbUJBQW1CLFNBQVM7QUFDN0QsZ0JBQU0scUJBQXFCLE1BQU0sbUJBQW1CLFNBQVM7QUFDN0QsZ0JBQU0saUJBQWlCLE1BQU0sZ0JBQWdCLFNBQVM7QUFDdEQsZ0JBQU0saUJBQWlCLHNCQUFzQjtBQUM3QyxnQkFBTSxLQUFLLGVBQWUsQ0FBQyxhQUFhO0FBQ3BDLGdCQUFJLGVBQWUsa0JBQWtCLENBQUMsU0FBUyxlQUFlLFNBQVMsSUFBSSxJQUFJLFVBQVUsR0FBRztBQUN4Rix1QkFBUyxlQUFlLFNBQVMsSUFBSSxJQUFJLFVBQVU7QUFFbkQsbUJBQUssVUFBVSxzQkFBc0I7QUFBQSxZQUN6QztBQUNBLGdCQUFJLGVBQWUsZ0JBQWdCO0FBQy9CLGtCQUFJLGtCQUFrQixDQUFDLFNBQVMsZUFBZSxLQUFLLElBQUksSUFBSSxVQUFVLEdBQUc7QUFDckUseUJBQVMsZUFBZSxLQUFLLElBQUksSUFBSSxVQUFVO0FBRS9DLHFCQUFLLFVBQVUsa0JBQWtCO0FBQUEsY0FDckMsV0FBVyxDQUFDLGtCQUFrQixDQUFDLFNBQVMsZUFBZSxVQUFVLElBQUksSUFBSSxVQUFVLEdBQUc7QUFDbEYseUJBQVMsZUFBZSxVQUFVLElBQUksSUFBSSxVQUFVO0FBRXBELHFCQUFLLFVBQVUscUJBQXFCO0FBQUEsY0FDeEM7QUFBQSxZQUNKO0FBQUEsVUFDSixDQUFDO0FBQ0Q7QUFBQSxRQUNKO0FBQUEsUUFDQSxLQUFLLFFBQVE7QUFDVCxjQUFJLE9BQU8sSUFBSSxjQUFjLGFBQWE7QUFDdEMsaUJBQUssVUFBVSxPQUFPLFNBQVMsSUFBSSxTQUFTLEVBQUUsS0FBSyxDQUFDLENBQUMsTUFBTSxNQUFNO0FBQzdELGtCQUFJLFdBQVcsT0FBTztBQUNsQix3QkFBUSxlQUFlLG1CQUFtQixRQUFRLEVBQUU7QUFDcEQsd0JBQVEsSUFBSSxJQUFJLE1BQU0sT0FBTyxNQUFNO0FBQ25DLHdCQUFRLFNBQVM7QUFBQSxjQUNyQjtBQUNBLHFCQUFPLEtBQUs7QUFBQSxnQkFDUjtBQUFBLGdCQUNBO0FBQUEsa0JBQ0ksSUFBSSxJQUFJO0FBQUEsa0JBQ1IsTUFBTTtBQUFBLGtCQUNOLFFBQVEsT0FBTztBQUFBLGdCQUNuQjtBQUFBLGdCQUNBO0FBQUEsa0JBQ0k7QUFBQSxnQkFDSjtBQUFBLGNBQ0o7QUFBQSxZQUNKLENBQUM7QUFBQSxVQUNMO0FBQ0E7QUFBQSxRQUNKO0FBQUEsUUFDQSxLQUFLLG9CQUFvQjtBQUNyQixjQUFJLElBQUksU0FBUyxLQUFLLFNBQVMscUJBQXFCLEdBQUc7QUFDbkQsaUJBQUssVUFBVSx1QkFBdUI7QUFBQSxVQUMxQztBQUNBO0FBQUEsUUFDSjtBQUFBLFFBQ0EsS0FBSyxlQUFlO0FBQ2hCLGtCQUFRLElBQUksZUFBZSxHQUFHO0FBQzlCO0FBQUEsUUFDSjtBQUFBLFFBQ0E7QUFDSSxlQUFLLGFBQWEsV0FBVyx1Q0FBdUMsSUFBSSxJQUFJLEVBQUU7QUFDOUU7QUFBQSxNQUNSO0FBQUEsSUFDSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFTQSxNQUFNLFVBQVUsT0FBTyxTQUFTLFdBQVc7QUFDdkMsYUFBTyxPQUFPLFVBQVUsY0FBYztBQUFBLFFBQ2xDLFFBQVE7QUFBQSxVQUNKO0FBQUEsVUFDQSxVQUFVLENBQUMsT0FBTztBQUFBLFFBQ3RCO0FBQUEsUUFDQSxPQUFPO0FBQUEsUUFDUCxNQUFNLFNBQWEsU0FBUztBQUFBLE1BQ2hDLENBQUM7QUFBQSxJQUNMO0FBQUEsSUFFQSxNQUFNLFVBQVUsV0FBVztBQUN2QixXQUFLLGVBQWUsQ0FBQyxhQUFhO0FBQzlCLGlCQUFTLGNBQWMsU0FBUyxLQUFLLFNBQVMsY0FBYyxTQUFTLEtBQUssS0FBSztBQUFBLE1BQ25GLENBQUM7QUFHRCxrQkFBWSx3QkFBdUIsb0JBQW9CO0FBQUEsUUFDbkQsZ0JBQWdCLHdCQUF1QjtBQUFBLE1BQzNDLENBQUM7QUFHRCxZQUFNLFlBQVksZUFBZSxTQUFTO0FBQzFDLFdBQUssYUFBYSxVQUFVLFdBQVcsU0FBUztBQUFBLFFBQzVDLHlCQUEwQixNQUFNLEtBQUssNEJBQTRCLElBQUssTUFBTTtBQUFBLFFBQzVFLGVBQWU7QUFBQSxNQUNuQixDQUFDO0FBQUEsSUFDTDtBQUFBLElBRUEsTUFBTSxtQkFBbUI7QUFDckIsVUFBSSxnQkFBZ0IsQ0FBQztBQUNyQixZQUFNLEtBQUssZUFBZSxDQUFDLGFBQWE7QUFDcEMsd0JBQWdCLGdCQUFnQixTQUFTLGFBQWE7QUFDdEQsaUJBQVMsZ0JBQWdCLENBQUM7QUFDMUIsaUJBQVMsZUFBZSxTQUFTLE1BQU07QUFDdkMsaUJBQVMsZUFBZSxLQUFLLE1BQU07QUFDbkMsaUJBQVMsZUFBZSxVQUFVLE1BQU07QUFBQSxNQUM1QyxDQUFDO0FBQ0QsV0FBSyxhQUFhLFVBQVUsdUJBQXVCLFlBQVk7QUFBQSxRQUMzRCxHQUFHO0FBQUEsUUFDSCx5QkFBMEIsTUFBTSxLQUFLLDRCQUE0QixJQUFLLE1BQU07QUFBQSxRQUM1RSxlQUFlO0FBQUEsTUFDbkIsQ0FBQztBQUFBLElBQ0w7QUFBQSxFQUNKOzs7QUc1bUJBO0FBVU8sTUFBTSx1QkFBdUIsS0FBSztBQUNsQyxNQUFNLG9CQUFvQixLQUFLO0FBQy9CLE1BQU0saUJBQWlCLElBQUk7QUFDM0IsTUFBTSxpQkFBaUI7QUFNdkIsTUFBTSx1QkFBTixNQUEyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLElBSTlCLFlBQVlDLGtCQUFpQjtBQUN6QixXQUFLLGtCQUFrQkE7QUFFdkIsV0FBSyxTQUFTLG9CQUFJLElBQUk7QUFFdEIsV0FBSyxTQUFTLFFBQVEsUUFBUTtBQUc5QixXQUFLLGdCQUFnQjtBQUFBLElBQ3pCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBT0EsTUFBTSxRQUFRQyxTQUFRLFFBQVE7QUFDMUIsWUFBTSxTQUFTLEtBQUssT0FDZixLQUFLLE1BQU07QUFDUixlQUFPLEtBQUssZ0JBQWdCLE9BQU9BLFNBQVEsTUFBTTtBQUFBLE1BQ3JELENBQUMsRUFDQSxNQUFNLENBQUMsTUFBTTtBQUNWLGdCQUFRLE1BQU0sK0JBQStCLENBQUM7QUFBQSxNQUNsRCxDQUFDO0FBQ0wsV0FBSyxTQUFTO0FBQ2QsWUFBTTtBQUFBLElBQ1Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFhQSxTQUFTQSxTQUFRLFFBQVEsVUFBVSxLQUFLO0FBQ3BDLFlBQU0sTUFBTSxLQUFLLE9BQ1osS0FBSyxZQUFZO0FBQ2QsWUFBSSxZQUFZLEtBQUs7QUFDakIsZ0JBQU0sU0FBUyxLQUFLLE9BQU8sSUFBSSxRQUFRO0FBQ3ZDLGNBQUksVUFBVSxLQUFLLElBQUksSUFBSSxPQUFPLE9BQU8sS0FBSztBQUMxQyxtQkFBTyxPQUFPO0FBQUEsVUFDbEI7QUFBQSxRQUNKO0FBQ0EsY0FBTSxTQUFTLE1BQU0sS0FBSyxnQkFBZ0IsUUFBUUEsU0FBUSxNQUFNO0FBQ2hFLFlBQUksWUFBWSxLQUFLO0FBRWpCLGNBQUksS0FBSyxPQUFPLFFBQVEsZ0JBQWdCO0FBRXBDLGtCQUFNLFNBQVMsS0FBSyxPQUFPLEtBQUssRUFBRSxLQUFLLEVBQUU7QUFDekMsZ0JBQUksV0FBVyxPQUFXLE1BQUssT0FBTyxPQUFPLE1BQU07QUFBQSxVQUN2RDtBQUNBLGVBQUssT0FBTyxJQUFJLFVBQVUsRUFBRSxNQUFNLEtBQUssSUFBSSxHQUFHLE9BQU8sT0FBTyxDQUFDO0FBQUEsUUFDakU7QUFDQSxlQUFPO0FBQUEsTUFDWCxDQUFDLEVBQ0EsTUFBTSxDQUFDLE1BQU07QUFDVixnQkFBUSxNQUFNLDhCQUE4QkEsT0FBTSxJQUFJLENBQUM7QUFBQSxNQUMzRCxDQUFDO0FBQ0wsV0FBSyxTQUFTO0FBQ2QsYUFBTztBQUFBLElBQ1g7QUFBQSxJQUVBLE1BQU0sV0FBVyxTQUFTO0FBQ3RCLGNBQVEsSUFBSSxPQUFPO0FBQ25CLFlBQU0sS0FBSyxRQUFRLGdCQUFnQjtBQUFBLFFBQy9CO0FBQUEsTUFDSixDQUFDO0FBQUEsSUFDTDtBQUFBLElBRUEsTUFBTSxzQkFBc0IsT0FBTyxLQUFLLGdCQUFnQjtBQUNwRCxZQUFNLEtBQUssUUFBUSw0QkFBNEI7QUFBQSxRQUMzQztBQUFBLFFBQ0E7QUFBQSxRQUNBLGVBQWU7QUFBQSxNQUNuQixDQUFDO0FBQUEsSUFDTDtBQUFBLElBRUEsTUFBTSxpQkFBaUIsT0FBTyxRQUFRLFlBQVk7QUFDOUMsWUFBTSxLQUFLLFFBQVEsb0JBQW9CO0FBQUEsUUFDbkM7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLE1BQ0osQ0FBQztBQUFBLElBQ0w7QUFBQSxJQUVBLE1BQU0sbUJBQW1CLE9BQU8sS0FBSztBQUNqQyxZQUFNLEtBQUssUUFBUSxzQkFBc0I7QUFBQSxRQUNyQztBQUFBLFFBQ0E7QUFBQSxNQUNKLENBQUM7QUFBQSxJQUNMO0FBQUEsSUFFQSxNQUFNLGlDQUFpQztBQUNuQyxZQUFNLFNBQVMsTUFBTSxLQUFLLFNBQVMsK0JBQStCLENBQUMsR0FBRyxlQUFlLGlCQUFpQjtBQUN0RyxhQUFPLFFBQVEsV0FBVztBQUFBLElBQzlCO0FBQUEsSUFFQSxNQUFNLCtCQUErQixLQUFLO0FBQ3RDLFlBQU0sU0FBUyxNQUFNLEtBQUssU0FBUyxvQkFBb0IsRUFBRSxhQUFhLGVBQWUsSUFBSSxHQUFHLFFBQVEsR0FBRyxJQUFJLGNBQWM7QUFDekgsYUFBTyxRQUFRLFdBQVc7QUFBQSxJQUM5QjtBQUFBLElBRUEsTUFBTSx1QkFBdUIsZ0JBQWdCO0FBQ3pDLFlBQU0sU0FBUyxNQUFNLEtBQUs7QUFBQSxRQUN0QjtBQUFBLFFBQ0EsRUFBRSxhQUFhLGVBQWUsZUFBZTtBQUFBLFFBQzdDLGNBQWMsY0FBYztBQUFBLFFBQzVCO0FBQUEsTUFDSjtBQUNBLGFBQU8sUUFBUSxXQUFXO0FBQUEsSUFDOUI7QUFBQSxJQUVBLE1BQU0sVUFBVSxXQUFXLE1BQU0sUUFBUTtBQUNyQyxZQUFNLEtBQUssUUFBUSxhQUFhO0FBQUEsUUFDNUI7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLE1BQ0osQ0FBQztBQUFBLElBQ0w7QUFBQSxJQUVBLE1BQU0sc0JBQXNCO0FBQ3hCLFlBQU0sZUFBZSxLQUFLLGlCQUFrQixNQUFNLHNCQUFzQixRQUFRLEtBQU0sRUFBRSxTQUFTLFVBQVU7QUFDM0csWUFBTSxzQkFBc0IsR0FBRyxhQUFhLE9BQU87QUFDbkQsTUFBUyxRQUFRLElBQUksaUJBQWlCLEtBQUssVUFBVSxZQUFZLENBQUMsRUFBRTtBQUVwRSxVQUFJO0FBQ0EsZ0JBQVEsSUFBSSxxREFBcUQsbUJBQW1CLEVBQUU7QUFFdEYsY0FBTSxTQUFTLE1BQU0sS0FBSyxnQkFBZ0IsUUFBUSxvQkFBb0IsRUFBRSxNQUFNLFVBQVUsU0FBUyxvQkFBb0IsQ0FBQztBQUN0SCxZQUFJLE9BQU8sU0FBUztBQUNoQixlQUFLLGdCQUFnQixPQUFPO0FBQzVCLGNBQUk7QUFDQSxrQkFBTSxvQkFBb0IsVUFBVSxLQUFLLGFBQWE7QUFBQSxVQUMxRCxTQUFTLEdBQUc7QUFFUixpQkFBSyxXQUFXLG1EQUFtRCxDQUFDLEVBQUU7QUFBQSxVQUMxRTtBQUNBLGlCQUFPLEtBQUs7QUFBQSxRQUNoQjtBQUNBLGVBQU87QUFBQSxNQUNYLFNBQVMsR0FBRztBQUNSLGFBQUssV0FBVyxtQ0FBbUMsQ0FBQyxFQUFFO0FBQ3RELFlBQUksd0JBQXdCLFdBQVc7QUFDbkMsaUJBQU87QUFBQSxRQUNYO0FBQ0EsY0FBTTtBQUFBLE1BQ1Y7QUFBQSxJQUNKO0FBQUEsRUFDSjs7O0FDaExBLE1BQUFDLGdDQUFvQjtBQUdwQjs7O0FDSEEsTUFBQUMsZ0NBQW9CO0FBQ3BCOzs7QUNEQSxNQUFNLFdBQVc7OztBREdqQix3QkFBcUI7OztBRU9yQixXQUFTLGdCQUFnQixFQUN2QixvQkFBb0IsTUFDcEIsc0JBQXNCLE9BQ3RCLFdBQVcsTUFDWCxpQkFBQUMsbUJBQWtCLE1BQ2xCLGNBQWMsTUFDZCxhQUFhLE1BQ2IsbUJBQW1CLEtBQUksR0FDTDtBQUNsQixXQUFPO01BQ0w7TUFDQTtNQUNBO01BQ0EsaUJBQUFBO01BQ0E7TUFDQTtNQUNBOztFQUVKO0FBRUEsTUFBTTs7SUFBa0MsZ0JBQWdCLENBQUEsQ0FBRTs7OztBQ01wRCxXQUFVLGlCQUFjO0FBQzVCLFdBQU87TUFDTCxRQUFRO01BQ1IscUJBQXFCO01BQ3JCLFVBQVU7TUFDVixTQUFTO01BQ1QsTUFBTTtNQUNOLFdBQVc7TUFDWCxjQUFjO01BQ2QsV0FBVzs7RUFFZjs7O0FDakNBLE1BQU0sU0FBa0IsZUFBYzs7O0FKVHRDLHVDQUFpQztBQUNqQyxvQkFBaUI7QUFDakIsTUFBTSxrQkFBYywrQkFBQUMsU0FBcUI7QUFpTGxDLFdBQVMsaUJBQWlCO0FBQzdCLFFBQUksQ0FBQyxlQUFlLENBQUMsWUFBWSxRQUFTO0FBRTFDLFFBQUksY0FBYyxZQUFZLFFBQVEsWUFBWTtBQUNsRCxRQUFJLGdCQUFnQixVQUFXLGVBQWM7QUFFN0MsV0FBTztBQUFBLEVBQ1g7QUFtUEEsTUFBTSxnQkFBZ0IsS0FBSyxLQUFLLEtBQUs7OztBSzNhckMsTUFBSSxhQUFhO0FBRVYsV0FBUyxnQkFBZ0I7QUFDNUIsV0FBTztBQUFBLEVBQ1g7QUFNTyxXQUFTLGNBQWMsTUFBTTtBQUNoQyxpQkFBYTtBQUFBLEVBQ2pCOzs7QU5QTyxNQUFNLHVCQUFOLGNBQW1DLFlBQVk7QUFBQSxJQUNsRCxZQUFZLEtBQUs7QUFDYixZQUFNLG1CQUFtQixFQUFFLFFBQVEsSUFBSSxDQUFDO0FBQUEsSUFDNUM7QUFBQSxJQUVBLElBQUksY0FBYztBQUNkLGFBQU8sS0FBSyxPQUFPO0FBQUEsSUFDdkI7QUFBQSxFQUNKO0FBRUEsTUFBcUIsZ0JBQXJCLGNBQTJDLFlBQVk7QUFBQSxJQUNuRCxjQUFjO0FBQ1YsWUFBTTtBQUNOLFlBQU0sY0FBYyxlQUFlO0FBRW5DLG9DQUFBQyxRQUFRLFFBQVEsVUFBVSxZQUFZLENBQUMsU0FBUztBQUM1QyxZQUFJLEtBQUssU0FBUyxxQkFBcUI7QUFDbkMsZUFBSyxzQkFBc0IsSUFBSTtBQUFBLFFBQ25DO0FBQUEsTUFDSixDQUFDO0FBR0Qsb0NBQUFBLFFBQVEsUUFBUSxVQUFVLFlBQVksQ0FBQyxLQUFLLFdBQVc7QUFDbkQsWUFBSSxPQUFPLE9BQU8sZUFBZSxFQUFHO0FBR3BDLFlBQUksZ0JBQWdCLGFBQWEsUUFBUSx3QkFBd0IsUUFBUSxzQ0FBc0M7QUFDM0csZ0JBQU0sRUFBRSxhQUFhLElBQUk7QUFBQSxRQUM3QjtBQUdBLGNBQU0scUJBQXFCO0FBQUEsVUFDdkI7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxRQUNKO0FBQ0EsbUJBQVcscUJBQXFCLG9CQUFvQjtBQUNoRCxjQUFJLHFCQUFxQixLQUFLO0FBQzFCLGdCQUFJLGNBQWM7QUFDbEIsZ0JBQUksVUFBVSxJQUFJLGlCQUFpQjtBQUFBLFVBQ3ZDO0FBQUEsUUFDSjtBQUVBLFlBQUksSUFBSSxxQ0FBcUM7QUFDekMsY0FBSSxjQUFjO0FBQUEsUUFDdEI7QUFFQSxZQUFJLElBQUksZUFBZSxJQUFJLGVBQWUsMEJBQWlCO0FBQ3ZELGVBQUssY0FBYyxJQUFJLHFCQUFxQixHQUFHLENBQUM7QUFDaEQsaUJBQU8sUUFBUSxRQUFRLHlCQUFnQixJQUFJLFdBQVcsRUFBRSxJQUFJLFNBQVMsUUFBUSxHQUFHLENBQUM7QUFBQSxRQUNyRjtBQUVBLGdCQUFRLE1BQU0sdUNBQXVDLEtBQUssTUFBTTtBQUFBLE1BQ3BFLENBQUM7QUFBQSxJQUNMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBVUEsc0JBQXNCLE1BQU07QUFDeEIsb0JBQWMsSUFBSTtBQUNsQixXQUFLLGFBQWEsWUFBWSxNQUFNO0FBQ2hDLFlBQUksY0FBYyxNQUFNLE1BQU07QUFDMUIsd0JBQWMsSUFBSTtBQUFBLFFBQ3RCO0FBQUEsTUFDSixDQUFDO0FBRUQsV0FBSyxVQUFVLFlBQVksT0FBTyxZQUFZO0FBQzFDLGNBQU0sY0FBYyxTQUFTO0FBRTdCLFlBQUksQ0FBQyxlQUFlLEVBQUUsZUFBZSwyQkFBa0I7QUFDbkQsa0JBQVEsTUFBTSwyREFBMkQsT0FBTztBQUNoRjtBQUFBLFFBQ0o7QUFDQSxhQUFLLGNBQWMsSUFBSSxxQkFBcUIsT0FBTyxDQUFDO0FBRXBELGNBQU0sV0FBVyxNQUFNLHlCQUFnQixXQUFXLEVBQUUsU0FBUyxTQUFTLE1BQU0sT0FBTztBQUNuRixZQUFJLE9BQU8sU0FBUyxPQUFPLFVBQVU7QUFDakMsZUFBSyxZQUFZO0FBQUEsWUFDYixJQUFJLFFBQVE7QUFBQSxZQUNaLGFBQWE7QUFBQSxZQUNiLFNBQVM7QUFBQSxVQUNiLENBQUM7QUFBQSxRQUNMO0FBQUEsTUFDSixDQUFDO0FBQUEsSUFDTDtBQUFBLEVBQ0o7OztBT3RHQSxNQUFBQyxnQ0FBb0I7QUFDcEI7QUFFZSxXQUFSLGVBQWdDO0FBQ25DLGFBQVMsbUJBQW1CO0FBQ3hCLGtCQUFZLGtCQUFrQixFQUFFLE1BQU0sS0FBSyxJQUFJLElBQUksSUFBSyxDQUFDO0FBQUEsSUFDN0Q7QUFFQSxrQ0FBQUMsUUFBUSxPQUFPLFFBQVEsWUFBWSxPQUFPLGVBQWU7QUFDckQsVUFBSSxXQUFXLFNBQVMsa0JBQWtCO0FBQ3RDO0FBQUEsTUFDSjtBQUVBLFVBQUksWUFBWTtBQUVoQixVQUFJO0FBQ0EsY0FBTSxXQUFXLE1BQU0sTUFBTSxrQkFBa0IsRUFBRSxPQUFPLFdBQVcsQ0FBQztBQUNwRSxvQkFBWSxNQUFNLFNBQVMsS0FBSztBQUFBLE1BQ3BDLFNBQVMsR0FBRztBQUFBLE1BQUM7QUFFYixVQUFJLFdBQVc7QUFDWCxjQUFNLG9CQUFvQixNQUFNLHNCQUFzQixXQUFXO0FBQ2pFLFlBQUksQ0FBQyxtQkFBbUI7QUFDcEIsZ0JBQU0sb0JBQW9CLGFBQWEsU0FBUztBQUFBLFFBQ3BELFdBQVcsY0FBYyxtQkFBbUI7QUFDeEMsd0NBQUFBLFFBQVEsUUFBUSxPQUFPO0FBQUEsUUFDM0I7QUFBQSxNQUNKO0FBRUEsdUJBQWlCO0FBQUEsSUFDckIsQ0FBQztBQUVELHFCQUFpQjtBQUFBLEVBQ3JCOzs7QUN0Q0EsTUFBQUMsZ0NBQW9CO0FBR3BCLE1BQU0sd0JBQXdCO0FBNkI5QixNQUFxQixrQkFBckIsTUFBcUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFNakMsWUFBWSxTQUFTLGFBQWEsUUFBUSx1QkFBdUI7QUFDN0QsV0FBSyxTQUFTO0FBQ2QsV0FBSyxXQUFXO0FBQ2hCLFdBQUssZUFBZTtBQUFBLElBQ3hCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFRQSxNQUFNLE9BQU9DLFNBQVEsU0FBUyxDQUFDLEdBQUc7QUFDOUIsWUFBTTtBQUFBO0FBQUEsUUFBMEM7QUFBQSxVQUM1QyxTQUFTLEtBQUs7QUFBQSxVQUNkLGFBQWEsS0FBSztBQUFBLFVBQ2xCLFFBQUFBO0FBQUEsVUFDQTtBQUFBLFFBQ0o7QUFBQTtBQUNBLE1BQVMsUUFBUSxJQUFJLDRCQUE0QixHQUFHLEtBQUssUUFBUSxJQUFJLEtBQUssWUFBWSxJQUFJQSxPQUFNLElBQUksTUFBTTtBQUMxRyxZQUFNLDhCQUFBQyxRQUFRLFFBQVEsa0JBQWtCLEtBQUssUUFBUSxHQUFHLEVBQUUsTUFBTSxDQUFDLE1BQU07QUFDbkUsUUFBUyxRQUFRLE1BQU0seUNBQXlDLENBQUM7QUFDakUsY0FBTTtBQUFBLE1BQ1YsQ0FBQztBQUFBLElBQ0w7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBU0EsTUFBTSxRQUFRRCxTQUFRLFNBQVMsQ0FBQyxHQUFHO0FBQy9CLFlBQU0sS0FBSyxPQUFPLFdBQVc7QUFDN0IsWUFBTTtBQUFBO0FBQUEsUUFBcUM7QUFBQSxVQUN2QyxTQUFTLEtBQUs7QUFBQSxVQUNkLGFBQWEsS0FBSztBQUFBLFVBQ2xCO0FBQUEsVUFDQSxRQUFBQTtBQUFBLFVBQ0E7QUFBQSxRQUNKO0FBQUE7QUFDQSxNQUFTLFFBQVEsSUFBSSw2QkFBNkIsR0FBRyxLQUFLLFFBQVEsSUFBSSxLQUFLLFlBQVksSUFBSUEsT0FBTSxJQUFJLE1BQU0sRUFBRSxJQUFJLE1BQU07QUFFdkgsWUFBTTtBQUFBO0FBQUEsUUFDRixNQUFNLDhCQUFBQyxRQUFRLFFBQVEsa0JBQWtCLEtBQUssUUFBUSxHQUFHLEVBQUUsTUFBTSxDQUFDLE1BQU07QUFDbkUsVUFBUyxRQUFRLE1BQU0sNEJBQTRCLENBQUM7QUFDcEQsaUJBQU87QUFBQSxZQUNIO0FBQUEsWUFDQSxTQUFTLEtBQUs7QUFBQSxZQUNkLGFBQWEsS0FBSztBQUFBLFlBQ2xCLE9BQU87QUFBQSxjQUNILFNBQVMsMkNBQTJDLENBQUM7QUFBQSxZQUN6RDtBQUFBLFVBQ0o7QUFBQSxRQUNKLENBQUM7QUFBQTtBQUVMLE1BQVMsUUFBUSxJQUFJLDJDQUEyQyxLQUFLLFVBQVUsUUFBUSxDQUFDO0FBRXhGLFVBQUksQ0FBQyxZQUFZLE9BQU8sYUFBYSxVQUFVO0FBQzNDLGNBQU0sSUFBSSxNQUFNLDhDQUE4QyxPQUFPLFFBQVEsRUFBRTtBQUFBLE1BQ25GO0FBRUEsVUFBSSxXQUFXLFlBQVksU0FBUyxPQUFPO0FBQ3ZDLFFBQVMsUUFBUSxJQUFJLG9DQUFvQyxNQUFNLEVBQUUsSUFBSSxTQUFTLEtBQUs7QUFDbkYsY0FBTSxJQUFJLE1BQU0sU0FBUyxNQUFNLFdBQVcsZUFBZTtBQUFBLE1BQzdEO0FBRUEsTUFBUyxRQUFRLElBQUksaUNBQWlDLE1BQU0sRUFBRSxJQUFJLFNBQVMsTUFBTTtBQUNqRixhQUFPLFNBQVMsVUFBVSxDQUFDO0FBQUEsSUFDL0I7QUFBQSxJQUVBLFVBQVUsTUFBTSxXQUFXO0FBQ3ZCLFlBQU0sSUFBSSxNQUFNLDJEQUEyRDtBQUFBLElBQy9FO0FBQUEsRUFDSjs7O0FkcEZBLE1BQU0sa0JBQWtCLElBQUksZ0JBQWdCLHdCQUF3QixlQUFlLDhCQUE4QjtBQUdqSCxhQUFXLGlCQUFpQixTQUFTLENBQUMsVUFBVTtBQUM1QyxvQkFDSyxPQUFPLHNCQUFzQjtBQUFBLE1BQzFCLFNBQVMsbUJBQW1CLE1BQU0sT0FBTyxXQUFXLE1BQU0sT0FBTztBQUFBLE1BQ2pFLE9BQU8sTUFBTSxPQUFPO0FBQUEsSUFDeEIsQ0FBQyxFQUNBLE1BQU0sQ0FBQyxNQUFNO0FBQUEsSUFFZCxDQUFDO0FBQUEsRUFDVCxDQUFDO0FBRUQsYUFBVyxpQkFBaUIsc0JBQXNCLENBQUMsVUFBVTtBQUN6RCxvQkFDSyxPQUFPLHNCQUFzQjtBQUFBLE1BQzFCLFNBQVMsZ0NBQWdDLE1BQU0sTUFBTTtBQUFBLE1BQ3JELE9BQU8sTUFBTSxRQUFRO0FBQUEsSUFDekIsQ0FBQyxFQUNBLE1BQU0sQ0FBQyxNQUFNO0FBQUEsSUFFZCxDQUFDO0FBQUEsRUFDVCxDQUFDO0FBRUQsTUFBTSxlQUFlLElBQUkscUJBQXFCLGVBQWU7QUFJN0QsTUFBTSxZQUFZLElBQUksY0FBYztBQUVwQyxNQUFNLE1BQU0sSUFBSSx1QkFBdUI7QUFBQSxJQUNuQztBQUFBLEVBQ0osQ0FBQztBQVNELE1BQU0sYUFBYTtBQUFBLElBQ2Y7QUFBQSxJQUNBO0FBQUEsRUFDSjtBQUVBLFVBQVEsSUFBSTtBQUFBLElBQ1IsOEJBQUFDLFFBQVEsVUFBVSw0QkFBNEI7QUFBQSxJQUM5Qyw4QkFBQUEsUUFBUSxPQUFPLE9BQU87QUFBQTtBQUFBLElBRXRCLDhCQUFBQSxRQUFRLFFBQVEsUUFBUSxjQUFjLElBQUk7QUFBQSxFQUM5QyxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUMsU0FBUyxRQUFRLHFCQUFxQixNQUFNO0FBRWxELFVBQU0sYUFBYSw4QkFBQUEsUUFBUSxRQUFRLFFBQVE7QUFDM0MsaUJBQWE7QUFBQSxNQUNUO0FBQUEsMkJBQ21CLEtBQUssVUFBVSxPQUFPLENBQUM7QUFBQSxrQkFDaEMsS0FBSyxVQUFVLE1BQU0sQ0FBQztBQUFBLHdCQUNoQixLQUFLLElBQUksQ0FBQztBQUFBLG9DQUNFLHFCQUFxQixXQUFXLFVBQVU7QUFBQTtBQUFBLElBRTFFO0FBQUEsRUFDSixDQUFDO0FBRUQsT0FBSyxhQUFhO0FBRWxCLEVBQVksYUFBYTsiLAogICJuYW1lcyI6IFsiZ2xvYmFsVGhpcyIsICJjaHJvbWUiLCAicnVudGltZSIsICJpZCIsICJFcnJvciIsICJicm93c2VyIiwgIkNIUk9NRV9TRU5EX01FU1NBR0VfQ0FMTEJBQ0tfTk9fUkVTUE9OU0VfTUVTU0FHRSIsICJ3cmFwQVBJcyIsICJleHRlbnNpb25BUElzIiwgImFwaU1ldGFkYXRhIiwgIk9iamVjdCIsICJrZXlzIiwgImxlbmd0aCIsICJEZWZhdWx0V2Vha01hcCIsICJXZWFrTWFwIiwgImNvbnN0cnVjdG9yIiwgImNyZWF0ZUl0ZW0iLCAiaXRlbXMiLCAidW5kZWZpbmVkIiwgImdldCIsICJrZXkiLCAiaGFzIiwgInNldCIsICJpc1RoZW5hYmxlIiwgInZhbHVlIiwgInRoZW4iLCAibWFrZUNhbGxiYWNrIiwgInByb21pc2UiLCAibWV0YWRhdGEiLCAiY2FsbGJhY2tBcmdzIiwgImxhc3RFcnJvciIsICJyZWplY3QiLCAibWVzc2FnZSIsICJzaW5nbGVDYWxsYmFja0FyZyIsICJyZXNvbHZlIiwgInBsdXJhbGl6ZUFyZ3VtZW50cyIsICJudW1BcmdzIiwgIndyYXBBc3luY0Z1bmN0aW9uIiwgIm5hbWUiLCAiYXN5bmNGdW5jdGlvbldyYXBwZXIiLCAidGFyZ2V0IiwgImFyZ3MiLCAibWluQXJncyIsICJtYXhBcmdzIiwgIlByb21pc2UiLCAiZmFsbGJhY2tUb05vQ2FsbGJhY2siLCAiY2JFcnJvciIsICJjb25zb2xlIiwgIndhcm4iLCAibm9DYWxsYmFjayIsICJ3cmFwTWV0aG9kIiwgIm1ldGhvZCIsICJ3cmFwcGVyIiwgIlByb3h5IiwgImFwcGx5IiwgInRhcmdldE1ldGhvZCIsICJ0aGlzT2JqIiwgImNhbGwiLCAiaGFzT3duUHJvcGVydHkiLCAiRnVuY3Rpb24iLCAiYmluZCIsICJwcm90b3R5cGUiLCAid3JhcE9iamVjdCIsICJ3cmFwcGVycyIsICJjYWNoZSIsICJjcmVhdGUiLCAiaGFuZGxlcnMiLCAicHJveHlUYXJnZXQiLCAicHJvcCIsICJyZWNlaXZlciIsICJkZWZpbmVQcm9wZXJ0eSIsICJjb25maWd1cmFibGUiLCAiZW51bWVyYWJsZSIsICJkZXNjIiwgIlJlZmxlY3QiLCAiZGVsZXRlUHJvcGVydHkiLCAid3JhcEV2ZW50IiwgIndyYXBwZXJNYXAiLCAiYWRkTGlzdGVuZXIiLCAibGlzdGVuZXIiLCAiaGFzTGlzdGVuZXIiLCAicmVtb3ZlTGlzdGVuZXIiLCAib25SZXF1ZXN0RmluaXNoZWRXcmFwcGVycyIsICJvblJlcXVlc3RGaW5pc2hlZCIsICJyZXEiLCAid3JhcHBlZFJlcSIsICJnZXRDb250ZW50IiwgIm9uTWVzc2FnZVdyYXBwZXJzIiwgIm9uTWVzc2FnZSIsICJzZW5kZXIiLCAic2VuZFJlc3BvbnNlIiwgImRpZENhbGxTZW5kUmVzcG9uc2UiLCAid3JhcHBlZFNlbmRSZXNwb25zZSIsICJzZW5kUmVzcG9uc2VQcm9taXNlIiwgInJlc3BvbnNlIiwgInJlc3VsdCIsICJlcnIiLCAiaXNSZXN1bHRUaGVuYWJsZSIsICJzZW5kUHJvbWlzZWRSZXN1bHQiLCAibXNnIiwgImVycm9yIiwgIl9fbW96V2ViRXh0ZW5zaW9uUG9seWZpbGxSZWplY3RfXyIsICJjYXRjaCIsICJ3cmFwcGVkU2VuZE1lc3NhZ2VDYWxsYmFjayIsICJyZXBseSIsICJ3cmFwcGVkU2VuZE1lc3NhZ2UiLCAiYXBpTmFtZXNwYWNlT2JqIiwgIndyYXBwZWRDYiIsICJwdXNoIiwgInNlbmRNZXNzYWdlIiwgInN0YXRpY1dyYXBwZXJzIiwgImRldnRvb2xzIiwgIm5ldHdvcmsiLCAib25NZXNzYWdlRXh0ZXJuYWwiLCAidGFicyIsICJzZXR0aW5nTWV0YWRhdGEiLCAiY2xlYXIiLCAicHJpdmFjeSIsICJzZXJ2aWNlcyIsICJ3ZWJzaXRlcyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJicm93c2VyIiwgInNldHRpbmdzIiwgImltcG9ydF93ZWJleHRlbnNpb25fcG9seWZpbGwiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAic2V0dGluZ3MiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAiYnJvd3NlciIsICJtZXRob2QiLCAiYmxvY2tzIiwgImltcG9ydF93ZWJleHRlbnNpb25fcG9seWZpbGwiLCAiX1Rvb2xzIiwgInJ1bGVzIiwgImltcG9ydF93ZWJleHRlbnNpb25fcG9seWZpbGwiLCAiYnJvd3NlciIsICJjcG1NZXNzYWdpbmciLCAiYnJvd3NlciIsICJydWxlcyIsICJuYXRpdmVNZXNzYWdpbmciLCAibWV0aG9kIiwgImltcG9ydF93ZWJleHRlbnNpb25fcG9seWZpbGwiLCAiaW1wb3J0X3dlYmV4dGVuc2lvbl9wb2x5ZmlsbCIsICJleHRyYWN0SG9zdG5hbWUiLCAicGFyc2VVc2VyQWdlbnRTdHJpbmciLCAiYnJvd3NlciIsICJpbXBvcnRfd2ViZXh0ZW5zaW9uX3BvbHlmaWxsIiwgImJyb3dzZXIiLCAiaW1wb3J0X3dlYmV4dGVuc2lvbl9wb2x5ZmlsbCIsICJtZXRob2QiLCAiYnJvd3NlciIsICJicm93c2VyIl0KfQo=

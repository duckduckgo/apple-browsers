"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __esm = (fn, res, err) => function __init() {
    if (err) throw err[0];
    try {
      return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
    } catch (e) {
      throw err = [e], e;
    }
  };
  var __commonJS = (cb, mod) => function __require() {
    try {
      return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
    } catch (e) {
      throw mod = 0, e;
    }
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // node_modules/webextension-polyfill/dist/browser-polyfill.js
  var require_browser_polyfill = __commonJS({
    "node_modules/webextension-polyfill/dist/browser-polyfill.js"(exports2, module2) {
      (function(global2, factory) {
        if (typeof define === "function" && define.amd) {
          define("webextension-polyfill", ["module"], factory);
        } else if (typeof exports2 !== "undefined") {
          factory(module2);
        } else {
          var mod = {
            exports: {}
          };
          factory(mod);
          global2.browser = mod.exports;
        }
      })(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : exports2, function(module3) {
        "use strict";
        if (!(globalThis.chrome && globalThis.chrome.runtime && globalThis.chrome.runtime.id)) {
          throw new Error("This script should only be loaded in a browser extension.");
        }
        if (!(globalThis.browser && globalThis.browser.runtime && globalThis.browser.runtime.id)) {
          const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received.";
          const wrapAPIs = (extensionAPIs) => {
            const apiMetadata = {
              "alarms": {
                "clear": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "clearAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "get": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "bookmarks": {
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getChildren": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getRecent": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getSubTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTree": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "browserAction": {
                "disable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "enable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "getBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "openPopup": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "browsingData": {
                "remove": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "removeCache": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCookies": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeDownloads": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFormData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeHistory": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeLocalStorage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePasswords": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePluginData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "settings": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "commands": {
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "contextMenus": {
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "cookies": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAllCookieStores": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "set": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "devtools": {
                "inspectedWindow": {
                  "eval": {
                    "minArgs": 1,
                    "maxArgs": 2,
                    "singleCallbackArg": false
                  }
                },
                "panels": {
                  "create": {
                    "minArgs": 3,
                    "maxArgs": 3,
                    "singleCallbackArg": true
                  },
                  "elements": {
                    "createSidebarPane": {
                      "minArgs": 1,
                      "maxArgs": 1
                    }
                  }
                }
              },
              "downloads": {
                "cancel": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "download": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "erase": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFileIcon": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "open": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "pause": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFile": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "resume": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "extension": {
                "isAllowedFileSchemeAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "isAllowedIncognitoAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "history": {
                "addUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "deleteRange": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getVisits": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "i18n": {
                "detectLanguage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAcceptLanguages": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "identity": {
                "launchWebAuthFlow": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "idle": {
                "queryState": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "management": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getSelf": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setEnabled": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "uninstallSelf": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "notifications": {
                "clear": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPermissionLevel": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "pageAction": {
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "hide": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "permissions": {
                "contains": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "request": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "runtime": {
                "getBackgroundPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPlatformInfo": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "openOptionsPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "requestUpdateCheck": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "sendMessage": {
                  "minArgs": 1,
                  "maxArgs": 3
                },
                "sendNativeMessage": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "setUninstallURL": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "sessions": {
                "getDevices": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getRecentlyClosed": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "restore": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "storage": {
                "local": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                },
                "managed": {
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  }
                },
                "sync": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                }
              },
              "tabs": {
                "captureVisibleTab": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "detectLanguage": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "discard": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "duplicate": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "executeScript": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getZoom": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getZoomSettings": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goBack": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goForward": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "highlight": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "insertCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "query": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "reload": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "sendMessage": {
                  "minArgs": 2,
                  "maxArgs": 3
                },
                "setZoom": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "setZoomSettings": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "update": {
                  "minArgs": 1,
                  "maxArgs": 2
                }
              },
              "topSites": {
                "get": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "webNavigation": {
                "getAllFrames": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFrame": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "webRequest": {
                "handlerBehaviorChanged": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "windows": {
                "create": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getLastFocused": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              }
            };
            if (Object.keys(apiMetadata).length === 0) {
              throw new Error("api-metadata.json has not been included in browser-polyfill");
            }
            class DefaultWeakMap extends WeakMap {
              constructor(createItem, items = void 0) {
                super(items);
                this.createItem = createItem;
              }
              get(key) {
                if (!this.has(key)) {
                  this.set(key, this.createItem(key));
                }
                return super.get(key);
              }
            }
            const isThenable = (value) => {
              return value && typeof value === "object" && typeof value.then === "function";
            };
            const makeCallback = (promise, metadata) => {
              return (...callbackArgs) => {
                if (extensionAPIs.runtime.lastError) {
                  promise.reject(new Error(extensionAPIs.runtime.lastError.message));
                } else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) {
                  promise.resolve(callbackArgs[0]);
                } else {
                  promise.resolve(callbackArgs);
                }
              };
            };
            const pluralizeArguments = (numArgs) => numArgs == 1 ? "argument" : "arguments";
            const wrapAsyncFunction = (name, metadata) => {
              return function asyncFunctionWrapper(target, ...args) {
                if (args.length < metadata.minArgs) {
                  throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
                }
                if (args.length > metadata.maxArgs) {
                  throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
                }
                return new Promise((resolve, reject) => {
                  if (metadata.fallbackToNoCallback) {
                    try {
                      target[name](...args, makeCallback({
                        resolve,
                        reject
                      }, metadata));
                    } catch (cbError) {
                      console.warn(`${name} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `, cbError);
                      target[name](...args);
                      metadata.fallbackToNoCallback = false;
                      metadata.noCallback = true;
                      resolve();
                    }
                  } else if (metadata.noCallback) {
                    target[name](...args);
                    resolve();
                  } else {
                    target[name](...args, makeCallback({
                      resolve,
                      reject
                    }, metadata));
                  }
                });
              };
            };
            const wrapMethod = (target, method2, wrapper) => {
              return new Proxy(method2, {
                apply(targetMethod, thisObj, args) {
                  return wrapper.call(thisObj, target, ...args);
                }
              });
            };
            let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);
            const wrapObject = (target, wrappers = {}, metadata = {}) => {
              let cache = /* @__PURE__ */ Object.create(null);
              let handlers = {
                has(proxyTarget2, prop) {
                  return prop in target || prop in cache;
                },
                get(proxyTarget2, prop, receiver) {
                  if (prop in cache) {
                    return cache[prop];
                  }
                  if (!(prop in target)) {
                    return void 0;
                  }
                  let value = target[prop];
                  if (typeof value === "function") {
                    if (typeof wrappers[prop] === "function") {
                      value = wrapMethod(target, target[prop], wrappers[prop]);
                    } else if (hasOwnProperty(metadata, prop)) {
                      let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                      value = wrapMethod(target, target[prop], wrapper);
                    } else {
                      value = value.bind(target);
                    }
                  } else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) {
                    value = wrapObject(value, wrappers[prop], metadata[prop]);
                  } else if (hasOwnProperty(metadata, "*")) {
                    value = wrapObject(value, wrappers[prop], metadata["*"]);
                  } else {
                    Object.defineProperty(cache, prop, {
                      configurable: true,
                      enumerable: true,
                      get() {
                        return target[prop];
                      },
                      set(value2) {
                        target[prop] = value2;
                      }
                    });
                    return value;
                  }
                  cache[prop] = value;
                  return value;
                },
                set(proxyTarget2, prop, value, receiver) {
                  if (prop in cache) {
                    cache[prop] = value;
                  } else {
                    target[prop] = value;
                  }
                  return true;
                },
                defineProperty(proxyTarget2, prop, desc) {
                  return Reflect.defineProperty(cache, prop, desc);
                },
                deleteProperty(proxyTarget2, prop) {
                  return Reflect.deleteProperty(cache, prop);
                }
              };
              let proxyTarget = Object.create(target);
              return new Proxy(proxyTarget, handlers);
            };
            const wrapEvent = (wrapperMap) => ({
              addListener(target, listener, ...args) {
                target.addListener(wrapperMap.get(listener), ...args);
              },
              hasListener(target, listener) {
                return target.hasListener(wrapperMap.get(listener));
              },
              removeListener(target, listener) {
                target.removeListener(wrapperMap.get(listener));
              }
            });
            const onRequestFinishedWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onRequestFinished(req) {
                const wrappedReq = wrapObject(req, {}, {
                  getContent: {
                    minArgs: 0,
                    maxArgs: 0
                  }
                });
                listener(wrappedReq);
              };
            });
            const onMessageWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onMessage(message, sender, sendResponse) {
                let didCallSendResponse = false;
                let wrappedSendResponse;
                let sendResponsePromise = new Promise((resolve) => {
                  wrappedSendResponse = function(response) {
                    didCallSendResponse = true;
                    resolve(response);
                  };
                });
                let result;
                try {
                  result = listener(message, sender, wrappedSendResponse);
                } catch (err) {
                  result = Promise.reject(err);
                }
                const isResultThenable = result !== true && isThenable(result);
                if (result !== true && !isResultThenable && !didCallSendResponse) {
                  return false;
                }
                const sendPromisedResult = (promise) => {
                  promise.then((msg) => {
                    sendResponse(msg);
                  }, (error) => {
                    let message2;
                    if (error && (error instanceof Error || typeof error.message === "string")) {
                      message2 = error.message;
                    } else {
                      message2 = "An unexpected error occurred";
                    }
                    sendResponse({
                      __mozWebExtensionPolyfillReject__: true,
                      message: message2
                    });
                  }).catch((err) => {
                    console.error("Failed to send onMessage rejected reply", err);
                  });
                };
                if (isResultThenable) {
                  sendPromisedResult(result);
                } else {
                  sendPromisedResult(sendResponsePromise);
                }
                return true;
              };
            });
            const wrappedSendMessageCallback = ({
              reject,
              resolve
            }, reply) => {
              if (extensionAPIs.runtime.lastError) {
                if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) {
                  resolve();
                } else {
                  reject(new Error(extensionAPIs.runtime.lastError.message));
                }
              } else if (reply && reply.__mozWebExtensionPolyfillReject__) {
                reject(new Error(reply.message));
              } else {
                resolve(reply);
              }
            };
            const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
              if (args.length < metadata.minArgs) {
                throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
              }
              if (args.length > metadata.maxArgs) {
                throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
              }
              return new Promise((resolve, reject) => {
                const wrappedCb = wrappedSendMessageCallback.bind(null, {
                  resolve,
                  reject
                });
                args.push(wrappedCb);
                apiNamespaceObj.sendMessage(...args);
              });
            };
            const staticWrappers = {
              devtools: {
                network: {
                  onRequestFinished: wrapEvent(onRequestFinishedWrappers)
                }
              },
              runtime: {
                onMessage: wrapEvent(onMessageWrappers),
                onMessageExternal: wrapEvent(onMessageWrappers),
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 1,
                  maxArgs: 3
                })
              },
              tabs: {
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 2,
                  maxArgs: 3
                })
              }
            };
            const settingMetadata = {
              clear: {
                minArgs: 1,
                maxArgs: 1
              },
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              set: {
                minArgs: 1,
                maxArgs: 1
              }
            };
            apiMetadata.privacy = {
              network: {
                "*": settingMetadata
              },
              services: {
                "*": settingMetadata
              },
              websites: {
                "*": settingMetadata
              }
            };
            return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
          };
          module3.exports = wrapAPIs(chrome);
        } else {
          module3.exports = globalThis.browser;
        }
      });
    }
  });

  // shared/js/background/wrapper.js
  var wrapper_exports = {};
  __export(wrapper_exports, {
    changeTabURL: () => changeTabURL,
    createAlarm: () => createAlarm,
    executeScript: () => executeScript,
    getDDGTabUrls: () => getDDGTabUrls,
    getExtensionId: () => getExtensionId,
    getExtensionURL: () => getExtensionURL,
    getExtensionVersion: () => getExtensionVersion,
    getFromManagedStorage: () => getFromManagedStorage,
    getFromSessionStorage: () => getFromSessionStorage,
    getFromStorage: () => getFromStorage,
    getManifestVersion: () => getManifestVersion,
    insertCSS: () => insertCSS,
    mergeSavedSettings: () => mergeSavedSettings,
    normalizeTabData: () => normalizeTabData,
    openExtensionPage: () => openExtensionPage,
    removeFromSessionStorage: () => removeFromSessionStorage,
    sessionStorageFallback: () => sessionStorageFallback,
    setActionIcon: () => setActionIcon,
    setToSessionStorage: () => setToSessionStorage,
    setUninstallURL: () => setUninstallURL,
    syncToStorage: () => syncToStorage
  });
  function getExtensionURL(path) {
    return import_webextension_polyfill.default.runtime.getURL(path);
  }
  function getExtensionVersion() {
    const manifest = import_webextension_polyfill.default.runtime.getManifest();
    return manifest.version;
  }
  function openExtensionPage(path) {
    import_webextension_polyfill.default.tabs.create({ url: getExtensionURL(path) });
  }
  async function setActionIcon(iconPath, tabId) {
    if (typeof import_webextension_polyfill.default.action === "undefined") {
      return import_webextension_polyfill.default.browserAction.setIcon({ path: iconPath, tabId });
    }
    return import_webextension_polyfill.default.action.setIcon({ path: iconPath, tabId });
  }
  function getManifestVersion() {
    const manifest = import_webextension_polyfill.default.runtime.getManifest();
    return manifest.manifest_version;
  }
  function syncToStorage(data) {
    return import_webextension_polyfill.default.storage.local.set(data);
  }
  async function getFromStorage(key, cb) {
    const result = await import_webextension_polyfill.default.storage.local.get(key);
    return result[key];
  }
  async function getFromManagedStorage(keys, cb) {
    try {
      return await import_webextension_polyfill.default.storage.managed.get(keys);
    } catch (e) {
      console.log("get managed failed", e);
    }
    return {};
  }
  function getExtensionId() {
    return import_webextension_polyfill.default.runtime.id;
  }
  function normalizeTabData(tabData) {
    const tabId = "tabId" in tabData ? tabData.tabId : tabData.id;
    const url = tabData.url;
    const status = "status" in tabData ? tabData.status : null;
    const requestId = "requestId" in tabData ? tabData.requestId : void 0;
    const incognito = "incognito" in tabData && !!tabData.incognito;
    return {
      tabId,
      url,
      requestId,
      status,
      incognito
    };
  }
  function mergeSavedSettings(settings4, results) {
    return Object.assign(settings4, results);
  }
  async function getDDGTabUrls() {
    const tabs = await import_webextension_polyfill.default.tabs.query({ url: "https://*.duckduckgo.com/*" }) || [];
    return tabs.map((tab) => tab.url);
  }
  function setUninstallURL(url) {
    import_webextension_polyfill.default.runtime.setUninstallURL(url);
  }
  function changeTabURL(tabId, url) {
    return import_webextension_polyfill.default.tabs.update(tabId, { url });
  }
  function convertScriptingAPIOptionsForTabsAPI(options) {
    if (typeof options !== "object") {
      throw new Error("Missing/invalid options Object.");
    }
    if (typeof options.file !== "undefined" || typeof options.frameId !== "undefined" || typeof options.runAt !== "undefined" || typeof options.allFrames !== "undefined" || typeof options.code !== "undefined") {
      throw new Error("Please provide options compatible with the (MV3) scripting API, instead of the (MV2) tabs API.");
    }
    if (typeof options.world !== "undefined") {
      throw new Error("World targetting not supported by MV2.");
    }
    const { allFrames, frameIds, tabId } = options.target;
    delete options.target;
    if (Array.isArray(frameIds) && frameIds.length > 0) {
      if (frameIds.length > 1) {
        throw new Error("Targetting multiple frames by ID not supported by MV2.");
      }
      options.frameId = frameIds[0];
    }
    if (typeof options.files !== "undefined") {
      if (Array.isArray(options.files) && options.files.length > 0) {
        if (options.files.length > 1) {
          throw new Error("Inserting multiple stylesheets/scripts in one go not supported by MV2.");
        }
        options.file = options.files[0];
      }
      delete options.files;
    }
    if (typeof allFrames !== "undefined") {
      options.allFrames = allFrames;
    }
    if (typeof options.injectImmediately !== "undefined") {
      if (options.injectImmediately) {
        options.runAt = "document_start";
      }
      delete options.injectImmediately;
    }
    let stringifiedArgs = "";
    if (typeof options.args !== "undefined") {
      if (Array.isArray(options.args)) {
        stringifiedArgs = "..." + JSON.stringify(options.args);
      }
      delete options.args;
    }
    if (typeof options.func !== "undefined") {
      if (typeof options.func === "function") {
        options.code = "(" + options.func.toString() + ")(" + stringifiedArgs + ")";
      }
      delete options.func;
    }
    return [tabId, options];
  }
  async function executeScript(options) {
    if (typeof import_webextension_polyfill.default.scripting === "undefined") {
      return await import_webextension_polyfill.default.tabs.executeScript(
        ...convertScriptingAPIOptionsForTabsAPI(options)
      );
    }
    return await import_webextension_polyfill.default.scripting.executeScript(options);
  }
  async function insertCSS(options) {
    if (typeof import_webextension_polyfill.default.scripting === "undefined") {
      return await import_webextension_polyfill.default.tabs.insertCSS(
        ...convertScriptingAPIOptionsForTabsAPI(options)
      );
    }
    return await import_webextension_polyfill.default.scripting.insertCSS(options);
  }
  async function setToSessionStorage(key, data) {
    if (typeof key !== "string") {
      throw new Error("Invalid storage key, string expected.");
    }
    if (sessionStorageSupported) {
      return await import_webextension_polyfill.default.storage.session.set({ [key]: data });
    }
    sessionStorageFallback.set(key, data);
  }
  async function getFromSessionStorage(key) {
    if (typeof key !== "string") {
      throw new Error("Invalid storage key, string expected.");
    }
    if (sessionStorageSupported) {
      const result = await import_webextension_polyfill.default.storage.session.get([key]);
      return result[key];
    }
    return sessionStorageFallback.get(key);
  }
  async function removeFromSessionStorage(key) {
    if (typeof key !== "string") {
      throw new Error("Invalid storage key, string expected.");
    }
    if (sessionStorageSupported) {
      return await import_webextension_polyfill.default.storage.session.remove(key);
    }
    return sessionStorageFallback.delete(key);
  }
  async function createAlarm(name, alarmInfo) {
    const existingAlarm = await import_webextension_polyfill.default.alarms.get(name);
    if (!existingAlarm) {
      return await import_webextension_polyfill.default.alarms.create(name, alarmInfo);
    }
  }
  var import_webextension_polyfill, sessionStorageSupported, sessionStorageFallback;
  var init_wrapper = __esm({
    "shared/js/background/wrapper.js"() {
      "use strict";
      import_webextension_polyfill = __toESM(require_browser_polyfill());
      sessionStorageSupported = typeof import_webextension_polyfill.default.storage.session !== "undefined";
      sessionStorageFallback = sessionStorageSupported ? null : /* @__PURE__ */ new Map();
    }
  });

  // shared/data/defaultSettings.js
  var require_defaultSettings = __commonJS({
    "shared/data/defaultSettings.js"(exports2, module2) {
      "use strict";
      module2.exports = {
        httpsEverywhereEnabled: true,
        embeddedTweetsEnabled: false,
        GPC: true,
        atb: null,
        set_atb: null,
        "config-etag": null,
        "httpsUpgradeBloomFilter-etag": null,
        "httpsDontUpgradeBloomFilters-etag": null,
        "httpsUpgradeList-etag": null,
        "httpsDontUpgradeList-etag": null,
        hasSeenPostInstall: false,
        extiSent: false,
        "tds-etag": null,
        lastTdsUpdate: 0,
        fireButtonClearHistoryEnabled: true,
        fireButtonTabClearEnabled: true,
        useNoAiSearch: false
      };
    }
  });

  // shared/js/background/settings.js
  var require_settings = __commonJS({
    "shared/js/background/settings.js"(exports2, module2) {
      "use strict";
      var defaultSettings = require_defaultSettings();
      var browserWrapper = (init_wrapper(), __toCommonJS(wrapper_exports));
      var onSettingUpdate = new EventTarget();
      if (typeof CustomEvent === "undefined") globalThis.CustomEvent = Event;
      var MANAGED_SETTINGS = ["hasSeenPostInstall"];
      var settings4 = {};
      var isReady = false;
      var _ready = init().then(() => {
        isReady = true;
        console.log("Settings are loaded");
      });
      async function init() {
        buildSettingsFromDefaults();
        await buildSettingsFromManagedStorage();
        await buildSettingsFromLocalStorage();
      }
      function ready() {
        return _ready;
      }
      function checkForLegacyKeys() {
        const legacyKeys = {
          // Keys to migrate
          whitelisted: "allowlisted",
          whitelistOptIn: "allowlistOptIn",
          // Keys to remove
          advanced_options: null,
          allowingDnrRulesByClickToLoadRuleAction: null,
          clickToLoadClicks: null,
          cookieExcludeList: null,
          dev: null,
          ducky: null,
          extensionIsEnabled: null,
          failedUpgrades: null,
          last_search: null,
          lastsearch_enabled: null,
          meanings: null,
          safesearch: null,
          socialBlockingIsEnabled: null,
          totalUpgrades: null,
          trackerBlockingEnabled: null,
          use_post: null,
          version: null,
          youtubePreviewsEnabled: null,
          zeroclick_google_right: null,
          "surrogates-etag": null,
          "brokenSiteList-etag": null,
          "surrogateList-etag": null,
          "trackersWhitelist-etag": null,
          "trackersWhitelistTemporary-etag": null
        };
        let syncNeeded = false;
        for (const legacyKey in legacyKeys) {
          const key = legacyKeys[legacyKey];
          if (!(legacyKey in settings4)) {
            continue;
          }
          syncNeeded = true;
          const legacyValue = settings4[legacyKey];
          if (key && legacyValue) {
            settings4[key] = legacyValue;
          }
          delete settings4[legacyKey];
        }
        if (syncNeeded) {
          syncSettingTolocalStorage();
        }
      }
      async function buildSettingsFromLocalStorage() {
        const results = await browserWrapper.getFromStorage(["settings"]);
        if (!results) return;
        settings4 = browserWrapper.mergeSavedSettings(settings4, results);
        checkForLegacyKeys();
      }
      async function buildSettingsFromManagedStorage() {
        const results = await browserWrapper.getFromManagedStorage(MANAGED_SETTINGS);
        settings4 = browserWrapper.mergeSavedSettings(settings4, results);
      }
      function buildSettingsFromDefaults() {
        settings4 = Object.assign({}, defaultSettings);
      }
      function syncSettingTolocalStorage() {
        return browserWrapper.syncToStorage({ settings: settings4 });
      }
      function getSetting(name) {
        if (!isReady) {
          console.warn(`Settings: getSetting() Settings not loaded: ${name}`);
          return;
        }
        if (name === "all") name = null;
        if (name) {
          return settings4[name];
        } else {
          return settings4;
        }
      }
      function updateSetting(name, value) {
        if (!isReady) {
          console.warn(`Settings: updateSetting() Setting not loaded: ${name}`);
          return;
        }
        settings4[name] = value;
        syncSettingTolocalStorage().then(() => {
          onSettingUpdate.dispatchEvent(new CustomEvent(name, { detail: value }));
        });
      }
      function incrementNumericSetting(name, increment = 1) {
        if (!isReady) {
          console.warn("Settings: incrementNumericSetting() Setting not loaded:", name);
          return;
        }
        let value = settings4[name];
        if (typeof value !== "number" || isNaN(value)) {
          value = 0;
        }
        updateSetting(name, value + increment);
      }
      function removeSetting(name) {
        if (!isReady) {
          console.warn(`Settings: removeSetting() Setting not loaded: ${name}`);
          return;
        }
        if (settings4[name]) {
          delete settings4[name];
          syncSettingTolocalStorage();
        }
      }
      function logSettings() {
        browserWrapper.getFromStorage(["settings"]).then((s) => {
          console.log(s.settings);
        });
      }
      module2.exports = {
        getSetting,
        updateSetting,
        incrementNumericSetting,
        removeSetting,
        logSettings,
        ready,
        onSettingUpdate
      };
    }
  });

  // shared/js/shared-utils/parse-user-agent-string.js
  var require_parse_user_agent_string = __commonJS({
    "shared/js/shared-utils/parse-user-agent-string.js"(exports2, module2) {
      "use strict";
      module2.exports = (uaString) => {
        if (!globalThis.navigator) return {};
        if (!uaString) uaString = globalThis.navigator.userAgent;
        let browser9;
        let version;
        try {
          let parsedUaParts = uaString.match(/(Firefox|Chrome|Edg)\/([0-9]+)/);
          const isEdge = /(Edge?)\/([0-9]+)/;
          const isOpera = /(OPR)\/([0-9]+)/;
          if (uaString.match(isEdge)) {
            parsedUaParts = uaString.match(isEdge);
          } else if (uaString.match(isOpera)) {
            parsedUaParts = uaString.match(isOpera);
            parsedUaParts[1] = "Opera";
          }
          browser9 = parsedUaParts[1];
          version = parsedUaParts[2];
          if (globalThis.navigator.brave) {
            browser9 = "Brave";
          }
        } catch (e) {
          browser9 = version = "";
        }
        let os = "o";
        if (globalThis.navigator.userAgent.indexOf("Windows") !== -1) os = "w";
        if (globalThis.navigator.userAgent.indexOf("Mac") !== -1) os = "m";
        if (globalThis.navigator.userAgent.indexOf("Linux") !== -1) os = "l";
        return {
          os,
          browser: browser9,
          version
        };
      };
    }
  });

  // shared/js/shared-utils/sha1.js
  var require_sha1 = __commonJS({
    "shared/js/shared-utils/sha1.js"(exports, module) {
      "use strict";
      (function() {
        "use strict";
        var root = typeof window === "object" ? window : {};
        var NODE_JS = !root.JS_SHA1_NO_NODE_JS && typeof process === "object" && process.versions && process.versions.node;
        if (NODE_JS) {
          root = global;
        }
        var COMMON_JS = !root.JS_SHA1_NO_COMMON_JS && typeof module === "object" && module.exports;
        var AMD = typeof define === "function" && define.amd;
        var HEX_CHARS = "0123456789abcdef".split("");
        var EXTRA = [-2147483648, 8388608, 32768, 128];
        var SHIFT = [24, 16, 8, 0];
        var OUTPUT_TYPES = ["hex", "array", "digest", "arrayBuffer"];
        var blocks = [];
        var createOutputMethod = function(outputType) {
          return function(message) {
            return new Sha1(true).update(message)[outputType]();
          };
        };
        var createMethod = function() {
          var method2 = createOutputMethod("hex");
          if (NODE_JS) {
            method2 = nodeWrap(method2);
          }
          method2.create = function() {
            return new Sha1();
          };
          method2.update = function(message) {
            return method2.create().update(message);
          };
          for (var i = 0; i < OUTPUT_TYPES.length; ++i) {
            var type = OUTPUT_TYPES[i];
            method2[type] = createOutputMethod(type);
          }
          return method2;
        };
        var nodeWrap = function(method) {
          var crypto = eval("require('crypto')");
          var Buffer = eval("require('buffer').Buffer");
          var nodeMethod = function(message) {
            if (typeof message === "string") {
              return crypto.createHash("sha1").update(message, "utf8").digest("hex");
            } else if (message.constructor === ArrayBuffer) {
              message = new Uint8Array(message);
            } else if (message.length === void 0) {
              return method(message);
            }
            return crypto.createHash("sha1").update(new Buffer(message)).digest("hex");
          };
          return nodeMethod;
        };
        function Sha1(sharedMemory) {
          if (sharedMemory) {
            blocks[0] = blocks[16] = blocks[1] = blocks[2] = blocks[3] = blocks[4] = blocks[5] = blocks[6] = blocks[7] = blocks[8] = blocks[9] = blocks[10] = blocks[11] = blocks[12] = blocks[13] = blocks[14] = blocks[15] = 0;
            this.blocks = blocks;
          } else {
            this.blocks = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
          }
          this.h0 = 1732584193;
          this.h1 = 4023233417;
          this.h2 = 2562383102;
          this.h3 = 271733878;
          this.h4 = 3285377520;
          this.block = this.start = this.bytes = this.hBytes = 0;
          this.finalized = this.hashed = false;
          this.first = true;
        }
        Sha1.prototype.update = function(message) {
          if (this.finalized) {
            return;
          }
          var notString = typeof message !== "string";
          if (notString && message.constructor === root.ArrayBuffer) {
            message = new Uint8Array(message);
          }
          var code, index = 0, i, length = message.length || 0, blocks2 = this.blocks;
          while (index < length) {
            if (this.hashed) {
              this.hashed = false;
              blocks2[0] = this.block;
              blocks2[16] = blocks2[1] = blocks2[2] = blocks2[3] = blocks2[4] = blocks2[5] = blocks2[6] = blocks2[7] = blocks2[8] = blocks2[9] = blocks2[10] = blocks2[11] = blocks2[12] = blocks2[13] = blocks2[14] = blocks2[15] = 0;
            }
            if (notString) {
              for (i = this.start; index < length && i < 64; ++index) {
                blocks2[i >> 2] |= message[index] << SHIFT[i++ & 3];
              }
            } else {
              for (i = this.start; index < length && i < 64; ++index) {
                code = message.charCodeAt(index);
                if (code < 128) {
                  blocks2[i >> 2] |= code << SHIFT[i++ & 3];
                } else if (code < 2048) {
                  blocks2[i >> 2] |= (192 | code >> 6) << SHIFT[i++ & 3];
                  blocks2[i >> 2] |= (128 | code & 63) << SHIFT[i++ & 3];
                } else if (code < 55296 || code >= 57344) {
                  blocks2[i >> 2] |= (224 | code >> 12) << SHIFT[i++ & 3];
                  blocks2[i >> 2] |= (128 | code >> 6 & 63) << SHIFT[i++ & 3];
                  blocks2[i >> 2] |= (128 | code & 63) << SHIFT[i++ & 3];
                } else {
                  code = 65536 + ((code & 1023) << 10 | message.charCodeAt(++index) & 1023);
                  blocks2[i >> 2] |= (240 | code >> 18) << SHIFT[i++ & 3];
                  blocks2[i >> 2] |= (128 | code >> 12 & 63) << SHIFT[i++ & 3];
                  blocks2[i >> 2] |= (128 | code >> 6 & 63) << SHIFT[i++ & 3];
                  blocks2[i >> 2] |= (128 | code & 63) << SHIFT[i++ & 3];
                }
              }
            }
            this.lastByteIndex = i;
            this.bytes += i - this.start;
            if (i >= 64) {
              this.block = blocks2[16];
              this.start = i - 64;
              this.hash();
              this.hashed = true;
            } else {
              this.start = i;
            }
          }
          if (this.bytes > 4294967295) {
            this.hBytes += this.bytes / 4294967296 << 0;
            this.bytes = this.bytes % 4294967296;
          }
          return this;
        };
        Sha1.prototype.finalize = function() {
          if (this.finalized) {
            return;
          }
          this.finalized = true;
          var blocks2 = this.blocks, i = this.lastByteIndex;
          blocks2[16] = this.block;
          blocks2[i >> 2] |= EXTRA[i & 3];
          this.block = blocks2[16];
          if (i >= 56) {
            if (!this.hashed) {
              this.hash();
            }
            blocks2[0] = this.block;
            blocks2[16] = blocks2[1] = blocks2[2] = blocks2[3] = blocks2[4] = blocks2[5] = blocks2[6] = blocks2[7] = blocks2[8] = blocks2[9] = blocks2[10] = blocks2[11] = blocks2[12] = blocks2[13] = blocks2[14] = blocks2[15] = 0;
          }
          blocks2[14] = this.hBytes << 3 | this.bytes >>> 29;
          blocks2[15] = this.bytes << 3;
          this.hash();
        };
        Sha1.prototype.hash = function() {
          var a = this.h0, b = this.h1, c = this.h2, d = this.h3, e = this.h4;
          var f, j, t, blocks2 = this.blocks;
          for (j = 16; j < 80; ++j) {
            t = blocks2[j - 3] ^ blocks2[j - 8] ^ blocks2[j - 14] ^ blocks2[j - 16];
            blocks2[j] = t << 1 | t >>> 31;
          }
          for (j = 0; j < 20; j += 5) {
            f = b & c | ~b & d;
            t = a << 5 | a >>> 27;
            e = t + f + e + 1518500249 + blocks2[j] << 0;
            b = b << 30 | b >>> 2;
            f = a & b | ~a & c;
            t = e << 5 | e >>> 27;
            d = t + f + d + 1518500249 + blocks2[j + 1] << 0;
            a = a << 30 | a >>> 2;
            f = e & a | ~e & b;
            t = d << 5 | d >>> 27;
            c = t + f + c + 1518500249 + blocks2[j + 2] << 0;
            e = e << 30 | e >>> 2;
            f = d & e | ~d & a;
            t = c << 5 | c >>> 27;
            b = t + f + b + 1518500249 + blocks2[j + 3] << 0;
            d = d << 30 | d >>> 2;
            f = c & d | ~c & e;
            t = b << 5 | b >>> 27;
            a = t + f + a + 1518500249 + blocks2[j + 4] << 0;
            c = c << 30 | c >>> 2;
          }
          for (; j < 40; j += 5) {
            f = b ^ c ^ d;
            t = a << 5 | a >>> 27;
            e = t + f + e + 1859775393 + blocks2[j] << 0;
            b = b << 30 | b >>> 2;
            f = a ^ b ^ c;
            t = e << 5 | e >>> 27;
            d = t + f + d + 1859775393 + blocks2[j + 1] << 0;
            a = a << 30 | a >>> 2;
            f = e ^ a ^ b;
            t = d << 5 | d >>> 27;
            c = t + f + c + 1859775393 + blocks2[j + 2] << 0;
            e = e << 30 | e >>> 2;
            f = d ^ e ^ a;
            t = c << 5 | c >>> 27;
            b = t + f + b + 1859775393 + blocks2[j + 3] << 0;
            d = d << 30 | d >>> 2;
            f = c ^ d ^ e;
            t = b << 5 | b >>> 27;
            a = t + f + a + 1859775393 + blocks2[j + 4] << 0;
            c = c << 30 | c >>> 2;
          }
          for (; j < 60; j += 5) {
            f = b & c | b & d | c & d;
            t = a << 5 | a >>> 27;
            e = t + f + e - 1894007588 + blocks2[j] << 0;
            b = b << 30 | b >>> 2;
            f = a & b | a & c | b & c;
            t = e << 5 | e >>> 27;
            d = t + f + d - 1894007588 + blocks2[j + 1] << 0;
            a = a << 30 | a >>> 2;
            f = e & a | e & b | a & b;
            t = d << 5 | d >>> 27;
            c = t + f + c - 1894007588 + blocks2[j + 2] << 0;
            e = e << 30 | e >>> 2;
            f = d & e | d & a | e & a;
            t = c << 5 | c >>> 27;
            b = t + f + b - 1894007588 + blocks2[j + 3] << 0;
            d = d << 30 | d >>> 2;
            f = c & d | c & e | d & e;
            t = b << 5 | b >>> 27;
            a = t + f + a - 1894007588 + blocks2[j + 4] << 0;
            c = c << 30 | c >>> 2;
          }
          for (; j < 80; j += 5) {
            f = b ^ c ^ d;
            t = a << 5 | a >>> 27;
            e = t + f + e - 899497514 + blocks2[j] << 0;
            b = b << 30 | b >>> 2;
            f = a ^ b ^ c;
            t = e << 5 | e >>> 27;
            d = t + f + d - 899497514 + blocks2[j + 1] << 0;
            a = a << 30 | a >>> 2;
            f = e ^ a ^ b;
            t = d << 5 | d >>> 27;
            c = t + f + c - 899497514 + blocks2[j + 2] << 0;
            e = e << 30 | e >>> 2;
            f = d ^ e ^ a;
            t = c << 5 | c >>> 27;
            b = t + f + b - 899497514 + blocks2[j + 3] << 0;
            d = d << 30 | d >>> 2;
            f = c ^ d ^ e;
            t = b << 5 | b >>> 27;
            a = t + f + a - 899497514 + blocks2[j + 4] << 0;
            c = c << 30 | c >>> 2;
          }
          this.h0 = this.h0 + a << 0;
          this.h1 = this.h1 + b << 0;
          this.h2 = this.h2 + c << 0;
          this.h3 = this.h3 + d << 0;
          this.h4 = this.h4 + e << 0;
        };
        Sha1.prototype.hex = function() {
          this.finalize();
          var h0 = this.h0, h1 = this.h1, h2 = this.h2, h3 = this.h3, h4 = this.h4;
          return HEX_CHARS[h0 >> 28 & 15] + HEX_CHARS[h0 >> 24 & 15] + HEX_CHARS[h0 >> 20 & 15] + HEX_CHARS[h0 >> 16 & 15] + HEX_CHARS[h0 >> 12 & 15] + HEX_CHARS[h0 >> 8 & 15] + HEX_CHARS[h0 >> 4 & 15] + HEX_CHARS[h0 & 15] + HEX_CHARS[h1 >> 28 & 15] + HEX_CHARS[h1 >> 24 & 15] + HEX_CHARS[h1 >> 20 & 15] + HEX_CHARS[h1 >> 16 & 15] + HEX_CHARS[h1 >> 12 & 15] + HEX_CHARS[h1 >> 8 & 15] + HEX_CHARS[h1 >> 4 & 15] + HEX_CHARS[h1 & 15] + HEX_CHARS[h2 >> 28 & 15] + HEX_CHARS[h2 >> 24 & 15] + HEX_CHARS[h2 >> 20 & 15] + HEX_CHARS[h2 >> 16 & 15] + HEX_CHARS[h2 >> 12 & 15] + HEX_CHARS[h2 >> 8 & 15] + HEX_CHARS[h2 >> 4 & 15] + HEX_CHARS[h2 & 15] + HEX_CHARS[h3 >> 28 & 15] + HEX_CHARS[h3 >> 24 & 15] + HEX_CHARS[h3 >> 20 & 15] + HEX_CHARS[h3 >> 16 & 15] + HEX_CHARS[h3 >> 12 & 15] + HEX_CHARS[h3 >> 8 & 15] + HEX_CHARS[h3 >> 4 & 15] + HEX_CHARS[h3 & 15] + HEX_CHARS[h4 >> 28 & 15] + HEX_CHARS[h4 >> 24 & 15] + HEX_CHARS[h4 >> 20 & 15] + HEX_CHARS[h4 >> 16 & 15] + HEX_CHARS[h4 >> 12 & 15] + HEX_CHARS[h4 >> 8 & 15] + HEX_CHARS[h4 >> 4 & 15] + HEX_CHARS[h4 & 15];
        };
        Sha1.prototype.toString = Sha1.prototype.hex;
        Sha1.prototype.digest = function() {
          this.finalize();
          var h0 = this.h0, h1 = this.h1, h2 = this.h2, h3 = this.h3, h4 = this.h4;
          return [
            h0 >> 24 & 255,
            h0 >> 16 & 255,
            h0 >> 8 & 255,
            h0 & 255,
            h1 >> 24 & 255,
            h1 >> 16 & 255,
            h1 >> 8 & 255,
            h1 & 255,
            h2 >> 24 & 255,
            h2 >> 16 & 255,
            h2 >> 8 & 255,
            h2 & 255,
            h3 >> 24 & 255,
            h3 >> 16 & 255,
            h3 >> 8 & 255,
            h3 & 255,
            h4 >> 24 & 255,
            h4 >> 16 & 255,
            h4 >> 8 & 255,
            h4 & 255
          ];
        };
        Sha1.prototype.array = Sha1.prototype.digest;
        Sha1.prototype.arrayBuffer = function() {
          this.finalize();
          var buffer = new ArrayBuffer(20);
          var dataView = new DataView(buffer);
          dataView.setUint32(0, this.h0);
          dataView.setUint32(4, this.h1);
          dataView.setUint32(8, this.h2);
          dataView.setUint32(12, this.h3);
          dataView.setUint32(16, this.h4);
          return buffer;
        };
        var exports = createMethod();
        if (COMMON_JS) {
          module.exports = exports;
        } else {
          root.sha1 = exports;
          if (AMD) {
            define(function() {
              return exports;
            });
          }
        }
      })();
    }
  });

  // shared/js/background/background-embedded.js
  var import_webextension_polyfill8 = __toESM(require_browser_polyfill());

  // node_modules/@duckduckgo/autoconsent/dist/autoconsent.esm.js
  var snippets = {
    // code-based rules
    EVAL_0: () => console.log(1),
    EVAL_DIDOMI_OPT_OUT: () => {
      if (window.Didomi) {
        window.Didomi.setUserDisagreeToAll();
        return true;
      }
      return false;
    },
    EVAL_DIDOMI_TEST: () => {
      const purposes = window.Didomi?.getCurrentUserStatus?.()?.purposes;
      if (purposes) {
        return Object.values(purposes).some((p) => !p.enabled);
      }
      const disabled = window.Didomi?.getUserConsentStatusForAll?.()?.purposes?.disabled;
      return Array.isArray(disabled) && disabled.length > 0;
    },
    EVAL_CONSENTMANAGER_1: () => {
      const cmpData = window.__cmp?.("getCMPData");
      return !!cmpData && typeof cmpData === "object";
    },
    EVAL_CONSENTMANAGER_2: () => window.__cmp?.("consentStatus")?.userChoiceExists === false,
    EVAL_CONSENTMANAGER_3: () => __cmp("setConsent", 0),
    EVAL_CONSENTMANAGER_4: () => __cmp("setConsent", 1),
    EVAL_CONSENTMANAGER_5: () => __cmp("consentStatus").userChoiceExists,
    EVAL_CONSENTMANAGER_NCMP_REJECT: () => {
      if (typeof window.__npcmp !== "function") return false;
      window.__npcmp("reject");
      return true;
    },
    EVAL_CONSENTMANAGER_NCMP_ACCEPT: () => {
      if (typeof window.__npcmp !== "function") return false;
      window.__npcmp("save");
      return true;
    },
    EVAL_COOKIEBOT_1: () => !!window.Cookiebot,
    EVAL_COOKIEBOT_2: () => !window.Cookiebot.hasResponse && window.Cookiebot.dialog?.visible === true,
    EVAL_COOKIEBOT_3: () => window.Cookiebot.withdraw() || true,
    EVAL_COOKIEBOT_4: () => window.Cookiebot.hide() || true,
    EVAL_COOKIEBOT_5: () => window.Cookiebot.declined === true,
    EVAL_KLARO_1: () => {
      const config = globalThis.klaroConfig || globalThis.klaro?.getManager && globalThis.klaro.getManager().config;
      if (!config) {
        return true;
      }
      const optionalServices = (config.services || config.apps).filter((s) => !s.required).map((s) => s.name);
      if (klaro && klaro.getManager) {
        const manager = klaro.getManager();
        return optionalServices.every((name) => !manager.consents[name]);
      } else if (klaroConfig && klaroConfig.storageMethod === "cookie") {
        const cookieName = klaroConfig.cookieName || klaroConfig.storageName;
        const consents = JSON.parse(
          decodeURIComponent(
            document.cookie.split(";").find((c) => c.trim().startsWith(cookieName)).split("=")[1]
          )
        );
        return Object.keys(consents).filter((k) => optionalServices.includes(k)).every((k) => consents[k] === false);
      }
    },
    EVAL_KLARO_OPEN_POPUP: () => {
      klaro.show(void 0, true);
    },
    EVAL_KLARO_TRY_API_OPT_OUT: () => {
      if (window.klaro && typeof klaro.show === "function" && typeof klaro.getManager === "function") {
        try {
          klaro.getManager().changeAll(false);
          klaro.getManager().saveAndApplyConsents();
          return true;
        } catch (e) {
          console.warn(e);
          return false;
        }
      }
      return false;
    },
    EVAL_ONETRUST_1: () => window.OnetrustActiveGroups.split(",").filter((s) => s.length > 0).length <= 1,
    EVAL_TRUSTARC_TOP: () => window && window.truste && window.truste.eu.bindMap.prefCookie === "0",
    EVAL_TRUSTARC_FRAME_TEST: () => window && window.QueryString && window.QueryString.preferences === "0",
    EVAL_TRUSTARC_FRAME_GTM: () => window && window.QueryString && window.QueryString.gtm === "1",
    // declarative rules
    EVAL_ACCEPTRICS_TEST: () => Object.values(JSON.parse(localStorage.getItem("__acceptrics_settings")).purposes).every((purpose) => purpose === "rejected"),
    EVAL_ADOPT_TEST: () => !!localStorage.getItem("adoptConsentMode"),
    EVAL_ADULTFRIENDFINDER_TEST: () => !!localStorage.getItem("cookieConsent"),
    EVAL_AYLO_COOKIE_MANAGER_READY: () => !!(window.wl_cookie_consent_manager || window._Cookie_Consent_Manager_brand),
    EVAL_BAHN_TEST: () => utag.gdpr.getSelectedCategories().length === 1,
    // the close handler listens for mouseup, which element.click() does not dispatch
    EVAL_BING_NOTICE_CLOSE: () => {
      const close = document.querySelector("#bnp_ttc_close");
      close.dispatchEvent(new MouseEvent("mouseup", { bubbles: true, cancelable: true, view: window }));
      close.click();
      return true;
    },
    EVAL_BIGCOMMERCE_CONSENT_MANAGER_DETECT: () => !!(window.consentManager && window.consentManager.version),
    EVAL_BORLABS_0: () => !JSON.parse(
      decodeURIComponent(
        document.cookie.split(";").find((c) => c.indexOf("borlabs-cookie") !== -1).split("=", 2)[1]
      )
    ).consents.statistics,
    EVAL_CC_BANNER2_0: () => !!document.cookie.match(/sncc=[^;]+D%3Dtrue/),
    // the close icon is an SVG, which has no click() method
    EVAL_COOKIE_POPUP_CLOSE: () => document.querySelector("#cookie-popup #close-cookies").dispatchEvent(new MouseEvent("click", { bubbles: true })) || true,
    EVAL_COOKIE_LAW_INFO_0: () => {
      if (CLI.disableAllCookies) CLI.disableAllCookies();
      if (CLI.reject_close) CLI.reject_close();
      document.body.classList.remove("cli-barmodal-open");
      return true;
    },
    EVAL_COOKIE_LAW_INFO_DETECT: () => !!window.CLI,
    EVAL_COOKIEFIRST_0: () => ((o) => o.performance === false && o.functional === false && o.advertising === false)(
      JSON.parse(
        decodeURIComponent(
          document.cookie.split(";").find((c) => c.indexOf("cookiefirst") !== -1).trim()
        ).split("=")[1]
      )
    ),
    EVAL_COOKIEFIRST_1: () => document.querySelectorAll("button[data-cookiefirst-accent-color=true][role=checkbox]:not([disabled])").forEach((i) => i.getAttribute("aria-checked") === "true" && i.click()) || true,
    EVAL_COOKIEINFORMATION_0: () => CookieInformation.declineAllCategories() || true,
    EVAL_COOKIEINFORMATION_1: () => CookieInformation.submitAllCategories() || true,
    // banner button order and meaning are configurable per site, so set the consent levels through the public API
    EVAL_COOKIEREPORTS_OPT_OUT: () => {
      const cr = window._cookiereports;
      if (typeof cr?.saveConsent !== "function") return false;
      cr.saveConsent({ 1: true, 2: false, 3: false, 4: false, 5: false });
      cr.processConsent("banner", { trigger: "ok" });
      cr.hideBanner();
      return true;
    },
    EVAL_COOKIEREPORTS_OPT_IN: () => {
      const cr = window._cookiereports;
      if (typeof cr?.saveConsent !== "function") return false;
      cr.saveConsent({ 1: true, 2: true, 3: true, 4: true, 5: true });
      cr.processConsent("banner", { trigger: "ok" });
      cr.hideBanner();
      return true;
    },
    EVAL_COOKIEREPORTS_TEST: () => {
      const levels = window._cookiereports?.loadConsent?.();
      return !!levels && Object.keys(levels).length > 0 && Object.values(levels).every((v) => !v);
    },
    // turn the single-button form into a decline submission, same fields as the CMP's own decline form
    EVAL_EE_CONSENT_DECLINE_0: () => document.querySelectorAll('#cookieConsentFormAccept input[name^="ee:cookies_"]').forEach((i) => i.value = "n") || true,
    EVAL_ETSY_0: () => document.querySelectorAll(".gdpr-overlay-body input").forEach((toggle) => {
      toggle.checked = false;
    }) || true,
    EVAL_ETSY_1: () => document.querySelector(".gdpr-overlay-view button[data-wt-overlay-close]").click() || true,
    EVAL_EZOIC_0: () => ezCMP.handleAcceptAllClick(),
    EVAL_FIDES_DETECT_POPUP: () => window.Fides?.initialized,
    // Zero while the embedding page still keeps the consent iframe collapsed.
    EVAL_IFRAME_SHOWN: () => window.innerHeight > 0,
    EVAL_IUBENDA_0: () => document.querySelectorAll(".purposes-item input[type=checkbox]:not([disabled])").forEach((x) => {
      if (x.checked) x.click();
    }) || true,
    EVAL_IUBENDA_1: () => !!document.cookie.match(/_iub_cs-\d+=/),
    EVAL_KALLES_THEME_TEST: () => {
      const consent = window.Shopify.customerPrivacy.currentVisitorConsent();
      return consent.marketing === "no" && consent.analytics === "no";
    },
    EVAL_KROWN_COOKIE_BANNER_TEST: () => localStorage.getItem("krown-cookie-banner") === "true",
    // the decline handler listens for mouseup/touchend, which element.click() does not dispatch
    EVAL_LETHPOLYTECH_DECLINE: () => document.querySelector(".consent-banner .cookie-decline").dispatchEvent(new MouseEvent("mouseup", { bubbles: true, cancelable: true, view: window })) || true,
    // reading a cross-origin parent's document throws
    EVAL_MERCADOLIBRE_CROSS_ORIGIN_PARENT: () => {
      try {
        return !window.parent.document;
      } catch (e) {
        return true;
      }
    },
    // the embedded preferences page saves its current toggles on this message, normally sent by the parent's Save button
    EVAL_MERCADOLIBRE_SAVE: () => window.postMessage({ eventName: "saveCookiesPreference" }, "*") || true,
    EVAL_MICROSOFT_0: () => Array.from(document.querySelectorAll("div > button")).filter((el) => el.innerText.match("Reject|Ablehnen"))[0].click() || true,
    EVAL_MICROSOFT_1: () => Array.from(document.querySelectorAll("div > button")).filter((el) => el.innerText.match("Accept|Annehmen"))[0].click() || true,
    EVAL_MICROSOFT_2: () => !!document.cookie.match("MSCC|GHCC"),
    EVAL_MOOVE_0: () => document.querySelectorAll("#moove_gdpr_cookie_modal input").forEach((i) => {
      if (!i.disabled) i.checked = i.name === "moove_gdpr_strict_cookies" || i.id === "moove_gdpr_strict_cookies";
    }) || true,
    // the site reloads on banner button clicks, which can abort the SDK's deferred save
    EVAL_NFL_ONETRUST_ALLOW_ALL: () => {
      window.OneTrust.AllowAll();
      return true;
    },
    EVAL_NFL_ONETRUST_REJECT_ALL: () => {
      window.OneTrust.RejectAll();
      return true;
    },
    EVAL_NHNIEUWS_TEST: () => !!localStorage.getItem("psh:cookies-seen"),
    EVAL_OSANO_DETECT: () => !!window.Osano?.cm?.dialogOpen,
    EVAL_PANDECTES_TEST: () => document.cookie.includes("_pandectes_gdpr=") && JSON.parse(
      atob(
        document.cookie.split(";").find((s) => s.trim().startsWith("_pandectes_gdpr")).split("=")[1]
      )
    ).status === "deny",
    EVAL_POSTHOG_TEST: () => localStorage.getItem("cookie_consent") === "acknowledged",
    EVAL_POVR_GOBACK: () => window.history.back() || true,
    EVAL_PUBTECH_0: () => document.cookie.includes("euconsent-v2") && (document.cookie.match(/.YAAAAAAAAAAA/) || document.cookie.match(/.aAAAAAAAAAAA/) || document.cookie.match(/.YAAACFgAAAAA/)),
    EVAL_SHOPIFY_TEST: () => document.cookie.includes("gdpr_cookie_consent=0") || document.cookie.includes("_tracking_consent=") && JSON.parse(
      decodeURIComponent(
        document.cookie.split(";").find((s) => s.trim().startsWith("_tracking_consent")).split("=")[1]
      )
    ).purposes.a === false,
    EVAL_SIRDATA_UNBLOCK_SCROLL: () => {
      document.documentElement.classList.forEach((cls) => {
        if (cls.startsWith("sd-cmp-")) document.documentElement.classList.remove(cls);
      });
      return true;
    },
    EVAL_SOURCEPOINT_RESTORE_SCROLL: () => {
      const root2 = document.documentElement;
      const saved = root2.dataset.previousScrollY;
      if (saved && saved !== "null") {
        root2.dataset.previousScrollY = "null";
        const y = -parseInt(saved, 10);
        if (y > 0 && window.scrollY === 0) {
          const behavior = root2.style.scrollBehavior;
          root2.style.scrollBehavior = "auto";
          window.scrollTo(0, y);
          root2.style.scrollBehavior = behavior;
        }
      }
      window.addEventListener("pagehide", () => {
        if (root2.dataset.previousScrollY) root2.dataset.previousScrollY = "null";
      });
      return true;
    },
    EVAL_SS_COM_OPT_OUT: () => _gdpr_confirm(false) || true,
    EVAL_SS_COM_TEST: () => /-necessary$/.test(localStorage.getItem("ss_cc")),
    EVAL_STEAMPOWERED_0: () => JSON.parse(
      decodeURIComponent(
        document.cookie.split(";").find((s) => s.trim().startsWith("cookieSettings")).split("=")[1]
      )
    ).preference_state === 2,
    EVAL_TARTEAUCITRON_0: () => tarteaucitron.userInterface.respondAll(false) || true,
    EVAL_TARTEAUCITRON_1: () => tarteaucitron.userInterface.respondAll(true) || true,
    EVAL_TARTEAUCITRON_2: () => document.cookie.match(/tarteaucitron=[^;]*/)?.[0].includes("false"),
    EVAL_TEALIUM_0: () => typeof window.utag !== "undefined" && typeof utag.gdpr === "object",
    EVAL_TEALIUM_1: () => utag.gdpr.setConsentValue(false) || true,
    EVAL_TEALIUM_DONOTSELL: () => utag.gdpr.dns?.setDnsState(false) || true,
    EVAL_TEALIUM_2: () => utag.gdpr.setConsentValue(true) || true,
    EVAL_TEALIUM_3: () => utag.gdpr.getConsentState() !== 1,
    EVAL_TEALIUM_DONOTSELL_CHECK: () => utag.gdpr.dns?.getDnsState() !== 1,
    // 0 means no stored decision; otherwise the user reopened the prompt themselves
    EVAL_TEALIUM_NO_DECISION: () => utag.gdpr.getConsentState() === 0,
    EVAL_TESTCMP_STEP: () => !!document.querySelector("#reject-all"),
    EVAL_TESTCMP_0: () => window.results.results[0] === "button_clicked",
    EVAL_TESTCMP_COSMETIC_0: () => window.results.results[0] === "banner_hidden",
    // Same handler the banner buttons call; which button refuses differs per template.
    EVAL_TRUSTCOMMANDER_BANNER_SHOWN: () => {
      const wrapper = document.getElementById("tc-privacy-wrapper");
      return !!wrapper && getComputedStyle(wrapper).visibility !== "hidden";
    },
    EVAL_TRUSTCOMMANDER_OPTIN: () => {
      if (typeof window.tC?.privacy?.clickBanner !== "function") return false;
      window.tC.privacy.clickBanner("optin");
      return true;
    },
    EVAL_TRUSTCOMMANDER_OPTOUT: () => {
      if (typeof window.tC?.privacy?.clickBanner !== "function") return false;
      window.tC.privacy.clickBanner("optout");
      return true;
    },
    EVAL_USERCENTRICS_API_0: () => typeof UC_UI === "object",
    EVAL_USERCENTRICS_API_1: () => !!UC_UI.closeCMP(),
    EVAL_USERCENTRICS_API_2: () => !!UC_UI.denyAllConsents(),
    EVAL_USERCENTRICS_API_3: () => !!UC_UI.acceptAllConsents(),
    EVAL_USERCENTRICS_API_4: () => !!UC_UI.closeCMP(),
    EVAL_USERCENTRICS_API_5: () => UC_UI.areAllConsentsAccepted() === true,
    EVAL_USERCENTRICS_API_6: () => UC_UI.areAllConsentsAccepted() === false,
    EVAL_WBD_LTP_CLOSE: () => document.querySelector("dialog#ltp-dialog").close() || true,
    EVAL_ZOHO_TEST: () => localStorage.getItem("zglobal_Acookie_optOut") === "3"
  };
  var BY_CONTINUING_PRIVACY = /(?:by continuing.{0,100}privacy)|(?:privacy.{0,100}by continuing)/gi;
  var USE_OF_COOKIES = /use of cookies/gi;
  var UTILISATION_DES_COOKIES = /utilisation.{0,100}des.{0,100}cookies/gi;
  var ACCEPTEZ_UTILISATION = /acceptez.{0,100}l.{0,100}utilisation/gi;
  var VERWENDUNG_VON_COOKIES = /verwendung.{0,100}von.{0,100}cookies/gi;
  var DE_COOKIE_VERB = /\b(?:nutzen|nutzt|verwenden|verwendet|setzen|setzt|benutzen|benutzt|speichert|platzieren)\b(?: \S+){0,4} cookies\b/gi;
  var GEBRUIK_VAN_COOKIES = /gebruik.{0,100}van.{0,100}cookies/gi;
  var DE_THIS_SITE_COOKIES = /\b(?:unsere|diese)[rs]? (?:web)?(?:seite|site)\b.{0,100}cookies/gi;
  var DE_SITE_USES_COOKIES = /\b(?:seite|site)\b.{0,100}\b(?:nutzt|benutzt)\b.{0,100}cookies/gi;
  var REJECT_PATTERNS_ENGLISH = [
    // e.g. "reject", "reject all", "reject all cookies", "reject cookie", "deny all", "refuse cookies", "decline", "disallow cookies",
    // "reject non-essential cookies", "reject unnecessary cookies", "reject all but necessary", "reject all and close"
    // note that "reject and subscribe" and "reject and pay" are excluded via BUTTON_NEVER_MATCH_PATTERNS
    /^\s*(no,?\s*)?(i\s+)?(reject|deny|refuse|decline|disable|disallow)\s*(all)?\s*(but|except)?\s*(non[- ]?essential|un(necessary|required)|optional|additional|targeting|analytics|marketing|non[- ]?necessary|extra|tracking|advertising|necessary|essential)?\s*(cookies?)?\s*(and\s+close)?\s*$/is,
    // e.g. "i do not accept", "do not accept cookies", "i do not accept the use of cookies", "do not allow cookies", "dont allow"
    /^\s*(no,?\s*)?(i\s+)?(do\s+not|dont)\s+(accept|allow)\s*(the\s+use\s+of\s+)?(any\s+)?(cookies)?\s*$/is,
    // e.g. "continue without accepting", "continue without agreeing", "continue without agreeing →"
    /^\s*(continue|proceed|continue\s+browsing)\s+without\s+(accepting|agreeing|consent|cookies|tracking)(\s*→)?\s*$/is,
    // essential/necessary/functional-only, e.g. "essential cookies only", "accept only essential cookies",
    // "allow necessary cookies continue", "use essential cookies only", "functional only", "essential only cookies", "i confirm necessary",
    // "proceed with necessary cookies only"
    /^\s*(i\s+)?(want\s+to\s+)?(only\s+)?(use|accept|allow|keep|enable|choose|continue\s+with|proceed\s+with|i\s+confirm)\s*(only\s+)?(strictly\s+)?(necessary|essential|essentials|functional|required|minimal)\s*(cookies)?\s*(continue|only)?\s*$/is,
    /^\s*(i\s+)?(want\s+to\s+)?only\s+(strictly\s+)?(necessary|essential|essentials|functional|required|minimal)\s*(cookies)?\s*(continue|only)?\s*$/is,
    /^\s*(strictly\s+)?(necessary|essential|essentials|functional|required|minimal)\s+((cookies\s+)?only|only\s+cookies)\s*$/is,
    // e.g. "do not sell or share my personal information", "do not share my personal information", "opt out of sale ..." (CCPA)
    // "do not sell page" is a link; "do not sellcookie settings" is two concatenated buttons
    /do\s+not\s+sell(?!\s*(page|cookie settings))|do\s+not\s+share\s+my\s+(personal\s+)?(information|info|data)|opt\s+out\s+of\s+sale/is,
    // e.g. "opt-out of sale/share or targeted advertising", "opt-out of advertising/social media cookies"
    /^opt[ -]?out of /is,
    // e.g. "reject all except strictly necessary", "reject all (except necessary cookies)"
    /except\s+(strictly\s+)?necessary/is,
    // e.g. "disagree", "i disagree", "disagree and close"
    /^(i\s+)?disagree\s*(and\s+close)?$/i,
    "no",
    /^no,? thank(s| you)$/is,
    // e.g. "no cookies", "no cookies for me, thanks", "rather not", "no, rather not"
    /^no,?\s+cookies(\s+for\s+me)?(,?\s*thank(s| you))?$/is,
    /^(no,?\s+)?rather not$/is,
    /^opt[ -]out$/is,
    "dont enable",
    "i do not agree"
  ];
  var REJECT_PATTERNS_DUTCH = [
    // weigeren / afwijzen / verwerpen (reject verbs, any position)
    /weiger|afwijz|verwerp/is,
    // "wijs (alles/ze) af" (reject verb with split particle)
    /wijs\b.*\baf\b/is,
    // "alleen/enkel/uitsluitend ... (noodzakelijk|functioneel|essentieel|...)"
    /(^|\s)(alleen|enkel|uitsluitend)\s+.{0,20}(noodzakelijk|functione|essenti|vereiste|verplichte|strikt|minimale|basis|basic|standaard)/is,
    // essential/necessary-only nouns
    /^\s*(accepteer\s+|aanvaard\s+|gebruik\s+|sta\s+|ik wil\s+)?(alleen\s+|enkel\s+|uitsluitend\s+|strikt\s+)?(de\s+)?(noodzakelijke?|functionele?|functioneel|essentiële|essentieel|vereiste|verplichte|minimale|basiscookies|basis|standaard)\s*(cookies?)?\s*(accepteren|toestaan|aanvaarden)?\s*$/is,
    // continue without accepting / consent
    /(doorgaan|ga door|ga verder|verder)\s+.{0,15}(zonder|aanvaard)/is,
    // "nee" refusals (but not "nee, sluiten" → acknowledge)
    /^nee(,?\s+(bedankt|dank je|dankje|liever niet|liever geen cookies|geen persoonlijke cookies|geen cookies.*|weigeren?))?$/is,
    "niet accepteren",
    "niet akkoord",
    "ik ga niet akkoord",
    "liever niet",
    "geen cookies toestaan",
    "liever geen cookies",
    "functioneel altijd actief",
    // e.g. "ik accepteer geen cookies", "nee, ik wil geen optimale cookies"
    /^(nee,?\s+)?(ik\s+)?(wil|accepteer|aanvaard)\s+geen\s+(\S+\s+)?cookies$/is
  ];
  var REJECT_PATTERNS_FRENCH = [
    // refuser / rejeter / interdire / décliner (reject verbs, any position)
    // "refuser et s'abonner" / "refuser et payer" are excluded via BUTTON_NEVER_MATCH_PATTERNS
    // skip English prose such as "cookies that you can refuse"
    /^(?!.*\bcan refuse\b)(.*\s)?(refus|rejet|rejeter|interdire|interdis|déclin|declin)/is,
    // only necessary / essential / technical / functional
    /^(?=.*(cookie|nécessaire|essentiel|techni|requis|obligatoire|fonctionnel|indispensable|sdk)).*(uniquement|seulement|indispensable|strictement nécessaire|que les cookies\s+(nécessaires|techniques|essentiels|indispensables|fonctionnels))/is,
    // continue/proceed without accepting; refuse everything; disable purposes
    /(sans accepter|ne pas accepter|je naccepte rien|je désactive)/is,
    // "non" / "non, merci"
    /^non(,?\s+merci\.?)?$/is
  ];
  var REJECT_PATTERNS_GERMAN = [
    // "... ablehnen" / "ablehnen ..." (reject/decline). Exclude the settings-list phrase "einstell(ungen|en) oder ablehnen".
    /^(?!einstell(ungen|en) oder ablehnen$).*ablehnen/is,
    // verweigern / verweigere / verweigert (refuse)
    /verweiger/is,
    // essential/necessary/functional-only variants (accepting only necessary → reject)
    /^\s*(nur|ausschließlich|lediglich|weiter\s+mit|mit|akzeptiere?n?|unbedingt|es\s+werden\s+nur)?\s*(technisch\s+)?(notwendige?[nrs]?|essenzielle?[nrs]?|essentielle?[nrs]?|erforderliche?[nrs]?|funktionale?[nrs]?|funktionelle?[nrs]?|wesentliche?[nrs]?)\s*(cookies?|technologien|funktionscookies|dienste)?\s*(akzeptieren|erlauben|zulassen|verwenden|annehmen|setzen|speichern|zustimmen|auswählen)?\.?\s*$/is,
    // continue with only necessary/functional cookies
    /^(weiter\s+|nur\s+)?mit\s+(nur\s+|ausschließlich\s+|lediglich\s+)?(den\s+)?(technisch\s+)?(notwendigen|essenziellen|essentiellen|erforderlichen|funktionalen|funktionellen)\s+(cookies\s+)?fortfahren\.?$/is,
    // continue without consent
    /(^|\s)(ohne\s+(zu\s+)?(einwilligung|zustimmung|einverständnis|annahme|annehmen|akzeptanz|akzeptieren)|(weiter|fortfahren)\s+ohne)/is,
    // negations / refusals not covered by the regexes above
    "nein, danke",
    "nein, bitte nicht",
    "nein, ich stimme nicht zu",
    "nicht zustimmen",
    "nicht einverstanden",
    "ich lehne ab",
    "mit erforderlichen einstellungen fortfahren"
  ];
  var REJECT_PATTERNS_ITALIAN = [
    // rifiuta / rifiutare / rifiuto / nega / negare / blocca (reject verbs)
    /(^|\s)(rifiut|neg(a|are|hi)|blocca i cookie)/is,
    // accept/use only necessary / essential / technical
    /^\s*(accetta|accettare|usa|installa|consenti|chiudi e prosegui( solo con)?)?\s*(solo|soltanto|unicamente)?\s*(i\s+|gli\s+)?(cookies?\s+)?(strettamente\s+)?(necessari|necessary|essenziali|tecnici|di navigazione)\s*(necessari|tecnici|essenziali)?\s*$/is,
    // continue without accepting
    /continua(re)? senza accettare/is,
    "non accetto"
  ];
  var REJECT_PATTERNS_BRAZILIAN_PORTUGUESE = [
    // (deny)
    /^\s*(rejeitar|recusar|desativar|bloquear|negar|não\s*aceito|não \s*aceitar)\s*$/is,
    // (proceed) (without accepting)
    /^\s*(continuar|prosseguir|seguir)\s*(sem\s*aceitar)\s*$/is,
    // (deny) (everything) (optional)
    /^\s*(rejeitar|recusar|desativar|bloquear|negar|não\s*aceito|não \s*aceitar)\s*(tudo|o)?\s*(opcional|(não[-\s](essencial|funcional|obrigatório|necessário)))?\s*$/is,
    // (deny) (all) (the) (optional) (cookies)
    /^\s*(rejeitar|recusar|desativar|bloquear|negar|não\s*aceito|não \s*aceitar)\s*(todos)?\s*(os)?\s*(cookies)?\s*(opcionais|(não[-\s](essenciais|funcionais|obrigatórios|necessários)))?\s*$/is,
    // (accept) (only) (the) (essential)
    /^\s*(aceitar|utilizar)?\s*(apenas|somente|só)?\s*(o)?\s*(essencial|funcional|obrigatório|necessário)\s*$/is,
    // (accept) (only) (the) (essential) (cookies)
    /^\s*(aceitar|utilizar)?\s*(apenas|somente|só)?\s*(os)?\s*(cookies)?\s*(essenciais|funcionais|obrigatórios|necessários)\s*$/is
  ];
  var REJECT_PATTERNS_SPANISH = [
    // rechazar / denegar / declinar / negar (reject verbs, any position)
    // "rechazar y pagar" / "rechazar y suscribirse" are excluded via BUTTON_NEVER_MATCH_PATTERNS
    /(^|\s)(rechaz|recház|deneg|negar|declin)/is,
    // accept/allow/use (only) necessary / essential / technical / functional / own
    /^\s*(aceptar?|acepta|permitir|permite|usar|utilizar)?\s*(solo|sólo|només|únicamente)?\s*(las?\s+|los\s+)?(cookies?\s+)?(estrictamente\s+)?(necesari\w*|esencial\w*|imprescindibl\w*|técnic\w*|obligatori\w*|funcional\w*|propias)\s*$/is,
    // "solo/sólo/no, sólo ... necessary/essential"
    /^(no,?\s+)?(solo|sólo|només)\s+(usar\s+|las?\s+|los\s+|lo\s+)?.{0,20}(necesari|esencial|estrictamente)/is,
    // refusals / opt-outs
    /^(no acept|no consentir|no permitir|no estoy de acuerdo|no,? gracias|sin consentimiento|continuar sin aceptar|prefiero rechazarlas|descartar todas)/is,
    "acceptar nom\xE9s les necess\xE0ries",
    "nom\xE9s sutilitzen cookies quan \xE9s necessari",
    "pulsa aqu\xED para desactivar las cookies opcionales"
  ];
  var REJECT_PATTERNS_SWEDISH = [
    // avvisa / avböj / neka / förneka (reject verbs)
    /(^|\s)(avvisa|avböj|neka|nekar|förneka)/is,
    // (allow/accept/use) only necessary cookies/kakor
    /(bara|endast|enbart)\s+nödvändig/is,
    // "godkänn/acceptera/använd/tillåt (bara/endast/enbart) nödvändiga (cookies/kakor)"
    /^(ok,?\s+|nej,?\s+)?(jag\s+)?(godkänn\w*|godta|acceptera\w*|använd\w*|tillåt|spara)?\s*(bara|endast|enbart)?\s*(strikt\s+)?nödvändiga?t?( (cookies|kakor|tjänster))?\.?$/is,
    // continue without accepting
    /fortsätt utan att (acceptera|godkänna)/is,
    /strikt nödvändig/is,
    "till\xE5t inte cookies",
    "jag accepterar endast grundl\xE4ggande kakor"
  ];
  var REJECT_PATTERNS_DANISH = [
    // afvis / afvis alle / afvis alle cookies (reject verbs)
    /(^|\s)afvis/is,
    // (accept/allow) only necessary cookies
    /^(accepter\s+|tillad\s+)?(kun|udelukkende)\s+(strengt\s+)?nødvendige( cookies)?$/is,
    // "nej tak" (no thanks), e.g. "du kan sige nej tak til statistik"
    /^nej(,?\s+tak)?$/is,
    /^(du kan )?(sige )?nej,? tak til \S+$/is
  ];
  var REJECT_PATTERNS_NORWEGIAN = [
    // avvis / avslå (reject verbs), not the status "avslått" (rejected)
    /(^|\s)(avvis|avslå)(\s|$)/is,
    // (accept/allow/use) only necessary cookies
    /^(godta\s+|tillat\s+|aksepter\s+|bruk\s+)?(kun|bare)\s+(strengt\s+)?nødvendige( (informasjonskapsler|cookies))?$/is,
    // "nei" / "nei takk" (no thanks)
    /^nei(,?\s+takk)?$/is
  ];
  var REJECT_PATTERNS_GREEK = [
    // απόρριψη / απορρίπτω / απόρριψε (reject); not "απόρρητο" (privacy)
    /(^|\s)απ[οό]ρρ[ιί](ψ|πτ)/is,
    /^[αά]ρνηση/is,
    // (accept) only necessary / mandatory / functional, e.g. "αποδοχή υποχρεωτικών", "μόνο τα απαραίτητα cookies"
    /^(αποδοχ[ηή]\s+|αποδ[εέ]χομαι\s+|επιτρ[εέ]ψτε\s+)?(μ[οό]νο\s+)?(των\s+|τα\s+)?(απαρα[ιί]τητ\S*|υποχρεωτικ\S*|αναγκα[ιί]\S*|λειτουργικ\S*|τεχνικ\S*)(\s+(cookies?|μπισκ[οό]τα))?$/is,
    // continue without accepting / consent
    /^συν[εέ]χεια\s+χωρ[ιί][σς]\s+(αποδοχ|συγκατ[αά]θεση)/is,
    // refusals: "δεν αποδέχομαι", "δε συμφωνώ", "όχι, ευχαριστώ"
    /^δεν?\s+(αποδ[εέ]χομαι|συμφων[ωώ]|συναιν[ωώ])/is,
    /^[οό]χι(,?\s+ευχαριστ[ωώ])?$/is
  ];
  var REJECT_PATTERNS_CATALAN = [
    /(^|\s)rebutj/is,
    "no accepto",
    "no, gr\xE0cies",
    // accept/allow/use (only) necessary / essential / technical / functional
    /^\s*(acceptar?|accepto|permetre|utilitzar|usar)?\s*(només|sols|únicament)?\s*(les\s+|els\s+)?(galetes\s+|cookies?\s+)?(estrictament\s+)?(necess[aà]ri\w*|essencial\w*|tècni\w*|funcional\w*|imprescindibles)\s*$/is,
    // continue without accepting
    /^continuar sense acceptar/is
  ];
  var REJECT_PATTERNS_GALICIAN = [/(^|\s)rexeitar/is];
  var REJECT_PATTERNS_BASQUE = [/(^|\s)(baztertu|ukatu)/is];
  var REJECT_PATTERNS_PORTUGUESE = [/^aceitar apenas cookies essenciais\.$/];
  var REJECT_PATTERNS_CZECH = ["povolit pouze nezbytn\xE9 cookie"];
  var REJECT_PATTERNS_POLISH = [
    // odrzuć / odrzucam / odmawiam / rezygnuję / blokuj wszystkie (reject verbs)
    /odrzu(ć|cam|cenie|cać|canie|cić)|odmaw|odmowa|odmów|rezygnuj|blokuj wszystk/is,
    // (accept) only necessary / required
    /(^|\s)tylko\s+(bezwzględnie\s+)?(niezbędn\w*|wymagan\w*|konieczne)/is,
    /(akceptuj|akceptuję|zaakceptuj|zatwierdź|potwierdzam|zezwól)\s+(tylko\s+)?(na\s+)?(niezbędn\w*|wymagan\w*|konieczne)/is,
    /korzystaj wyłącznie z niezbędn/is,
    // continue without accepting / consent
    /kontynuuj bez (akceptacj|akceptowani|wyrażania zgody)/is,
    // refusals
    /nie (akceptuję|zgadzam|wyrażam zgody|wyrażaj zgody|zezwalaj|potwierdzam)/is,
    /^nie(,?\s+(dziękuję|nie zgadzam.*))?$/is,
    "niezb\u0119dne",
    "niezb\u0119dne pliki cookie",
    /^funkcjonalne pliki cookie \(wymagane\)$/
  ];
  var REJECT_PATTERNS_RUSSIAN = [
    // отклонить / отказаться / запретить (reject verbs); \w does not match Cyrillic
    /(^|\s)(отклон[а-яё]*|отказ[а-яё]*|откаж[а-яё]*|запрет[а-яё]*|запрещ[а-яё]*)/is,
    // "только необходимые (файлы cookie)" / "принять только необходимые куки"
    /^\s*(принять\s+|принима[а-яё]+\s+|разрешить\s+|использовать\s+|оставить\s+)?(только|лишь)\s+(строго\s+)?(необходим[а-яё]+|нужн[а-яё]+|обязательн[а-яё]+|техническ[а-яё]+|функциональн[а-яё]+)(\s+файл[а-яё]*)?([\s-]+(cookie|куки)([\s-]+файл[а-яё]*)?)?\s*$/is,
    // refusals: "не принимаю", "не согласен", "не соглашаюсь", "нет, спасибо"
    /^\s*(не\s+(принима[а-яё]+|соглас[а-яё]+|разреша[а-яё]+|хочу)|нет(,?\s+спасибо)?)\s*$/is
  ];
  var REJECT_PATTERNS_TURKISH = [
    // e.g. "tümünü reddet", "isteğe bağlı çerezleri reddet"; [ıi] because text in capitals lowercases I to i
    /^((tümünü|hepsini|tüm çerezleri|çerezleri|isteğe bağl[ıi] çerezleri|zorunlu olmayan çerezleri) )?reddet( ve kapat)?$/,
    "reddediyorum",
    "kabul etmiyorum"
  ];
  var REJECT_PATTERNS_INDONESIAN = ["tolak cookie"];
  var REJECT_PATTERNS_JAPANESE = [
    // e.g. "拒否", "すべて拒否", "全て拒否する", "cookieを拒否"
    /^(すべて|全て)?\s?(の)?(cookie|クッキー)?\s?(を)?拒否(する)?$/i,
    "\u540C\u610F\u3057\u306A\u3044",
    "\u540C\u610F\u3057\u307E\u305B\u3093"
  ];
  var REJECT_PATTERNS = [
    ...REJECT_PATTERNS_ENGLISH,
    ...REJECT_PATTERNS_DUTCH,
    ...REJECT_PATTERNS_FRENCH,
    ...REJECT_PATTERNS_GERMAN,
    ...REJECT_PATTERNS_ITALIAN,
    ...REJECT_PATTERNS_BRAZILIAN_PORTUGUESE,
    ...REJECT_PATTERNS_SPANISH,
    ...REJECT_PATTERNS_SWEDISH,
    ...REJECT_PATTERNS_DANISH,
    ...REJECT_PATTERNS_NORWEGIAN,
    ...REJECT_PATTERNS_GREEK,
    ...REJECT_PATTERNS_CATALAN,
    ...REJECT_PATTERNS_GALICIAN,
    ...REJECT_PATTERNS_BASQUE,
    ...REJECT_PATTERNS_PORTUGUESE,
    ...REJECT_PATTERNS_CZECH,
    ...REJECT_PATTERNS_POLISH,
    ...REJECT_PATTERNS_RUSSIAN,
    ...REJECT_PATTERNS_TURKISH,
    ...REJECT_PATTERNS_INDONESIAN,
    ...REJECT_PATTERNS_JAPANESE
  ];
  var COOKIE_CHOICE = [
    "\\b(?:accept|reject|decline|refuse|deny|allow|manage|customi[sz]e)\\b[^\\n]{0,25}\\bcookies?\\b",
    "\\b(?:reject|decline|deny|refuse) all\\b",
    "\\b(?:essential|necessary|required) (?:cookies )?only\\b|\\bonly (?:essential|necessary|required)\\b",
    "\\bcookies? (?:notice|settings|preferences|banner)\\b",
    "\\b(?:alle )?(?:cookies )?ablehnen\\b",
    "\\b(?:alles |alle cookies )?(?:weigeren|weiger|afwijzen)\\b",
    "\\b(?:tout )?refuser\\b",
    "\\brechazar(?: todas?)?\\b",
    "\\brifiuta(?: tutti)?\\b",
    // purposes and vendors as a button or heading line: some consent dialogs ask "under 18?"
    "^[^\\n]{0,40}\\b(?:purposes|finalit\xE9s|prop\xF3sitos|zwecke|doeleinden|finalit\xE0|vendors|fournisseurs|proveedores|leveranciers|fornitori)(?!\\w)[^\\n]{0,10}$",
    "\\b(?:legitimate (?:business )?interest|int\xE9r\xEAt l\xE9gitime|inter\xE9s leg\xEDtimo|berechtigtes interesse|gerechtvaardigd belang|legittimo interesse)\\b",
    "\\b(?:we|nous|wir|wij|noi|nosotros) (?:and|et|und|en|e|y) (?:our|nos|unsere|onze|i nostri|nuestros) (?:\\d+ )?(?:partners|partenaires|partner|socios)\\b"
  ].join("|");
  var BARE_ACCEPT = [
    "\\b(?:accept|allow) all\\b",
    "\\b(?:alle )?(?:cookies )?(?:akzeptieren|erlauben|zulassen)\\b",
    "\\b(?:alles |alle cookies )?(?:accepteren|accepteer|toestaan)\\b",
    "\\b(?:tout )?accepter\\b",
    "\\baceptar(?: todas?)?\\b",
    "\\baccetta(?: tutti)?\\b"
  ].join("|");
  var COOKIE_CHOICE_RE = new RegExp(COOKIE_CHOICE, "im");
  var CONSENT_CHOICE = new RegExp(`${COOKIE_CHOICE}|${BARE_ACCEPT}`, "im");
  var AGE_WORDING = new RegExp(
    [
      "\\b(?:over|above|at least|older than|minimum(?: age of)?)\\s*(?:18|21|eighteen)\\b",
      // "18+" only with age words after it: a bare "18+" also appears in cookie banners on adult sites
      "\\b(?:18|21)\\+?\\s*(?:years?(?: of age| old)?|yo|or older|or over)\\b",
      "\\b(?:you|users?|visitors?) must be (?:over |above |at least )?(?:18|21)\\b",
      "\\b(?:i'?m|i am) (?:over |at least )?(?:18|21)\\b",
      "\\bage (?:verification|confirmation|check|gate|restriction)\\b",
      "\\b(?:adults? only|adult[\\s-](?:oriented|content|material|website)|legal age|age of majority|not a minor|minors)\\b",
      "\\b(?:18|21) jahre\\b",
      "\\balters(?:beschr\xE4nkung|best\xE4tigung|verifikation|pr\xFCfung|kontrolle)",
      "\\b(?:vollj\xE4hrig|f\xFCr erwachsene|minderj\xE4hrige)\\b",
      "\\b(?:18|21) jaar\\b",
      "\\b(?:volwassenen|meerderjarig|minderjarigen|leeftijdsverificatie)\\b",
      "\\b(?:18|21) ans\\b",
      // no \\b before an accented letter: without the u flag it is not a word character
      "\\b(?:pour adultes|v\xE9rification de l.\xE2ge|mineurs)\\b|\xE2ge l\xE9gal\\b",
      "\\b(?:18|21) a\xF1os\\b",
      "\\b(?:mayor(?:es)? de edad|menores de edad|para adultos|verificaci\xF3n de edad)\\b",
      "\\b(?:18|21) anni\\b",
      "\\b(?:maggiorenne|minorenni|per adulti)\\b|\\bverifica dell.et\xE0(?!\\w)"
    ].join("|"),
    "i"
  );
  var DISMISS_LINE = /^\s*(?:(?:yes,? )?(?:i )?(?:ok(?:ay)?|accept|agree|allow|decline|deny|reject|refuse|understand|acknowledge(?: the use of cookies)?|got it|understood)(?: all)?(?:,? (?:and|&) (?:continue|close))?(?: non-essential)?|close|dismiss|akzeptieren|zustimmen|verstanden|einverstanden|ablehnen|accepteren|akkoord|weigeren|accepter|j.accepte|d.accord|refuser|fermer|aceptar|acepto|rechazar|entendido|accetto|accetta|rifiuta|ho capito|chiudi)\s*[!.]?\s*$/im;
  var DISMISS_END = /[.!?]\s+(?:ok(?:ay)?|got it|i agree|accept)\s*!?\s*$|\[\s*[x×]\s*\]|^\s*[x×✕]\s*$/im;
  var NOTICE_CONTROL = new RegExp(`${CONSENT_CHOICE.source}|${DISMISS_LINE.source}|${DISMISS_END.source}`, "im");
  var LEAVE_LINE = /^\s*(?:(?:no,? )?(?:i )?(?:want to )?(?:leave|exit|verlassen|quitter|sortir|salir|abandonar|esci|uscire|verlaten)\b[^\n]{0,30}|no,? take me away|(?:seite|hier) verlassen|(?:i am|i'm|ich bin|ik ben|je suis|soy|sono) (?:under|unter|onder|jonger dan|menor de(?: edad)?|minorenne|mineur)\b[^\n]{0,10})\s*[!.]?\s*$/im;
  var NOTICE_OWN_CONTROL = new RegExp(
    [
      "\\bcookies? verwalten\\b|\\bcookie-?(?:einstellungen|pr\xE4ferenzen)\\b|\\beinstellungen verwalten\\b",
      "\\bconfigura(?:r|ci\xF3n de)(?: las)? cookies\\b|\\bgestionar(?: las)? cookies\\b|\\bpersonalizar(?: las)? cookies\\b",
      "\\bparam[\xE9e]trer(?: les)? cookies\\b|\\bparam[\xE8e]tres(?: des)? cookies\\b|\\bg[\xE9e]rer(?: les)? cookies\\b|\\bpersonnaliser(?: les)? cookies\\b",
      "\\bgestisci(?: i)? cookie|\\bimpostazioni(?: dei| sui)? cookie|\\bpersonalizza(?: i)? cookie",
      "\\bcookie-?instellingen\\b|\\bcookies? beheren\\b|\\bvoorkeuren (?:beheren|aanpassen)\\b",
      "^\\s*(?:customi[sz]e|personnaliser|param\xE9trer|personalizar|configurar|personalizza|anpassen|aanpassen|meer opties|more options|weitere optionen|plus d.options|m\xE1s opciones|altre opzioni|manage (?:options|preferences|choices))\\s*$",
      "^\\s*close (?:this|the) (?:popup|banner|notice|message)\\s*$"
    ].join("|"),
    "im"
  );
  var ageGateUnless = (control) => (text) => !LEAVE_LINE.test(text) && (control.test(text) || NOTICE_OWN_CONTROL.test(text));
  var CONSENT_WORDS = /cookie|consent|track|partner|personali[sz]|advertis|analytic|privacy (?:options|choices|settings|rights)|do not sell|opt[- ]out/i;
  var LEGAL_AGREEMENT = /\b(?:end[- ]user licen[cs]e agreement|licen[cs]e agreement|limitation of liability|governing law|indemnif\w*|hereunder|disclaimers? of warrant\w*|warrant(?:y|ies) of merchantability)\b/i;
  var INVESTOR_GATE = /\beligible\s+counterpart(?:y|ies)\b|\bnot\s+(?:suitable|intended)\s+for\s+retail\s+(?:clients|investors)\b|\bconfirm\w*\s+(?:that\s+)?(?:you\s+are|i\s+am)\s+an?\s+(?:(?:professional|institutional|qualified|accredited|sophisticated)\s+(?:investor|client)|financial\s+(?:intermediary|advis[eo]r))\b/i;
  var DETECT_CONTEXT_NEGATIVES = [
    // popups with their own age confirmation are age gates, even when they mention cookies; a bare accept doesn't count
    // as a cookie choice here, since it may confirm the age
    { name: "age-gate-popup", pattern: AGE_WORDING, unless: ageGateUnless(COOKIE_CHOICE_RE), whole: true, input: "popup" },
    // a license or terms agreement may mention cookies, and its decline button must not be clicked as a cookie reject
    { name: "legal-agreement", pattern: LEGAL_AGREEMENT, whole: true, input: "popup" },
    // an investor eligibility gate may mention cookies, and its decline button must not be clicked as a cookie reject
    { name: "investor-gate", pattern: INVESTOR_GATE, whole: true, input: "popup" },
    // page text next to an age gate, unless a consent control is there too
    { name: "age-gate", pattern: AGE_WORDING, unless: ageGateUnless(NOTICE_CONTROL), lines: [4, 5], input: "page" },
    // terms of use need cookie or consent wording; a privacy-policy-only notice needs that or a button
    {
      name: "terms-without-consent",
      pattern: /\bterms\b|\bconditions\b/i,
      unless: CONSENT_WORDS,
      appliesTo: [BY_CONTINUING_PRIVACY]
    },
    {
      name: "privacy-without-control",
      unless: new RegExp(`${CONSENT_WORDS.source}|${DISMISS_LINE.source}`, "im"),
      appliesTo: [BY_CONTINUING_PRIVACY]
    },
    // a cookie policy link among short footer link lines
    {
      name: "footer-link",
      pattern: /^[^.!?:\n]{0,60}\n[\s]*\n?[^.!?:\s][^.!?:\n]{0,59}(?:\n|$)/,
      unless: NOTICE_CONTROL,
      lines: [0, 2],
      input: "page",
      appliesTo: [USE_OF_COOKIES, VERWENDUNG_VON_COOKIES, UTILISATION_DES_COOKIES, GEBRUIK_VAN_COOKIES]
    },
    {
      name: "acceptez-terms",
      pattern: /conditions (?:générales )?d.utilisation|\bcgu\b/i,
      unless: /cookie|témoin|traceur|partenaire/i,
      appliesTo: [ACCEPTEZ_UTILISATION]
    },
    // the same sentence is also a footer line with only a "learn more" link
    {
      name: "de-cookie-verb-needs-control",
      unless: NOTICE_CONTROL,
      lines: [1, 6],
      input: "page",
      appliesTo: [DE_COOKIE_VERB, DE_THIS_SITE_COOKIES, DE_SITE_USES_COOKIES]
    }
  ];
  var FRAGMENT_NEGATIVES = DETECT_CONTEXT_NEGATIVES.filter((n) => !n.whole);
  var compactedRuleSteps = [
    ["exists", "e"],
    ["visible", "v"],
    ["waitForThenClick", "c"],
    ["click", "k"],
    ["waitFor", "w"],
    ["waitForVisible", "wv"],
    ["hide", "h"],
    ["cookieContains", "cc"]
  ];
  function clearUnusedStrings(ruleset, ignoreBeforeIndex = 0) {
    const { v, s, r } = ruleset;
    const usedStringIds = /* @__PURE__ */ new Set();
    function addStringIdsFromRuleSteps(steps) {
      steps.forEach((step) => {
        for (const [, shortKey] of compactedRuleSteps) {
          if (step[shortKey] !== void 0) {
            usedStringIds.add(step[shortKey]);
          }
        }
        if (step.if) {
          addStringIdsFromRuleSteps([step.if]);
        }
        if (step.then) {
          addStringIdsFromRuleSteps(step.then);
        }
        if (step.else) {
          addStringIdsFromRuleSteps(step.else);
        }
        if (step.any) {
          addStringIdsFromRuleSteps(step.any);
        }
      });
    }
    ruleset.r.forEach((rule) => {
      addStringIdsFromRuleSteps(rule[6]);
      addStringIdsFromRuleSteps(rule[7]);
      addStringIdsFromRuleSteps(rule[8]);
      addStringIdsFromRuleSteps(rule[9]);
      rule[5].forEach((id) => usedStringIds.add(id));
    });
    return {
      v,
      r,
      s: s.slice(0, Math.max(...usedStringIds) + 1).map((str, idx) => {
        if (idx < ignoreBeforeIndex || usedStringIds.has(idx)) {
          return str;
        }
        return "";
      })
    };
  }
  function shouldRunRuleInContext(rule, mainFrame, url) {
    const runContext = rule[4];
    if (mainFrame && runContext === 1) {
      return false;
    }
    if (!mainFrame && [20, 22, 10, 12].includes(runContext)) {
      return false;
    }
    const urlPattern = rule[3];
    if (urlPattern && urlPattern !== "" && url.match(urlPattern) === null) {
      return false;
    }
    return true;
  }
  function filterCompactRules(rules, context) {
    const { v, s, r, index: index2 } = rules;
    const { url, mainFrame } = context;
    const shouldRunInContext = (rule) => shouldRunRuleInContext(rule, mainFrame, url);
    if (!mainFrame) {
      const ruleset = {
        v,
        s: s.slice(0, index2.frameStringEnd),
        r: r.slice(index2.frameRuleRange[0], index2.frameRuleRange[1]).filter(shouldRunInContext)
      };
      return clearUnusedStrings(ruleset);
    }
    const genericRules = r.slice(index2.genericRuleRange[0], index2.genericRuleRange[1]);
    const specificRules = r.slice(index2.specificRuleRange[0], index2.specificRuleRange[1]).filter(shouldRunInContext);
    if (specificRules.length > 0) {
      const ruleset = {
        v,
        s,
        r: [...genericRules, ...specificRules]
      };
      return clearUnusedStrings(ruleset);
    }
    return {
      v,
      s: s.slice(0, index2.genericStringEnd),
      r: genericRules
    };
  }
  var _config;
  _config = /* @__PURE__ */ new WeakMap();

  // shared/js/background/components/cookie-prompt-management.js
  var import_webextension_polyfill3 = __toESM(require_browser_polyfill());
  init_wrapper();

  // shared/js/background/message-registry.js
  var messageHandlers = {};
  function registerMessageHandler(name, func) {
    messageHandlers[name] = func;
  }
  var message_registry_default = messageHandlers;

  // shared/js/background/components/mv3-content-script-injection.js
  var import_webextension_polyfill2 = __toESM(require_browser_polyfill());

  // shared/js/background/components/cookie-prompt-management.js
  var logsConfig = {
    lifecycle: false,
    detectionsteps: false,
    errors: false,
    evals: false,
    messages: false,
    rulesteps: false,
    waits: false
  };
  var DEFAULT_HEURISTIC_POPUP_SEARCH_TIMEOUT = 100;
  function getHeuristicPopupSearchTimeout(autoconsentSettings) {
    const timeout = (
      /** @type {{ heuristicPopupSearchTimeout?: unknown } | undefined} */
      autoconsentSettings?.heuristicPopupSearchTimeout
    );
    return typeof timeout === "number" && Number.isInteger(timeout) && timeout > 0 ? timeout : DEFAULT_HEURISTIC_POPUP_SEARCH_TIMEOUT;
  }
  var CookiePromptManagement = class _CookiePromptManagement {
    static SUMMARY_ALARM_NAME = "cpm-summary";
    static SUMMARY_DELAY_MINUTES = 2;
    static CPM_CONTENT_SCRIPT_ID = "cookie-prompt-management-script";
    /**
     *
     * @param {{
     *  cpmMessaging: CPMMessagingBase,
     *  siteRankLookup?: (url: string) => SiteRankBucket,
     * }} opts
     */
    constructor({ cpmMessaging: cpmMessaging2, siteRankLookup }) {
      this.cpmMessaging = cpmMessaging2;
      this.siteRankLookup = siteRankLookup;
      this.cpmMessaging.setDiagnosticsErrorHandler?.((tabId, errorName) => {
        this.recordCpmDiagnosticError(tabId, errorName);
      });
      this.scheduleConfigRefresh();
      if (false) {
        const remoteConfig = (
          /** @type {import('./cpm-standalone-messaging').CPMStandaloneMessaging} */
          cpmMessaging2.remoteConfig
        );
        remoteConfig.onUpdate(async () => {
          const enabled = remoteConfig.isFeatureEnabled("autoconsent");
          const existingScripts = await chrome.scripting.getRegisteredContentScripts({
            ids: [_CookiePromptManagement.CPM_CONTENT_SCRIPT_ID]
          });
          const cpmScriptExists = existingScripts.length > 0;
          if (enabled && !cpmScriptExists) {
            console.log("registering CPM content script");
            await registerContentScripts([
              {
                id: _CookiePromptManagement.CPM_CONTENT_SCRIPT_ID,
                allFrames: true,
                js: ["public/js/content-scripts/cpm.js"],
                runAt: "document_start",
                world: "ISOLATED",
                matches: ["*://*/*"],
                matchOriginAsFallback: true
              }
            ]);
          } else if (!enabled && cpmScriptExists) {
            console.log("unregistering CPM content script");
            await unregisterContentScripts([_CookiePromptManagement.CPM_CONTENT_SCRIPT_ID]);
          }
        });
      }
      this._tabUrlsCache = /* @__PURE__ */ new Map();
      this._lastHandledCMP = /* @__PURE__ */ new Map();
      this._reloadLoopDetected = /* @__PURE__ */ new Set();
      this._stateQueue = Promise.resolve();
      this.getCpmState();
      import_webextension_polyfill3.default.alarms.onAlarm.addListener(async (alarm) => {
        if (alarm.name === _CookiePromptManagement.SUMMARY_ALARM_NAME) {
          await import_webextension_polyfill3.default.alarms.clear(_CookiePromptManagement.SUMMARY_ALARM_NAME);
          await this.sendSummaryPixel();
        }
      });
      import_webextension_polyfill3.default.runtime.onSuspend?.addListener(() => {
        this.sendSummaryPixel();
      });
      registerMessageHandler("autoconsent", (options, sender, req) => {
        return this.handleAutoConsentMessage(req.autoconsentPayload, sender).then((response) => {
          return response;
        });
      });
    }
    scheduleConfigRefresh() {
      this.remoteConfigJson = this.cpmMessaging.refreshRemoteConfig().catch((e) => {
        return null;
      });
    }
    /**
     * @param {any} jsonCpmState
     * @returns {CpmState}
     */
    _deserializeCpmState(jsonCpmState) {
      return {
        detectionCache: {
          patterns: new Set(jsonCpmState.detectionCache?.patterns || []),
          both: new Set(jsonCpmState.detectionCache?.both || []),
          onlyRules: new Set(jsonCpmState.detectionCache?.onlyRules || [])
        },
        summaryEvents: structuredClone(jsonCpmState.summaryEvents || {}),
        summaryEventsByRank: structuredClone(jsonCpmState.summaryEventsByRank || {}),
        dashboardStates: structuredClone(jsonCpmState.dashboardStates || {}),
        globalErrors: new Set(jsonCpmState.globalErrors || [])
      };
    }
    /**
     * @param {CpmState} cpmState
     * @returns {object}
     */
    _serializeCpmState(cpmState) {
      return {
        detectionCache: {
          patterns: Array.from(cpmState.detectionCache.patterns),
          both: Array.from(cpmState.detectionCache.both),
          onlyRules: Array.from(cpmState.detectionCache.onlyRules)
        },
        summaryEvents: structuredClone(cpmState.summaryEvents),
        summaryEventsByRank: structuredClone(cpmState.summaryEventsByRank),
        dashboardStates: structuredClone(cpmState.dashboardStates),
        globalErrors: Array.from(cpmState.globalErrors)
      };
    }
    /**
     * @returns {Promise<CpmState>}
     */
    async getCpmState() {
      if (!this._jsonCpmState) {
        this._jsonCpmState = await getFromSessionStorage("cpmState") || {
          detectionCache: {
            patterns: [],
            both: [],
            onlyRules: []
          },
          summaryEvents: {},
          summaryEventsByRank: {},
          dashboardStates: {},
          globalErrors: []
        };
      }
      return this._deserializeCpmState(this._jsonCpmState);
    }
    /**
     * @param {number=} tabId
     */
    async checkHeuristicActionEnabled(tabId) {
      const settings4 = await this.cpmMessaging.checkAutoconsentSetting(tabId);
      const heuristicMode = this.settingsToHeuristicModeName(settings4);
      return heuristicMode !== "off" && heuristicMode !== "";
    }
    /**
     * @param {CpmState} newState
     */
    async updateCpmState(newState) {
      this._jsonCpmState = this._serializeCpmState(newState);
      try {
        await setToSessionStorage("cpmState", this._jsonCpmState);
      } catch (e) {
        this.cpmMessaging.logMessage(`error setting cpmState to session storage: ${e}`);
      }
    }
    /**
     * Atomically read-modify-write the CPM state.
     * All state mutations are serialized through this method to prevent race conditions
     * between parallel message handlers.
     *
     * IMPORTANT: The callback must NOT await other methods that call
     * modifyCpmState (e.g. firePixel), as that would deadlock the queue.
     * Non-awaited calls are fine -- they simply queue up after the current operation.
     *
     * @param {(state: CpmState) => void | Promise<void>} fn
     * @returns {Promise<void>}
     */
    modifyCpmState(fn) {
      const op = this._stateQueue.then(async () => {
        const state = await this.getCpmState();
        await fn(state);
        await this.updateCpmState(state);
      });
      this._stateQueue = op.catch((e) => {
        this.cpmMessaging.logMessage(`error in state queue: ${e}`);
      });
      return op;
    }
    /**
     * @param {number} tabId
     */
    clearReloadLoopState(tabId) {
      this._lastHandledCMP.delete(tabId);
      this._reloadLoopDetected.delete(tabId);
    }
    /**
     * @param {number} tabId
     * @param {string} url
     * @returns {URL}
     */
    updateTopUrl(tabId, url) {
      const oldTopUrl = this._tabUrlsCache.get(tabId) || new URL("about:blank");
      let newTopUrl;
      try {
        newTopUrl = new URL(url);
      } catch (e) {
        this.cpmMessaging.logMessage(`invalid top URL: ${url}: ${e}`);
        return oldTopUrl;
      }
      this.cpmMessaging.logMessage(`${tabId} Main frame navigated from ${oldTopUrl} to ${newTopUrl}`);
      if (oldTopUrl.host !== newTopUrl.host || oldTopUrl.pathname !== newTopUrl.pathname || oldTopUrl.protocol !== newTopUrl.protocol) {
        this.clearReloadLoopState(tabId);
      }
      this._tabUrlsCache.set(tabId, newTopUrl);
      return newTopUrl;
    }
    /**
     * @returns {CpmDashboardState}
     */
    defaultCpmDashboardState() {
      return {
        consentManaged: false,
        cosmetic: null,
        optoutFailed: null,
        selftestFailed: null,
        consentReloadLoop: false,
        consentRule: null,
        consentHeuristicEnabled: null,
        cpmStage: "not_started",
        cpmErrors: [],
        cpmConfigVersion: ""
      };
    }
    /**
     * @param {number} tabId
     */
    resetCpmDashboardState(tabId) {
      this.modifyCpmState((cpmState) => {
        cpmState.dashboardStates[`${tabId}`] = this.defaultCpmDashboardState();
      });
    }
    /**
     * Record a diagnostic error in the CPM dashboard state (no propagation to native side).
     * @param {number | null} tabId
     * @param {string} errorName
     * @returns {Promise<CpmDashboardState | null>}
     */
    async recordCpmDiagnosticError(tabId, errorName) {
      let updatedDashboardState = null;
      await this.modifyCpmState((cpmState) => {
        if (typeof tabId === "number") {
          const key = `${tabId}`;
          cpmState.dashboardStates[key] ||= this.defaultCpmDashboardState();
          const dashboardState = cpmState.dashboardStates[key];
          dashboardState.cpmErrors = [.../* @__PURE__ */ new Set([...cpmState.globalErrors, ...dashboardState.cpmErrors, errorName])];
          updatedDashboardState = structuredClone(dashboardState);
        } else {
          cpmState.globalErrors.add(errorName);
        }
      });
      return updatedDashboardState;
    }
    /**
     * Atomically read-modify-write the CPM dashboard state  (extension side only).
     * @param {number} tabId
     * @param {Partial<Omit<CpmDashboardState, 'cpmErrors'>>} updates - cpmErrors should be updated with recordCpmDiagnosticError
     * @returns {Promise<CpmDashboardState>}
     */
    async updateCpmDashboardState(tabId, updates) {
      let updatedDashboardState = this.defaultCpmDashboardState();
      await this.modifyCpmState((cpmState) => {
        const key = `${tabId}`;
        cpmState.dashboardStates[key] ||= this.defaultCpmDashboardState();
        const dashboardState = cpmState.dashboardStates[key];
        Object.assign(dashboardState, updates);
        dashboardState.cpmErrors = [.../* @__PURE__ */ new Set([...cpmState.globalErrors, ...dashboardState.cpmErrors])];
        updatedDashboardState = structuredClone(dashboardState);
      });
      return updatedDashboardState;
    }
    /**
     * @param {number} tabId
     * @param {string} cmp
     * @param {boolean} isCosmetic
     */
    rememberLastHandledCMP(tabId, cmp, isCosmetic) {
      if (isCosmetic) {
        this.clearReloadLoopState(tabId);
        return;
      }
      const lastHandledCMP = this._lastHandledCMP.get(tabId);
      if (lastHandledCMP !== cmp) {
        this.clearReloadLoopState(tabId);
      }
      this._lastHandledCMP.set(tabId, cmp);
    }
    /**
     * @param {number} tabId
     * @param {string} cmp
     * @returns {boolean} true when a new reload loop is detected
     */
    detectReloadLoop(tabId, cmp) {
      const lastHandledCMP = this._lastHandledCMP.get(tabId);
      if (!this._reloadLoopDetected.has(tabId) && lastHandledCMP === cmp) {
        this.cpmMessaging.logMessage(`reload loop detected: ${cmp} on ${this._tabUrlsCache.get(tabId)} tabId: ${tabId}`);
        this._reloadLoopDetected.add(tabId);
        return true;
      }
      return false;
    }
    /**
     * Called on EVERY message from the content script.
     * Make sure not to trigger anything heavy (e.g. native messaging) without a message type filter!
     * Replies to the frame (initResp, evalResp) are returned as the response to its message rather than sent with
     * tabs.sendMessage, so content scripts don't need a runtime.onMessage listener: WebKit keeps a frame whose content
     * script has one alive after the page removes it.
     * @param {import('@duckduckgo/autoconsent').ContentScriptMessage} msg
     * @param {browser.Runtime.MessageSender} sender
     * @returns {Promise<AutoconsentReply | undefined>}
     */
    async handleAutoConsentMessage(msg, sender) {
      const frameId = sender.frameId;
      if (!sender.tab || typeof frameId !== "number") {
        this.cpmMessaging.logMessage(`Invalid frameId ${frameId} or tab ${sender.tab}`);
        return;
      }
      const tabId = sender.tab.id;
      if (typeof tabId !== "number") {
        this.cpmMessaging.logMessage(`Invalid tabId ${tabId}`);
        return;
      }
      const isMainFrame = frameId === 0;
      const frameUrl = sender.url || sender.origin || "about:blank";
      const tabUrl = sender.tab.url || sender.tab.pendingUrl || "about:blank";
      const siteRank = this.siteRankLookup?.(tabUrl);
      const mark = (stage) => {
        if (isMainFrame) this.cpmMessaging.notifyInitProgress?.(tabId, tabUrl, stage);
      };
      if (msg.type === "init" && isMainFrame) {
        mark("background_received");
        this.updateTopUrl(tabId, tabUrl);
        this.resetCpmDashboardState(tabId);
      }
      const remoteConfig = await this.remoteConfigJson;
      if (!remoteConfig) {
        this.cpmMessaging.logMessage("Remote config not ready, scheduling retry");
        this.scheduleConfigRefresh();
        if (isMainFrame) {
          this.cpmMessaging.refreshDashboardState(
            tabId,
            tabUrl,
            await this.updateCpmDashboardState(tabId, {
              cpmStage: "config_unavailable",
              cpmConfigVersion: "unknown"
            })
          );
        }
        return;
      }
      if (msg.type === "init") {
        mark("config_read");
      }
      const cpmConfigVersion = `${remoteConfig.version || "unknown"}`;
      const autoconsentRemoteConfig = remoteConfig.features?.autoconsent;
      const autoconsentSettings = autoconsentRemoteConfig?.settings;
      if (!autoconsentSettings) {
        this.cpmMessaging.logMessage(`autoconsentSettings not ready: ${autoconsentSettings}`);
        if (isMainFrame) {
          this.cpmMessaging.refreshDashboardState(
            tabId,
            tabUrl,
            await this.updateCpmDashboardState(tabId, {
              cpmStage: "settings_missing",
              cpmConfigVersion
            })
          );
        }
        return;
      }
      switch (msg.type) {
        case "init": {
          const settings4 = await this.cpmMessaging.checkAutoconsentSetting(tabId);
          isMainFrame && this.cpmMessaging.setInitProgressEnabled?.(!!settings4.featureFlags?.cpmInitProgress);
          mark("settings_checked");
          const heuristicMode = this.settingsToHeuristicModeName(settings4);
          const heuristicActionEnabled = heuristicMode !== "off";
          if (heuristicMode === "") {
            this.cpmMessaging.logMessage("autoconsent setting not enabled");
            if (isMainFrame) {
              this.cpmMessaging.refreshDashboardState(
                tabId,
                tabUrl,
                await this.updateCpmDashboardState(tabId, {
                  cpmStage: "setting_disabled",
                  cpmConfigVersion,
                  consentHeuristicEnabled: heuristicActionEnabled
                })
              );
            }
            return;
          }
          if (isMainFrame) {
            this.updateTopUrl(tabId, tabUrl);
            this.scheduleConfigRefresh();
          }
          const isEnabled = await this.cpmMessaging.checkAutoconsentEnabledForSite(tabUrl, tabId);
          mark("site_checked");
          if (!isEnabled) {
            this.cpmMessaging.logMessage(`autoconsent disabled for site: ${tabUrl}`);
            if (isMainFrame) {
              this.cpmMessaging.refreshDashboardState(
                tabId,
                tabUrl,
                await this.updateCpmDashboardState(tabId, {
                  cpmStage: "site_disabled",
                  cpmConfigVersion,
                  consentHeuristicEnabled: heuristicActionEnabled
                })
              );
              this.firePixel("disabled-for-site", siteRank);
            }
            return;
          }
          if (isMainFrame) {
            this.scheduleConfigRefresh();
          }
          const visualTest = false;
          let autoAction = "optOut";
          if (this._reloadLoopDetected.has(tabId)) {
            this.cpmMessaging.logMessage(`reload loop detected, disabling autoAction: ${tabId}`);
            autoAction = null;
          }
          if (isMainFrame) {
            this.updateCpmDashboardState(tabId, {
              consentReloadLoop: this._reloadLoopDetected.has(tabId),
              consentRule: this._lastHandledCMP.get(tabId) || null,
              consentHeuristicEnabled: heuristicActionEnabled,
              cpmStage: "init_received",
              cpmConfigVersion
            }).then((dashboardState) => this.cpmMessaging.refreshDashboardState(tabId, tabUrl, dashboardState));
            this.firePixel("init", siteRank);
          }
          const autoconsentConfig = {
            enabled: isEnabled,
            autoAction,
            detectRetries: 20,
            isMainWorld: false,
            disabledCmps: autoconsentSettings.disabledCMPs || [],
            enablePrehide: true,
            prehideTimeout: 2e3,
            enableCosmeticRules: true,
            enableGeneratedRules: true,
            enableHeuristicDetection: true,
            heuristicMode,
            enableHeuristicHitTest: !!settings4.featureFlags?.heuristicHitTest,
            enablePopupMutationObserver: !!settings4.featureFlags?.popupMutationObserver,
            heuristicPopupSearchTimeout: getHeuristicPopupSearchTimeout(autoconsentSettings),
            visualTest,
            logs: logsConfig
          };
          const compactRuleList = autoconsentSettings.compactRuleList;
          const rules = {
            autoconsent: []
          };
          if (compactRuleList) {
            if (compactRuleList.index) {
              rules.compact = filterCompactRules(
                /** @type {import('@duckduckgo/autoconsent').IndexedCMPRuleset} */
                compactRuleList,
                {
                  // use the frame URL here because rules are filtered by frame context
                  url: frameUrl,
                  mainFrame: isMainFrame
                }
              );
            } else {
              rules.compact = compactRuleList;
            }
          }
          mark("response_sent");
          return {
            type: "initResp",
            rules,
            config: autoconsentConfig
          };
        }
        case "cmpDetected": {
          break;
        }
        case "popupFound": {
          if (this.detectReloadLoop(tabId, msg.cmp)) {
            this.firePixel("error_reload-loop", siteRank);
          }
          this.cpmMessaging.refreshDashboardState(
            tabId,
            tabUrl,
            await this.updateCpmDashboardState(tabId, {
              cpmStage: "popup_found",
              consentRule: msg.cmp,
              consentReloadLoop: this._reloadLoopDetected.has(tabId)
            })
          );
          this.firePixel("popup-found", siteRank);
          break;
        }
        case "optOutResult": {
          if (!msg.result) {
            this.firePixel("error_optout", siteRank);
            this.cpmMessaging.refreshDashboardState(
              tabId,
              tabUrl,
              await this.updateCpmDashboardState(tabId, {
                consentManaged: true,
                optoutFailed: true,
                selftestFailed: null,
                consentRule: msg.cmp,
                cpmStage: "optout_failed"
              })
            );
          } else {
          }
          break;
        }
        case "autoconsentDone": {
          this.rememberLastHandledCMP(tabId, msg.cmp, msg.isCosmetic);
          this.cpmMessaging.refreshDashboardState(
            tabId,
            tabUrl,
            await this.updateCpmDashboardState(tabId, {
              consentManaged: true,
              cosmetic: msg.isCosmetic,
              optoutFailed: false,
              // Re-read after rememberLastHandledCMP, which can clear the loop state, so the done state stays authoritative.
              consentReloadLoop: this._reloadLoopDetected.has(tabId),
              consentRule: msg.cmp,
              cpmStage: "done"
            })
          );
          if (msg.cmp.startsWith("HEURISTIC")) {
            this.firePixel("done_heuristic", siteRank);
          } else {
            this.firePixel(msg.isCosmetic ? "done_cosmetic" : "done", siteRank);
          }
          this.cpmMessaging.showCpmAnimation(tabId, tabUrl, msg.isCosmetic);
          this.firePixel(msg.isCosmetic ? "animation-shown_cosmetic" : "animation-shown", siteRank);
          this.cpmMessaging.notifyPopupHandled(tabId, msg);
          break;
        }
        case "report": {
          const state = msg.state || {};
          const detectedByPatterns = state.heuristicPatterns?.length > 0;
          const detectedBySnippets = state.heuristicSnippets?.length > 0;
          const detectedPopups = state.detectedPopups?.length > 0;
          const heuristicMatch = detectedByPatterns || detectedBySnippets;
          await this.modifyCpmState((cpmState) => {
            if (isMainFrame && heuristicMatch && !cpmState.detectionCache.patterns.has(msg.instanceId)) {
              cpmState.detectionCache.patterns.add(msg.instanceId);
              this.firePixel("detected-by-patterns", siteRank);
            }
            if (isMainFrame && detectedPopups) {
              if (heuristicMatch && !cpmState.detectionCache.both.has(msg.instanceId)) {
                cpmState.detectionCache.both.add(msg.instanceId);
                this.firePixel("detected-by-both", siteRank);
              } else if (!heuristicMatch && !cpmState.detectionCache.onlyRules.has(msg.instanceId)) {
                cpmState.detectionCache.onlyRules.add(msg.instanceId);
                this.firePixel("detected-only-rules", siteRank);
              }
            }
          });
          break;
        }
        case "eval": {
          if (typeof msg.snippetId !== "undefined") {
            let result = false;
            try {
              const [injectionResult] = await this.evalInTab(tabId, frameId, msg.snippetId);
              result = injectionResult?.result ?? false;
            } catch (e) {
              this.cpmMessaging.logMessage(`eval failed in ${frameUrl}: ${e}`);
            }
            if (logsConfig.evals) {
              console.groupCollapsed(`eval result for ${frameUrl}`);
              console.log(msg.code, result);
              console.groupEnd();
            }
            return {
              id: msg.id,
              type: "evalResp",
              result
            };
          }
          break;
        }
        case "autoconsentError": {
          if (msg.details?.msg?.includes("Found multiple CMPs")) {
            const dashboardState = await this.recordCpmDiagnosticError(tabId, "multiple_cmps");
            if (dashboardState) {
              this.cpmMessaging.refreshDashboardState(tabId, tabUrl, dashboardState);
            }
            this.firePixel("error_multiple-popups", siteRank);
          }
          break;
        }
        case "visualDelay": {
          console.log("visualDelay", msg);
          break;
        }
        default:
          this.cpmMessaging.logMessage(`Unhandled autoconsent message type: ${msg.type}`);
          break;
      }
    }
    /**
     *
     * @param {number} tabId
     * @param {number} frameId
     * @param {keyof typeof evalSnippets} snippetId
     * @returns {Promise<chrome.scripting.InjectionResult<boolean>[]>}
     */
    async evalInTab(tabId, frameId, snippetId) {
      return chrome.scripting.executeScript({
        target: {
          tabId,
          frameIds: [frameId]
        },
        world: "MAIN",
        func: snippets[snippetId]
      });
    }
    /**
     * Determine the autoconsent operating mode from user settings and feature flags.
     *  - '' if autoconsent is disabled.
     *  - 'off' if heuristic action is disabled.
     *  - 'reject' if cookie popup preference setting is disabled (this is the old settings UI)
     *  - 'tier1' if user preference is 'default'.
     *  - 'tier2' if user preference is 'max'.
     *  - '' if the operating mode is not determined.
     * @param {AutoconsentUserSettings} settings
     * @returns {'' | 'off' | 'reject' | 'tier1' | 'tier2'}
     */
    settingsToHeuristicModeName(settings4) {
      const { enabled, userPreference, featureFlags } = settings4;
      if (!enabled || userPreference === "off") {
        return "";
      }
      if (!featureFlags.heuristicAction) {
        return "off";
      }
      if (userPreference === "default") {
        return "tier1";
      }
      if (userPreference === "max") {
        return "tier2";
      }
      return "off";
    }
    async getPixelHeuristicParameter() {
      return this.settingsToHeuristicModeName(await this.cpmMessaging.checkAutoconsentSetting());
    }
    /**
     * @param {string} eventName
     * @param {SiteRankBucket | undefined} siteRank
     */
    async firePixel(eventName, siteRank) {
      this.modifyCpmState((cpmState) => {
        let counts = cpmState.summaryEvents;
        if (siteRank) {
          counts = cpmState.summaryEventsByRank[siteRank] ||= {};
        }
        counts[eventName] = (counts[eventName] || 0) + 1;
      });
      createAlarm(_CookiePromptManagement.SUMMARY_ALARM_NAME, {
        delayInMinutes: _CookiePromptManagement.SUMMARY_DELAY_MINUTES
      });
      const pixelName = `autoconsent_${eventName}`;
      this.cpmMessaging.sendPixel(pixelName, "daily", {
        consentHeuristicEnabled: await this.getPixelHeuristicParameter(),
        fromExtension: "1"
      });
    }
    /**
     * @param {Record<string, number>} events - summary counts of one bucket
     * @returns {CoverageCounts}
     */
    static coverageCounts(events) {
      const patterns = events["detected-by-patterns"] || 0;
      const both = events["detected-by-both"] || 0;
      return { unhandled: Math.max(0, patterns - both), pages: events.init || 0 };
    }
    /**
     * @param {Record<string, number>} events - summary counts of one bucket
     * @param {SiteRankBucket=} siteRank
     */
    async reportCoverage(events, siteRank) {
      const counts = _CookiePromptManagement.coverageCounts(events);
      if (counts.unhandled === 0 && counts.pages === 0) {
        return;
      }
      try {
        await this.cpmMessaging.reportCoverage(counts, siteRank);
      } catch (e) {
        this.cpmMessaging.logMessage(`error reporting coverage: ${e}`);
      }
    }
    /**
     * Counts without a bucket, e.g. from a state saved before the lookup was added, go in a pixel without `siteRank`.
     */
    async sendSummaryPixel() {
      let summaryEvents = {};
      let summaryEventsByRank = {};
      await this.modifyCpmState((cpmState) => {
        summaryEvents = structuredClone(cpmState.summaryEvents);
        summaryEventsByRank = structuredClone(cpmState.summaryEventsByRank);
        cpmState.summaryEvents = {};
        cpmState.summaryEventsByRank = {};
        cpmState.detectionCache.patterns.clear();
        cpmState.detectionCache.both.clear();
        cpmState.detectionCache.onlyRules.clear();
      });
      const consentHeuristicEnabled = await this.getPixelHeuristicParameter();
      if (!this.siteRankLookup || Object.keys(summaryEvents).length > 0) {
        this.cpmMessaging.sendPixel("autoconsent_summary", "standard", {
          ...summaryEvents,
          consentHeuristicEnabled,
          fromExtension: "1"
        });
        this.reportCoverage(summaryEvents);
      }
      for (const [siteRank, events] of Object.entries(summaryEventsByRank)) {
        if (Object.keys(events).length === 0) {
          continue;
        }
        this.cpmMessaging.sendPixel("autoconsent_summary", "standard", {
          ...events,
          siteRank,
          consentHeuristicEnabled,
          fromExtension: "1"
        });
        this.reportCoverage(
          events,
          /** @type {SiteRankBucket} */
          siteRank
        );
      }
    }
  };

  // shared/js/background/components/cpm-embedded-messaging.js
  init_wrapper();
  var SUBFEATURE_CHECK_TTL = 30 * 1e3;
  var SETTING_CHECK_TTL = 10 * 1e3;
  var SITE_CHECK_TTL = 3 * 1e3;
  var MAX_CACHE_SIZE = 100;
  var NATIVE_MESSAGE_TIMEOUT_MS = 20 * 1e3;
  var CPMEmbeddedMessaging = class {
    /**
     * @param {NativeMessagingInterface} nativeMessaging
     */
    constructor(nativeMessaging2) {
      this.nativeMessaging = nativeMessaging2;
      this._cache = /* @__PURE__ */ new Map();
      this._diagnosticsErrorHandler = null;
      this._cachedConfig = null;
      this._initProgressEnabled = false;
      this._initProgressKnown = false;
      this._initProgressLoaded = getFromSessionStorage("initProgressEnabled").then((enabled) => {
        if (!this._initProgressKnown) this._initProgressEnabled = enabled === true;
      }).catch(() => {
      });
    }
    /**
     * Remember whether the app wants init progress notifications, also for a background that is woken later.
     * @param {boolean} enabled
     */
    async setInitProgressEnabled(enabled) {
      this._initProgressKnown = true;
      if (enabled === this._initProgressEnabled) return;
      this._initProgressEnabled = enabled;
      try {
        await setToSessionStorage("initProgressEnabled", enabled);
      } catch (e) {
      }
    }
    /**
     * @param {(tabId: number | null, errorName: string) => void} handler
     */
    setDiagnosticsErrorHandler(handler) {
      this._diagnosticsErrorHandler = handler;
    }
    /**
     * @param {number | null} tabId
     * @param {string} method
     */
    _recordDiagnosticsError(tabId, method2) {
      const scope = typeof tabId === "number" ? "tab" : "glob";
      const errorName = `${scope}_${method2}`;
      this._diagnosticsErrorHandler?.(tabId, errorName);
    }
    /**
     * Send a fire-and-forget notification message to the native app. May reject if the native side didn't acknowledge the message.
     * @param {string} method
     * @param {Record<string, any>} params
     */
    async _notify(method2, params, timeout = NATIVE_MESSAGE_TIMEOUT_MS) {
      const diagnosticsTabId = typeof params.tabId === "number" ? params.tabId : null;
      try {
        await this._withTimeout(this.nativeMessaging.notify(method2, params), timeout);
      } catch (e) {
        console.error("error sending native notification", e);
        this._recordDiagnosticsError(diagnosticsTabId, method2);
      }
    }
    /**
     * Send a fire-and-forget progress mark for the main frame `init` message.
     * Unlike other notifications this never records a diagnostics error and never rejects,
     * so that these marks cannot change the CPM state or the breakage reports. Nothing is sent unless the app
     * enabled them. A background that was just woken waits for the saved flag first, so its early marks are not lost.
     * @param {number} tabId
     * @param {string} url
     * @param {import('./cookie-prompt-management').CpmInitProgressStage} stage
     */
    async notifyInitProgress(tabId, url, stage) {
      if (!this._initProgressKnown) await this._initProgressLoaded;
      if (!this._initProgressEnabled) return;
      try {
        await this._withTimeout(this.nativeMessaging.notify("cpmInitProgress", { tabId, url, stage }));
      } catch (e) {
      }
    }
    /**
     * Send a request to the native app and wait for a response.
     * If cacheKey and ttl are provided, the result is cached and
     * returned immediately on subsequent calls within the TTL.
     * @param {string} method
     * @param {Record<string, any>} params
     * @param {string} [cacheKey]
     * @param {number} [ttl]
     * @param {number=} diagnosticsTabId
     * @param {number} [timeout] - milliseconds to wait before abandoning the native request
     * @returns {Promise<any>}
     */
    async _request(method2, params, cacheKey, ttl, diagnosticsTabId, timeout = NATIVE_MESSAGE_TIMEOUT_MS) {
      if (cacheKey && ttl) {
        const cached = this._cache.get(cacheKey);
        if (cached && Date.now() - cached.time < ttl) {
          return cached.value;
        }
      }
      try {
        const result = await this._withTimeout(this.nativeMessaging.request(method2, params), timeout);
        if (cacheKey && ttl) {
          if (this._cache.size >= MAX_CACHE_SIZE) {
            const oldest = this._cache.keys().next().value;
            if (oldest !== void 0) this._cache.delete(oldest);
          }
          this._cache.set(cacheKey, { time: Date.now(), value: result });
        }
        return result;
      } catch (e) {
        console.error(`error sending native request for ${method2}`, e);
        this._recordDiagnosticsError(diagnosticsTabId ?? null, method2);
      }
    }
    /**
     * Race a native operation against a timeout so a hung native side cannot leave the promise pending forever. Rejects with a timeout error.
     * @param {Promise<any>} operation
     * @param {number} [timeout] - milliseconds before the operation is rejected
     * @returns {Promise<any>}
     */
    async _withTimeout(operation, timeout = NATIVE_MESSAGE_TIMEOUT_MS) {
      let timeoutId;
      try {
        return await Promise.race([
          operation,
          new Promise((_resolve, reject) => {
            timeoutId = setTimeout(() => reject(new Error(`native message timed out after ${timeout}ms`)), timeout);
          })
        ]);
      } finally {
        if (timeoutId !== void 0) clearTimeout(timeoutId);
      }
    }
    async logMessage(message, isDebug = false) {
      console.log(message);
      if (isDebug) {
        await this._notify("extensionLog", {
          message
        });
      }
    }
    /**
     * @param {Partial<CpmDashboardState>} dashboardState
     */
    async refreshDashboardState(tabId, url, dashboardState) {
      const { cpmErrors, ...rest } = dashboardState;
      await this._notify("refreshCpmDashboardState", {
        tabId,
        url,
        consentStatus: {
          ...rest,
          // convert cpmErrors from an array to a comma-separated string
          ...cpmErrors ? {
            // limit the length to avoid overflows in breakage pixel
            cpmErrors: cpmErrors.join(",").substring(0, 255)
          } : {}
        }
      });
    }
    async showCpmAnimation(tabId, topUrl, isCosmetic) {
      await this._notify("showCpmAnimation", {
        tabId,
        topUrl,
        isCosmetic
      });
    }
    async notifyPopupHandled(tabId, msg) {
      await this._notify("cookiePopupHandled", {
        tabId,
        msg
      });
    }
    /**
     * Check autoconsent enabled state and user preference.
     * @param {number} [tabId]
     * @returns {Promise<import('./cookie-prompt-management').AutoconsentUserSettings>}
     */
    async checkAutoconsentSetting(tabId) {
      const result = await this._request("isAutoconsentSettingEnabled", {}, "userSetting", SETTING_CHECK_TTL, tabId);
      return result ?? { enabled: false };
    }
    async checkAutoconsentEnabledForSite(url, tabId) {
      const result = await this._request("isFeatureEnabled", { featureName: "autoconsent", url }, `site:${url}`, SITE_CHECK_TTL, tabId);
      return result?.enabled ?? false;
    }
    async checkSubfeatureEnabled(subfeatureName, tabId) {
      const result = await this._request(
        "isSubFeatureEnabled",
        { featureName: "autoconsent", subfeatureName },
        `subfeature:${subfeatureName}`,
        SUBFEATURE_CHECK_TTL,
        tabId
      );
      return result?.enabled ?? false;
    }
    async sendPixel(pixelName, type, params) {
      await this._notify("sendPixel", {
        pixelName,
        type,
        params
      });
    }
    async reportCoverage(counts, siteRank) {
      await this._notify("reportCpmCoverage", {
        unhandled: counts.unhandled,
        pages: counts.pages,
        ...siteRank ? { siteRank } : {}
      });
    }
    async refreshRemoteConfig() {
      const cachedConfig = this._cachedConfig || await getFromSessionStorage("config") || { version: "unknown" };
      const cachedConfigVersion = `${cachedConfig.version}`;
      try {
        console.log(`fetching config from native, cachedConfigVersion: ${cachedConfigVersion}`);
        const result = await this._withTimeout(
          this.nativeMessaging.request("getResourceIfNew", { name: "config", version: cachedConfigVersion })
        );
        if (result.updated) {
          this._cachedConfig = result.data;
          try {
            await setToSessionStorage("config", this._cachedConfig);
          } catch (e) {
            this.logMessage(`error setting cached config to session storage: ${e}`);
          }
          return this._cachedConfig;
        }
        return cachedConfig;
      } catch (e) {
        this._recordDiagnosticsError(null, "getResourceIfNew");
        this.logMessage(`error refreshing remote config: ${e}`);
        if (cachedConfigVersion !== "unknown") {
          return cachedConfig;
        }
        throw e;
      }
    }
  };

  // shared/js/shared-utils/domain-hashes.js
  function fnv1a32(str) {
    let hash = 2166136261;
    for (let i = 0; i < str.length; i++) {
      hash ^= str.charCodeAt(i);
      hash = Math.imul(hash, 16777619);
    }
    return hash >>> 0;
  }
  function decodeDomainHashes(domainHashes) {
    const binary = globalThis.atob(domainHashes.data);
    const hashes = new Uint32Array(domainHashes.count);
    let pos = 0;
    let prev = 0;
    for (let i = 0; i < domainHashes.count; i++) {
      let delta = 0;
      let shift = 0;
      let byte;
      do {
        byte = binary.charCodeAt(pos++);
        delta += (byte & 127) * 2 ** shift;
        shift += 7;
      } while (byte & 128);
      prev += delta;
      hashes[i] = prev;
    }
    if (pos !== binary.length || prev > 4294967295) {
      throw new Error("Malformed domain hashes");
    }
    return hashes;
  }
  function containsHash(sorted, hash) {
    let lo = 0;
    let hi = sorted.length - 1;
    while (lo <= hi) {
      const mid = lo + hi >>> 1;
      if (sorted[mid] < hash) {
        lo = mid + 1;
      } else if (sorted[mid] > hash) {
        hi = mid - 1;
      } else {
        return true;
      }
    }
    return false;
  }

  // shared/js/background/components/cpm-site-rank.js
  function hostnameFromUrl(url) {
    let hostname;
    try {
      hostname = new URL(url).hostname;
    } catch {
      return "";
    }
    return hostname.endsWith(".") ? hostname.slice(0, -1) : hostname;
  }
  function createSiteRankLookup(topSites) {
    if (!topSites.count) {
      return void 0;
    }
    let hashes;
    try {
      hashes = decodeDomainHashes(topSites);
    } catch {
      return void 0;
    }
    return (url) => {
      const hostname = hostnameFromUrl(url);
      const last = hostname.lastIndexOf(".");
      if (last <= 0) {
        return "other";
      }
      let start = hostname.lastIndexOf(".", last - 1);
      for (; ; ) {
        if (containsHash(hashes, fnv1a32(hostname.slice(start + 1)))) {
          return "top10k";
        }
        if (start <= 0) {
          return "other";
        }
        start = hostname.lastIndexOf(".", start - 1);
      }
    };
  }

  // shared/js/background/components/message-router.js
  var import_webextension_polyfill5 = __toESM(require_browser_polyfill());
  init_wrapper();

  // shared/js/background/utils.js
  var import_webextension_polyfill4 = __toESM(require_browser_polyfill());
  init_wrapper();

  // shared/js/background/storage/tds.js
  var settings = require_settings();

  // shared/js/background/utils.js
  var import_settings = __toESM(require_settings());

  // node_modules/tldts-core/dist/es6/src/options.js
  function setDefaultsImpl({ allowIcannDomains = true, allowPrivateDomains = false, detectIp = true, detectSpecialUse = false, extraSuffixes = null, extractHostname: extractHostname2 = true, mixedInputs = true, validHosts = null, validateHostname = true }) {
    return {
      allowIcannDomains,
      allowPrivateDomains,
      detectIp,
      detectSpecialUse,
      extraSuffixes,
      extractHostname: extractHostname2,
      mixedInputs,
      validHosts,
      validateHostname
    };
  }
  var DEFAULT_OPTIONS = (
    /*@__INLINE__*/
    setDefaultsImpl({})
  );

  // node_modules/tldts-core/dist/es6/src/factory.js
  function getEmptyResult() {
    return {
      domain: null,
      domainWithoutSuffix: null,
      hostname: null,
      isIcann: null,
      isIp: null,
      isPrivate: null,
      isSpecialUse: null,
      publicSuffix: null,
      subdomain: null
    };
  }

  // node_modules/tldts/dist/es6/src/data/trie.js
  var nodeFlags = /* @__PURE__ */ new Uint8Array([1, 2, 1, 1, 1, 1, 1, 1, 0, 1, 1, 2, 1, 1, 2, 2, 2, 0, 2, 2, 2, 2, 0, 2, 2, 2, 1, 2, 2, 2, 1, 1, 1, 1, 1, 1, 1, 0, 2, 0, 1, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1, 1, 1, 0, 0, 2, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 0, 1, 1, 0, 0, 2, 0, 0, 0, 1, 1, 1, 0, 2, 0, 0, 0, 0, 0, 0, 0, 2, 0, 2, 2, 0, 0, 2, 2, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 1, 0, 2, 1, 1, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 2, 2, 2, 0, 0, 2, 0, 0, 2, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 1, 0, 2, 2, 0, 0, 0, 2, 0, 1, 1, 0, 2, 0, 2, 2, 2, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 0, 0, 0, 0, 1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 2, 2, 0, 2, 2, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 2, 2, 0, 2, 2, 2, 2, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 2, 2, 0, 0, 0, 2, 2, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 2, 2, 0, 0, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 2, 2, 1, 2, 1, 1, 1, 2, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 2, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0]);
  var edgeStart = /* @__PURE__ */ new Uint16Array([0, 0, 0, 10, 11, 18, 106, 111, 117, 118, 126, 132, 133, 140, 149, 150, 151, 152, 153, 154, 156, 157, 159, 160, 161, 163, 165, 240, 253, 255, 256, 257, 272, 274, 281, 282, 285, 286, 287, 290, 292, 311, 312, 314, 323, 328, 345, 346, 349, 350, 352, 354, 390, 391, 393, 396, 397, 401, 403, 407, 410, 442, 445, 458, 459, 467, 468, 470, 480, 494, 495, 496, 497, 506, 507, 544, 549, 565, 585, 591, 633, 635, 636, 637, 638, 665, 692, 693, 841, 847, 850, 851, 852, 857, 862, 871, 893, 894, 895, 896, 897, 898, 899, 918, 920, 921, 924, 926, 927, 929, 931, 946, 961, 966, 967, 969, 970, 971, 972, 973, 975, 978, 983, 984, 985, 987, 988, 991, 994, 995, 996, 1009, 1011, 1023, 1034, 1042, 1044, 1084, 1087, 1091, 1092, 1094, 1097, 1108, 1110, 1120, 1122, 1128, 1130, 1131, 1133, 1136, 1137, 1138, 1191, 1193, 1195, 1215, 1216, 1217, 1218, 1220, 1231, 1262, 1273, 1274, 1287, 1297, 1306, 1314, 1315, 1320, 1334, 1345, 1357, 1369, 1383, 1384, 1395, 1429, 1430, 1431, 1447, 1463, 1475, 1548, 1549, 1551, 1552, 1588, 1607, 1608, 1609, 1610, 1611, 1614, 1618, 1621, 1623, 1657, 1658, 1666, 1667, 1668, 1669, 1670, 1672, 1674, 1676, 1677, 1681, 1682, 1683, 1685, 1687, 1688, 1690, 1691, 1692, 1703, 1705, 1706, 1710, 1711, 1714, 1721, 1722, 1727, 1731, 1732, 1734, 1735, 1736, 1737, 1738, 1739, 1740, 1741, 1742, 1743, 1744, 1745, 1746, 1747, 1749, 1750, 1751, 2214, 2217, 2218, 2220, 2227, 2234, 2244, 2248, 2259, 2260, 2261, 2273, 2274, 2276, 2278, 2279, 2286, 2287, 2289, 2290, 2292, 2293, 2294, 2295, 2296, 2371, 2373, 2394, 2395, 2396, 2398, 2399, 2401, 2402, 2458, 2459, 2460, 2467, 2473, 2483, 2493, 2546, 2547, 2548, 2558, 2572, 2573, 2576, 2583, 2584, 2592, 2594, 2595, 2596, 2597, 2608, 2609, 2610, 2612, 2613, 2615, 2616, 2625, 2637, 2643, 2645, 2677, 2681, 2683, 2684, 2686, 2687, 2699, 2700, 2702, 2710, 2717, 2723, 2728, 2729, 2735, 2738, 2744, 2751, 2758, 2766, 2767, 2768, 2806, 2812, 2816, 2833, 2834, 2839, 2857, 2888, 2906, 2908, 2911, 2919, 2921, 2928, 2980, 3004, 3005, 3006, 3007, 3008, 3009, 3010, 3017, 3018, 3019, 3020, 3021, 3022, 3024, 3025, 3029, 3113, 3126, 3127, 3564, 3568, 3582, 3634, 3662, 3684, 3742, 3764, 3779, 3842, 3893, 3931, 3967, 3992, 4134, 4180, 4231, 4250, 4284, 4299, 4319, 4349, 4380, 4403, 4434, 4464, 4496, 4523, 4598, 4620, 4658, 4668, 4702, 4721, 4747, 4789, 4839, 4865, 4934, 4935, 4937, 4960, 4983, 5019, 5050, 5067, 5124, 5137, 5161, 5190, 5192, 5226, 5242, 5270, 5575, 5584, 5593, 5600, 5617, 5621, 5627, 5666, 5668, 5675, 5682, 5691, 5698, 5699, 5700, 5712, 5715, 5730, 5731, 5740, 5741, 5750, 5759, 5765, 5767, 5768, 5769, 5807, 5808, 5810, 5818, 5825, 5838, 5842, 5844, 5845, 5851, 5858, 5872, 5882, 5887, 5895, 5903, 5909, 5910, 5914, 5916, 5917, 5929, 6001, 6002, 6003, 6004, 6006, 6007, 6010, 6012, 6015, 6019, 6020, 6021, 6027, 6028, 6029, 6031, 6033, 6035, 6036, 6037, 6040, 6042, 6045, 6046, 6048, 6246, 6253, 6254, 6255, 6265, 6270, 6287, 6301, 6310, 6311, 6312, 6316, 6317, 6319, 6321, 6327, 6328, 6331, 6332, 6334, 6335, 6336, 7236, 7239, 7243, 7261, 7270, 7273, 7280, 7281, 7283, 7284, 7285, 7287, 7339, 7340, 7343, 7344, 7462, 7463, 7474, 7492, 7499, 7502, 7511, 7512, 7513, 7528, 7583, 7775, 7777, 7779, 7780, 7782, 7787, 7800, 7801, 7817, 7824, 7833, 7836, 7839, 7846, 7854, 7858, 7859, 7860, 7874, 7879, 7888, 7889, 7890, 7894, 7929, 7930, 7951, 7958, 7966, 7967, 7972, 7980, 8024, 8025, 8031, 8034, 8047, 8052, 8053, 8055, 8057, 8097, 8098, 8104, 8111, 8112, 8122, 8131, 8146, 8150, 8152, 8204, 8205, 8210, 8211, 8214, 8216, 8217, 8218, 8227, 8241, 8249, 8263, 8274, 8275, 8277, 8279, 8301, 8312, 8318, 8319, 8331, 8343, 8430, 8442, 8450, 8453, 8459, 8484, 8487, 8488, 8489, 8490, 8492, 8495, 8498, 8509, 8511, 8513, 8541, 8616, 8623, 8627, 8628, 8637, 8659, 8660, 8665, 8666, 8748, 8750, 8751, 8760, 8764, 8770, 8776, 8782, 8792, 8797, 8798, 8816, 8827, 8832, 8837, 8847, 8853, 8857, 8863, 8869, 10476, 10477, 10478, 10485, 10487]);
  var edgeLength = /* @__PURE__ */ new Uint8Array([3, 3, 3, 3, 3, 3, 3, 3, 5, 8, 8, 2, 2, 3, 3, 3, 3, 3, 8, 5, 5, 5, 5, 5, 3, 3, 5, 5, 9, 12, 19, 8, 19, 8, 11, 9, 9, 8, 7, 7, 6, 8, 9, 16, 10, 7, 7, 11, 8, 6, 6, 9, 7, 11, 7, 14, 4, 4, 4, 4, 4, 4, 10, 7, 6, 6, 6, 6, 10, 10, 6, 10, 10, 22, 11, 9, 10, 10, 10, 9, 10, 8, 7, 7, 7, 8, 21, 13, 11, 11, 9, 10, 9, 13, 10, 8, 8, 9, 12, 9, 7, 10, 7, 7, 13, 7, 3, 3, 3, 3, 3, 2, 3, 3, 3, 3, 3, 4, 3, 3, 3, 3, 3, 8, 4, 6, 3, 3, 3, 3, 3, 3, 1, 2, 5, 3, 3, 3, 3, 7, 2, 2, 2, 2, 2, 2, 3, 3, 3, 1, 7, 8, 5, 2, 2, 7, 4, 5, 7, 2, 2, 1, 4, 1, 11, 9, 9, 5, 5, 8, 5, 5, 5, 5, 5, 5, 5, 3, 3, 3, 3, 3, 5, 5, 11, 9, 9, 8, 9, 9, 13, 7, 14, 7, 6, 6, 6, 7, 6, 6, 6, 6, 6, 6, 10, 7, 11, 9, 4, 4, 4, 4, 4, 6, 6, 6, 6, 13, 6, 8, 7, 10, 10, 9, 9, 7, 9, 8, 8, 9, 8, 7, 10, 6, 9, 8, 10, 10, 7, 8, 1, 9, 10, 12, 12, 12, 10, 9, 9, 10, 10, 9, 9, 1, 1, 5, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 6, 6, 6, 4, 2, 3, 3, 3, 3, 7, 4, 4, 4, 3, 3, 6, 7, 3, 4, 1, 2, 2, 2, 6, 1, 2, 2, 2, 2, 2, 12, 5, 3, 8, 9, 13, 4, 4, 13, 9, 9, 11, 7, 3, 12, 9, 2, 2, 2, 3, 3, 3, 3, 3, 8, 2, 2, 3, 3, 3, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 3, 7, 10, 15, 15, 7, 15, 20, 15, 9, 10, 10, 12, 14, 14, 14, 12, 12, 12, 12, 12, 14, 14, 10, 10, 10, 10, 14, 9, 9, 9, 9, 10, 14, 14, 14, 13, 13, 14, 9, 9, 9, 9, 9, 9, 7, 8, 6, 8, 8, 6, 8, 13, 8, 8, 6, 13, 8, 11, 13, 8, 6, 13, 8, 6, 9, 10, 10, 12, 14, 14, 14, 12, 12, 12, 12, 14, 14, 10, 10, 10, 10, 9, 9, 9, 10, 14, 14, 11, 13, 13, 9, 9, 9, 9, 9, 9, 2, 6, 9, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 4, 4, 2, 3, 3, 3, 3, 3, 3, 7, 7, 2, 3, 2, 2, 5, 3, 3, 3, 3, 3, 3, 4, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 4, 5, 7, 4, 2, 2, 12, 8, 10, 8, 10, 7, 18, 4, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 5, 2, 2, 3, 3, 3, 5, 5, 3, 8, 8, 6, 8, 6, 6, 4, 6, 7, 7, 7, 10, 11, 2, 5, 5, 3, 3, 3, 3, 3, 3, 5, 5, 6, 11, 10, 7, 7, 7, 4, 4, 4, 2, 3, 3, 3, 3, 3, 2, 2, 7, 5, 5, 3, 3, 3, 3, 3, 3, 3, 3, 7, 7, 7, 11, 7, 6, 9, 6, 6, 8, 10, 8, 6, 8, 13, 4, 4, 4, 4, 4, 10, 8, 11, 8, 8, 8, 10, 10, 7, 5, 4, 4, 4, 10, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 2, 2, 2, 2, 2, 2, 5, 5, 5, 5, 5, 5, 5, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 7, 10, 13, 7, 8, 7, 11, 8, 8, 6, 9, 8, 8, 6, 6, 6, 8, 8, 6, 6, 6, 6, 6, 9, 7, 6, 4, 4, 4, 4, 4, 4, 4, 6, 6, 6, 9, 7, 8, 10, 8, 8, 2, 3, 3, 3, 3, 3, 2, 8, 9, 9, 2, 2, 2, 3, 3, 3, 2, 3, 3, 3, 9, 2, 2, 3, 3, 3, 3, 3, 3, 5, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 12, 5, 5, 3, 5, 4, 2, 3, 2, 4, 3, 9, 2, 2, 2, 2, 2, 5, 5, 3, 3, 8, 8, 13, 6, 10, 9, 4, 7, 9, 11, 2, 3, 7, 3, 3, 4, 1, 3, 4, 2, 9, 3, 3, 12, 5, 3, 7, 10, 10, 7, 4, 4, 6, 14, 7, 9, 7, 13, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 8, 15, 4, 4, 2, 3, 3, 3, 7, 4, 9, 9, 2, 3, 3, 3, 5, 3, 2, 2, 7, 2, 7, 6, 6, 7, 2, 4, 2, 2, 2, 2, 2, 2, 8, 8, 8, 9, 5, 2, 3, 3, 3, 3, 3, 3, 10, 7, 4, 4, 4, 4, 3, 4, 2, 3, 3, 3, 3, 3, 10, 7, 4, 4, 4, 4, 2, 3, 3, 3, 3, 10, 7, 4, 4, 4, 4, 3, 9, 6, 6, 6, 9, 13, 9, 2, 2, 2, 8, 7, 9, 5, 3, 3, 3, 5, 5, 13, 12, 9, 10, 7, 8, 7, 6, 8, 6, 11, 12, 7, 10, 4, 4, 7, 8, 11, 6, 7, 9, 8, 7, 10, 8, 9, 15, 7, 8, 5, 4, 7, 2, 3, 3, 3, 2, 14, 10, 2, 14, 10, 2, 14, 3, 9, 13, 13, 10, 14, 16, 17, 11, 2, 14, 2, 14, 3, 9, 13, 10, 14, 16, 17, 11, 14, 10, 14, 2, 7, 3, 10, 7, 14, 10, 2, 14, 10, 9, 9, 17, 6, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 10, 10, 10, 12, 9, 4, 10, 10, 11, 8, 8, 8, 7, 9, 5, 3, 3, 3, 3, 3, 3, 3, 3, 5, 8, 4, 4, 4, 4, 4, 4, 6, 16, 3, 3, 14, 3, 14, 2, 14, 9, 13, 10, 10, 14, 16, 17, 11, 6, 9, 10, 10, 12, 14, 14, 14, 12, 12, 12, 12, 14, 14, 10, 10, 10, 10, 14, 9, 9, 9, 10, 14, 14, 14, 9, 9, 9, 9, 9, 9, 2, 14, 9, 13, 10, 10, 14, 16, 17, 11, 6, 14, 2, 14, 9, 17, 13, 10, 10, 14, 17, 16, 17, 11, 6, 2, 14, 9, 13, 10, 14, 17, 16, 17, 11, 2, 14, 9, 13, 10, 14, 16, 17, 11, 2, 14, 9, 13, 10, 17, 16, 11, 17, 2, 14, 10, 19, 7, 2, 14, 9, 13, 10, 19, 10, 7, 14, 17, 16, 17, 11, 6, 2, 14, 9, 13, 10, 19, 7, 14, 16, 17, 11, 2, 14, 9, 13, 10, 10, 14, 17, 16, 17, 11, 6, 2, 14, 9, 13, 10, 10, 14, 17, 16, 17, 11, 6, 2, 14, 9, 13, 17, 13, 10, 10, 14, 17, 16, 17, 11, 6, 3, 2, 14, 9, 13, 10, 10, 14, 16, 17, 11, 6, 9, 10, 12, 14, 14, 14, 12, 12, 12, 12, 12, 14, 14, 14, 10, 10, 10, 14, 9, 9, 9, 9, 14, 14, 14, 13, 13, 14, 9, 9, 9, 9, 9, 9, 4, 11, 2, 14, 9, 13, 17, 13, 10, 19, 10, 7, 14, 17, 16, 17, 11, 6, 2, 14, 9, 13, 17, 13, 10, 19, 10, 7, 14, 17, 16, 17, 11, 6, 2, 14, 9, 13, 10, 19, 7, 14, 17, 16, 17, 11, 2, 9, 10, 10, 7, 17, 3, 3, 12, 12, 16, 15, 15, 12, 14, 14, 14, 20, 20, 13, 12, 12, 12, 12, 12, 12, 20, 25, 14, 14, 12, 12, 10, 10, 10, 10, 14, 9, 9, 9, 25, 4, 9, 17, 10, 7, 14, 16, 21, 13, 13, 14, 20, 14, 13, 17, 24, 9, 12, 13, 25, 13, 21, 20, 17, 9, 9, 9, 9, 9, 9, 12, 17, 4, 4, 9, 9, 9, 10, 10, 12, 14, 14, 14, 12, 12, 12, 12, 12, 14, 14, 10, 10, 10, 10, 14, 9, 9, 9, 9, 10, 14, 14, 14, 13, 13, 14, 9, 9, 9, 9, 9, 9, 9, 10, 14, 12, 12, 14, 14, 10, 9, 9, 9, 10, 14, 14, 14, 9, 9, 9, 9, 2, 1, 5, 8, 7, 11, 11, 1, 3, 3, 3, 5, 3, 3, 4, 8, 9, 10, 10, 12, 14, 14, 14, 12, 12, 12, 12, 14, 14, 10, 10, 10, 10, 14, 9, 9, 9, 10, 14, 14, 14, 13, 13, 14, 9, 9, 9, 9, 9, 9, 7, 4, 4, 4, 4, 4, 4, 4, 4, 10, 2, 2, 6, 7, 6, 2, 3, 2, 3, 6, 2, 7, 6, 10, 7, 4, 9, 12, 6, 14, 4, 12, 7, 2, 2, 1, 2, 7, 6, 4, 4, 4, 6, 8, 8, 7, 2, 2, 13, 2, 2, 2, 2, 6, 2, 8, 12, 2, 7, 7, 6, 8, 10, 12, 2, 2, 2, 3, 3, 13, 2, 2, 3, 3, 6, 7, 6, 4, 5, 6, 3, 3, 3, 3, 4, 16, 8, 5, 4, 3, 3, 3, 5, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 11, 12, 7, 7, 13, 9, 10, 17, 12, 8, 9, 7, 17, 17, 8, 5, 12, 10, 13, 14, 5, 5, 5, 13, 5, 5, 5, 3, 3, 3, 5, 16, 5, 5, 5, 5, 7, 12, 14, 8, 12, 8, 10, 12, 9, 11, 7, 9, 7, 10, 7, 13, 13, 9, 7, 12, 8, 17, 7, 7, 16, 10, 13, 13, 8, 10, 10, 14, 17, 7, 16, 16, 15, 8, 10, 10, 12, 17, 17, 7, 17, 14, 7, 10, 17, 8, 7, 7, 7, 8, 15, 15, 7, 14, 10, 10, 10, 11, 11, 7, 7, 13, 8, 10, 7, 16, 7, 8, 7, 14, 17, 12, 10, 11, 21, 8, 9, 7, 13, 9, 8, 6, 13, 6, 12, 7, 6, 13, 10, 10, 10, 8, 18, 9, 17, 13, 10, 12, 6, 13, 6, 11, 8, 13, 10, 13, 18, 13, 11, 13, 8, 16, 7, 10, 8, 16, 12, 10, 8, 8, 14, 11, 8, 15, 8, 8, 7, 7, 12, 7, 8, 9, 14, 15, 8, 9, 10, 9, 15, 7, 8, 8, 12, 13, 9, 10, 15, 13, 7, 10, 10, 20, 7, 6, 9, 6, 6, 14, 11, 14, 11, 12, 9, 10, 16, 16, 12, 7, 11, 28, 8, 11, 10, 7, 21, 8, 7, 9, 4, 4, 4, 17, 7, 8, 6, 9, 6, 6, 13, 6, 6, 6, 6, 18, 20, 14, 8, 11, 12, 9, 10, 13, 15, 15, 19, 8, 9, 12, 7, 10, 16, 12, 9, 9, 9, 14, 12, 11, 10, 9, 12, 11, 18, 9, 9, 9, 10, 7, 7, 16, 8, 9, 7, 13, 12, 10, 14, 18, 7, 8, 11, 10, 7, 7, 8, 8, 13, 7, 7, 7, 11, 15, 13, 11, 7, 8, 15, 11, 7, 8, 18, 8, 14, 13, 18, 15, 10, 12, 12, 9, 7, 11, 11, 8, 7, 10, 8, 14, 12, 10, 18, 7, 10, 9, 7, 8, 13, 10, 14, 10, 8, 8, 23, 7, 7, 11, 12, 12, 17, 7, 7, 11, 11, 17, 16, 16, 7, 8, 11, 14, 14, 8, 10, 7, 15, 7, 16, 16, 13, 9, 11, 9, 15, 15, 11, 11, 7, 7, 14, 7, 9, 7, 7, 16, 10, 13, 10, 11, 14, 7, 11, 10, 11, 7, 11, 10, 11, 15, 11, 15, 10, 12, 10, 14, 13, 11, 11, 12, 13, 10, 7, 13, 16, 12, 21, 15, 9, 10, 10, 7, 11, 14, 17, 7, 7, 8, 11, 13, 12, 8, 15, 14, 14, 8, 17, 12, 10, 10, 7, 9, 11, 7, 10, 7, 11, 18, 7, 11, 7, 12, 11, 8, 8, 14, 12, 7, 8, 15, 3, 7, 7, 5, 2, 9, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 2, 5, 3, 3, 3, 3, 3, 3, 4, 4, 3, 3, 3, 3, 3, 3, 5, 11, 6, 4, 7, 10, 7, 7, 11, 1, 10, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 5, 7, 3, 5, 6, 3, 3, 5, 2, 2, 5, 3, 4, 13, 11, 3, 3, 6, 3, 5, 14, 2, 2, 3, 8, 2, 2, 12, 5, 18, 5, 3, 3, 3, 3, 16, 5, 5, 5, 10, 7, 13, 12, 13, 9, 12, 14, 19, 9, 9, 21, 9, 9, 10, 6, 9, 6, 15, 10, 6, 12, 8, 6, 10, 15, 4, 4, 6, 6, 9, 9, 12, 16, 14, 23, 7, 7, 7, 14, 9, 7, 7, 11, 14, 10, 7, 10, 10, 10, 12, 6, 11, 10, 13, 11, 15, 11, 7, 12, 10, 3, 7, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 4, 3, 7, 5, 1, 5, 2, 2, 2, 5, 5, 5, 5, 5, 5, 3, 3, 3, 3, 3, 5, 5, 10, 9, 11, 8, 7, 12, 8, 9, 7, 6, 13, 11, 6, 13, 7, 9, 9, 4, 4, 4, 4, 4, 6, 10, 7, 8, 13, 11, 8, 8, 9, 14, 7, 14, 8, 10, 7, 9, 7, 7, 9, 6, 9, 2, 12, 5, 3, 3, 13, 4, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 2, 3, 3, 3, 3, 3, 3, 3, 3, 4, 5, 5, 5, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 8, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 9, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 2, 2, 2, 5, 3, 3, 3, 3, 3, 3, 3, 3, 4, 4, 1, 7, 6, 4, 12, 3, 3, 3, 3, 3, 8, 7, 3, 3, 3, 3, 3, 3, 4, 4, 11, 15, 14, 2, 8, 3, 5, 5, 8, 10, 8, 6, 4, 7, 17, 7, 4, 5, 2, 6, 3, 5, 4, 2, 2, 12, 5, 5, 3, 15, 13, 8, 11, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 4, 4, 5, 3, 3, 3, 3, 4, 2, 3, 18, 2, 12, 5, 3, 3, 3, 3, 3, 5, 16, 8, 8, 9, 6, 6, 4, 4, 4, 4, 31, 6, 6, 10, 11, 21, 10, 9, 7, 10, 7, 7, 2, 4, 4, 4, 4, 6, 5, 3, 3, 4, 3, 3, 3, 3, 3, 3, 3, 3, 3, 6, 6, 4, 6, 2, 2, 2, 5, 3, 3, 3, 7, 7, 4, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 2, 3, 3, 3, 3, 8, 2, 3, 3, 3, 3, 3, 5, 9, 11, 3, 3, 3, 3, 4, 4, 3, 3, 3, 3, 3, 5, 10, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 4, 2, 3, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 11, 10, 10, 10, 10, 10, 11, 10, 11, 10, 11, 10, 9, 9, 11, 3, 3, 3, 3, 3, 3, 2, 2, 3, 3, 5, 5, 3, 7, 8, 8, 7, 6, 6, 11, 4, 4, 4, 4, 7, 8, 9, 9, 2, 3, 7, 4, 4, 2, 5, 5, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 2, 2, 5, 5, 5, 5, 5, 3, 3, 5, 5, 5, 7, 7, 6, 6, 6, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 6, 6, 8, 8, 1, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 4, 4, 6, 9, 12, 3, 7, 10, 7, 2, 2, 3, 3, 3, 3, 3, 4, 3, 3, 2, 2, 2, 2, 3, 3, 3, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 5, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 5, 5, 8, 8, 6, 6, 8, 6, 7, 4, 4, 4, 4, 4, 4, 6, 7, 5, 5, 20, 19, 8, 10, 9, 7, 10, 6, 8, 11, 6, 6, 6, 6, 13, 12, 8, 6, 7, 14, 11, 9, 2, 5, 3, 6, 2, 3, 2, 2, 2, 2, 2, 2, 2, 5, 4, 3, 7, 6, 4, 7, 4, 3, 6, 4, 7, 2, 2, 7, 7, 7, 5, 5, 5, 5, 3, 3, 3, 3, 3, 3, 3, 3, 3, 5, 9, 10, 10, 10, 11, 7, 8, 20, 7, 9, 8, 9, 8, 12, 6, 6, 6, 8, 9, 8, 12, 6, 6, 8, 13, 10, 12, 6, 6, 7, 7, 9, 6, 4, 4, 4, 4, 4, 4, 10, 6, 6, 6, 7, 14, 11, 10, 7, 8, 10, 8, 11, 14, 11, 11, 9, 7, 9, 8, 11, 13, 9, 17, 10, 9, 2, 2, 2, 9, 3, 3, 3, 3, 15, 14, 9, 5, 5, 2, 8, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 15, 12, 22, 19, 17, 18, 18, 19, 21, 7, 16, 16, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 7, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 9, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 5, 7, 16, 11, 11, 7, 7, 7, 7, 17, 7, 8, 12, 15, 9, 19, 7, 19, 8, 21, 11, 12, 19, 14, 22, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 16, 16, 19, 24, 12, 7, 14, 7, 12, 7, 8, 10, 10, 13, 7, 12, 12, 7, 7, 10, 18, 15, 12, 16, 7, 14, 12, 17, 10, 16, 17, 12, 17, 25, 7, 7, 7, 13, 6, 9, 6, 9, 18, 6, 6, 11, 20, 10, 6, 6, 6, 6, 6, 6, 17, 6, 6, 6, 15, 6, 6, 6, 6, 6, 8, 14, 11, 12, 11, 15, 13, 19, 17, 21, 7, 18, 8, 13, 13, 8, 12, 8, 6, 6, 13, 6, 15, 15, 16, 6, 6, 16, 6, 6, 6, 14, 6, 18, 6, 6, 6, 17, 18, 9, 13, 15, 8, 19, 8, 15, 15, 18, 14, 16, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 6, 11, 10, 11, 6, 21, 23, 12, 17, 12, 11, 14, 13, 22, 15, 15, 11, 12, 14, 12, 7, 12, 8, 12, 14, 12, 18, 10, 8, 16, 19, 17, 12, 14, 15, 8, 19, 17, 12, 13, 13, 15, 18, 13, 23, 24, 23, 21, 17, 24, 8, 21, 8, 14, 14, 16, 20, 14, 8, 8, 15, 20, 8, 19, 21, 9, 8, 13, 12, 13, 15, 11, 8, 11, 9, 9, 8, 11, 8, 21, 14, 21, 15, 15, 13, 7, 19, 7, 7, 7, 7, 7, 7, 16, 12, 17, 18, 7, 7, 11, 11, 7, 9, 9, 2, 2, 3, 3, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 5, 5, 5, 5, 5, 5, 5, 5, 3, 3, 10, 10, 7, 9, 7, 7, 7, 6, 8, 6, 6, 6, 6, 6, 6, 6, 7, 6, 8, 6, 6, 9, 7, 7, 7, 4, 4, 4, 4, 4, 4, 4, 4, 8, 9, 8, 7, 8, 7, 8, 10, 7, 5, 5, 5, 5, 5, 5, 3, 9, 7, 7, 8, 6, 6, 6, 6, 6, 6, 6, 6, 9, 6, 6, 9, 11, 13, 7, 8, 9, 9, 5, 5, 5, 7, 8, 6, 6, 6, 6, 6, 6, 6, 7, 8, 9, 7, 10, 9, 10, 7, 8, 5, 5, 5, 5, 5, 5, 7, 7, 9, 8, 7, 7, 6, 6, 6, 6, 6, 6, 10, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 9, 10, 4, 4, 4, 4, 8, 7, 7, 10, 10, 9, 8, 8, 15, 9, 8, 8, 8, 8, 8, 9, 10, 9, 10, 7, 8, 13, 5, 5, 5, 5, 5, 3, 3, 7, 7, 8, 6, 6, 6, 4, 4, 11, 9, 7, 8, 9, 10, 7, 5, 5, 5, 5, 5, 3, 3, 7, 6, 6, 13, 7, 9, 8, 7, 5, 5, 5, 5, 5, 5, 5, 5, 3, 3, 3, 3, 7, 8, 7, 8, 13, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 8, 8, 6, 6, 6, 6, 7, 6, 7, 6, 6, 9, 7, 4, 4, 4, 4, 4, 4, 4, 7, 8, 7, 8, 9, 8, 8, 8, 7, 10, 7, 8, 5, 5, 5, 5, 5, 5, 5, 5, 3, 7, 7, 7, 7, 9, 7, 10, 9, 6, 6, 6, 6, 6, 8, 8, 6, 6, 6, 7, 6, 6, 6, 9, 9, 4, 4, 13, 7, 10, 9, 9, 12, 7, 8, 8, 10, 8, 8, 8, 8, 8, 8, 5, 5, 5, 5, 3, 7, 7, 11, 7, 9, 8, 8, 6, 6, 10, 6, 8, 8, 8, 6, 7, 6, 6, 12, 4, 4, 4, 4, 4, 4, 4, 4, 4, 9, 8, 8, 16, 8, 9, 8, 7, 5, 5, 5, 5, 5, 3, 3, 7, 7, 7, 10, 15, 8, 9, 8, 9, 9, 6, 6, 6, 6, 6, 6, 7, 4, 8, 7, 8, 8, 7, 8, 11, 8, 5, 5, 5, 5, 5, 3, 7, 7, 6, 11, 16, 7, 6, 4, 4, 4, 4, 9, 9, 8, 8, 8, 13, 12, 8, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 11, 7, 8, 8, 9, 13, 7, 7, 7, 9, 8, 8, 9, 12, 7, 12, 7, 12, 8, 7, 10, 12, 9, 9, 6, 6, 8, 8, 6, 6, 6, 6, 6, 6, 6, 9, 8, 9, 11, 8, 6, 6, 6, 6, 6, 12, 7, 6, 6, 6, 9, 7, 7, 6, 6, 6, 6, 6, 11, 9, 6, 6, 6, 6, 6, 7, 9, 4, 4, 4, 4, 4, 4, 4, 4, 9, 9, 9, 9, 7, 7, 7, 7, 7, 11, 7, 7, 8, 8, 8, 8, 8, 8, 9, 8, 9, 9, 7, 7, 11, 11, 7, 12, 8, 8, 8, 8, 8, 7, 8, 8, 8, 8, 8, 13, 12, 8, 8, 8, 8, 7, 7, 7, 9, 5, 5, 5, 5, 5, 5, 5, 3, 3, 7, 7, 11, 7, 8, 8, 8, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 10, 11, 6, 7, 9, 4, 4, 4, 4, 4, 4, 9, 9, 8, 9, 8, 8, 8, 7, 7, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 3, 3, 11, 7, 7, 7, 9, 6, 6, 11, 8, 10, 6, 6, 6, 12, 8, 8, 7, 6, 6, 8, 7, 4, 4, 4, 4, 4, 4, 4, 4, 9, 10, 9, 9, 8, 10, 9, 11, 8, 5, 5, 5, 7, 6, 6, 8, 7, 4, 4, 4, 4, 8, 7, 7, 8, 7, 8, 8, 5, 5, 5, 5, 7, 7, 8, 8, 8, 6, 6, 6, 6, 6, 10, 8, 9, 13, 6, 7, 6, 6, 8, 7, 8, 4, 4, 4, 4, 11, 8, 8, 8, 10, 5, 5, 8, 7, 8, 13, 8, 7, 6, 8, 6, 9, 7, 8, 7, 5, 5, 5, 5, 5, 5, 3, 3, 7, 8, 9, 6, 4, 8, 10, 10, 8, 12, 9, 13, 2, 7, 5, 5, 5, 5, 5, 7, 7, 10, 6, 6, 6, 6, 6, 6, 6, 8, 4, 4, 9, 8, 8, 8, 14, 8, 8, 8, 9, 8, 5, 5, 5, 5, 5, 3, 3, 9, 6, 6, 6, 6, 10, 12, 6, 6, 6, 6, 6, 6, 6, 4, 4, 4, 4, 11, 8, 7, 8, 8, 8, 5, 5, 3, 3, 3, 3, 7, 7, 6, 8, 6, 8, 11, 7, 6, 6, 6, 7, 4, 8, 11, 9, 10, 5, 5, 5, 3, 3, 3, 7, 7, 8, 9, 8, 15, 9, 6, 6, 6, 6, 6, 6, 11, 11, 4, 4, 4, 4, 4, 7, 9, 9, 10, 8, 7, 5, 5, 5, 5, 5, 5, 3, 3, 8, 6, 6, 6, 6, 6, 6, 6, 6, 6, 9, 7, 4, 4, 4, 4, 4, 9, 9, 8, 8, 10, 13, 5, 5, 5, 3, 17, 7, 7, 7, 7, 7, 8, 6, 8, 13, 6, 6, 6, 6, 6, 6, 6, 6, 4, 4, 4, 9, 10, 8, 8, 8, 5, 5, 5, 5, 3, 7, 7, 7, 8, 8, 6, 6, 6, 8, 8, 8, 9, 10, 8, 4, 8, 10, 9, 8, 8, 8, 9, 13, 10, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 3, 3, 7, 8, 9, 9, 7, 7, 7, 10, 9, 9, 8, 9, 8, 8, 8, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 8, 12, 6, 6, 6, 6, 6, 6, 6, 6, 6, 12, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 11, 8, 8, 9, 9, 10, 8, 9, 7, 7, 5, 5, 5, 5, 5, 5, 3, 7, 8, 7, 6, 6, 8, 6, 6, 10, 4, 7, 8, 9, 12, 8, 7, 7, 5, 5, 5, 5, 5, 5, 3, 3, 7, 14, 7, 9, 8, 8, 6, 6, 8, 12, 12, 6, 6, 7, 7, 10, 4, 4, 4, 4, 4, 9, 9, 14, 9, 13, 8, 7, 5, 5, 5, 6, 6, 6, 7, 4, 8, 7, 5, 5, 5, 5, 5, 5, 5, 5, 3, 3, 7, 7, 7, 8, 6, 6, 6, 6, 6, 6, 12, 6, 6, 6, 6, 4, 4, 9, 9, 8, 8, 11, 7, 7, 7, 5, 5, 5, 3, 9, 8, 6, 6, 7, 4, 4, 4, 4, 4, 4, 8, 8, 11, 5, 5, 5, 7, 7, 7, 9, 6, 6, 6, 6, 6, 6, 9, 8, 4, 4, 4, 4, 7, 12, 9, 8, 8, 8, 7, 10, 10, 5, 5, 5, 5, 5, 5, 5, 3, 11, 14, 8, 7, 8, 8, 6, 6, 6, 6, 6, 8, 7, 6, 6, 6, 7, 6, 8, 9, 4, 4, 4, 7, 8, 9, 7, 9, 7, 7, 9, 8, 5, 5, 5, 5, 5, 5, 5, 5, 5, 11, 3, 9, 7, 7, 12, 14, 8, 6, 6, 12, 11, 8, 6, 6, 6, 6, 6, 6, 6, 6, 6, 15, 7, 4, 4, 4, 16, 9, 9, 9, 8, 9, 9, 9, 9, 9, 8, 8, 8, 13, 11, 8, 5, 5, 5, 5, 3, 7, 6, 6, 8, 8, 8, 6, 6, 7, 10, 7, 4, 4, 4, 4, 9, 7, 8, 7, 7, 7, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 3, 7, 7, 7, 9, 6, 6, 6, 6, 6, 8, 8, 7, 7, 9, 6, 6, 6, 7, 6, 6, 6, 6, 6, 15, 4, 4, 4, 4, 4, 8, 8, 7, 8, 12, 9, 8, 8, 8, 8, 8, 9, 8, 8, 10, 8, 8, 8, 8, 16, 9, 10, 2, 5, 5, 5, 5, 5, 5, 5, 9, 7, 6, 8, 9, 4, 4, 4, 4, 4, 7, 8, 8, 8, 9, 8, 11, 10, 5, 5, 5, 5, 3, 7, 8, 6, 6, 6, 6, 6, 8, 6, 6, 6, 6, 4, 12, 10, 12, 7, 7, 7, 7, 7, 7, 7, 5, 5, 5, 5, 3, 3, 7, 7, 10, 8, 9, 7, 6, 10, 7, 6, 6, 4, 4, 8, 9, 7, 9, 9, 9, 9, 8, 8, 8, 8, 10, 5, 5, 5, 5, 5, 5, 8, 7, 6, 6, 6, 10, 6, 7, 10, 7, 4, 4, 4, 4, 4, 4, 4, 12, 9, 10, 7, 7, 10, 8, 10, 5, 12, 9, 6, 6, 6, 6, 6, 7, 6, 4, 4, 4, 10, 9, 9, 8, 7, 7, 5, 5, 5, 5, 5, 5, 3, 3, 13, 7, 7, 9, 7, 7, 7, 8, 9, 9, 7, 8, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 7, 13, 9, 15, 15, 4, 4, 4, 4, 4, 10, 10, 9, 8, 9, 8, 8, 9, 7, 8, 7, 8, 5, 5, 7, 6, 6, 6, 4, 4, 4, 7, 8, 11, 8, 5, 5, 5, 5, 5, 5, 5, 7, 6, 6, 6, 6, 6, 6, 9, 11, 10, 7, 4, 4, 4, 9, 8, 8, 5, 5, 5, 5, 5, 9, 9, 6, 6, 6, 6, 6, 6, 6, 9, 9, 4, 4, 4, 4, 8, 8, 8, 9, 9, 8, 8, 8, 13, 2, 4, 2, 7, 5, 5, 5, 5, 5, 5, 9, 9, 6, 6, 6, 6, 10, 8, 8, 8, 6, 6, 6, 4, 4, 9, 8, 10, 8, 9, 8, 8, 8, 9, 8, 8, 5, 3, 3, 3, 11, 6, 6, 6, 7, 6, 6, 6, 4, 4, 9, 8, 5, 5, 5, 5, 5, 3, 11, 8, 6, 6, 6, 6, 6, 9, 7, 4, 4, 14, 10, 9, 8, 12, 8, 8, 8, 11, 15, 8, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 11, 11, 11, 10, 10, 7, 7, 3, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 3, 3, 3, 7, 11, 7, 7, 11, 11, 7, 8, 9, 10, 7, 7, 9, 9, 9, 9, 7, 7, 10, 8, 13, 8, 8, 8, 8, 11, 10, 6, 6, 8, 10, 11, 14, 14, 6, 6, 6, 6, 6, 6, 9, 11, 7, 7, 6, 8, 12, 11, 11, 6, 6, 10, 6, 6, 6, 6, 6, 10, 7, 7, 6, 6, 11, 6, 6, 6, 11, 8, 9, 7, 6, 10, 11, 9, 10, 11, 7, 11, 8, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 8, 6, 6, 8, 9, 10, 9, 6, 6, 6, 10, 6, 6, 6, 6, 11, 10, 11, 10, 9, 8, 7, 7, 7, 7, 11, 14, 8, 10, 9, 9, 8, 8, 7, 11, 8, 8, 8, 11, 11, 10, 10, 9, 10, 8, 11, 10, 8, 11, 9, 12, 8, 10, 8, 11, 8, 9, 9, 11, 11, 10, 11, 13, 8, 7, 8, 8, 9, 7, 8, 8, 8, 8, 7, 8, 2, 2, 2, 2, 2, 2, 2, 4, 4, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 2, 3, 3, 3, 3, 3, 3, 3, 3, 8, 6, 4, 4, 4, 11, 7, 11, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 5, 5, 5, 5, 3, 3, 3, 3, 8, 7, 7, 8, 8, 4, 8, 7, 7, 7, 9, 7, 8, 9, 8, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 6, 3, 3, 3, 3, 3, 3, 3, 3, 4, 2, 2, 3, 3, 3, 3, 3, 3, 4, 5, 5, 3, 3, 8, 8, 6, 9, 4, 4, 10, 7, 3, 3, 3, 2, 5, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 3, 2, 2, 2, 3, 3, 3, 3, 3, 4, 10, 2, 3, 3, 3, 3, 3, 3, 3, 4, 2, 3, 3, 3, 3, 3, 3, 3, 3, 2, 2, 3, 3, 3, 5, 2, 4, 2, 6, 2, 2, 9, 5, 5, 3, 3, 3, 3, 3, 3, 3, 3, 5, 5, 5, 9, 8, 7, 9, 6, 6, 11, 4, 4, 4, 4, 4, 4, 4, 4, 6, 6, 7, 7, 11, 8, 8, 6, 5, 11, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 2, 2, 3, 3, 3, 3, 3, 3, 6, 4, 4, 4, 4, 3, 3, 3, 3, 5, 7, 2, 3, 3, 3, 3, 3, 8, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 6, 4, 4, 4, 4, 2, 2, 3, 3, 3, 3, 3, 3, 3, 4, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 2, 2, 3, 3, 3, 3, 3, 3, 2, 3, 3, 3, 3, 3, 6, 3, 3, 8, 10, 3, 4, 4, 1, 1, 1, 1, 1, 1, 1, 8, 9, 10, 7, 7, 1, 14, 18, 13, 18, 13, 10, 10, 16, 13, 18, 16, 13, 16, 18, 13, 22, 16, 16, 16, 14, 21, 16, 9, 14, 16, 9, 9, 14, 10, 10, 14, 12, 14, 19, 12, 11, 18, 13, 17, 15, 15, 15, 15, 16, 14, 13, 19, 18, 15, 19, 18, 12, 18, 12, 11, 20, 14, 15, 10, 17, 17, 16, 19, 20, 21, 15, 13, 16, 15, 15, 15, 1, 1, 3, 8, 7, 7, 8, 8, 8, 1, 6, 1, 1, 6, 3, 3, 4, 7, 3, 3, 5, 5, 4, 4, 4, 4, 4, 2, 7, 7, 8, 12, 3, 4, 5, 1, 3, 4, 4, 10, 4, 3, 3, 3, 8, 7, 7, 2, 2, 2, 2, 2, 2, 2, 2, 2, 12, 9, 20, 7, 5, 5, 5, 9, 13, 5, 5, 5, 5, 5, 3, 3, 3, 16, 5, 5, 5, 13, 7, 8, 8, 11, 8, 7, 9, 7, 11, 12, 9, 9, 8, 8, 11, 10, 14, 7, 12, 10, 11, 13, 7, 9, 11, 17, 17, 14, 13, 7, 8, 7, 10, 10, 7, 16, 13, 7, 8, 17, 12, 9, 8, 6, 7, 10, 6, 6, 12, 6, 8, 10, 8, 8, 8, 6, 8, 6, 14, 6, 6, 6, 13, 6, 10, 6, 6, 7, 14, 8, 6, 6, 10, 11, 10, 9, 9, 7, 7, 6, 6, 6, 9, 9, 7, 9, 10, 9, 13, 12, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 6, 6, 6, 8, 8, 6, 8, 9, 10, 9, 7, 10, 10, 8, 7, 8, 7, 10, 12, 9, 8, 15, 8, 7, 8, 8, 7, 7, 15, 13, 7, 10, 9, 14, 18, 16, 7, 24, 7, 8, 10, 11, 16, 8, 14, 7, 9, 9, 9, 13, 19, 14, 15, 14, 11, 7, 13, 9, 10, 7, 13, 9, 10, 11, 12, 8, 9, 2, 3, 5, 8, 7, 4, 4, 15, 10, 5, 3, 3, 3, 3, 3, 5, 4, 4, 4, 2, 2, 2, 2, 2, 1, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 4, 4, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 2, 12, 5, 3, 8, 10, 15, 6, 7, 2, 3, 2, 5, 5, 12, 2, 5, 5, 5, 5, 2, 2, 5, 5, 12, 9, 5, 2, 2, 9, 5, 5, 12, 12, 5, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 9, 12, 5, 8, 8, 9, 5, 5, 5, 8, 19, 7, 16, 15, 14, 9, 9, 9, 9, 7, 11, 11, 11, 7, 14, 10, 10, 5, 5, 5, 5, 5, 5, 5, 5, 5, 15, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 9, 9, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 14, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 15, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 5, 5, 5, 5, 5, 5, 5, 12, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 9, 9, 12, 9, 9, 12, 12, 12, 15, 7, 11, 7, 14, 11, 18, 13, 8, 18, 15, 18, 12, 14, 12, 8, 8, 8, 8, 9, 9, 9, 12, 7, 10, 10, 8, 8, 12, 12, 12, 7, 12, 12, 9, 7, 7, 7, 7, 7, 8, 15, 12, 9, 10, 10, 7, 10, 10, 13, 11, 10, 9, 22, 11, 9, 8, 8, 8, 8, 8, 13, 18, 13, 9, 15, 19, 9, 7, 7, 10, 7, 7, 7, 11, 8, 13, 17, 7, 7, 10, 10, 10, 7, 20, 16, 7, 7, 7, 7, 7, 7, 11, 21, 12, 12, 13, 11, 14, 16, 8, 8, 13, 11, 7, 7, 13, 7, 7, 14, 15, 15, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 13, 10, 18, 6, 6, 6, 6, 6, 6, 6, 6, 6, 11, 8, 8, 12, 12, 11, 11, 8, 12, 9, 9, 9, 13, 13, 9, 9, 9, 9, 9, 9, 6, 10, 12, 6, 6, 6, 6, 17, 11, 7, 7, 7, 7, 14, 14, 12, 6, 7, 7, 6, 6, 15, 10, 13, 10, 6, 8, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 7, 13, 9, 9, 15, 13, 6, 12, 12, 6, 19, 11, 10, 7, 7, 16, 8, 19, 17, 9, 9, 9, 9, 9, 6, 6, 6, 10, 8, 16, 8, 6, 6, 9, 6, 6, 6, 6, 6, 6, 6, 6, 8, 8, 8, 6, 7, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 14, 6, 6, 6, 6, 20, 6, 9, 6, 14, 9, 9, 9, 6, 9, 8, 8, 12, 9, 8, 8, 8, 8, 7, 8, 12, 7, 8, 8, 8, 6, 8, 6, 6, 6, 6, 6, 6, 6, 9, 8, 8, 6, 6, 13, 9, 12, 13, 12, 14, 13, 12, 11, 11, 6, 8, 8, 8, 6, 13, 12, 11, 11, 12, 6, 11, 12, 11, 13, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 15, 6, 6, 6, 6, 6, 6, 6, 13, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 8, 8, 8, 8, 6, 18, 6, 12, 13, 13, 13, 9, 10, 15, 9, 12, 6, 6, 6, 6, 6, 6, 6, 6, 9, 15, 10, 9, 10, 13, 9, 19, 8, 18, 17, 10, 10, 8, 8, 6, 6, 6, 6, 6, 6, 10, 14, 8, 16, 16, 9, 8, 15, 8, 8, 10, 12, 14, 7, 7, 8, 8, 7, 7, 7, 7, 8, 13, 13, 11, 9, 9, 9, 12, 10, 17, 8, 11, 9, 7, 7, 14, 8, 14, 14, 7, 7, 7, 7, 7, 7, 14, 7, 7, 7, 7, 7, 10, 10, 8, 14, 7, 7, 7, 7, 8, 8, 8, 8, 8, 17, 9, 7, 15, 7, 8, 12, 7, 9, 14, 7, 7, 7, 9, 13, 8, 14, 7, 16, 18, 13, 15, 14, 12, 13, 10, 15, 9, 7, 7, 7, 10, 13, 15, 15, 9, 9, 9, 9, 19, 11, 7, 11, 11, 13, 8, 8, 8, 8, 7, 12, 19, 17, 9, 9, 13, 7, 7, 7, 9, 7, 7, 7, 12, 13, 15, 10, 8, 8, 14, 15, 12, 13, 13, 8, 12, 14, 7, 11, 7, 14, 15, 13, 12, 8, 8, 8, 8, 11, 13, 15, 15, 8, 13, 12, 8, 8, 8, 13, 10, 16, 14, 11, 8, 8, 12, 12, 9, 15, 15, 12, 12, 13, 8, 8, 9, 12, 13, 9, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 11, 12, 11, 7, 14, 7, 13, 13, 13, 12, 18, 16, 7, 12, 11, 10, 10, 15, 9, 9, 9, 21, 7, 7, 7, 11, 16, 8, 8, 11, 11, 7, 7, 7, 7, 7, 19, 7, 7, 7, 7, 7, 7, 7, 7, 7, 12, 8, 9, 12, 14, 11, 9, 9, 9, 22, 12, 3, 3, 4, 8, 8, 15, 4, 2, 2, 5, 5, 3, 3, 3, 3, 3, 3, 6, 6, 4, 4, 4, 12, 7, 10, 2, 3, 3, 3, 3, 3, 3, 3, 6, 7, 3, 7, 5, 14, 4, 4, 7, 8, 10, 4, 1, 3, 3, 6, 2, 4, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 4, 2, 2, 5, 3, 4, 2, 2, 2, 2, 2, 2, 2, 11, 5, 5, 5, 11, 5, 5, 3, 5, 5, 5, 5, 11, 14, 13, 9, 11, 9, 12, 8, 11, 11, 8, 11, 16, 9, 9, 7, 10, 9, 12, 8, 15, 6, 7, 6, 6, 13, 10, 8, 11, 8, 6, 6, 6, 12, 16, 6, 11, 7, 8, 9, 18, 6, 6, 9, 4, 4, 6, 13, 6, 6, 6, 6, 8, 8, 9, 16, 7, 7, 14, 7, 8, 8, 8, 7, 7, 7, 7, 7, 7, 15, 13, 7, 10, 7, 7, 10, 12, 16, 15, 7, 9, 9, 14, 11, 11, 10, 9, 10, 8, 12, 7, 8, 7, 7, 10, 12, 7, 12, 8, 7, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 5, 5, 3, 3, 5, 5, 5, 10, 8, 7, 4, 4, 4, 8, 7, 10, 9, 7, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 1, 3, 3, 3, 3, 3, 3, 3, 7, 4, 5, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 5, 5, 5, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 5, 6, 6, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 9, 8, 2, 2, 2, 8, 12, 7, 7, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 8, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 5, 5, 5, 7, 11, 9, 8, 8, 8, 7, 8, 9, 7, 7, 9, 7, 7, 7, 10, 7, 7, 10, 9, 10, 6, 6, 6, 6, 6, 6, 15, 7, 8, 9, 9, 8, 6, 6, 10, 9, 6, 8, 13, 9, 7, 6, 6, 6, 6, 6, 6, 12, 6, 6, 7, 6, 7, 6, 6, 6, 10, 10, 7, 6, 6, 6, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 6, 14, 6, 6, 7, 7, 9, 6, 6, 6, 6, 9, 9, 8, 9, 10, 9, 8, 9, 12, 7, 7, 7, 8, 7, 10, 12, 11, 9, 10, 7, 7, 7, 9, 10, 10, 8, 12, 9, 7, 7, 9, 8, 8, 8, 10, 7, 7, 8, 9, 9, 7, 7, 7, 8, 2, 4, 2, 4, 6, 3, 4, 2, 3, 3, 3, 3, 2, 3, 3, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 5, 5, 3, 3, 3, 3, 3, 3, 3, 3, 5, 5, 8, 6, 4, 7, 3, 3, 3, 3, 3, 3, 3, 12, 3, 3, 3, 3, 3, 3, 4, 4, 2, 3, 5, 3, 4, 7, 3, 3, 3, 3, 3, 3, 4, 3, 3, 3, 3, 3, 3, 3, 4, 3, 3, 6, 4, 3, 4, 2, 2, 2, 5, 3, 3, 3, 3, 3, 5, 4, 4, 4, 4, 2, 7, 6, 8, 9, 2, 2, 2, 2, 3, 3, 3, 5, 7, 2, 3, 3, 8, 7, 7, 2, 2, 8, 5, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 5, 5, 8, 8, 7, 7, 6, 10, 6, 9, 7, 11, 4, 6, 8, 8, 7, 8, 4, 2, 5, 5, 5, 5, 3, 3, 3, 11, 8, 9, 6, 6, 8, 7, 4, 4, 7, 6, 8, 7, 2, 2, 3, 3, 3, 3, 4, 3, 3, 3, 3, 3, 3, 3, 3, 7, 2, 2, 5, 3, 3, 2, 3, 3, 3, 3, 3, 3, 4, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 12, 5, 5, 3, 3, 3, 5, 10, 12, 6, 15, 4, 6, 6, 7, 14, 9, 3, 3, 3, 3, 3, 8, 2, 2, 3, 5, 5, 3, 3, 3, 3, 3, 3, 8, 8, 6, 8, 7, 5, 8, 4, 6, 11, 2, 2, 7, 3, 3, 2, 9, 8, 5, 5, 5, 3, 3, 3, 5, 5, 5, 7, 7, 6, 6, 10, 6, 8, 6, 8, 9, 7, 4, 4, 4, 4, 4, 7, 6, 6, 8, 7, 7, 10, 9, 9, 8, 11, 8, 3, 3, 3, 3, 3, 4, 4, 2, 3, 3, 3, 3, 3, 7, 6, 2, 5, 5, 6, 7, 6, 4, 8, 9, 11, 2, 2, 3, 3, 3, 3, 3, 3, 3, 2, 2, 5, 3, 3, 3, 3, 3, 9, 9, 6, 4, 8, 7, 7, 5, 9, 8, 6, 2, 6, 8, 7, 8, 5, 5, 5, 5, 5, 3, 3, 3, 16, 8, 7, 7, 7, 8, 7, 7, 7, 7, 9, 6, 9, 6, 10, 7, 7, 7, 6, 10, 8, 9, 11, 11, 8, 4, 4, 10, 8, 8, 6, 9, 6, 11, 8, 8, 8, 15, 7, 8, 9, 5, 3, 3, 3, 3, 3, 5, 2, 2, 3, 8, 9, 10, 3, 2, 2, 2, 2, 2, 2, 3, 6, 4, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 4, 2, 3, 3, 3, 3, 3, 3, 3, 11, 5, 3, 3, 3, 3, 3, 3, 3, 3, 6, 7, 4, 4, 2, 3, 3, 3, 3, 3, 3, 3, 12, 7, 4, 12, 4, 6, 5, 4, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 4, 2, 3, 3, 3, 3, 3, 3, 3, 3, 4, 4, 11, 10, 6, 4, 6, 10, 8, 3, 3, 3, 3, 3, 3, 3, 3, 5, 4, 4, 4, 2, 2, 2, 2, 2, 2, 2, 2, 5, 3, 4, 4, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 10, 5, 5, 5, 5, 5, 5, 3, 3, 3, 3, 3, 3, 3, 3, 7, 8, 8, 7, 13, 12, 10, 10, 8, 8, 7, 7, 9, 12, 11, 6, 6, 8, 8, 9, 7, 7, 7, 10, 15, 10, 4, 4, 4, 4, 4, 11, 8, 8, 9, 7, 9, 14, 14, 12, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 12, 5, 5, 5, 11, 10, 7, 9, 3, 8, 7, 3, 15, 13, 11, 4, 4, 2, 2, 2, 19, 7, 5, 5, 3, 3, 3, 3, 3, 3, 3, 5, 22, 18, 6, 14, 17, 4, 4, 19, 16, 18, 2, 3, 3, 7, 2, 3, 2, 3, 3, 6, 4, 2, 3, 3, 2, 5, 3, 3, 3, 3, 3, 3, 3, 9, 9, 2, 3, 2, 2, 2, 3, 3, 3, 5, 7, 14, 7, 7, 12, 9, 13, 6, 11, 6, 10, 9, 7, 7, 8, 12, 12, 8, 8, 8, 10, 7, 7, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 5, 8, 10, 7, 8, 11, 8, 12, 9, 4, 14, 7, 7, 9, 13, 2, 3, 3, 3, 3, 3, 3, 2, 3, 3, 3, 1, 2, 2, 3, 3, 3, 3, 3, 3, 5, 2, 2, 5, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 8, 4, 4, 4, 3, 2, 3, 3, 3, 3, 5, 2, 2, 2, 2, 2, 2, 2, 5, 5, 5, 5, 3, 3, 3, 3, 3, 3, 3, 3, 3, 7, 7, 7, 7, 7, 8, 8, 8, 8, 8, 12, 9, 8, 8, 9, 8, 6, 17, 6, 6, 6, 8, 8, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 7, 4, 4, 8, 8, 9, 9, 9, 7, 7, 7, 7, 7, 7, 7, 9, 9, 9, 7, 8, 8, 8, 10, 7, 13, 10, 8, 9, 3, 3, 5, 3, 3, 3, 3, 3, 7, 7, 6, 6, 10, 13, 11, 11, 8, 8, 9, 8, 9, 9, 10, 10, 10, 11, 10, 10, 13, 13, 16, 15, 11, 12, 9, 9, 10, 9, 11, 10, 9, 9, 14, 7, 8, 3, 10, 7, 7, 3, 2, 2, 2, 5, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 6, 7, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 4, 11, 6, 7, 4, 6, 2, 2, 3, 3, 3, 1, 3, 3, 3, 3, 3, 3, 6, 4, 4, 2, 2, 2, 3, 3, 3, 3, 4, 4, 6, 6, 6, 6, 5, 4, 4, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 9, 11, 6, 10, 9, 12, 7, 7, 11, 14, 9, 7, 12, 3, 3, 7, 12, 11, 12, 7, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 9, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 3, 3, 3, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 11, 5, 5, 5, 5, 5, 5, 5, 5, 11, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 5, 5, 5, 5, 5, 5, 5, 3, 3, 3, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 3, 3, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 6, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 3, 10, 3, 3, 3, 11, 3, 5, 9, 11, 8, 12, 14, 9, 7, 8, 7, 7, 11, 11, 7, 7, 10, 9, 8, 10, 9, 7, 7, 7, 7, 7, 7, 8, 8, 7, 11, 8, 8, 8, 7, 7, 10, 8, 7, 13, 12, 7, 17, 10, 8, 8, 11, 7, 11, 11, 14, 7, 11, 7, 8, 6, 9, 20, 8, 7, 9, 16, 7, 10, 6, 11, 10, 8, 9, 7, 16, 11, 11, 9, 8, 9, 8, 8, 8, 11, 8, 15, 8, 8, 9, 7, 8, 8, 11, 10, 7, 5, 7, 10, 10, 15, 7, 7, 7, 8, 7, 8, 8, 10, 11, 10, 10, 10, 11, 11, 7, 8, 6, 8, 8, 10, 6, 8, 6, 6, 7, 8, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 16, 6, 15, 6, 7, 11, 11, 7, 9, 10, 11, 13, 10, 6, 16, 8, 10, 12, 11, 6, 6, 6, 6, 6, 6, 6, 10, 6, 10, 7, 7, 7, 11, 7, 11, 6, 6, 6, 6, 6, 6, 17, 7, 7, 6, 6, 12, 22, 6, 6, 6, 6, 6, 8, 6, 6, 6, 6, 7, 6, 6, 5, 6, 6, 8, 11, 6, 9, 14, 11, 9, 11, 7, 7, 8, 6, 6, 6, 8, 10, 9, 6, 6, 6, 6, 9, 7, 6, 6, 6, 6, 6, 15, 6, 4, 4, 4, 6, 4, 17, 8, 11, 6, 6, 9, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 7, 6, 6, 6, 6, 10, 6, 10, 6, 6, 6, 6, 12, 8, 6, 6, 6, 6, 6, 6, 6, 6, 6, 9, 6, 6, 6, 6, 18, 6, 6, 6, 8, 9, 10, 7, 8, 9, 10, 11, 7, 13, 6, 8, 8, 6, 6, 14, 7, 7, 7, 7, 10, 7, 14, 9, 6, 6, 9, 15, 9, 7, 14, 6, 11, 14, 13, 7, 12, 8, 7, 7, 7, 7, 7, 12, 7, 10, 9, 16, 6, 8, 6, 5, 17, 6, 8, 10, 4, 6, 4, 10, 15, 17, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 8, 4, 4, 11, 7, 4, 4, 7, 7, 7, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 19, 17, 6, 10, 11, 6, 6, 6, 6, 18, 6, 6, 11, 4, 4, 4, 5, 6, 6, 6, 9, 5, 6, 4, 6, 6, 4, 6, 6, 6, 6, 10, 6, 6, 4, 6, 6, 10, 6, 10, 6, 6, 6, 6, 11, 6, 6, 10, 6, 6, 8, 6, 6, 6, 8, 6, 11, 4, 11, 9, 10, 9, 11, 4, 8, 4, 11, 12, 7, 9, 8, 6, 7, 7, 8, 12, 12, 11, 13, 10, 11, 7, 7, 7, 9, 7, 11, 10, 7, 7, 7, 16, 11, 10, 11, 17, 9, 9, 8, 8, 7, 7, 7, 9, 7, 7, 7, 14, 7, 13, 9, 11, 10, 14, 10, 10, 12, 11, 10, 7, 10, 5, 14, 8, 8, 8, 9, 7, 8, 7, 7, 9, 8, 7, 8, 7, 7, 7, 7, 7, 7, 7, 11, 8, 10, 8, 7, 8, 14, 11, 8, 9, 9, 9, 8, 24, 10, 10, 12, 7, 7, 15, 11, 8, 8, 12, 11, 8, 9, 9, 7, 8, 9, 10, 11, 10, 11, 7, 12, 7, 7, 11, 9, 8, 14, 13, 12, 8, 11, 10, 8, 8, 7, 7, 14, 9, 10, 8, 9, 11, 7, 14, 8, 8, 13, 8, 8, 12, 7, 10, 14, 14, 11, 9, 10, 9, 9, 7, 7, 11, 11, 13, 9, 13, 5, 5, 5, 7, 9, 5, 11, 12, 14, 8, 7, 7, 11, 10, 9, 7, 8, 8, 7, 10, 11, 11, 5, 5, 7, 5, 5, 5, 7, 7, 15, 7, 7, 8, 7, 15, 12, 12, 10, 7, 8, 7, 11, 7, 7, 7, 23, 11, 8, 8, 11, 10, 7, 8, 11, 7, 19, 7, 7, 6, 9, 9, 9, 11, 3, 4, 7, 8, 6, 6, 4, 10, 8, 2, 2]);
  var labelText = "orgmilcomschnetedugovdrrformsfeedbackofficialaccoorgmilschnetgovmagazinemediaunioncargopilotgroupcaarespressworksaerodromeworkinggroupair-traffic-controlaircraftaccident-preventioneducatormarketplaceambulanceinsurancecateringairportrepbodyenginesoftwaremodellingair-surveillanceconsultingchartertrainermaintenanceservicesdesignflightskydivingfreightassociationstudentgroundhandlingdgcafuelclubtaxicrewshowballooningexpresstraderbrokerauthoragentsairtrafficjournalistsafetyconsultantmicrolightaccident-investigationparachutingequipmentproductionfederationrecreationscientistnavigationengineertradingglidingleasingresearchpassenger-associationentertainmentparaglidinghangglidingaerobaticrotorcraftemergencycertificationgovernmentaeroclubexchangelogisticschampionshiphomebuiltcouncilconferencecontrolairlinecivilaviationjournalorgcomnetedugovcoorgcomnomnetobjappsofforgcomnetuwukiloappsdevsframerorgmilcomnetedugov*coradio2naorgcomnetcommuneedogpbcoitgvorgedugovspreviewfrontendrelayononstagingauthcloudsandboxupid*mtls*privatelinktypedreamdeveloperbravemochawindsurfaivenmirenupsunwnextbegetngrokclerkwale2bwebcsbrunputercrbtsflutterflowcloudzyrospawnbasesliplanemodelenceshiptodaymagicpatternsnetlifyondigitaloceanrailwayhostedclaudehasurabotdashretoolvercelgithubluyanigadgetreplitcloudflaretelebitedgecomputeevervaultexponyatnoopencrpplxzeaburwasmerframerzeropsrocketpreviewconvexmedusajsspritesagilevibesonherculeseasypanelstreamlitglideossnowflakefastedgemesserliloginlinehackclubcodepennorthflankbase44corespeedleapcellngrok-freeclerkstagelovableon-fleek*us-west-3ap-south-2us-central-2us-central-1eu-central-1ap-south-1us-west-2us-east-2eu-north-1ap-north-1us-west-1us-east-1*rcloudintsegorgmilcomgobbetnetintedugovturmusicasenasamutualcoopv6dnsip6uriurnin-addre164homeirisgovdixdaemoncloudnssthwien*inexexkunden4accogvormymyspreadshop4lima2ixortsinfofuturecmsfuturehosting12hpprivfuturemailinglima-cityfunkfeuer123webseitednshomemelmyspreadshopcloudletswasantqldvicactnswtascatholicwasaqldvictasidwasantozqldorgcomvicasnactnetedugovnswtasconfcomairflowlambda-urltransfer-webapptransfer-webappairflowtransfer-webapptransfer-webapp-fipstransfer-webappeu-west-3ap-south-2eu-south-2eu-central-2ap-southeast-3ap-southeast-4ap-northeast-3eu-central-1mx-central-1me-central-1ca-central-1il-central-1ap-northeast-1ap-southeast-1me-south-1af-south-1eu-south-1ap-south-1ap-southeast-7us-west-2eu-west-2ap-east-2us-east-2eu-north-1ap-southeast-2ap-northeast-2ap-southeast-5us-gov-west-1us-gov-east-1ap-southeast-6ca-west-1us-west-1eu-west-1us-east-1ap-east-1sa-east-1privatenotebookstudiolabelingnotebookstudionotebooknotebook-fipslabelingnotebookstudionotebook-fipsnotebookstudio-fipsnotebook-fipsnotebookstudionotebook-fipsnotebookstudioeu-west-3ap-south-2eu-south-2eu-central-2ap-southeast-3ap-southeast-4ap-northeast-3eu-central-1me-central-1ca-central-1il-central-1ap-northeast-1ap-southeast-1me-south-1af-south-1eu-south-1ap-south-1us-west-2eu-west-2us-east-2eu-north-1ap-southeast-2ap-northeast-2experimentsus-gov-west-1us-gov-east-1ca-west-1us-west-1eu-west-1us-east-1ap-east-1sa-east-1onrepostsagemakercopporgmilcompronetintedugovbiznameinfoshoprsorgmilcomnetedugovbrendlyresolvenzauscotvstoreorgcomnetedugovbizinfoidacaicoittvorgmilcomschnetedugovinfocloudezproxysiteacmymyspreadshopkuleuvenwebhostingtransurl123websitecloudnsinterhostsolutionsddns5476103298edgfacbmlonihkjutwvqpsryxzbarsycoororgcomedumyftpno-iporxcloud-ipfor-somemmafanfor-morewebhopselfipjozidyndnscloudnsdscloudfor-thefor-betteractivetrailcoeconorestooteorgcomeconeteduassurmoneyafricaarchitectesrestaurantloisirstourismavocatsinfoagrounivcoorgcomnetedugoviatvdeportesaludtksatorgmilcomwebgobnetinteducienciaboliviarevistacooperativaempresanombreindustriamusicapatriamedicinademocraciapoliticapuebloindigenaplurinacionalarteblogwikiinfoagrotransportenoticiasprofesionalacademiaeconomiaecologiamovimientotecnologianaturalpagesappsgroksailsimplesitecepesebamapadfmgalampbacscpirngorotomtrjspaprrprrsesmscepesebamapadfmgalampbacscpirngorotomtrjspaprrprrsesms*biaamfmtcmptvfeirasampajampanatalbelemananiradiog12medindfndbmdtrdthepoaggfjdfdefinfenflegsegongengcngorgzlgslglogppgmillelqslcimcomnomadmjabimbbibbsbabcrectecsjcetcpscpvhudieticriapipsiecnbiorioecogeoteoodoproatoartfstmatvetdetbetnetcntnotfotgrueduajuespappreptmpemparqsrvadvdevgovntrturagrjorfarjusmusdesvixxyzcozfozslzbhzmaringasantamariacampinagrandegoianiasorocabafloripasaobernardocuritibaboavistarecifeaparecidasaogoncasalvadorcuiabamorenamacapalondrinacontagemsocialfortalmaceioleilaoosascoriobranconiteroi9guacutcheblogflogvlogwikitaxicoopmanauspalmascaxiasjoinvillebaruericampinassantoandreribeiraoriopretoweorgcomnetedugovv0windsurfshiptodaycloudsitecoaccoorgnetgovofmilcomgovmediatechzacoorgcomnetedugsjgovmydnspenfnlabnbmbgcbcqconcontnuyksknsmyspreadshopno-ipawdevboxbarsyonidatemfuinabusavinstanceseceuguukussryzespawnloccsxcloud-ipmyphotosfantasyleaguetwmailcleverappsscrappingccwucloudnsftpaccessgame-serverccgovobjectsrmalpgcust*svcalp1aeappenginermalpgmyspreadshop4lima2ixsquare7cloudscale123websitefirenet12hpflowgotdnslinkyard-cloudcloudnslima-citydnskingobjectstorageedaccogoorusorgcomnetintedua\xE9roportxn--aroport-byaassogouvcomilgobgovcloudnses-1eu-west-1us-east-1euvipit1eurarubait1s3lbwebsites3websiteru-spbru-mskelasticcsrunstnukukcaukusnl-ams-1fr-par-1fr-par-2functionsnodess3ddlwhmrdbfnck8sifrs3-websitecockpitscblmgdbdtwhkafkpubprivs3ddlwhmrdbk8sifrs3-websitecockpitscblmgdbdtwhkafks3ddlrdbk8sifrs3-websitecockpitscblmgdbdtwhkafkk8sscalebookpl-wawfr-parnl-amsbaremetalsmartlabelinginstancesdechk2kuleuvenlaravelvoorloperurownoxazapscwhstgrvaporonline-serverobservablehqelementorantagonistreclaimjoteluluencowaydiademjelasticmatlabmagentositetrendhostingaxarnetjenv-arubajelejoteravendbemergenttrafficplexconvexkeliwebserveboltbegetcdnstaticson-rancherprimetelonstackitunison-servicesdnshomelinkyardbarsyjelecloudnscocomnetgovmycn-northwest-1cn-north-1s3s3-accesspoints3-websites3s3-accesspointrdsdualstacks3-deprecatedemrappui-prods3-websiteemrstudio-prods3-object-lambdaemrnotebooks-prodexecute-apis3s3-accesspoints3s3-accesspointrdsdualstackemrappui-prods3-websiteemrstudio-prods3-object-lambdaemrnotebooks-prodexecute-apicn-northwest-1cn-north-1cn-northwest-1ebcomputeelbcn-north-1airflowcn-northwest-1cn-north-1oncn-northwest-1cn-north-1amazonawssagemakeramazonwebservicesdirectasgdsdhehahljlnmhbacscahqhshhihnlnynsnmofjbjzjxjtjhkcqtwgsjssxnxjxgxxzgz\u7DB2\u7D61\u7F51\u7EDC\u516C\u53F8orgmilcomnetedugovxn--55qx5dcanva-appsxn--io0a7iquickconnectcanvasitekhsjxn--od0algcanva-codemyqnapcloudsrvrlessclustersrealtimestorageleadpagescarrdcrdorgmilcomnomnetedugovhidnssupabaserdpareplmypiumsoxmitotaplpagesfirewalledreplitowodevwebview-assetsvfswebview-assetss3s3-accesspointdualstackemrappui-prods3-websiteaws-cloud9emrstudio-prods3-object-lambdaemrnotebooks-prodexecute-apicloud9eu-west-3ap-south-2eu-south-2eu-central-2ap-southeast-3ap-southeast-4ap-northeast-3eu-central-1me-central-1ca-central-1il-central-1ap-northeast-1ap-southeast-1me-south-1af-south-1eu-south-1ap-south-1ap-southeast-7us-west-2eu-west-2us-east-2eu-north-1ap-southeast-2ap-northeast-2ap-southeast-5ca-west-1us-west-1eu-west-1us-east-1ap-east-1sa-east-1s3s3-accesspointdualstackemrappui-prods3-websiteaws-cloud9emrstudio-prods3-object-lambdaemrnotebooks-prodexecute-apicloud9consent-portals3s3-accesspointdualstackanalytics-gatewayemrappui-prods3-websiteaws-cloud9emrstudio-prodbedrock-agentcores3-object-lambdaemrnotebooks-prodexecute-apicloud9s3s3-accesspointdualstackemrappui-prods3-websiteemrstudio-prodbedrock-agentcores3-object-lambdaemrnotebooks-prodexecute-apis3s3-accesspointdualstackemrappui-prods3-websiteemrstudio-prods3-object-lambdaemrnotebooks-prodexecute-apis3s3-accesspointdualstacks3-deprecateds3-websitebedrock-agentcores3-object-lambdaexecute-apibedrock-agentcores3s3-accesspoints3-websites3-accesspoint-fipss3-fipss3s3-accesspointdualstackemrappui-prods3-websites3-accesspoint-fipsaws-cloud9s3-fipsemrstudio-prodbedrock-agentcores3-object-lambdaemrnotebooks-prodexecute-apicloud9s3s3-accesspointdualstackemrappui-prods3-websites3-accesspoint-fipss3-fipsemrstudio-prods3-object-lambdaemrnotebooks-prodexecute-apis3s3-accesspointdualstackemrappui-prods3-websiteaws-cloud9emrstudio-prodbedrock-agentcores3-object-lambdaemrnotebooks-prodexecute-apicloud9s3s3-accesspointdualstackemrappui-prods3-websiteaws-cloud9emrstudio-prodbedrock-agentcores3-object-lambdaemrnotebooks-prodexecute-apicloud9s3s3-accesspointdualstacks3-deprecatedanalytics-gatewayemrappui-prods3-websiteaws-cloud9emrstudio-prodbedrock-agentcores3-object-lambdaemrnotebooks-prodexecute-apicloud9vfss3s3-accesspointdualstackemrappui-prods3-websiteaws-cloud9emrstudio-prods3-object-lambdaemrnotebooks-prodexecute-apicloud9eu-west-3ap-south-2eu-central-2ap-southeast-3ap-southeast-4ap-northeast-3eu-central-1mx-central-1me-central-1ca-central-1il-central-1ap-northeast-1us-northeast-1ap-southeast-1me-south-1af-south-1ap-south-1ap-southeast-7us-west-2eu-west-2ap-east-2us-east-2ap-southeast-2ap-northeast-2ap-southeast-5us-gov-west-1us-gov-east-1ap-southeast-6ca-west-1us-west-1eu-west-1us-east-1ap-east-1sa-east-1mrapaccesspoints3s3-accesspointdualstacks3-deprecatedanalytics-gatewayemrappui-prods3-websites3-accesspoint-fipsaws-cloud9s3-fipsemrstudio-prodbedrock-agentcores3-object-lambdaemrnotebooks-prodexecute-apicloud9s3s3-accesspointdualstacks3-deprecatedanalytics-gatewayemrappui-prods3-websites3-accesspoint-fipsaws-cloud9s3-fipsemrstudio-prodbedrock-agentcores3-object-lambdaemrnotebooks-prodexecute-apicloud9s3s3-accesspointdualstackemrappui-prods3-websites3-accesspoint-fipss3-fipsemrstudio-prodbedrock-agentcores3-object-lambdaemrnotebooks-prodexecute-apis3eu-west-3ap-south-2eu-south-2computes3-ap-northeast-2elbrdss3-ap-east-1s3-sa-east-1s3-us-gov-west-1s3-eu-central-1s3-ca-central-1eu-central-2ap-southeast-3ap-southeast-4ap-northeast-3s3-website-us-west-2s3-website-eu-west-1s3-external-1eu-central-1me-central-1ca-central-1il-central-1s3-us-west-1s3-eu-west-1s3-website-sa-east-1s3-website-ap-southeast-2ap-northeast-1ap-southeast-1s3-us-west-2s3-eu-west-2me-south-1af-south-1eu-south-1ap-south-1ap-southeast-7us-west-2eu-west-2us-east-2s3-website-ap-southeast-1s3-1s3-globals3-ap-northeast-3eu-north-1airflowap-southeast-2s3-us-gov-east-1s3-fips-us-gov-east-1s3-me-south-1s3-ap-south-1ap-northeast-2s3-website-us-west-1ap-southeast-5s3-eu-north-1s3-ap-southeast-1s3-website-us-gov-west-1compute-1s3-eu-west-3us-gov-west-1s3-website-ap-northeast-1us-gov-east-1s3-fips-us-gov-west-1s3-website-us-east-1s3-ap-southeast-2ca-west-1us-west-1eu-west-1us-east-1ap-east-1sa-east-1s3-us-east-2s3-ap-northeast-1authauthauth-fipsauth-fipseu-west-3ap-south-2eu-south-2eu-central-2ap-southeast-3ap-southeast-4ap-northeast-3eu-central-1mx-central-1me-central-1ca-central-1il-central-1ap-northeast-1ap-southeast-1me-south-1af-south-1eu-south-1ap-south-1ap-southeast-7us-west-2eu-west-2ap-east-2us-east-2eu-north-1ap-southeast-2ap-northeast-2ap-southeast-5us-gov-west-1us-gov-east-1ap-southeast-6ca-west-1us-west-1eu-west-1us-east-1ap-east-1sa-east-1eu-west-3eu-south-2ap-southeast-3eu-central-1ca-central-1ap-northeast-1ap-southeast-1ap-south-1us-west-2eu-west-2us-east-2eu-north-1ap-southeast-2ap-northeast-2ap-southeast-5eu-west-1us-east-1ap-east-1sa-east-1csrframeservicesbuilderstg-builderdev-builder*ociocpocsazuregcpawsdemoinstanceeu-west-3ap-south-2eu-south-2eu-central-2ap-southeast-3ap-southeast-4ap-northeast-3eu-central-1me-central-1ca-central-1il-central-1ap-northeast-1ap-southeast-1me-south-1af-south-1eu-south-1ap-south-1ap-southeast-7us-west-2eu-west-2us-east-2eu-north-1ap-southeast-2ap-northeast-2ap-southeast-5us-gov-west-1us-gov-east-1ap-southeast-6ca-west-1us-west-1eu-west-1us-east-1ap-east-1sa-east-1previeweu-4us-4us-1eu-1us-2eu-2us-3eu-3s3-websitekrkrobjectprivateobjectkrkrskrkrsobjectkrprivateobjectkr-privatecomputepaasrag-cloudrag-cloud-chjcloudjcloud-ver-jpcdemonodebalancermembersipeuxvsoncillaocelotonzayalilynxsphinxfentigercustomercaracalsgkrobjectstoragedesgkrusobjectkrkr-naverkr-naver-devkrprivatewebsiteobjectkr-naverkr-privatekr-naver-devjpjpkrjp4jp5s3-website-jpjpkrjp4jp5objectprivateobjecto365cloudstaticxendevapp001testcode-builder-stgplatformmediasiteprojedrydpagesjsx0desazacncoitrueu4uhkukgrbrushatenadiarymyspreadshopfrom-flfrom-wvwebspace-hosttheworkpchatenablogcursorusercontentservesarcasmapplinzisakuratanwixsitefin-ncloudstoragegov-ncloudstorageappchizigiizeis-into-carsdnsiskinkyadobeaemcloudis-a-therapistpgfogmyvncdojinis-an-actress1kappfldrvkozowqa2jpnmexprgmrfirewall-gatewaydynnscafjsfbsbxooguyfrom-gawoltlab-demois-a-anarchistwiardwebteaches-yogadattowebtb-hostinglive-websiteservegamegotpantheonfrom-nhsubsc-payfrom-ohvipsinaappfrom-cadyndns-officeztna-dingtalkhomelinuxfrom-mahercules-appservebbsstreakusercontentfrom-okfrom-wyfastly-terrariumis-a-llamaqualyhqportalserveexchangeon-vaporvivenushopciscofreakgrayjayleaguesmetaaiusercontentfrom-iais-a-libertariansaves-the-whalestaveusercontentyolasiteoperaunitepoint2thisis-a-catererclaudeusercontentlinodeusercontentfrom-vagithubusercontentsells-for-lesshosteurcanva-appsplaystation-cloudddnsfreefrom-pafrom-prfrom-waddnskingoutsystemscloudhotelwithflightmydattois-a-nascarfanmydbserverminiserverdamnserverservehumouris-a-playerfrom-nvfrom-nmemergentagentgentappsamplifyappfrom-kyis-an-accountantnfshostserveircfrom-akpythonanywherestackhero-networkpostman-echolikescandydyndns-mailobservableusercontentserveftpfreeboxosfrom-utcdn77-storageamazonawsneat-urlnclouddyndns-serverlinodeis-a-teacherfrom-vtgleezemythic-beastsus1-pleniteu1-plenitla1-plenitpaywhirlservecounterstrikejdevcloudhealth-carereformis-into-animegoogleapisis-a-painterafricaisa-hockeynutatmetais-an-actora2hostedis-a-democratdatadetectest-le-patrondigitaloceanspacesis-a-designeris-a-hunterlinodeobjectstemp-dnsissmarterthanyoufrom-arsimplesiteevennodetownnews-stagingis-a-liberalgooglecodejelasticservemp3qualyhqpartnerdyndns-free1cooldnsest-a-la-masiondrayddnsdynuddnsfrom-orfrom-miis-a-bloggerfrom-himydobisscanvacodeis-an-engineerest-a-la-maisonupsunappdevinappswafflecellmyasustorwpenginepoweredfrom-ctservep2psame-appmyshopblocksthingdustdatalikes-piediscordsezis-with-thebandlpusercontentis-leetshopitsite3utilitiesis-a-personaltrainersinaappladeskis-a-cheflogoipselfipbase44-sandboxnospamproxyalibabacloudcsmesswithdnsauthgearappsiamallamawithgooglelutrausercontentmochausercontentframercanvasmytabitdyndns-homew-credentialless-staticblitzcpserverdiscordsaysis-a-nurseappspotatlassian-isolated-3premotewdfrom-mtwixstudiocode0emm180rmyactivedirectoryawsappsmytuleapdnsabrpolyspaceqbuserrenderbuiltwithdarkboutirgotdnsabrdnsdopaascanva-hosted-embedawsglobalacceleratorhomesecuritypcmyiphostditchyouripclever-clouddyndns-ipon-aptibleis-a-musicianhosted-by-filessecuritytacticsappspaceusercontenthomeunixstrapiappsame-previewcf-ipfsmycloudnaselasticbeanstalkis-certifieddontexistkasserverik-serverdrive-platformatlassian-3pfirebaseappncpstorageherokuappawsapprunnerbarsycenteris-a-cubicle-slaveservehttpmyshopifyis-a-guruquicksytessiiitesorsitesmagicpatternsappis-a-cpameteorappfrom-wiis-a-rockstarbumbleshrimpdattolocaldatabricksappsreadthedocs-hostedfrom-rifamilydsdyndns-picsmyoxypagesplesknsbplaceddnsaliasdynaliasdyndns-remotedoomdnsip-ddnsblogdnsis-a-doctorroutingthecloudamazoncognitobarsyonlinedsmynasddnsgurucloudflare-ipfsdeus-canvasfrom-idsmushcdnpagespeedmobilizergcorecdndyndns-at-homeunusualpersonhosted-by-previderis-a-republicandyn-o-saurstreamlitappworkisboringonthewificprapidqualifioappis-uberleetis-slickgetmyipwpdevcloudtypeformdyndns-at-workgentlentapismynascloudw-corp-staticblitzfrom-ingeekgalaxyservebeerfrom-mdonrenderspace-to-rentaivencloudappspacehostedwafaicloudcodespotblogspotatlassian-3p-us-gov-modfrom-ndfrom-msis-a-techieis-a-studentcustomer-ociis-a-photographerdurumisfrom-ksmassivegriddyndns-wikiis-an-entertaineris-a-hard-workermysecuritycamerafrom-mnrackmazedyndns-blogis-a-bulls-fanwritesthisblogfreemyipsimple-urlfrom-sdninjaneer-sitesreservdauthgear-stagingest-mon-blogueuris-into-gamesrice-labsxtooldevicesakurawebis-an-anarchistoraclecloudappsdyndns-worksells-for-urhcloudfrom-dcfastvps-serverwpmucdnis-a-geekscrysecfrom-txis-into-cartoonsmodelscapetrycloudflarelocaltonetstreak-linkbalena-devicesfrom-njforgeblocksfreebox-oswebadorsitefrom-ncdoesntexisthobby-sitestreaklinkshomesecuritymacownprovidertuleap-partnersdattorelaywphostedmailservequakeis-a-socialistservehalflifepivohostingdynuhostingquipelementsw-staticblitzdyndns-webfrom-deproject-studyis-not-certifiedhercules-devis-a-financialadvisoramazonlightsailservepicsis-a-greenloseyouripfrom-ilwithyoutubemwcloudnonprodwiredbladehostingdnsdojofrom-tnpixolinomyqnapcloudncloudstorageis-an-artisthostedpiis-a-landscaperauiusercontentoaiusercontenton-forgeis-a-conservativedreamhostersnet-freaksapps-1and1is-goneencoreapifastly-edgefrom-nesalesforcefrom-scdeployagentoraclegovcloudappsfrom-alis-a-lawyercechirevultrobjectsstufftoreadisa-geekddnsgeeklovableprojecttry-snowplowfrom-moblogsyteis-a-bookkeepernogmyforumravendbmyboxdeelementoredsaacficogoorinforgcomgobnatneteduidstoreorgcomnetintedudevnomepublorgcomneteduathgovtestscalculatorspaynowinfoquizzesresearchedcloudnsfunnelsassessmentsjscaleforcetmacltdorgmilcompronetgovbizpresseklogesrsccloudcustomfltusrcloude4corealmgovmunicontentproxy9metacentrumdyndyndyndnsdynpagespages-researchitionoccustomercomymyspreadshopipv64diskussionsbereich4limacomrubgov2ixfirewall-gatewayddnssspdnsbarsykeymachinesquare7myhome-serverspeedpartnercommunity-proschuldockxenonconnectg\xFCnstigliefernbwcloud-os-instancedyndnssecmy-routerxn--gnstigliefern-wobin-butterl-o-g-i-nisteingeekin-dslin-berlinin-brbfuettertdasnetzleitungsenin-vpnlcube-serverdyn-ip24logoipdyn-berlinruhr-uni-bochum12hpgoipsrvdnsfruskygit-repossvn-reposinternet-dnsg\xFCnstigbestellenhome-webserverxn--gnstigbestellen-zvbbplacedheimdnscosidnswebspaceconfiglima-citydyndns1istmeinvirtualuserschulplattformmy-gatewayddnsseclebtimnetztest-iservmein-iservvirtual-userhome64iservschuletaifun-dnstraeumtgeradeschulserverdynamisches-dns123webseitednshomehs-heilbronndnsupdaterbssgraphicdwadpdwdaepeweaawapaafpfwfabwbpbacwcpcciwebuserapiobjectssites*teamst3r2lpuncldabymebravepanelngrokiservstglclcrmerpflypagesbarsyvivenushoplocalcertlocalplayerbearbloggatewaydeno-stagingis-not-ais-a-goodbotdashvercelmocha-sandboxplatter-appreplitgithubpreviewworkersinbrowserevervaultis-ahrsndenoxmitmodxmyaddrstorageapipayloadgrebedocruncontainersreliantlabsstgstagelclstageloginlineis-a-fullstackcodepenreliantpreviewleapcellngrok-freeis-coolpagelemonstoragewebharemediatechlibp2pdiscoursecomyspreadshopstoreregbiz123hjemmesidefirmcoorgcomnetedugovsldorgmilcomwebgobartnetedugovtmorgpolcomsocartnetedugovassoagrondiscoodontk12medcuegyecpaabgengorgmilgalsaltulcomadmesmgobpubdocmonfindgnriouioproartlatvetnetfotedulojgovntrturibrbarxxxofficialbasechefprofmktgpsictechinfoarqtcontdentrrpppsiqgit-pagesritmedfieorgcomlibprieduaipgovriikmeactvsportorgmilcomscieunnetedugovnameinfopintouchtawktotawkmyspreadshoporgcomnomgobedu123miwebcomputeorgcomnetedugovbiznameinfocognito-idptransfer-webappeusc-de-east-1onjelasticnxaspdnsbarsydirectwpdeuxfleurstransurldogadoprvwcloudnsamazonwebservicesdnshomeuserpartycokoobinmkmspaceviewfidymyspreadshopalandkapsiikixn--hkkinen-5wacloudplatformh\xE4kkinen123kotisivuidacorgmilcompronetedugovbiznameinforadioorgcomneteduusercocomexperts-comptablestmmyspreadshopgretaprdcomnomynhccifbxoshuissier-justicenotairesaeroportfreeboxoson-webavocatassoportgouvkdnschirurgiens-dentistes-en-franceavouesfbx-os123sitewebveterinairechirurgiens-dentistespharmacienchambagrimedecinfreebox-osdediboxgoupilemszicpyicpvicppleysheezypagesedugovcnpyorgcomcybllcpvtnetedugovtnxonlineschoolddnsdaemond6atcopanelorgnetplybotdashstackitkaasorgmilcomnetedugovbizmodltdorgcomedugovcoorgcomneteduappwriteacorgcomnetedugovcloudtranslateusercontentorgcomnetedumobiassoorgcomnetedugovbarsysimplesiteindorgmilcomgobneteduorgcomwebnetedugovguaminfonxhra\u6559\u80B2\u654E\u80B2\u7DB2\u7D61\u7F51\u7D61\u7EC4\u7E54\u7D44\u7E54\u7F51\u7EDC\u7DB2\u7EDC\u7EC4\u7EC7\u7D44\u7EC7\u516C\u53F8\u653F\u5E9C\u500B\u4EBA\u4E2A\u4EBA\u7B87\u4EBAltdorgcomincneteduidvgovxn--uc0ay4axn--55qx5dxn--mk0axixn--io0a7ixn--uc0atvxn--zf0avxxn--lcvr32dxn--od0algxn--wcvs22dxn--gmqw5axn--od0aq3bxn--mxtq1mxn--ciqpnxn--tn0agxn--gmq050iorgmilcomgobnetedufngocdnappvoatiiservwp2tempurlmircloudfreesitewpmudevmyfastgadgetcloudaccessjeleambahalfboltfastvpsemergenteasypanelopencraftizcombrendlynamefromrtpersoadultmedorgpolrelcomproartnetedufirminfoassoshopcoopgouvtmcomediahotelforumvideosportorgsexagrargameslakaseroticaerotikatozsdereklamcasino2000filmsuliinfoboltshopprivnewsszexcityutazasjogaszkonyveloingatlaneacaicogoormy\u1B29\u1B2E\u1B36milwebschnetkopbizzonedesaponpesxn--9tfkymyspreadshopgovmytabittabitorderravpageaccok12idforgnetgovmuniltdplcaccotttvorgcomnetmeca6g5gpgamubacaicniocoukuptverdruscsdelhiindorgmilcomwebnicfingenpronetintedugovresbizbiharbarsyinternetbusinessschooltravelsupabasealumnigujaratfirminfoaeropostbankcoopindevscloudnsno-ipbarsybarrell-of-knowledgebarrel-of-knowledgensupdategroks-thisdnsupdatefor-ourknowsitalldvrcammittwalddynamic-dnsv-infowebhopselfipdyndnshere-for-moreilovecollegemayfirstforumzcloudnsmittwaldservertypo3servergroks-theeusekd1cdndyndnsidrawsainaueuapjpusstagemocksysdevicesclientcustreservdcustdevdisrecprodtestingcowzbeebyteutwenteboxfusebravepstmndedynngrokorgmilcomnomnetedugovqcxqzzbarsythingdustmailerpagemo-siemensrb-hostingfh-muenstergitbookbluebitecloudbeesusercontentnodeartterramindkiloappsforgerockdarklangresinstagingapigeebubbleb-datascryptedhypernodedappnodepantheonsitegitlabgithubkeeneticvirtualservercleverappshostyhostingon-rioedugitticketstelebitwixstudioon-k3sicp0icp12038jeleqotolairbubbleappsmyaddrstolosmyrdbxwebflowdrive-platformbeagleboardhasura-applolipopdefinimavaporcloudmusicianwebflowtestazurecontainerresindevicereadthedocsloginlineeditorxmoonscalesandcatsbasicserversubscribepagewebthingsbrowsersafetymarkbeebyteappbitbucketidaccovistablogorgschnetgovxn--mgba3a4f16axn--mgba3a4fraarvanedge\u0627\u064A\u0631\u0627\u0646\u0627\u06CC\u0631\u0627\u0646jclaspeziapdudcefegelemeperetevebacanatavaparasabgagfgogrgpgalclblimfmrmcbmbvbfclcmcvcrcpcchlimifibicivipirisimncnbnanenrnpntnnolomobocoaogorosopotoptvtatctbtmtltotpusulunutpspapaqsvpvvvtvavvrtrsrprgrfrcrbrarorkrvstsssbscsmsispzczbzbozen-suedtirolmyspreadshopxn--bulsan-sdtirol-nsbxn--valledaoste-ebbtrentinoaltoadigetrentin-sued-tirolxn--forlcesena-c8axn--forl-cesena-fcbxn--bozen-sdtirol-2obtriestetrentinsuedtiroltrentino-s-tirollecceudineaostesienaparmaluccapaviagenoapaduaaostamonzaabruzzoternirietiturinmilanbozenlaziofermoleccocuneonuoropratola-speziavdataaligfvgpugmolcalcamlomumbsicpmnvenvaoedugovabrsarmaremrbastoslazibxosfirenzetrentinos\xFCdtirolval-d-aostavalle-aostamessinacremonaravennatoscanatrentin-suedtirolbolognacalabriaurbinopesarofriuli-v-giuliaogliastraxn--valle-aoste-ebblaquilaandriatranibarlettasyncloudxn--valle-d-aoste-ehbaostavalleyvalled-aostatrentino-alto-adigevallee-d-aostexn--balsan-sdtirol-nsbpistoiasicilialucaniacataniaiserniaperugiabresciaveneziagorizialiguriaimperiabulsan-suedtirolbalsan-suedtirolbarlettatraniandriaxn--trentino-sdtirol-szbforl\xEC-cesenatuscanyvall\xE9e-d-aostemantovavall\xE9e-aostecasertapiemontevalleaostaval-daostafriulivgiuliatrevisoforli-cesenavall\xE9edaosteferrarapescaravald-aostatrentino-altoadigefriuli-vegiuliavallee-aostecarboniaiglesiastarantomediocampidanovalleedaostetrentinosud-tirolcampobassotrentins\xFCd-tiroltrentinos\xFCd-tirolmonzabrianzatrentino-s\xFCdtirolxn--trentino-sd-tirol-c3bpotenzacosenzavicenzaemiliaromagnavenicefrosinonemarchepordenonetrentinosued-tirolvaresemolisevall\xE9eaostefriuli-veneziagiuliabasilicatalatinaanconasavonaveronamodenabiellabolzano-altoadigepugliafoggiaumbriatrentino-stirolgenovapadovamateranovararagusapiacenzatrentinostirolvalleeaostetempio-olbiasudsardegnatrentinsudtirolmassa-carrarafriuliveneziagiuliatrentinosuedtirolandria-barletta-tranitrapanixn--cesenaforl-i8amaceratacaltanissettaascoli-picenobrindisicarraramassacagliaririmininapolivibo-valentiachietibulsan-sudtirolbalsan-sudtiroltrentino-a-adigebulsanbalsaniglesiascarboniamilanotorinoteramodell-ogliastraarezzotrentinoalto-adigerovigotrentovenetoiglesias-carboniatrentino-sud-tirolaltoadigereggio-emiliareggio-calabriasardegnatranibarlettaandriapiedmontxn--sdtirol-n2amedio-campidanotrentino-s\xFCd-tirolfriuli-vgiuliafriuli-ve-giuliaromeennaromapisa32-b16-b64-blodiastibarineencomonaplesforlicesenailiadboxosalessandriasicilytrani-barletta-andriaxn--trentin-sdtirol-7vbpesarourbinotrentinsued-tirolcesena-forliforl\xECcesenaemilia-romagnamonzaebrianzaxn--trentinsdtirol-nsbtrentinos-tiroltrentins\xFCdtirolvalledaostaolbia-tempiocampidanomediovibovalentiasassarivalle-daostalombardysud-sardegnafriulivegiuliareggioemiliamonzaedellabrianzaalto-adigevercellitrentin-sudtiroltraniandriabarlettatrentino-sudtirolascolipicenobozen-s\xFCdtirolfriulive-giuliaflorencexn--cesena-forl-mcbcarbonia-iglesiasaosta-valleycarrara-massadellogliastratrentinoa-adigexn--valleaoste-e7apesaro-urbinoxn--trentinosdtirol-7vbxn--trentin-sd-tirol-rzbxn--trentinsd-tirol-6vbtrani-andria-barlettatrentin-s\xFCd-tirolxn--trentinosd-tirol-rzbgrossetomonza-e-della-brianzas\xFCdtirolreggiocalabriatrentinoaadigetrentin-s\xFCdtirolverbano-cusio-ossolafriuliv-giuliaverbaniacampaniatrentino-aadigefriulivenezia-giuliasardiniaandriabarlettatranibarletta-trani-andriacatanzarooristanourbino-pesarocesena-forl\xECvalle-d-aostacampidano-medio123homepagesiracusatempioolbiasuedtirollombardiaavellinocesenaforl\xECtrentinofriuli-venezia-giuliabozen-sudtirolandria-trani-barlettabulsan-s\xFCdtirolbalsan-s\xFCdtirolmonza-brianzabolzanotrentino-sued-tirolbellunosalernolivornocrotonesondriodnshometrentinsud-tirolmassacarraratrentin-sud-tiroltrentino-suedtirolviterbobergamocesenaforliolbiatempiopalermobeneventoagrigentoofcoorgnetfmaitvphdengorgmilcomschnetedugovperagrikanieasukehandachitatokaiaisaikonanoharuamaobuhigashiuraowariasahiinuyamatobishimaiwakurashitarainazawatoyonegamagorimihamatoyotataharakariyayatomioguchikomakimiyoshinishiotokonamekiyosuchiryutoyohashiokazakiisshikikasugaikotakiratoeianjotogofusosetohazutsushimashinshirotakahamanisshinshikatsuhekinantoyokawaichinomiyatoyoakeodateogataakitaikawakyowahonjoogayurihonjonoshirokamiokakatagamimitanegojomeyokotekosakadaisenkazunonikahohonjyomoriyoshimisatohappoukamikoanihachirogatahigashinarusesembokufujisatokitaakitaitayanagiowanitakkomutsutsurutahirosakigonoheoirasetowadamisawanohejiaomorishingohiranairokunohehashikamitsugarushichinohehachinohenakadomarisannohekuroishisakaeisumiasahiotakiinzaiabikomatsudoyachiyomutsuzawakujukuriomigawakashiwatoganemihamanaritasakuranagaramobarahanamigawachoshishiroichoseikozakishisuikatorimidorichonankyonanfuttsuonjukufunabashinagareyamanodasosatakochuotohnoshourayasukimitsuyokaichibayotsukaidosodegauratateyamakamagayayokoshibahikariyachimatakatsuuratomisatokisarazukamogawaichikawanarashinoichinomiyashimofusaminamibososhirakoichiharaoamishirasatoikatahonaiainansaijoseiyoiyoozuuwajimaniihamanamikatamasakiuchikokihokutobetoonshikokuchuomatsuyamaimabarikamijimakumakogenyawatahamamatsunosabaeikedaobamasakaifukuiohionotsurugamihamawakasaminamiechizeneiheijikatsuyamatakahamaechizensoedaukihaomutaokawanishiogoribuzenonojosueumiokiotochikugosasagurisaigawamizumakishinyoshitomikurumekurateyamadakasuganakamamiyamanogatatakatahakataiizukakawaratagawakasuyaashiyainatsukimunakataminamitsuikishonaikurogifukuchikeisenhigashimiyakoshinguyukuhashiokagakiyamekogaongausuikahotohochuotoyotsumiyawakadazaifuhisayamatachiaraiyanagawanakagawahirokawachikujochikushinochikuhochikuzennamieotamaokumashowateneiiwakikoorinangoononishigoshimogoomotegomishimafukushimaasakawakagamiishishirakawaiitatefutabahiratayugawahanawakitakatakawamatakunimiyabukibandaihigashihironoyamatomiharuyamatsuriaizubangedatesomaaizuwakamatsuyanaizuaizumisatonishiaizuizumizakikitashiobarataishinkaneyamakoriyamainawashirotanagurafurudonosamegawasukagawaishikawatamakawaikedaogakitaruiginanenahashimahichisonakatsugawaibigawashirakawamizunamiminokamomitakekawauesekigaharatomikasakahogikitagatayamagatatajimianpachimotosuyaotsukakamigaharahidakanisekitokigujominogodoyorogifukasamatsutakayamawanouchihigashishirakawakasaharashimonitatsumagoichiyodakannakanrashowameiwakiryuotaoratomiokafujiokaitakuranaganoharahigashiagatsumatakasakishibukawaminakamikatashinatsukiyonokawabanumataannakaoizumimidorishintoisesakiuenoyoshiokakusatsutakayamanakanojonanmokutamamuratatebayashimaebashiotakekaitadaiwahongofuchukuietajimashobaramiharahatsukaichihigashihiroshimamiyoshikumanokurenakasakaseraseranishiasaminamifukuyamashinichionomichiosakikamijimajinsekikogentakeharaotobenanaeikedatohmaozoraobiraabirakyowaeniwataikibibaisharirebunerimohiroooketootarupippunishiokoppechitosefurubirahakodateshiranukakitahiroshimakushiroobihironanporoiwamizawaniikappukunneppufukushimanakasatsunaitoyourakuromatsunaiakabirakamisunagawashibechaurakawakamifuranonakatombetsuasahikawashimokawakayabeokoppebiratoriabashirisaromaatsumanumatahidakabifukamukawamikasahorokanaitoyotomisarufutsuhigashikawaishikarikitamiyoichiesashiiwanaitomariminamifuranoakkeshifuranotoyakoyakumootoineppushikaoishiraoinemuronayorohaboroashorobihororishirifujiutashinaihokutotakasuebetsuurausuassabukikonaishimamakinaiedatetoyabieinikiesanuryuoumuteshikagarikubetsuashibetsukimobetsuaibetsutobetsusobetsuembetsushimizuchippubetsurishirihokuryuhoronobeshintokutsubetsushibetsuhonbetsumombetsutsukigatakuriyamakoshimizushiriuchikutchanmurorannoboribetsukamishihorowassamushinshinotsukembuchiwakkanaikamoenaikiyosatotakinoueshikabesunagawafukagawanakagawatakikawakamikawahigashikagurahamatonbetsumatsumaemoseushirankoshishakotanimakanemashikeotofuketomakomaisandatambaitamiawajikasaiasagoshisoonoakoyashirotoyookaminamiawajiinagawafukusakitakasagokamigorikasugaharimayokawaashiyahimejiakashitaishiaogakisannantakinosumototakarazukanishinomiyashingugoshikinishiwakiyokatakaaioimikisayoyabukawanishiamagasakisasayamashinonsenkakogawaichikawakamikawatatsunotsukubaiwamaogawaasahisakaitokaioaraiitakobandodaigosuifuinaamikasumigaurakashimaomitamayachiyoshimodatetomobetoridehitachinakainashikisakuragawakasamayawaramoriyahitachiomiyanamegatayamagatahitachikamisuushikutakahagiibarakitonekoganakasowayukimihojosomitoryugasakishimotsumafujishirotsuchiurachikuseihitachiotashirosatotamatsukuriuchiharashikahakuinanaotsubatawajimakahokukawakitatsurugikaganominotosuzuuchinadakomatsuanamizunakanotohakusannonoichikanazawaiwateshiwafudaikawaimoriokaofunatohanamakikuzumakikitakamininohekunoheyamadayahabasumitaichinosekitanohatahiraizumirikuzentakatajobojiotsuchihironomiyakoiwaizumikarumaiichinohenodakujitonooshushizukuishifujisawamizusawakamaishikanegasakimannoutazukotohiraayagawazentsujihigashikagawauchinomikanonjisanukimarugamemitoyotakamatsutadotsunaoshimatonoshoakuneamamiizumihiokiyusuikinkoisasookouyamanakatanekagoshimakanoyaisenkawanabeminamitanemakurazakitarumizunishinoomotematsumotosatsumasendaioimatsudaayaseebinamiurazushinakaiodawaraiseharasagamiharahakoneaikawakaiseiatsugitsukuihadanoyamatoyamakitazamaoisochigasakininomiyayokosukakamakuraminamiashigarafujisawasamukawakiyokawahiratsukayugawaraokawaumajikochitsunootoyoakiinonishitosayasudahidakamiharasakawaniyodogawahigashitsunokagamigeiseisusakiotsukinaharisukumomurototosakamiochitoyotosashimizumotoyamanankokunakamurakitagawayusuharaogunichoyoukiasoutoozugyokutoamakusamifunetakamoriyamagaminamataminamiogunikikuchisumotoyamatonagasumashikiaraokumamotokamiamakusanishiharayatsushiroayabeseikasakyoideineujinakagyokameokakyotangokyotanabekyotambaminamiyamashiroyamashinatanabeyawatawazukaminaminantanmiyazuhigashiyamafukuchiyamakitamukokamojoyokizumaizuruujitawaraoyamazakinagaokakyokumiyamakawagoeinabeshimameiwaasahitaikiudonoisetsukisosakikuwanamihamamiyamasuzukatamakimisuginabarikumanokomonominamiisewataraitobakiwatakikihotadomatsusakayokkaichikameyamaureshinoishinomakishichikashukuohirataiwaosakizaohigashimatsushimashikamaiwanumashibataogawaraonagawakawasakiseminemarumoriminamisanrikukakudamuratawakuyatomiyanatoriwataritagajomisatotomekamirifushiroishimatsushimayamamotoshiogamafurukawahyugaebinotsunosaitoayakushimanobeokakitauramiyazakitakazakigokaseshiibamimatashintomikunitomikitakatakobayashikawaminamitakaharukijotakanabemiyakonojonishimeranichinankitagawakadogawamorotsukakisofukushimaminamimakisakaeobuseikedaogawamiasaokayaasahiotakiotarichinoinaomichikumakomaganechikuhokukaruizawayasuokaooshikaikusakaminamiaikitogakushimatsukawakawakamitateshinatakamorikitaaikishiojirimiyadahakubaiizunaiijimaiiyamamiyotasuzakayasakatoguraookuwanagawaminowahirayayamagataminamiminowafujimiomachisakakitakaginaganonakanosakuhokomoronagisoshinanomachiwadauedaiidaharasuwatomiachiaokianankisosakunozawaonsenagematsutakayamashimosuwamatsumotoyamanouchinakagawamochizukiazuminotatsunoobamaomuraseihiunzenosetofutsuikichijiwanagasakiisahayahasamisaikaikawatanasasebohiradokuchinotsugototogitsutsushimashimabarashinkamigotomatsuurayamazoekashibaikomakawaitenrioyodosangokoryoudaojiikarugayamatokoriyamatenkawakatsuragikurotakikawakamimiyakemitsuetakatorikamikitayamayamatotakadahegurishinjokanmakisakuraitawaramotogoseoudanarasoniandokawanishishimoichihigashiyoshinokashiharashimokitayamanosegawayoshinomintsivorytopazsakuragehirnsumomoaseinetopalmail-boxmokurenyoitamuikaojiyagosensanjoaganomyokoseiroagaomishibataniigatanagaokamurakamiuonumayuzawakariwatagamitainaitsunanminamiuonumatochioyahikojoetsuseiroukamosadoizumozakitokamachiitoigawasekikawakashiwazakitsubamemitsukekokonoesaikiusukibeppuusahimeshimakunisakihasamataketatsukumihitaoitahijikusuyufukujukamitsuebungoonobungotakadaibaraniimibizentsuyamaokayamakasaokahayashimayakagemaniwaakaiwamisakishinjotamanotakahashikibichuowakesojanagishookumenannishiawakurakurashikiasakuchisetouchikagaminosatoshotomigusukunakagusukuyaeseizenaurumaiheyaaguniogiminanjokinminamidaitokitanakagusukuyonaguniokinawaishigakikunigamiurasoekadenataramahiraraginozataketomishimojizamamitonakiitomanhigashimotobuyonabarugushikamionnanahanagohaebarukumejimakitadaitonakijinnishiharayomitanginowantokashikiishikawaikedasuitaminohizuminishisakaikananabenodaitoosakasayamayaokishiwadatadaokakaizukatondabayashichihayaakasakakumatorikadomasayamahigashiosakashijonawatehirakatataishimisakitajirihannansennankatanotoyonominatosettsuhigashiyodogawaibarakinosekitachuohigashisumiyoshifujiiderakashiwaraizumiotsutoyonakamatsubaramoriguchiizumisanoshimamototakatsukineyagawahabikinotakaishikawachinaganoyoshinogarikamiminearitaouchiimarihizenogikashimaariakekiyamafukudomikitagatakitahataomachigenkaikanzakinishiaritakyuragisagataratosutakushiroishikaratsuhamatamakouhokukawagoeyoshidasatteogoseirumaasakaurawaogawaniizaomiyayoriiotakishikihonjooganohannohanyuinasaitamaokegawaarakawayoshikawayokozehasudasayamahidakafukayachichibuiwatsukiryokamiyoshimikamiizumifujimiwarabiranzanmiyoshiminanoyashiosakadosugitomisatohigashichichibutodasokakukiyonokazoshiraokakasukabekounosukawajimatsurugashimamiyashirokitamotohatoyamamoroyamahatogayakumagayakawaguchinagatorokamisatomatsubushinamegawatokigawakamikawafujiminohigashimatsuyamakoshigayatokorozawas3isk01isk02ryuohkoseikonanaishorittotakashimamaibarahikonetorahimenishiazaikokagamokotoyasuotsukusatsunagahamamoriyamatoyosatotakatsukinotogawaomihachimanhigashiomiakagiunnanizumogotsuamayatsukakakinokimatsuehamadamasudahikawahikimiokuizumoyasugiyakumomisatotamayuohdahigashiizumookinoshimanishinoshimatsuwanoshimaneshimadafujiedayoshidashimodagotembaiwataatamikosaiyaizuitoizumishimahaibaramakinoharaomaezakikawanehonkannamisusonohigashiizufukuroinumazukawazufujiaraishizuokahamamatsushimizuizunokunimatsuzakimorimachiminamiizunishiizukikugawakakegawafujikawafujinomiyaujiietsugaoyamayaitaohiranikkoashikagakuroisokanumasakurashioyakarasuyamamotegiichikaikaminokawatochigihagamokanogisanobatonasumibunasushiobaranishikatautsunomiyaiwafunemashikoshimotsukeohtawaratakanezawaitanokomatsushimatokushimaichibaminamiaizumiwajikikainanmiyoshinarutomimamugiananmatsushigesanagochishishikuinakagawamachidachiyodakomaefussainagitaitochofufuchuomeotahigashiyamatotoshimaokutamaaogashimakodairaedogawaarakawahachiojishinagawatachikawashibuyasuginamihinodekiyosesumidaoshimanerimamitakahamuraadachinakanomizuhobunkyomegurominatokoganeihigashikurumekokubunjihigashimurayamamusashimurayamatamakitahinochuokotokatsushikakouzushimaogasawaraakishimakunitachishinjukusetagayamusashinohachijoitabashiakirunohinoharachizunanbukotouramisasawakasayonagokogehinoyazutottorinichinansakaiminatokawaharaoyabetairainamiasahinantoimizufuchutakaokakurobeyamadajohanatoyamatonaminyuzenfunahashinakaniikawanamerikawaunazukitogahimiuozufukumitsutateyamakamiichiiwadearidayuasainamitaijikatsuragiaridagawatanabemihamahidakakainankiminomisatoshingushirahamakamitondayurakozakoyagobokitayamawakayamakudoyamahashimotokushimotokozagawahirogawakinokawanachikatsuurarsuseroeoishidasagaeoguniasahinagaitendonanyoobanazawanishikawasakataohkuratozawamikawamamurogawayamagatafunagatatakahatashonaishinjokahokuiideyuzakawanishitsuruokakaminoyamayamanobeshiratakamurayamanakayamakaneyamahigashineyonezawasakegawamitouubeyuuabushimonosekitabuseoshimatoyotaiwakunihikarishunannagatohagihofukudamatsutokuyamashowadoshitsurunanbukoshukaiminami-alpsnirasakikosugeotsukioshinohokutominobuyamanashifuefukichuokofuichikawamisatoyamanakakonakamichitabayamanishikatsuranarusawafujikawahayakawafujiyoshidafujikawaguchikouenohara\u9577\u91CE\u4EAC\u90FD\u5C90\u961C\u5927\u962A\u4E09\u91CD\u7FA4\u99AC\u5343\u8449\u6ECB\u8CC0\u4F50\u8CC0\u5948\u826Fadednelgaccogogror\u79CB\u7530\u611B\u77E5\u9AD8\u77E5\u57FC\u7389\u6C96\u7E04\u6803\u6728\u718A\u672C\u5CA9\u624B\u9752\u68EE\u5C71\u68A8\u65B0\u6F5F\u5CF6\u6839\u9CE5\u53D6\u9577\u5D0E\u9999\u5DDD\u5BAE\u57CE\u77F3\u5DDD\u5927\u5206\u5BAE\u5D0E\u8328\u57CE\u5C71\u53E3\u5175\u5EAB\u5C71\u5F62\u5FB3\u5CF6\u5E83\u5CF6\u798F\u5CF6\u798F\u5CA1\u5CA1\u5C71\u5BCC\u5C71\u9759\u5CA1\u611B\u5A9B\u798F\u4E95\u6771\u4EACxn--4it168dhatenadiaryxn--vgu402ckawaiishophatenablogcocottenamaste\u5317\u6D77\u9053penneehimeiwateversestabachibashigagonnagunmapermahaccaakitaosakauh-ohblushkochiaichifukuikuroncapooitigohyogotokyokyotopunyuthickcheap0t00g00j0mie2-ddaapyawjg0amfemsubxiiboomoobutchueekpgwrgrherskrboyrdyupperunderflierchipsmydnsheavyangryhippygirlyrulez\u795E\u5948\u5DDD\u9E7F\u5150\u5CF6\u548C\u6B4C\u5C71bambinaxn--nit225kokayamasaitamaxn--k7yn95exn--1lqs03nsapporoparasitelolipopmcxn--efvn9sniigatafukuokatokushimafukushimahiroshimakagoshimafakefurokinawaxn--8pvr4ucoolblogxn--0trq7p7nnkawasakinagasakimiyazakichilloutxn--8ltr62kxn--klty5xpeeweezombiecutegirlxn--rny31hxn--uuwu58axn--ntso0iqx3axn--djrs72d6uytoyamanikitanyantakagawamimozanagoyaboyfriendxn--2m4a15egreaterchowderegoismyamagatafashionstorexn--elqq16hxn--pssu33lsendaimiyagixn--rht27zpecoriaomorisaloonwatsonvivianxn--djty4knobushipigboatnaganopinokoxn--f6qx53asadistvelvetsecretxn--5js045dchicappayamanashiibarakidigickgirlfriendxn--1lqs71dmongolianxn--c3s14mxn--qqqt11mtochigixn--5rtq34kparallelo0o0mondkobesagabonadecaoitanarafoolkilldecimainhiholomosblokilociaoundopupugifutankcrapflopnooroopsmodsholyjeezstripperpepperbittershizuokaxn--rht3dkitakyushureadymadeicurusversusmatrixxn--rht61ehungryfloppygloomycrankyhandcraftedlittlestarxn--klt787dxn--kltx9awhitesnowsunnydaytottorilovepoptheshopbuyshopxn--5rtp49cxn--d5qv7z876cwebaccelxn--kbrq7oxn--4pvxsxn--1ctwolovesickkumamotocatfoodxn--tor131oyokohamawakayamatonkotsuxn--ehqz56nxn--uist22hxn--6btw5axn--kltp7dyamaguchifrenchkisspussycatxn--4it797kxn--uisz3gbabybluexn--zbx025dnetgamersxn--7t0a264ckanagawaxn--6orx2rishikawaxn--ntsq17ghalfmoonschoolbusjellybeanxn--mkru45iusercontentlolitapunkxn--32vp30hsakurastoragehokkaidoshimanecandypopbabymilksupersaleweblikeraindropbackdropwebsozaikikirarahateblodaynightmeneacsccogoormobiinfoaeusxxorgmilcomnetedugovorgcomnetedugovbizinfotmprdorgmilcomnomedugovassnotairespresseassocoopgouvveterinairemedecinpharmaciensorgnetedugovtraorgcomedurepgovmeneperekgacscaiiocogoitoresmshsseoulbusanulsandaeguc01milvkimmvchungnamjeonnamjeonbukeliv-dnsgyeonggijejueliv-cdnincheondaejeongangwongyeongbukgwangjuchungbukgyeongnameliv-apicoeduindorgcomembnetedugovorgmilcomnetedugovjcloudorgcomnetintedugovperbnrinfocooyorgcomnetedugovethipfscanvamypepethw3sstorachakeeneticjoinmcinbrowserdwebcyonnftstoragemyfritzaemewphlxachotelltdorgcomwebsocschngonetintedugrpgovassnomgacsccoorgnetedugovbizinfo123websiteidorgmilcomasnnetedugovconfidmedorgcomplcschnetedugovaccoorgnetgovpresstmassoirseproxaccosoundcasthoptocraftvp4c66orgnetedugovitsxwxmcdirmyboxbarsyedgestacksynologylogintoopencloudnohostwebhopdiskstationi234tcp4hoocgroknoipprivmydsddnsdnsforlohmustransipdscloudfilegear-sgbrasiliafilegearframerbarsybarsyonlinecoprdorgmilcomnomedugovinforgcomnetedugovnameacprorgcomartnetedugovpresseinfoassoinstgouvorgnycedugovbarsydscloudjuorgcomnetedugovminisiteaccoororgcomnetgovorgmilcompronetintedugovbizmuseumnameinfoaerocoopaccoorgcomnetintedugovbizcooporgcomgobneteduorgmilcomnetedugovbiznameaccoorgmilneteduadvgovcoorgcomnetaltgovforgotherhiskeeneticispmanagernomassoprod5476132eastasiacentraluswesteuropewestus2eastus2pnortheurope-01newzealandnorth-01southindia-01southcentralus2-01norwaywest-01eastus2-01westus2-01australiaeast-01italynorth-01israelnorthwest-01swedencentral-01westeurope-01centraluseuap-01taiwannorthwest-01uaecentral-01northcentralusstage-01israelcentral-01mexicocentral-01canadacentral-01austriaeast-01germanywestcentral-01francecentral-01ukwest-01denmarkeast-01polandcentral-01eastus-01westus-01swedensouth-01eastus3-01westus3-01brazilsouth-01centralus-01francesouth-01australiacentral-01westindia-01uaenorth-01jioindiacentral-01canadaeast-01belgiumcentral-01spaincentral-01koreacentral-01chilecentral-01qatarcentral-01westcentralus-01eastus2euap-01norwayeast-01southafricanorth-01brazilsoutheast-01germanynorth-01switzerlandnorth-01switzerlandwest-01japanwest-01southafricawest-01japaneast-01eastasia-01indiasouthcentral-01taiwannorth-01centralindia-01uksouth-01southcentralus-01northcentralus-01eastasiastage-01indonesiacentral-01australiacentral2-01australiasoutheast-01malaysiawest-01koreasouth-01southeastasia-01southeastus5-01northeastus5-01jioindiawest-01rucdnwest1-usfra1-desandboxjls-sto1jls-sto3jls-sto2aglobalabglobalsslmapprodfreetlsmapvpslon-1lon-2ny-1fr-1sg-1ny-2paassnwebpaashostingjelasticnordeste-idcsocuserpagescwebfileblobservicebuscoreatlricnjsjelasticwebsitestoragesezagbinruhuukjptsmyspreadshopmynetnameakamaiorigin-stagingfrom-coipv64dynv6cdn77serveblogadobeaemcloudhicamsprytdnsupno-ipownipde5ovhicpfirewall-gatewaysytesmypsxbarsyusgovcloudapimyamazemyradwebakamaihdsaveincloudfastlylbfrom-lasubsc-paysquare7in-the-bandblackbaudcdnhomelinuxoninfernoctfcloudservebbsdns-dynamiccloudfrontakamai-stagingipifonyham-radio-opsenseeringclickrisingcommunity-profrom-nylocalcertgrafana-devedgesuite-stagingcloudflareanycasteating-organicatlassian-devmydattofeste-iplocaltotorprojectknx-serveredgekeycloudflareglobalcloudyclustercasacamserveftpakamaized-stagingakamaiorigindns-cloudmyeffectboomlabotdashbuyshousestwmailhetemlazure-mobilein-dslthruhereredirectmedynuddnsbouncemesupabaseluyanicloudappakamaicloudfunctionsdebiannhlfanpgafanstatic-accessin-vpnmysynologymafeloappudohomeftptrafficmanagersiteleafseidatmemsetcloudflarecloudaccesskeyword-onazure-apiis-a-chefdoes-itgets-itwebhopselfiphomeipkicks-assedgesuitewindowsserver-ontunnelmolemydissentscrapper-sitecloudflarecnuni5srcfggffiobbzabchrsndenodynuopikddnsvpndnsakadnselastxkinghostvps-hostfastlyhomeunixazureedgeshopselectdontexistmyfritzcloudjiffyalwaysdatasells-itsquaresbroke-itazurefddattolocalat-band-campmeinforumfamilydsazurestaticappsdefinimabplaceddnsaliasdynaliasnow-dnsblogdnsroutingthecloudendofinternetdsmynasakamaiedgemymediapcadobeio-staticakamaiedge-stagingakamaihd-stagingddns-ipprivatizehealthinsurancelive-onkrellianschokokeksmassivegridmysecuritycamerarackmazeserveminecraftfrom-azis-a-geekakamaizedmoonscaleoffice-on-theusgovtrafficmanageradobeioruntimeedgekey-stagingreserve-onlinechannelsdvrdnsdojousgovcloudappcdn77-sslapps-1and1podzoneazurewebsitesdynathomescaleforceyandexcloudvusercontentisa-geekcdn-edgescoaemalcesappwriteazimuthtlonarvobuiltwithrocketnoticeablestorecomwebrecnetperotherfirminfoartslgdloncogoiltdorgmilcolcomplcschgenngonetedugovbiznamefirmmobiacincoorgmilcomnomwebgobnetintedubizinfocomyspreadshopdemongovtransurl123websitehosting-clusterkhplaycistrongsnesosvalerv\xE5lerxn--vler-qoaossandeheroysandeher\xF8yb\xF8boheroyher\xF8yxn--hery-iraxn--b-5gavalerb\xF8boxn--b-5gasandesandexn--hery-iraxn--vler-qoav\xE5lerh\xE5re\xE5laahavaofsfvfhlolnlalrlhmfmtmahcostntbu\xE5strmreigersundmyspreadshopg\xE1ls\xE1eidsvolltingvollgildeskalflor\xF8vads\xF8vard\xF8vanylvenxn--bhccavuotna-k7astrandaxn--kvnangen-k0axn--sknland-fxaxn--mosjen-eyarakkestadhyllestadnannestadvevelstadvaapstenordre-landsondre-lands\xF8ndre-landtjieltexn--vrggt-xqads\xF8r-aurdalsor-aurdalheradstordmoldefordef\xF8rdeseljefedjeryggehemnexn--krehamn-dxasognegranes\xF8gnebrynetjomevallebykletokkegiskedovretj\xF8mehob\xF8lvoldasaudatolgas\xF8mnaviknad\xF8nnasomnadonnatranafrananesnaraumasmolatr\xE6nafr\xE6nalesjasm\xF8la\xF8rstaorstahitrafloraaukraloppafr\xF8yarissasnasahalsagalsaromsaraisar\xE1isafroyasn\xE5sagronghobolfjelltydal\xE5rdalardalaskimharamkraanghkekr\xE5anghkesorumbarumhurumb\xE6rums\xF8rummodums\xE1l\xE1tb\xE1l\xE1tfrognbjugnv\xE5ganvagangulenskienl\xF8tenlotenstrynvefsnxn--merker-kuaskaunsveiob\xF8mlobomloskj\xE5kvardoflorovadsosalatbalats\xE1latkl\xE6buklabuselbubarduulvikskjakkleppris\xF8rxn--nttery-byaefl\xE5eidflahofmilgolholsellomskifetvikdepvgsfhsaskerrisorhamarasnes\xE5snesr\xF8rosrorosxn--slat-5namasoynaroyvaroyluroydyroyaskoyradoyandoyrodoymeloyrad\xF8yand\xF8yr\xF8d\xF8ymel\xF8yask\xF8ylur\xF8ydyr\xF8ym\xE5s\xF8yv\xE6r\xF8yn\xE6r\xF8yhoylandeth\xF8ylandetdivtasvuodnal\xF8renskoglorenskognesoddtangenxn--tjme-hraxn--smla-hraxn--stjrdal-s1aunjargalillehammerunj\xE1rgaxn--hamary-fyadavvenjargaxn--bearalvhki-y4a123hjemmesidegjerdrumxn--brnnysund-m8acxn--tnsberg-q1axn--mlatvuopmi-s4axn--snsa-roaxn--skierv-utaxn--brum-voatysfjordkvafjordeidfjordkv\xE6fjordsongdalenmjondalenmj\xF8ndalenxn--gls-elackragerog\xE1\u014Bgaviikagangaviikas\xF8rreisasorreisas\xF8r-varangersor-varangerxn--risr-iraskiervaxn--frna-woaxn--trna-woakvinesdalleksvikleirvikr\xF8yrvikroyrviksvelvikvenneslaevje-og-hornnessandnessj\xF8enmarnardalvindafjordsandefjordenebakksnillfjordullensvangxn--trany-yuabr\xF8nn\xF8ysundnamsskoganaustevollxn--stjrdalshalsen-sqbnord-aurdalnord-frontr\xF8gstadtrogstadgrimstadflakstadgjerstadxn--sandy-yuaxn--leagaviika-52bnore-og-uvdalvegarsheixn--rlingen-mxaxn--ggaviika-8ya47hveg\xE5rsheikarlsoykvitsoymasfjordenhamaroyinderoyosteroydavvenj\xE1rgasauheradguovdageaidnuxn--vre-eiker-k8abronnoysiellakkr\xF8dsheradkrodsheradkvinnheradbr\xF8nn\xF8yxn--mtta-vrjjat-k7afxn--lrenskog-54akvits\xF8yv\xE1rgg\xE1tkarls\xF8yoster\xF8yinder\xF8yhamar\xF8ybronnoysundxn--aurskog-hland-jnbbahccavuotnab\xE1hccavuotnagiehtavuoatnastor-elvdalmidtre-gauldalxn--gildeskl-g0akarasjokevenassixn--bievt-0qaxn--yer-znalebesbynessebyxn--hbmer-xqamalselvm\xE5lselvxn--unjrga-rtam\xF8re-og-romsdalmore-og-romsdalhareidmeland\xF8rlandorlandstrand\xE5lg\xE5rdsolundalgardafjord\xE5fjorddielddanuorrikautokeinoxn--stre-toten-zcbskodjeaejriestangeliernebamblestokkefauskesn\xE5asesnaasekongsvingerlangevagberlevagxn--flor-jrahattfjelldalostre-toten\xF8stre-totenvestfoldxn--mely-ira\xE1laheadjualaheadjunordreisaxn--troms-zuaxn--lgrd-poacporsangerflatangerstavangerleikangerbremangersamnangergieldakarasjohkaxn--rdy-0nabfrostautsirasnoasatromsaxn--sr-aurdal-l8aflekkefjordj\xF8lsterjolsteraremarkhedmarkn\xE5\xE5mesjevuemienaamesjevuemiexn--vard-jrarollagmer\xE5kermerakerorskog\xF8rskogxn--bdddj-mrabd\xE1k\u014Boluoktaxn--osyro-wuaaknoluoktatrysilskjerv\xF8ymandaljondalbindalrindalmeldalsuldalorkdalsigdalalvdall\xE6rdalhurdalsirdalverdallerdallardaloppdal\xE5seralaseralhadselkrager\xF8divttasvuotnaoverhallasteinkjerxn--hnefoss-q1askedsmokorsettroms\xF8xn--dyry-iravestre-totenmuseumxn--sandnessjen-ogbrahkkeravjufylkesbiblb\xE1jddarbajddarxn--laheadju-7yarennes\xF8yxn--koluokta-7ya57hxn--hgebostad-g3aleirfjordstorfjordbalsfjordb\xE5tsfjordbatsfjordmuos\xE1tbiev\xE1tloab\xE1tk\xE1r\xE1\u0161johkan\xF8tter\xF8yxn--mjndalen-64anordkappl\xE1hppilahppialstahaugsiljanverranr\xF8ykenroykenhaldenlyngenbergenhortenh\xF8nefosshonefosstroandinbeiarnvarggatosoyroos\xF8yrotromsoidrettmuosatbievatruovatloabatvoagattynsetnessetxn--indery-fyask\xE1nitskanitraholtr\xE5holtxn--ystre-slidre-ujbandebusarpsborgbearduxn--karlsy-fyahordalandjorpelandj\xF8rpelanddeatnuringsakers\xF8r-odalsor-odalxn--slt-elabringerikeaudnedalnittedalnissedalhemsedalslattumsurnadalxn--blt-elabelverumstj\xF8rdalnaustdalhjartdalgj\xF8vikfyresdalhasviknarviklarvikgjovikmalvikgamviklenvikporsgrunnstjordalengerdaldrobakdr\xF8bakxn--msy-ula0hvestvagoyxn--vgan-qoaxn--ryken-vuaxn--lten-graxn--stfold-9xaxn--hpmir-xqaxn--lury-iram\xE1latvuopmimalatvuopmitysv\xE6rkirkenesbirkenesmoskenesb\xE1id\xE1rxn--fjord-lraxn--rdal-poabahcavuotnab\xE1hcavuotnaxn--frde-gralind\xE5sbearalvahkixn--hobl-irar\xE1hkker\xE1vjuxn--loabt-0qav\xE5g\xE5\xE1lt\xE1bod\xF8sundlundrader\xE5deetnetimeholeauregrueoddavagavegaranatanaarnasolasulaaltalekafusavangbergkvam\xE5mliamlibokntinnroangranosenoslobodor\xF8stroststat\xE5motamotivgupriv\xF8yeroyerliermossvossxn--nvuotna-hwalusterlunnermarkerh\xE1bmerhabmerhvalerfjalerxn--rholt-mratysvarbaidarfitjargaularh\xE1pmirhapmirmelhusfosnes\xF8ksnesoksnestysneshemnesevenesflesbergeidsbergtonsbergt\xF8nsberglindasxn--sndre-land-0cbnamsosxn--srum-gra\xF8ystre-slidreoystre-slidrevestre-slidretrondheimbalestrandxn--langevg-jxaaustrheimxn--skjk-soavagsoyaveroysandoykarmoyfinnoytranoyvestbytranbysykkylvenxn--hyanger-q1aspjelkavikandasuoloxn--fl-ziaxn--drbak-wuastathellexn--sr-varanger-ggbtelemarkxn--bhcavuotna-s4axn--porsgu-sta26f\u010D\xE1hcesuolocahcesuoloakrehamn\xE5krehamnsand\xF8ykarm\xF8yfinn\xF8ytran\xF8yv\xE5gs\xF8yaver\xF8ynamdalseidxn--lesund-huabadaddjaxn--vegrshei-c0axn--btsfjord-9zagildesk\xE5lporsanguxn--trgstad-r1an\xE1vuotnanavuotnahammerfestxn--sgne-graxn--brnny-wuacibestadharstadnarviikaeven\xE1\u0161\u0161ivestnesgjemnessandnesagdenesrennesoyxn--avery-yuaxn--tysvr-vrabearalv\xE1hkikongsbergspydebergrandabergxn--andy-iradavvesiidaxn--krdsherad-m8apors\xE1\u014Bgufredrikstadbjerkreimringeburennebuaurskog-holandnotteroyxn--vgsy-qoa0jxn--rmskog-byaskierv\xE1ivelandbyglandfrolandaurlandforsandxn--bjddar-ptamidsund\xE5lesundalesundfetsundfarsundovre-eiker\xF8vre-eikerakershusxn--moreke-juas\xF8rfold\xF8stfoldostfoldsorfoldh\xF8yangerhoyangerlevangerorkangertanangerxn--vestvgy-ixa6olillesandulsteinxn--rennesy-v1agranvinskjervoyxn--klbu-woalavagisxn--h-2faxn--ryrvik-byakafjordk\xE5fjordseljordfolkebiblxn--gjvik-wuajevnakerxn--kfjord-iuabudejjuxn--kranghke-b0axn--davvenjrga-y4axn--rland-uuaxn--ldingen-q1axn--mlselv-iuaxn--rady-iraxn--linds-prabrumunddalxn--ygarden-p1amo-i-ranaeidskogr\xF8mskogromskoghjelmelandxn--finny-yuaxn--sr-odal-q1axn--skjervy-v1aballangenkvanangenkv\xE6nangengratangenxn--hmmrfeasta-s4acvossevangensuohkanxn--rde-ulaxn--mli-tlaxn--ksnes-uuanordlandskanlandsk\xE5nlandsortlandfuoiskuxn--rros-graxn--hcesuolo-7ya35bxn--eveni-0qa01gagaivuotnag\xE1ivuotnaxn--seral-lradrammenmodalenmosjoenjan-mayentorskensteigengloppenxn--snes-poamatta-varjjatxn--sr-fron-q1aomasvuotnajessheimb\xE5d\xE5ddj\xE5xn--krager-gyaxn--kvfjord-nxaxn--asky-iraxn--snase-nraxn--bidr-5nacholt\xE5lenxn--vads-jraxn--jlster-byamosj\xF8enxn--rst-0nastavernxn--ostery-fyaxn--oppegrd-ixaxn--sknit-yqaxn--risa-5naoppeg\xE5rdskiptvetrendalenholtalenxn--mot-tlaxn--lhppi-xqaxn--holtlen-hxaxn--srreisa-q1akopervikxn--muost-0qaxn--bmlo-grahokksundkvalsundegersundxn--karmy-yuaullensakerxn--hylandet-54axn--kvitsy-fyaxn--bod-2nalangev\xE5gberlev\xE5gkristiansandxn--rsta-frahornindalstj\xF8rdalshalsenstjordalshalsensandnessjoenh\xE1mm\xE1rfeastaxn--lrdal-sras\xF8r-fronsor-fronnord-odalkristiansundm\xE1tta-v\xE1rjjatvestv\xE5g\xF8ynesoddennotoddenbuskerud\xF8ygardenoygardensalangenlavangenralingenr\xE6lingenlodingenl\xF8dingenlea\u014Bgaviikalaakesvuemieleangaviikauenorgexn--srfold-byaaskvollxn--rskog-uuaxn--nry-yla5gxn--vry-yla5ghammarfeastaxn--rhkkervju-01afxn--givuotna-8yakommunekrokstadelvanedre-eikerhagebostadh\xE6gebostadxn--berlevg-jxakviteseidxn--s-1faxn--l-1faxn--nmesjevuemie-tcbafuosskomo\xE5rekemoarekexn--lt-liacxn--jrpeland-54asvalbardoppegardholmestrandtvedestrandsogndalsokndalarendalsunndalfolldalxn--krjohka-hwab49jlyngdaletnedalnorddalsaltdalgausdalskedsmovaksdalgjesdalstordalxn--frya-hraaarbortedrangedalxn--smna-graaurskog-h\xF8landxn--vg-yiabtjeldsundhaugesundlindesnesxn--mre-og-romsdal-qqbxn--dnna-gradyntmpheremerseineshacknetenterprisecloudmineaccomaorim\u0101oriorgmilcriiwigennetschoolhealthkiwigovtgeekxn--mori-qsacloudnsparliamentcomedorgcompronetedugovmuseumwebsitekinservicebarsywebsitebuildereerobookheimdnsleapcelleero-stagetechcrscsslorigingohomecdbedeeeiemesecabgngilnlalplchfisiincnnoroptatitmtltruauhulumkdkukskjplvtrgrfrkrhrusesismycynzcznetinteduassoososcloudstgbetaaezaeuhkusjswzhatenadiarycdn77hoptozaptois-a-knightmyftpno-ipjpnddnssdpdnsspdnsbarsysweetpepperis-a-bruinsfanis-very-sweetservegameis-a-soxfanhomelinuxcdn77-secureservebbsmisconfusedwebredirectblogsitefreedesktopcouchpotatofriestoolforgeaccesscamis-lostreadmyblogsmall-webfedorapeopleserveftpis-a-celticsfanmywirepotagertwmailin-dslsellsyourhomeread-booksfreeddnscable-modemis-savednflfanufcfanmlbfanstuff-4-saleendoftheinternetin-vpnmy-firewallhomeftpis-localis-a-chefboldlygoingnowherewebhopselfipkicks-assroxatunkcamdvrfedoraprojectgotdnsdvrdnsdyndnspubtlspimientahomeunixdontexistfedorainfracloudwmflabsfspagesbmoattachmentsteckidsfamilydsdnsaliasdynaliasnow-dnscloudnsdoomdnsduckdnsblogdnshomednsroutingthecloudendofinternetdsmynasip-dynamicpoivronhttpbinmyfirewallis-very-evilmysecuritycamerais-a-linux-userwmcloudis-a-geektuxfamilyis-a-candidatedoesntexistis-very-badhobby-sitegame-hostaltervistais-foundis-a-patsfandnsdojohepforgepodzonedynservcollegefanis-very-goodfrom-meis-very-niceisa-geeknerdpolacmedsldingorgcomnomgobabonetedugintapleskaemhlxmyboxrockyprvcydeuxfleurssolidresvibekitprodomgspdnscodebergheyflowstatichostlinkyhostmymagicorgmilcomnomgobneteduorgcomeduiorgmilcomngonetedugovcloudns1337ngrokacorggogfamcomwebgobnetedugokgopgkpgovgosbizpasaugumicsopozpapuwmwsrprusiskwpspkppspkmpspokeoiawsawifoumsdnskokwpmuppuppsppiwwiwoowuzswkzoschrzpisdnwzmiuwwitdpssewsseumigugimoirmpinbwinbwiihupporzgwgriwupowwskrwioswuozstarostwokonsulattmpccopruszkowmyspreadshopostrodakartuzyopolegminamediaustkazgorajgoraolawailawalomzawloclradombytomjaworznotargilubinkoninzagantorunkutnokepnonakloczestsopotsanokturekplockslasksklepzarowlukowmedaidgdaorgmilrelcomnomatmgsmartneteduelkgovwawsossexbiztgorysejnytychypomorzeboleslawiechomesklepsdscloudunicloudzakopanelegnicarawa-mazbydgoszczswidnikkrasnikwloclawekbielawamragowograjeworealestatebeskidykaszubymalopolskaprzeworskswiebodzinlecznadfirmaszkolawarmiagdyniamiastakazimierz-dolnymalborkswidnicadlugolekaostrolekapodlasieelblagtravelsimplesitezachpomormielecszczecinnieruchomosciwalbrzychlezajsklublinbedzinpoznanwielunmielnooleckostarachowicedkontopowiatwroclawrybniksuwalkileborkslupskgdanskostrowwlkptarnobrzegtourismwegrowkrakowglogowyou2pilanysamailwrocinfoagroautobeepshoppriviqhslapypiszlodzcfolksecommerce-shopmazurypulawyskoczowrzeszowpomorskiezgierzkaliszolkuszlowiczostrowiecsosnowiecmazowszewodzislawbialowiezazgorzeleckatowicepabianicejelenia-gorawolominkarpaczsieradznowarudaczeladzkonskowolaskierniewiceswinoujscieturystykabieszczadycieszynketrzynolsztynbialystokbabia-goraprochowicewarszawastalowa-wolapolkowicegorlicegliwiceponiatowalimanowalubartowaugustowkobierzyceopocznognieznoszczytnokolobrzegshoparenapodhalebielskoklodzkostargardcoshipatwithplayitownnamecoorgnetedugovacorgcomproestnetedugovbiznameislaprofinfoprodrechtngrokmedaaaacacpaenglawjurbarenterbarsykeeneticavocatacctcloudnsorgcomsecplonetedugov123paginaweborgcomnetintedugovnomepublidkinbarsygovx443cloudnsorgmilcomnetedugovcooporgmilcomschnetedugovnamecomcannetlibassoaemclantmcontstoreorgcomnomrecwwwbarsyfirminfoshopartsv6stackitmyddnswebspacelima-cityacincooxorgedugovbarsybrendlyhbvpsvpsspectrumlandinghostingacppmordoviamcprecbgorgmilcomspbnetintedumsknovgovbirrasmcdirmytismircloudvladimirnalchikadygeyamarinepyatigorskmyjinobashkiriaeurodirvladikavkazna4ugroznykustanaikalmykiacldmaildagestaniransmbuildcloudcanvaliaravalrwxwixdevelopmentappwritemigrationneedleverceldatabasestackitcodereplravendbsanityonporterlovableaccoorgmilnetgovcoopmedorgcompubschnetedugovservicemecomygovorggovtvmedorgcomnetedugovinfoedgfacbmlonihkutwpsryxzbdtmacfhppmyspreadshopbrandpartiorgcomfhvpress123minsidaitcouldbeworlanbibkommunalforbundfhskiopsyskomvuxkomforbnaturbruksgymnloginlineorgcomnetedugovenscaledeuusentsurgebotdaorgmilcomnetgovnowteleporthashbangbearlyplatformlovablebarsyshopwarebasehoplixbarsyonlinemsf5gitpagewawamscofigma-govcaffeinefigmacanvaceerosoltstscwputernippybarsysupportchatgptsquareomniweopensocialcpanelplaycodenotionnovecorewpsquaredpreviewjelecyonbyensrhtklivfastvpspieboxconvexmedusajsjouwwebheyflowplatformshdocsflowyloginlinemadethissourcecraftclouderaorgorgcomartedugouvunivmeorgcomnetedugovsurveysstatichfheiyumanusxs4allprojectmyfastubervibehostapp-ionosdeployagentmecoorgcomschnetedugovbizcncostoreorgmilcomneteduembaixadaconsuladokiraranohoprincipesaotomeheliohobarsystorebaseshopwaresellfyaisanityabkhaziavologdamordoviapenzalenugsochinavoiexnetspbmsknovnorth-kazakhstanashgabadkareliaarmeniageorgiavladimirnalchikivanovobukharaadygeyakhakassiakalugakrasnodarjambylaktyubinsktroitskbryanskobninskkurganazerbaijanpokrovskbashkiriatselinogradvladikavkazmurmansktulatuvamangyshlaktashkentchimkentgroznykaragandatermezarkhangelskkustanaikalmykiabalashoveast-kazakhstankaracoldagestantogliattibarsyredorgcomgobedumirenaccoorgjelasticdiscoursecleverappsschacmiincogoornetonlineshopcogoorgmilcomwebnicnetintedugovbiznametestcoorgmilcomnomnetedugovorangecloudpersoindorgcomfinnatnetgovensmincomtourismintlinfox0611orgmilcomnetedugovquickconnectvpnplusnettprequalifymeaddrmyaddrntdllwadlnctvavdrk12orgmilpolbeltelcomwebgennetedutskkepgovbbsbiznameinfocoorgmilcompronetedugovbiznameinfobetter-thanworse-thansakurafromdyndnson-the-webmymailerorgmilurlcomneteduidvgovmydnsgameclubebizmeneacsccogotvorhotelmilmobiinfovodteiflgplkmsmsbcckhincndnvncoztltmkckppzpdprvcvkvlvcrkrkscxuzchernovtsyrivneyaltaodesavolynrovnolutskltdinforgcomnetedugovbizvinnicazhitomirternopilpoltavakropyvnytskyizaporizhzhiasevastopolsebastopoluzhgoroduzhhorodkharkovkharkivvinnytsiakhmelnytskyizaporizhzhecrimeaodessazhytomyrnikolaevcherkassydonetskluganskluhanskkirovogradivano-frankivskchernivtsikrymkievkyivlvivsumyzakarpattiamykolaivcherkasychernigovkhersonchernihivdnipropetrovskdnepropetrovskkhmelnitskiyneacsccogoorusorgmilcomedugovmyspreadshopadimono-ipbarsybarsyonlinelayershiftnh-servretrosnubapicampaignservicelugaffinitylotteryweeklylotteryraffleentrygluglugsmeaccoindependent-inquestnimsitecopropymntltdorgplcschnetgovnhsbarsyindependent-commissionindependent-reviewpolicepublic-inquiryindependent-panelconnhospindependent-inquiryroyal-commissionoraclegovcloudappscck12libaws-govccphxcclibpvtparochchtrcck12libcceatonk12coglibtecgendstmusann-arborwashtenawcck12glghcck12sealibforksolympiabainbridge-islkeyporthoquiamyarrow-pointcentraliaport-townsendsequimport-ludlowrentonsilverdalebremertonredmondsheltonbellevueport-orchardport-angeleskingstonchehalisaberdeengig-harborseattlepoulsboidmdndsddemenegacalamaiavawapailalflnmdcncscohnhmihiviwiriinmntnmocoutvtctmtgunjokakwvnvprarorasmskstxwynykyazisadninsnngosrvis-bymircloudservernamepointtoenscaledland-4-salefreeddnsstuff-4-saleazure-apinoipdatabricksappscloudnsgolffanheliohostazurewebsitesgvorgmilcomgubneteducoorgcomnetd0egvorgmilcomnetedugovmydnsiacostoree12orgmilcomnomwebgobbibrectecnetintedugovraremprendefirminfoartseducok12orgcomnethidnsadidacaionioapsonlahanamhanoicamauhueorgcompronetintedugovbizbacninhtayninhhoabinhnamdinhtravinhhaiphongvinhlonghaiduongquangnamquangtrithuathienhuequangninhbacgianghaugiangquangbinhsoctrangbentrethanhphohochiminhdanangkontumhatinhkhanhhoathanhhoahealthgialailaocaiyenbaibackanngheanlonganphuyenphuthocanthodaklakdongnainameinfovinhphucdongthapkiengiangtiengiangquangngailaichaulangsonlamdongdaknonghagiangangiangcaobangbinhduongninhthuanbinhthuanbaclieuthaibinhninhbinhbinhdinhtuyenquanghungyenbaria-vungtauthainguyendienbienbinhphuocschbizputerorgcomnetedugovcloud66advisormypetsdyndnsxn--8dbq2axn--4dbgdty6cxn--5dbhl8dxn--hebda8bxn--80auxn--d1atxn--c1avgxn--o1acxn--o1achxn--90azhxn--55qx5dxn--uc0atvxn--od0algxn--wcvs22dxn--gmqw5axn--mxtq1mxn--12c1fe0brxn--h3cuzk1dixn--12co0c3b4evaxn--12cfi8ixb8lxn--o3cyx2axn--m3ch0j3axn--j1adpxn--90amcxn--90a1afxn--h1ahnxn--j1ael8bxn--h1alizxn--c1avgxn--j1aefxn--80aaa0cvacxn--41acaffeineexeopentunnelbotdashtelebitorgtmaccoagricorgmilnomwebnicngonetaltedugovlawnisschoolgrondaraccoorgmilcomschnetedugovbizinfoprg1-zeropstritonstackitlimazeropsaccoorgmilgov\u044F\u0441\u043F\u0431\u043E\u0440\u0433\u043A\u043E\u043C\u043C\u0441\u043A\u0431\u0438\u0437\u043C\u0438\u0440\u0441\u0430\u043C\u0430\u0440\u0430\u043A\u0440\u044B\u043C\u0441\u043E\u0447\u0438\u0430\u043A\u043E\u0434\u043F\u0440\u043E\u0440\u0433\u043E\u0431\u0440\u0443\u043F\u0440\u05E6\u05D4\u05DC\u05DE\u05DE\u05E9\u05DC\u05D9\u05E9\u05D5\u05D1\u05D0\u05E7\u05D3\u05DE\u05D9\u05D4\u0E2D\u0E07\u0E04\u0E4C\u0E01\u0E23\u0E18\u0E38\u0E23\u0E01\u0E34\u0E08\u0E23\u0E31\u0E10\u0E1A\u0E32\u0E25\u0E28\u0E36\u0E01\u0E29\u0E32\u0E17\u0E2B\u0E32\u0E23\u0E40\u0E19\u0E47\u0E15\u6559\u80B2\u7DB2\u7D61\u7D44\u7E54\u516C\u53F8\u653F\u5E9C\u500B\u4EBA\uB2F7\uB137\uD55C\uAD6D\u6FB3\u95E8\u65B0\u95FB\u6FB3\u9580\u8054\u901A\u5BB6\u96FB\u5609\u91CC\u62DB\u8058\u901A\u8CA9\uB2F7\uCEF4\uC0BC\uC131\u30B3\u30E0\u10D2\u10D4\u0431\u0433\u0440\u0444\u0435\u044Eadcdbdgdidmdsdtdaebedeeegeiejekemenepereseveyegabacalamanauavapaqasazacfbfafgfnfpfwftfbgcgagggegkgngmgsgpgvgtgugilmlnlalclglplsltlhmimjmkmmmomambmcmdmfmgmzmpmsmtmgbbblbsbecccacnclcmcvctcscmhkhghchbhthphshlinikifigiaibicivisikninhnmncnbngnsnpnvntnjoionomobocoaofodorosotoptstttytatbtetgtithtmtltrusuvuaucueuguhulumunufjdjbjtjsjlkmkhkfkdkcktkukskpkgpmpnpkpjpgqaqmqiqsvtvcvbvmvlvrwpwtwzwbwcwawgwkwmwtrsrprgrfrercrbrarnrmrlrkrirhrwsusrssspsgsesbsaslsmsissxmxaxcxuypysylymykygybycyuztzsznzmzkzdzczbzaz\u03B5\u03BB\u03B5\u03C5\u4E16\u754C\u53F0\u7063\u8D2D\u7269\u516C\u76CA\u70B9\u770B\u81FA\u7063\u7F51\u7EDC\u66F8\u7C4D\u5728\u7EBF\u7F51\u7AD9\u624B\u673A\u673A\u6784\u5927\u62FF\u6E38\u620F\u4FE1\u606F\u53F0\u6E7E\u8C37\u6B4C\u6148\u5584\u5546\u6807\u9999\u6E2F\u4E2D\u56FD\u9910\u5385\u7F51\u5740\u4E2D\u570B\u5546\u57CE\u98DF\u54C1\u5FAE\u535A\u653F\u52A1\u79FB\u52A8\u96C6\u56E2\u516C\u53F8\u516B\u5366\u5546\u5E97\u5065\u5EB7\u7F51\u5E97\u653F\u5E9C\u65F6\u5C1A\u4F5B\u5C71\u4E2D\u4FE1\u5A31\u4E50\u5E7F\u4E1C\u4F01\u4E1Ahomedepotengineering\u0627\u0645\u0627\u0631\u0627\u062Arepublicankuokgroupversicherungchannelcitadelxn--pgbs0dhxn--b4w605ferdstatebankwebsitexn--mgb9awbf\u4E9A\u9A6C\u900A\u6DE1\u9A6C\u9521alibabaxn--ngbc5azdxn--mgbbh1axn--45br5cyltoshibabuildworldcloudtradeguideplacespacedancemoviephoneprimesmilebiblestyleappleazurestoreskypegripexn--l1accdrivelottehorsehouseleasechasereisestadahondaomegaaetnaamicaninjanokiamediadeltavodkaedekaosakapizzaslingemailgmailtirolshelltmallfinallegaltotalhotelamfamforumrehabmusicciticricohcoachwatchboschearthfaithirishmiamiarchidubaiguccipraxi\u307F\u3093\u306A\u30B9\u30C8\u30A2\u30BB\u30FC\u30EBcanonsalononionnikonepsonkoelngreensevencrownikanoradioaudioweiboglobopromogalloyahoociscorodeovideomangobingotokyovolvolottokyotophotosmartsportquesttrusthyattjetztadultcymrubaidutushuxn--kprw13dubankclickblackmerckgroupsharpcheapnowtvxn--h2brj9c\u05E7\u05D5\u05DD\u0570\u0561\u0575\u043E\u0440\u0433\u0441\u0440\u0431\u043C\u043E\u043D\u043A\u043E\u043C\u0431\u0435\u043B\u043C\u043A\u0434\u049B\u0430\u0437\u0440\u0443\u0441\u0443\u043A\u0440\u0645\u0635\u0631\u0642\u0637\u0631\u0639\u0631\u0628\u0643\u0648\u0645dadcfdmedwedredphdthdbidpidkrdmsdltdiceonewmeglemoerwecfageacbanbambaaaammakianraspacpaaxawtfbcgaegongingaigvigorgdogdhlmilrilonlaolloluoljllcalgalnflafltelsrlfrllplkimibmcamcombommomifmabbjcbscbwebcabnabtabmlbpubabcbbcnecincpncllcstcwtcpwcnyckfhbzhovhmoiskiobisbitcifyituipinvinwinxincbnbcnmanfangdnmenrenkpnmtnyunrunfununobiojioriohbogmofooboooooacoecoceongoproartistottnttbbtcateatlatvetpetbetnethktmitfitintjothotgotdotbotprueduicujnjyouinknhktdkappsapgapmapdnptopgopllpjmpzipvipripesqtrvdtvitvdevmovgovhivnrwlawsewnewbmwwownowhowdvrftrmtrsfrbarcartvscrseusawsupsubssbsadsddsldssasbmsmlsxxxboxfoxgmxtjxsextaxbuyflydiysoyjoyskypaydaygayxyzanzbizwebersenerpokerlameractortatarsolar\u0EA5\u0EB2\u0EA7\u0E04\u0E2D\u0E21\u0E44\u0E17\u0E22tourslocusnexuslexusgiftsbeatsboatspartspressglassswiss\u0915\u0949\u092E\u0928\u0947\u091Ftiresgivescodeshomesgamestunesshoescardswalesloansvegastoolsdealsautosparis\u30D5\u30A1\u30C3\u30B7\u30E7\u30F3workssucksrocksxeroxforexfedexpartylillymoneystudyrugbytoraytoday\u4E2D\u6587\u7F51xn--unup4y\u5929\u4E3B\u6559\u98DE\u5229\u6D66\u65B0\u52A0\u5761enterprises\u6211\u7231\u4F60\u5609\u91CC\u5927\u9152\u5E97christmasxn--fct429kholdingsxn--8y0a063axn--mgbx4cd0ablifestyleabogadoallstatenetbank\u0643\u0627\u062B\u0648\u0644\u064A\u0643xn--s9brj9cxn--gk3at1ebestbuycharityxn--55qx5dmicrosoftpropertybasketballhomegoodscorsicajewelrygallerygrocerysurgerycountrybrusselsverisignferreroxn--czr694bhdfcbankcommbanksoftbank\u067E\u0627\u0643\u0633\u062A\u0627\u0646\u067E\u0627\u06A9\u0633\u062A\u0627\u0646nextdirect\u0627\u0644\u0633\u0639\u0648\u062F\u064A\u0647\u0627\u0644\u0639\u0644\u064A\u0627\u0646xn--h2brj9c8cxn--80adxhksshikshaxn--mgbai9azgqp6jcuisinellabarclayscatholicxn--kpry57dcompanyxn--xhq521bblackfridayxn--mgba3a3ejtsandvikxn--d1acj3bacademydownload\u0645\u0644\u064A\u0633\u064A\u0627xn--j1amhxn--w4r85el8fhu5dnraipirangaathletaxn--fhbeixn--mgbqly7cvafrzuerichxn--c2br7g\u0B87\u0BB2\u0B99\u0BCD\u0B95\u0BC8contractorsxn--io0a7igraphicsinsurancetemasekxn--xkc2al3hye2amotorcyclesphotographydirectoryplumbingxn--vhquvclothingtrainingcleaningwilliamhilllightingxn--mgba3a4f16ashoppingcateringeducationokinawapicturesventuresproductionsxn--9et52uwalmart\u0D2D\u0D3E\u0D30\u0D24\u0D02supportrealestatecapitalonexn--nqv7fs00emaauspostfloristdentistxn--qxamgodaddybradescobargainsmitsubishikerryhotelsxn--9dbq2axn--3pxu8kimmobilienxn--fjq720axn--mgbtx2bholidaymckinseymadridbusinessbuildersxn--4gbrim\u043C\u043E\u0441\u043A\u0432\u0430\u0627\u0644\u0633\u0639\u0648\u062F\u06CC\u0629coffeedegreelacaixapartnersalsaceofficeabbvievoyageorangegeorgeonlinechromemobilekindlegoogleoraclecircleschulesecureinsurexn--mgba7c0bbn0aestatexn--mgbc0a9azcgcruisehangoutxn--vuq861bxn--42c2d9arexrothfirestoneuniversityxn--nnx388alifeinsuranceextraspace\u043E\u043D\u043B\u0430\u0439\u043Dverm\xF6gensberatersoftwarexn--fiqs8sxn--mgbab2bdxn--w4rs40ltienda\u092D\u093E\u0930\u0924\u092E\u094Dafricatoyotaotsukasakuracameracreditcardnagoyaconsultingnetworktheatermonsterprogressivepioneerxn--55qw42gracingdatingvotingvikinglivinggivingxn--bck1b9a5dre4cbrotherweatherjoburg\u0641\u0644\u0633\u0637\u064A\u0646lplfinancialxn--clchc0ea0b2g2a9gcdfutbolschoolsocialglobaldentalwoodsidechanelairtelmatteltravelrealtorwebcamstream\u0C2D\u0C3E\u0C30\u0C24\u0C4Dunicomalstomxn--nodexn--6frz82gmuseumfurniturexn--rvc1e0am3exn--mix891faccenturexn--11b4c3dismailineustardiscountquebeccomsecclinicservicesxn--y9a3aqxn--c1avgswatchchurchsearch\u0627\u0644\u0627\u0631\u062F\u0646marketingcontacthealthmonashshoujisanofitaipeiamericanexpresssuzuki\u30A2\u30DE\u30BE\u30F3\u30AF\u30E9\u30A6\u30C9\u30DD\u30A4\u30F3\u30C8bharti\u30B0\u30FC\u30B0\u30EBxn--mgberp4a5d4armemorialxn--1qqw23alondonmormoninstitutevisionbostonnortoncouponmaisonamazonvirginberlindesigndurbanolayannissananquanxihuanhitachikaufengardenreisenbayerntechnologydatsunxn--90a3aclatinocasinostudiophysioxn--ngbe9e0apharmacytattootaobaoaramcoexpertreportabbottdirectselectimamatfairwindspictettargetmarketintuittravelersinsurancecreditdupontryukyusuppliesxn--tckwebnpparibasschmidtmerckmsdyodobashirestaurantbridgestonecricketxn--fpcrj9c3dbostikbroadwayattorneylefrakemerckxn--fiq228c5hscareersfarmerswinnersflowersxn--wgbh1cguitarsxn--54b7fta0ccxn--p1acfmakeupgalluplandroverxn--kcrx77d1x4agoldpointbauhausxn--mgbayh7gpahiphopplaystationxn--mgba3a4fraxn--eckvdtc9dhyundaixn--gckr3f0fistanbulticketsmarketsflightschintaireviewsxn--3e0b707ewindowsxn--fiqz9sfinancialxn--fzys8d69uvgm\u0627\u0628\u0648\u0638\u0628\u064Adiscoverreview\u09AC\u09BE\u0982\u09B2\u09BExn--5su34j936bgsgmoscowobserverapartments\u0434\u0435\u0442\u0438\u0627\u0631\u0627\u0645\u0643\u0648\u0441\u0430\u0439\u0442eurovisionxn--i1b6b1a6a2exn--xkc2dl3a5ee0h\u062A\u0648\u0646\u0633\u0645\u0648\u0642\u0639\u0628\u0627\u0631\u062A\u0680\u0627\u0631\u062A\u0634\u0628\u0643\u0629\u0639\u0645\u0627\u0646\u0628\u064A\u062A\u0643\u0639\u0631\u0627\u0642readkredbondlandbandfundfoodprodgoldfordtubecafesafelifeggeeieeefreefagepagegugezonewinememenamegamesaleablebikenikelikecarecbreherefiresaveloveliveblueartedatesitevotecaseluxebofamodaltdaasdatiaayogasinavanashiaasiajavabbvatevavivadatazaraarpacasavisasncfprofmaifsurfgolfdvagsongbingpingwangkpmggoogblogpohlfailcooldellcalldeallidlsarlfilmteamroomfarmimdbarabclubhdfcicbchsbcgmbhrichtechfishdishcashminiernikddiaudiwikimobitaxicitikiwidesiqponskinloanakdnwienopenporncerntownimmolimoolloinfonicofidolegosaxozeroaerovivoautovotomotofastbestresthostpostnextlgbtchatseatgiftmeetdietreitmintrentgentspotscotguruitausohumenucyoubanklinkpinkdclktalksilkbookseekworkrsvpaarpjeepshopcoophelpcamppccwshowbeerstarruhrflirweirhaircarsparsjprshausplusnewstipstoysjobskidsfanspicsdocsxboxamexsexynavycitysonyarmyallybabyplaydeliverybuzzgbizlamborghiniphilips\u0DBD\u0D82\u0D9A\u0DCF\u0CAD\u0CBE\u0CB0\u0CA4fitnessexpresslanxesspfizercenterwalterlawyersoccercareerkosherbrokerlockerdealerdoctorauthorxn--mgbqly7c0a67fbcverm\xF6gensberatungjaguarxn--pssy2uxn--hxt814eflickrrepairrogersairbusxn--mgbai9a5eva00beventsyachtsxn--t60b56a\u09AD\u09BE\u09F0\u09A4\u09AD\u09BE\u09B0\u09A4\u092D\u093E\u0930\u0924\u092D\u093E\u0930\u094B\u0924viajeshermeshughesxn--j1aef\u0938\u0902\u0917\u0920\u0928villas\u0B2D\u0B3E\u0B30\u0B24claimshotels\u0AAD\u0ABE\u0AB0\u0AA4zapposphotosjuegoscondostatamotorsgratistennis\u0A2D\u0A3E\u0A30\u0A24tkmaxxtjmaxxschaeffleryandexxn--80aswgrealtysafetybeautyluxuryxn--3ds443gsupplyfamilyxn--o3cw4hhockeysydneyxn--90aenissayalipayenergycomputeragencyxn--rovu88b\u96FB\u8A0A\u76C8\u79D1xn--gecrj9cstatefarmaccountantaquarelleolayangroup\u9999\u683C\u91CC\u62C9xn--p1ai\u7EC4\u7EC7\u673A\u6784xn--1ck2e1bxn--mgbt3dhdschwarz\u0645\u0648\u0631\u064A\u062A\u0627\u0646\u064A\u0627abudhabinowruzkomatsufujitsuhospitalxn--80asehdbxn--mgbtf8flxn--j6w193gxn--yfro4i67oprudentialxn--flw351ecruisescoursesrecipesxn--e1a4cferrarixn--ses554gxn--wgbl6awatchesstaplessinglesxn--mgbcpq6gpa1axn--otu796dpropertiescreditunionxn--mgbah1a3hjkrdstockholmhisamitsu\u0627\u0644\u0633\u0639\u0648\u062F\u064A\u0629stcgroupdomainsoriginscouponsbloombergclubmedfroganslimitedxn--80aqecdr1aexposedinternationalequipmentbarclaycardxn--q7ce6axn--mgbi4ecexpprotectionassociatesconstructionxn--cck2b3bxn--45q11candroidfoundation\u05D9\u05E9\u05E8\u05D0\u05DCxn--mgbca7dzdocliniqueboutiqueengineerxn--qxa6asystemsfirmdalefashionauctionxn--nqv7finfinitirentalsreliancetradingweddingfishinghostinggentingbookingcookingxn--3hcrj9cgraingerxn--czrs0tdemocratsamsungyokohamaxn--h2breg3evexn--nyqy26alundbeckmelbournevacationssolutionsfrontierxn--vermgensberatung-pwbmanagementxn--cg4bkixn--mgb2ddeslincolnhamburgsandvikcoromantblockbusterairforcebarefootxn--4dbrk0ceinvestmentsfeedbackcommunityxn--ngbrx\u0627\u0644\u0628\u062D\u0631\u064A\u0646diamondsamsterdamhealthcareredumbrellaxn--mxtq1mxn--2scrj9cagakhanxn--mgbpl2fh\u043A\u0430\u0442\u043E\u043B\u0438\u043Acaravan\u0B9A\u0BBF\u0B99\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0BC2\u0BB0\u0BCDrichardlimortgageamericanfamilyxn--fzc2c9e2cscholarshipssaarlandxn--imr513nvlaanderensamsclubgoodyearkitchen\u0B87\u0BA8\u0BCD\u0BA4\u0BBF\u0BAF\u0BBEweatherchannelallfinanzxn--kput3i\u0627\u0644\u0633\u0639\u0648\u062F\u06CC\u06C3xn--90aisxn--efvy88h\u0627\u0644\u062C\u0632\u0627\u0626\u0631xn--mgbaam7a8hexchangejpmorganxn--tiq49xqyjfidelitysecurityxn--mk1bu44cwanggouxn--fiq64bxn--6qq986b3xlxn--mgbbh1a71exn--80ao21amarshallsxn--5tzm5gtravelerspanasoniclatrobeyoutubeaccountantsxn--rhqv96gxn--cckwcxetdanalyticsxn--ygbi2ammx\u0628\u0627\u0632\u0627\u0631\u0628\u06BE\u0627\u0631\u062A\u0633\u0648\u0631\u064A\u0629organicfresenius\u0633\u0648\u0631\u064A\u0627xn--9krt00axn--qcka1pmcxn--jlq480n2rgdeloittesciencefinancexn--jvr189mxn--30rr7yhomesensehotmailbaseballfootballleclercboehringerxn--q9jyb4cxn--mix082f\u0627\u0644\u064A\u0645\u0646\u0647\u0645\u0631\u0627\u0647politie\u0633\u0648\u062F\u0627\u0646\u0627\u064A\u0631\u0627\u0646\u0627\u06CC\u0631\u0627\u0646netflixyamaxunxn--lgbbat1ad8jcollegestoragecapetowncolognekerrypropertiesxn--mgbgu82axn--ogbpf8flxn--czru2dwhoswhociprianilasallexn--g2xx48cforsalebanamexaudiblexn--vermgensberater-ctbxn--zfr164bericssonvanguardxn--45brj9cindustriestheatremarriottxn--3bst00mcomparexn--mgberp4a5d4a87gcapitaldigital\u0627\u0644\u0645\u063A\u0631\u0628barcelonashangrilaxn--d1alfcalvinkleinwwwcitysapporokawasakinagoyasendaikobekitakyushuyokohamackjp";

  // node_modules/tldts/dist/es6/src/suffix-trie.js
  var numberOfNodes = nodeFlags.length;
  var numberOfEdges = edgeLength.length;
  var edgeOffset = new Uint32Array(numberOfEdges);
  var edgeHash = new Uint32Array(numberOfEdges);
  var wildcardEdge = new Int32Array(numberOfNodes).fill(-1);
  for (let node = 0, offset = 0; node < numberOfNodes; node += 1) {
    for (let edge = edgeStart[node]; edge < edgeStart[node + 1]; edge += 1) {
      edgeOffset[edge] = offset;
      const end = offset + edgeLength[edge];
      let hash = 5381;
      for (let i = end - 1; i >= offset; i -= 1) {
        hash = hash * 33 ^ labelText.charCodeAt(i);
      }
      edgeHash[edge] = hash >>> 0;
      if (edgeLength[edge] === 1 && labelText.charCodeAt(offset) === 42) {
        wildcardEdge[node] = edge;
      }
      offset = end;
    }
  }

  // node_modules/tldts/dist/es6/index.js
  var RESULT = getEmptyResult();

  // shared/js/background/utils.js
  var import_parse_user_agent_string = __toESM(require_parse_user_agent_string());
  var import_sha1 = __toESM(require_sha1());
  var browserInfo = (0, import_parse_user_agent_string.default)();
  function getBrowserName() {
    if (!browserInfo || !browserInfo.browser) return;
    let browserName = browserInfo.browser.toLowerCase();
    if (browserName === "firefox") browserName = "moz";
    return browserName;
  }
  var dayMultiplier = 24 * 60 * 60 * 1e3;

  // shared/js/background/popup-messaging.js
  var activePort = null;
  function getActivePort() {
    return activePort;
  }
  function setActivePort(port) {
    activePort = port;
  }

  // shared/js/background/components/message-router.js
  var MessageReceivedEvent = class extends CustomEvent {
    constructor(msg) {
      super("messageReceived", { detail: msg });
    }
    get messageType() {
      return this.detail.messageType;
    }
  };
  var MessageRouter = class extends EventTarget {
    constructor() {
      super();
      const browserName = getBrowserName();
      import_webextension_polyfill5.default.runtime.onConnect.addListener((port) => {
        if (port.name === "privacy-dashboard") {
          this.popupConnectionOpened(port);
        }
      });
      import_webextension_polyfill5.default.runtime.onMessage.addListener((req, sender) => {
        if (sender.id !== getExtensionId()) return;
        if (browserName === "chrome" && (req === "healthCheckRequest" || req === "rescheduleCounterMessagingRequest")) {
          req = { messageType: req };
        }
        const hasExplicitMessageType = Boolean(req.messageType);
        const legacyMessageTypes = [
          "addUserData",
          "getUserData",
          "removeUserData",
          "getEmailProtectionCapabilities",
          "getAddresses",
          "refreshAlias",
          "debuggerMessage"
        ];
        for (const legacyMessageType of legacyMessageTypes) {
          if (!hasExplicitMessageType && legacyMessageType in req) {
            req.messageType = legacyMessageType;
            req.options = req[legacyMessageType];
          }
        }
        if (!hasExplicitMessageType && req.registeredTempAutofillContentScript) {
          req.messageType = "registeredContentScript";
        }
        if (req.messageType && req.messageType in message_registry_default) {
          this.dispatchEvent(new MessageReceivedEvent(req));
          return Promise.resolve(message_registry_default[req.messageType](req.options, sender, req));
        }
        console.error("Unrecognized message to background:", req, sender);
      });
    }
    /**
     * Set up the messaging connection with the popup UI.
     *
     * Note: If the ServiceWorker dies while there is an open connection, the popup
     *       will take care of re-opening the connection.
     *
     * @param {Port} port
     */
    popupConnectionOpened(port) {
      setActivePort(port);
      port.onDisconnect.addListener(() => {
        if (getActivePort() === port) {
          setActivePort(null);
        }
      });
      port.onMessage.addListener(async (message) => {
        const messageType = message?.messageType;
        if (!messageType || !(messageType in message_registry_default)) {
          console.error("Unrecognized message (privacy-dashboard -> background):", message);
          return;
        }
        this.dispatchEvent(new MessageReceivedEvent(message));
        const response = await message_registry_default[messageType](message?.options, port, message);
        if (typeof message?.id === "number") {
          port.postMessage({
            id: message.id,
            messageType: "response",
            options: response
          });
        }
      });
    }
  };

  // shared/js/background/devbuild-reloader.js
  var import_webextension_polyfill6 = __toESM(require_browser_polyfill());
  init_wrapper();

  // shared/data/bundled/site-buckets.json
  var site_buckets_default = {
    count: 17588,
    data: "ib0a/L0C3OQNmY4V1eQ024gUucoDjY4hlOcK29kLuYgLjawJzZEI898s55gN3+4F+k3tzgWuwhrm+CWcUeW9EaHCD7KGCIfbCNHoA8KFA9CoAYbmAb7aCa3kCZzbB6DNCobZG86BAoW8B5niE5bNIsm2BJqTDrfzJdCAA7qoDpj+BcLlHoHfFoGMDqaDBsbkFOT8T6WNEoy4Cq3iF8S+CJyCKfk3540Hrl/k8Rnb9AHtnwqwuwPt0iuw2A2Ea6+uCcepDtzTAffoBrXFBYqsEZbQKu+9CfvUHs/SB/D8CPzlA6XnCNurEbGZA+XaDIrDCZvBKeC0CrybEvOlBOCtCsgMpM0U77oD/r8B0LQJzNAWgOcq7/AGvt8FnfgKqJsL+p0F5YQIm3/7gAXv5wLk+wScxxTXqgOIogSS6yKbvATI0BrHhhTRqRyF4xPZkQL2oAuToAKHshjV7xLOmwOAZ+q3BZ/mKYiXBo2eC47iBriFCO2OFd6UB7XrMJbEAajwC5KQI8OTGdWBAcCuC/uOBpyPBZStAaOqA9nEL6HUJcb5BPT+ErWpA+zuA++2DMKlCoLKB8PwOpfdAsNyhYAG5s4E4fMJlPIQ26cNsc0CgYwmovcV7qcDnPAW/IcE9MVElo0Mzd4b6KQOkuEHtosKkb8BycIH0pQHlq8B/+Ebn8gh68QKoe4F5rkLxbk2w7ABma8Ujb8FzIYM6d8ewoMKrKow97YUqRagoA6ixx6MX+fsHL2OIKyOGYmwDJW7AoLcDaCWC4GMBfpazLkU0fAlwIkJp/ohie4Syr0jykzPgwHbjQ2shwrpKYz9A8+7AdXXEf1j8pkH0FXKxwmwsgKmN5PjJY/HH+yhB+CCEdaWCMGOAaWqBfWbFsP/HvDbBuuLC4qWBKabAduABqWsCtPLBK+9FPCvGe7gC+XoE5DFDJnrGqx/vokV0Zse7dQWo/I8v7YKkowUuLIG9/wP0pkZurwVqMwEyrMGkbossJ4DitgIkoI7hrgR840Mv4kBh9wIuYIcpcIU/c0H2ecUxvYSteEN7N8HiIYkiLYF9vM17toCqJIGrqgEhrAP0bAO3MYNs+QB3/AIlfkG10XqmBjswwHpmwnUmAqhf9rdJ4O6B9H6F/z3AtSFB6UI4dgHhYwDmq0M9ecNzvwX8tEl/+0BneEK3/kr1aMBqOssys0ayfcJpIIBxYcI89UFkPoMhaYarsUGqbINj4oC/eEB1OULo7kBm7YIjcsG76kUyvcGq6M157AG6LYO1tcO8agCt+MFviGKjAvk0i7flgmRkwyr2QT6wQ+A+QrBryDx3wiBhAX9lAGxmiH2qgihjiDruCeIMZTCCobFAp+SF4PQJbqdIrT8BYvUDKSZCfilCuPYCceeGOSvCaWeAdumGfqkCuPTDJC4DJXvH/yLCN7nEYWeC5LcCLHRCJ7gLsXOKKqQB8DLA/e0BK3EE7TXCqeABP0FtZAF8Mgj98kC8YgE2lLH7yaeoAfghhWZpgGNowe9rwvc7yvihhHT/gWC+QWm0RCm0Qqm9Ru+pxP45xCD9g+P7ga/sATvmg+nhRjgsxDy8gnD0gKGxgT8nwv+nRTXhAaYvAP9jRnw2AOJiALVkgnXoh/QnhKrrwOczlaTrQKEniiL2x7KxwK36APCjgSijRPI5APE0gP7hQTGoQjRB6m5F+CQDZjRAcjjFaKoDMqTIb2CIcndLOXgHKvGA8HtHtScCvekFOLiKZ/EBrbHHeDeD7mIBM+qDa+LBbaSAvLkC9+yBLeaA9mQGcgZmc8mrqQFl7gGn7QJ9P0CvMIB5/ow4hn8xwOs/AbbmwOZ0S2rpAHKgQXmpRSnfc2cHPenDZf3CLKzYImeGeitC+OoKfv/Cqk79MEEiNcB/dIC55IN1/EDp3q39wmOuQSllTen2Wvg3RC39guE4wGCpg+LjQ3PjQfqlAOxrwLcvh7V0zflMZOcLOH+Bt36CrK2A9+GDbjrAabfAreyD4Ef5OsEznGy+h277AWA8RiigBanjAar4BDwpQiR3CDo7wj32y+QlxOnriXYmBD26gWezgGpmwHukwf25R2JhhD6rwWAoALSlwSHiBHptwSZBKy/H8P0Ff+KD+7oDI6RFupUx4wc28gCjs8Equ0E1/AD1Y0L/doD/FzVswy63xbW/wjR9BSKVMiNCpCIC9vnApCDBLGDHapLxKgB6/ECmNQlvAjl1AyGpQrKqS2Yxw/augS0gCHBnSHJ0RCnpgX24wu3owPwvArS8g73wALdxAnDdOHcCMKCGcCUGt2tF6PjA8CdArT3BaLrCJvnB97+BveGA5OLBYvxCPmLDMWzH4DgKojFIrPcX534D7iaM4OoG/i1CfLSBLjxH+ePB8b2EfPSCY+sAs4znKIFydQBrL4ar/wStZoB6LABlv8FwYMe6bIO/4gIyMcGku8kipQXq54jyeUC1+wHp9Eg0egTzdwEyPICtJQH2uIKxL4Eh7MD17IE3h6z2xu2xQeVihL+khOH4BzC9AWUxQOkxxPlsQXBUamXFIfaILSbBJC7BrG7BueFCMT8Cp3SDq74BuuTF+D/CLKcFO6mEdhA1uoEz5IcvsIE+dcCn4QEwN8J+s0Bmvsa5P4dm9gpwrAXwNkbnd4Dq78UoYUM1K4R4ssqoqUH8bkp+IQq5dwInz+Lrxu5wA2exAXq2QG12AX4RMXFQojcEaz7DeGvBvqrEMzHHP3WA6+zB6uQApTBEfmQIOL/CYrdBM/OBozAEoKTCOC8BbWtE4DoGtnnEd2nB8bIFPfvAZHfCoyvErf9FdH1DZWQAryJA8T4JIrzD9+WBfyyHfeRCJyVB72YELCcE+DQAsiSIZ+CD87rHt+MG7eDA4KKSr6DCaCbCMLFC4exBf35EPitAtfJB9THAa+BLZaoB478F+OxHrK1CeybCdPyCoO/AatLztQH0rMe1bQEwuYO64sHuuEJ640ax48BvJAJ+JYJu7wH8agBrc4GltoZv8sn7fcI9fwDkKQl25gR/+IWotgGt9QKrrMRyqEMxocCn6MD1rAI0NMa2YwIhsAFv/IFkbYa86MSqdofjqEE86cQ//QqxvcJ00CWvgfbnyq54AX5tAufiCWrtwWPyCvJ/iWMlwGl3ATN9Q6RyRHO3hX/+hDtkRf3AZmoBaO6BdGiI4m8DPr6FtrCF6mBG63gAvDOBbmJHNH7HPG1CL9a0YQEkY0Oor0xnJcX/M4gxPENlDeGmAbzsQuhswjD1wqe1gyD0wSQhAWrxyOCiB/NWIaQA+rfB/HTCtqoEvyNC4GpCKyHAbfjFJ7PAYqUBqOmBOyhHLL8CbAwsNMB6+QH+8AJhqUPq80B2OgH6d4Eu7wKnYQMmZcO/wvJ+SinjBbioxnuhg7c2yfwhhDl9gf3ygS7qgXr1ArhqwOQ3ge67QWTqSCn0gSdxAGVvBnf+we0sQYtgeoK04EKrMsP/7Am/8YTq+4EuqEahcgU+tIBstEFqpAXld8Hs7UktSD/6BPiUonIDNwu5v4E2b8JuNsFq6MGpJoChtMBpsQHwjza0Qj+qw+/3wKVCc+nNPr8C/PuAsulDPGaE48pldkB1fYj1ooIocVU0M4Ez/4WuckLu+QNoY8C6YkgjECHpCXS3xL3nhDm2gLUiBnklSvrvhyO0wGhqgmee++BAoHiBtOQA8rCB+WcGZP6CK70JP/cDKX3As3nD4iJCaSOCLnABtGDJebZAZblGdSvHs+qB6yNRda6Fd+1Dq/MCOKcGZfOKdHBCa3/Cpv0DreBGLezAty9A6LPBujWIL71A9OdC6K+BN+KDo6VAvvFBoegGdafCoHzDu3DAuWEF533B7nhIe7ACpnBD6OUK+fCC/vSBK+jDamFBIaVE9OWDembAYP0Gc77BsHLHKjFG5fpJ5LhE8mzC9OgGaKtA4f1DK/oAZ7VMa+PC4GcEdQZgvAB0e0Cg98Vl+4S0Zoau+ECt5wguJwXkesC1KsawbQHkcUZ3JAGkcUJsbMMmqYBwtMQhtIBxcggxvIK0qoEpXLO4hyYnj783BiHpSvS6g2KnQWkkRHJ6Qa3nx7xxAXT1wSLwwWagBbB7gSN3w7zqyWcgwTLqgWi5CavihGQmAS0tx29pgfJ4g/kugvV/AbN+xiTG9qEEZW6BOjGFY/uLPrjBb3IA/rBI/CoAqfFFrDtNs3WBYCoCP//KLWbC8959c8Btf0H6mzSiSiOtQX4uAqNtgLBohz37AetwhSGlwe6uBCo4wPvgRSv8gme2w+rhBn/pAuYyBqZ8ye8qiDymhqB7RzyrQqCJaCNFcyJDrSTBY2nBqfWA9ieHpmkGNHLFIKpEOaKCZ2eBc/qAZ76Atj6DrWeB7D4GOHtBKTRAp3OA/KfCJPfAuXIKe33Cee1A9bDL7+zEsjVCurOE5DeBuXIB9TKAuYIg68vyyjPrxDmnSLrsBKgFdWaCvmLBLipAqrMBfnrGOjjBtjlFL+fCIrxEfmGDPr0NqmFA5OyBYKbCZV5js8DmdQGzsgcsbsV36kUhJMC5rcWh4gy2IcD9s0I4ckDl5kbjKYByYYF1Ikhp/cOt+4avZAGipUP9PIKzqYLgMUF5uwk3Wfu5QL12A773Bf+3AOWxBHO8QLVsQP6rxGL+RrpvA6qmRbh2xGs5C3a1CKCwwbIpQbOswfToBbolhWJwAWgkCKEvgKa/Aee9xjwIufYB6HFAd+aL5i1AYaiEs63EaKcAoO2ArSxBMDcAoLiBcizAdLWAcQCte8evocYjsMFgP8M/CPkuybsqTjEd/7ECvCHB/jtEraBAonFAtXkG+b9BdaEB5WvEJPqD8/UFKXfILqABcKzA7frC+bPCM+RDYjgBdWiGY3xKIPoHoWVBd7rCvyqBoC+BaWFBNHXFOKJFtrFO96ECIKVD/zGCqBp2IUByL4p5+UO7MsNvfIEtJsL5/0L0qQX0u8Bh4oHpsUPr9gMn9pD4aUGuLUV/dkJ5TznhBGW4QHuV+LpBY7sAZG/CZXEC6mrAsGGAtqMDOuTIM3xA4a+A4/WBNbKDJqqL+2sCvPuDteiE/AK2+AJ4eMM7KIBoooPxRHGzAGBhAWsiQ7UhRya8AL+oAe4sQSx9B35jge8qAab+gjO0we0oBTBjQa49gTdowz/qRuH7Aqi+ATGxwKdjw2knxLz/Afv2jX9mQuatwqdlwX19gSLjALKxAPs8AOiwRSN+wLr4gyszhu4wAK8zw+Wqj3gmAGBkgn0tATJvx7C9gXo2QryMI7/B5yOBI+iA+G6D5/FC6KpCKT+BfD4Gv7HEIfNH/po8rQJ0KkWvcwehq4D5t8H2ogMqMUHo4UfmOgJnukShK4SuNcY/NEV89MB7KMGnJ8G8YkF6dMvr+MDhRDQmAfdeo+6LZqiB7vNHPeKF+TKL/3/FpeMAtPaJcepFuK0IqLhI44o0swwgfoRgJ0BuZ4FvO0SlZgB5NMDmooC7KYCmM0ElcwPxqID6rQqtvcFrIwGzKoJ87MBuIgKmtMb4/oDo6QihokJhrIBmaENp7sJ/OYQruMC6tob1p8IubsZwdwE274J+LUB74Uw+ZIDjfcE7Z8Lup0WtYkVrqsBlu0YqckYgi7Z/AOUMPOyDr7BLoz1AqvlGr2TBqn0EpnVCaHcEYGUHtmZCqLXD9PmF+60LMOTIbaMDY2+B4+HD5HJDpCNCZ3oEZreDtKZGrnUCIzWAtniV6CZCbX1A7ewEefrKt/tDqyzB9LOBqOsA5b1BPDABZzCBMDjF/nRB46PBYD+EfEzjMsRs+cj0KwPnvACpPYNxb0bl9UC8i3Y8wTOsgPApg+CvQWl6Af0twrEwhKWpxntqQ+2ow//3Q2biRylqBSE7wXg1CLHqEfTkgbavhvJOv+2BsjnAaRUjP8Dhu0jo40Bwv8E8asBvuM3so8Bo5sEzNwHrtgkvawFjYsZw7UBlpkL1f8W8QiQyEX+1gjF+BCrnhennRCchgvKjC+YYoMytrgDy4obmrMctPEFjssC9MYdivQC+40gjcwM2qMD/4gJnKkCzuIJjacZ1sc4180CsL4F6qAMr6Av8+cB5/kZwawD1NMKidkBu4IJ7IgM+fMB18oGo5EDjagK+LUEgH3alwfX9Rec+AGEugXS7RLjygazlQO2owvPsRGA2BjTlgaZU6/jEPPAEKflB6ixCpyMAoXMQMefAsSiD5qdA7DbFOS+EbuaAbz5H/n3EK3eA+CrLczhKJrzFK6UB5HmC6C2AoyCC+6yBv2hEKSvDNrTFczNBvnjBtfEDdrNCsSDBOXyEcm/F4eHHcPJEODJHJ3uBsTpBpqNBsSvG57dBu2/B9u3FdO2BrfgBMrrDJLoDbbEAvW+AaHEBtLFCP/CDJTmMIGMEvbzPPMPybQOz9gEw7cn94YDsrgS3JcDysUQ45cC0JYCxwqsugqEjhDijBGQryK5yTau1CbKkCWCvw3E4gfi4xrQ2grngyW67wKpzQLkzwuNUKHFBtPAA4eiCP6zMqmFIbyzFs+5FI6rEJeZAon2DMelHfGuB9/mC8td0fMZijCo2AeOqiuK4wvFgAWlqgyfpAeGlBj8S8rHIZWiH+ygFIyqBNjRC4bdAumMDM2zE6HQOY2GEJL3BsD5EukpoZNNpEiz2Qn1hRuEgxflswG1qAqJ0hGojCfW1gjuqwOJmiep5w2T3A3vrAXiwwLHpDj4mhP+zRSJ91bSjAfsa4KjN9qUI9jDEcdJ9J4D7YULvK1el6QSzvkYmfwL9rYF5agc6NAss9If3KELzPMLifcb2fMTz6MHy6NB4M0b3NoWnrwhuagN6pITxJAQkocH/KoNgpoS0Z0cp7MEuLEBp7wEidwKiK4DhPcCuqIEvLQp5PgF67oE0MAS8b0OrtoFzaE07s8ojeYDpIwEimz+uR/noRe98THJ/wT1uwe96xDb+gvYuAbctRi4ihSzngmYtiL+4hbaqj7zrw3CxgnztAGM1QjoTvOWBNPmGdOFDrDQIZSfGZ7HAYfvA4PMI9LgE7muBZauMcHzE8v9AvyABsvgJuSFCsWiBvMJ5pIRkooOw/4mlRqn5wiE3x7/esb1Co3VHeksiR+mtwvQ4wGYqDOCM7GiBZioA5KDC7CwBZiAGrfvA7aPA+XnCO7sBYCkFYLaIK+aBOLzA6GPBumLCZGtAZ2uBdfnCNKvDJj3GPiDCITRBO2IO9D0A7rxCc+4AsDXDM3QGs+rAuXnOeeTCO3yO8HjEfFWvZkKy5IG0e0RyaMFiIQ21IEB4IcRlIUP1KAB+NdBirAfuZ4HsNAikqsEufUE9vsIzrQJ68wCx8EK95QOp6gC0ZMcqqcCkO4m1soDy5sDvPID+/AS0KMRr5gCmc8RzsVOk80L1MINtdIeqdIfrDXWjwqp/Abb0AOEhweN7wmQ4gTBuhC40AXZwQvjnhuA4A7fqxzjrQGcjwWi/xOWpgWnhRfb1Aq6rgqRlQHdlQP0hhvbokuIug+cxhG9CZCXCvyKEZKrBfLNC837IIjqDMLhCPX2AtvRFf/SRtrJEM+rBOfxE+CPAq/RDrW1F4qlCsSBA+yLAaOFBNaICIOpAcbzAv+mA5VPt9IBttAK7ZsHqZ8DpfcC+IwC1pAGo6AmgL4YlLEJmeYKs/QOl4wehucBz13nsiS9lwrdzBei+C6S1BTDS6fwA4ibAcKYArqlEbX9A6uyC9y0Eq+nBMq8CcvBJaflDaPrBuj5CMWjBam4JKWUFN+1A6/eKPjZBoYv05MD7OUDsIkV/voM+84u27QFzYcHn+IC3Pwf87ZC6IMCgM0K3dMj2qgCr/wWiZUX2NQDz9QD/MIF04IB04gJ87II/SnoiQSw7kHIvwjz6QaxnwHmMIeWT97JEpmMJOGsFr7iF8KgE8acBNvSHvXIDoeFEuqsAa3eB4reCblczcUds23vqh3mpgb7gA6+iQLKjwutnQuE6RiGjAS6ywiFmgHi2BPP2gfAihr13hHXmgzNtxX7xwTVjwrkhgTu0Qv+kBnQsBTI3AmL1CuS8ASQmwaPtyPkOf7tH6PpBPpI3YoG9tEn4c0R/ZwHpZQSvaAMoLMk64JLvdABipIB55ks39IMgb0MgrQEk5UNoqEMl9AZ/PQzkuUEo+4Blvw16dQSqpsB/+kB7qACndANsMEWv90Ctoch7tcD1oscifIDpq0csL4o+rY6r+sJkMMS4KwQqeMIvRT81RWCxwHf1QqCswGhJNHyAe2YEM3QCOLkAf2EI5+yEev7Aeu3A82fAs3oA5PvAcXHD7zOD7vrD+yiFZjGA+6vCeibNqMYhqgPwawNz8sIsgjrtxy2pAmjowOmpiLimROtqAzk2ROGqgPtmhTvoBq7sj2HnAP+nxLvkgvxmA+Q3hLD+gq74girmRyDrx2k7SDQuBmFmAG7jRSxhgu+wgediwPz2R6rzBCl+R2MsQKtphKXywO5vha73gG1F+6+BfmWIeGbD47JE626BfDjB9KvDeqYBfeKDsqnCIG2CNjlA+++AavmHZOVBahdteYx4+AVsIASlq0j+ecWvZoG/McD1LQW9NMZ3cYGl4gRvtMrt7wGnOML2ATd1BboRaTXAYDjCKzrDaO2AtnlDIXII4itKJuDC6HSAvi9AcfPAfmaAb7LCPzWApTBG8ySKry+A4D6CuW5BubMBq7/Bs60BpbOJIujB6ayBeqlC+rLBaaFAb6ZAc3qCvHkIO7rEbuLCNbDFNDgEazpDvDAB5KKHtXoC9ydEqb0B8nxDrdRp6gxgaEWqdkHj9UB/PsQ4oMC77oEwv4evKkGqfMDpJsD2ogIru8CkI4H5oQ79oIV6LIX6PwHue0T6fIF+OA0jO0StqkMgESRpwGo0hO3twnTavzDMbWqCJSRGufzBciPEYSeCoidDcmPB72FMf21A6TXAumjNKW/D+6bCZraAoG6EOXbDuSiAbawBNLHAaCnA8y9Gdd3h+gJmLAFw8Ik1+EBqKwMwOEJ68ANrZYC++QIvroSmZYGg4YLrosT6NUXnagK1MgI5O0W7LoF+40KzdwL160Is5EFg8wMr+QHgswD644Br9gJofVD7OUaqfIF0ZUBqdUbqO8E24Ef6w3pug6T1APomAOZ0QLH7QHwiBLkjQiNgAPqoRar8ASFE9jrI9WtCKaRAa+UDdrOJv4Dx9oPxJcDjJsFuv4Q1o0CnMYBy8Uq24oPmZIHncUejPYC8/wE26IJuPoIsBfJ6gHtzSzgNcGyCLSCA4DHAv+TGfjCDdfYAqjCAaD9CsvbEsiSJ8qrEpelA8LMBpPTD4ZVlvYXyGfKxgGD3wOZ9QON1BCv5gK2xwuzyATfkx6g1wqo/QKQ6DKaig6pygK3nR3MumKsxgLulAiD2gG7PIrKBbaxM6SSF4Yuk4sI2c8Po60D6YwH/tQInvED4ZoKtoYur9sC6u4GtSD46wrcyAeoggK6tQixkQiThRCRvBaA5RG9uiaBHabcBvT+Ge+KA6euA6S8AqDOCM+0DKnZFO20CdqPC7vjRLjeB9f1D7mKA/jxEKHpE8XyItGjCI+ZIbjMBfG4HNrLEfXdIKbNCZCcMvXqBp67EOqOAqKAF77FIMfFFtmSGoj9A6H+C9qqBczZBJla+N0IwqQD9t0Noeki9b8B9u0SrrUDjeYNj4s5/ccsgccJhf4steMV68YPjdUI9tcm9M8h1pAW0tMJyrwEmvUUojLBsgGa+AGBiD+02g6T+gPR+QP90AXX/waXyQnG1kGvkBWM7gWt3gqCpiPx9xCGmgvxxgWy6g/ungHn2EG97CSi7hvluQK3oQuWCoXWDtXGDP2ZEd/yA4+XFqC9Ba/6A6j3BfbvCfh+luAblJIMrjW+jgWX9QiY/jS2MvXNBOzaBs+mC9brH/6aDrKDG/KECfuXC6fiAtyjCpAgopQB5coE3dcHuNwKjLcL4P4Q6ZoIxekDlN4Rn94K8P8XzqUH2rod7NYJsNoVlbILp+EKqJ4GxJQLo8EXoqEPltgF+ckLvakDts4HqcME6d4IspYyxosN194q/r44v68V6fQBh80DuJkDwssK7/cuz6cB8q8QwZAetrwCmfIMna0X9e4Y2OgPu64Jz5IOyqcOi9YQiuQE9tEE8a0BiJwGobAayq0T2rAMtp4X+KEVogHKqyLD3wHR8wvuixH7wwyzmQKUqAKsoAXYmxPJog+F6R2ggh/9/gGR5Aas2SONF+jxD9X3I8nECOqOBs+NArv9BILdDtO/HuWCEbjVE9OhAaHHAda9Dd7bEublKPu3BLKbAt+SBeOyBbb9AZmyAZmpBOPlBZVd7/cLm5QNppoDutYGxo4H5O4TqoANhdQOqfUTiqUP8cMY9YYCiYARzKAcnYgX4JAJ058F5qIsv58HzqoU/jCKrRPN4w/GmQb8Ct2pDI7dFuLDDJKBAqOxCKaMAvqUBfT8CqGXFZivJ8zlGozvC5KIDrTkCN7nHtX/PoW7NLDnId3XA6HOCsXpEYzVDYuuAtaVB9vDA++fB73XAv7yJNa5C6e8JuO/DYGEEP6wDujXCLLlELz8ApD4HenjDaPXCMH6IZzpDbOgA67XCeGPLqvyEO+8C8TrA5CZA7bDE4KuEqq5Dq2aDYc1pNkItx+GignQlhXClzL3sAL4lQfI3Q3jvQSI8RW2zRy7SrCZDotPxm664BjEvQS7yxzmvw+nqwL18RC6gEjbmgW06wOQiwy7kw35oAKjpRWYwBbhxgHGqgelnwaZzgOY0wGVGvubCa6mEbgqtpYc/voDmr0jvdsO61+E7xK3Gv6cFN6IBd/9EruYDa6tCsebDbirDID8JITrDoXgK9bLCbXrAbS+E9adC4a4Del1gMkHePvMDqNrnbUO5fAS9OkInIsT7d0lr9oc57QFrrED3Yws8/0D/eU43tYazcga5e4egcEBnLoeuZsL+fYU/asF+qIG2KIl4YkC97MQ9N0SjfID19Unx7wLhs0CyBeG5xTl8wvRpgKb8gXmNprJAsjcC773DK/6EIyLBeKtA/rTA6DbIuftJ/yqHKK/AveUKf2lBLqkGdvPEfzkBtuAGs2XOcj2BbLFBOKwDYzXA+2fBdWvErq+CpCIFvH1BvcBvMkIndME0uAdhlmYFZudN8+jFID1A8rgBtK7BcvjLL9soOc5kJYNqagDhv0Yya8rgJUBrJcFraMFnETkyRPFlgTLjRGcxAup2RnitwT0tA3Tjy3VrQa0ngH1qgfV4QiswibzqAjO4AWZuQSv6gm28g/VrgzCgAbC1wav8AyRhgfYrhHOtwfJtxTJtwTSvxLBS5uGDujfC6qbLKDHG6anAZu2Bdf1F7W3DtODBu6UBtDGHLnuJ9CQNZ3kQa/bDJz/G6zyCKSrAssd9NkS8co8keoWyeUMwoQIvZ8LiJ8QouQC/aAVwN0Niug61DGArA/gqATuuBKvxRjdzTn66BnZkALpzFneENLvBaaOA9CBAo2uGbGcCYyrB5LmCb2zAcWgA92REJriBpOuAobSArvVCZSCGpKICf3DAp/7Asf2DqKJJvmKA5GNAbDUFpKyEKikDry5BIXsIc38CMrYBpiiGLykA87SBZ81na1DixTK1Sf+vgX9jQrwxwHniRXdvQH9hgq6ygKMuxjS9Ab33AfamAPoogO6Qpb+H9f7BOv3F+rvC92RIIrMBvvKA7L4KvbOC5eMC/7mBMXJMoDSFYOKHo+oAoPtGuDsAa6kK5nZA6ekAe8io7MDiW/10hSJsg3KiAH40gHLS86KHOCyHN2HB7vPFcOhDMWPGK3YJOX2BsiTD9eKBrLKB/SsFe2HC7PDCf/tK6CxCa7UAt79AdC4K771BvapBvOTBbKlB+mOA6+wPfvSCNq/A8PEFvL/Do3gBKKxDLi0Bf/DEPi3PoLHDLbBEZyLGZ+TAl/FsALY7QrIsQrQrAfVgQL47QacwRHXzAzSzhWD/wzIqQHDrg6DgRmrnBCc2gPO0QS6yQfMixrg5ATPhQr69wei+wa/2QX51RPRvwTNnwnUxguCzg799y+IpQ3t3gqW9gWS2hi4HorXC4neAYDPFbiZGPbTBIegA96UBrSDHoyeApidDvfZBcOCJPSvC6XnAsbxL945kIgI1lrrhwOu4Qu84xTKN5DKBLzHDrWlAd+xAtiCDvDrC4Z+yrwQj9UH79Yv/7AG2rAUucAj0/8BtaAI8waWlgHemAmhwRyahwjr+j+S/Sqw/wuShjSl1ByA5AmmjQXNtgLf2hmP0wKL9QWn6Af83By7liSYhAbGnwrxggyaygrHxw2lnAH0pgzRwwXjAdqBAvrrA9+zAbyREpmrHfvGILqAQ4KUAauHFbCeG4fbDa2jFObpD6GAD+DcM7vhKambDtb8CLb9BKvWCJm7IpHVAeaiEu7pBKTNAq6UC8P0F4arEIPHCsbrGtn8FO6vKJWYCI3zHoXGCKrxDPWKCKK7F8mQBoVTvMkXu8AD/5EK/8oBtNQD6qUF/pEJ7MUPs6ACzY8Goc8F6LQIq5QTkosD5poR7JgE+fISrqoCsqwD1d0kgvEVpakMzJkInzr8+xC5qwXktwvb1RzRtwH8nRHr1RmgzgS//RKxgwfLsy2giST6pQSOoAL9GdLZBN/wAdiFCtPRC6GqA7/rEcUSv5cKuDn/7Ab/9gfFsyG4uAn3qgHM3B2+4Beh2QekwQXZqwHnsxC7jQKD4RDIxAemwAKI7wqn6hjP1hWEimauFqHaA534B4GeI4jBBNvdOKa2Ca6uDc6LEa/tBYY0jYUVyIIDgbQUgYUB66ED2t4367cKy4EJ+Ncjh94Dn8cgjZQdnOESy/0Bn+kUhIoBxGyf/wKtmAP0gAu9xwe4sATXrhe1UMqgK6TiBb+PAoiOCc+DA/PcNungDpegJfzaEIstv+9FotsDnPwQ35wCsvEO8/AL44wS9+8InoQG97EPmIQC1O8EydcKu9UHjZ4HrPoD+YUVuQKkrgKgkQ+H7wGnjwLs+SzrlhesmSLL3TL32wi1xB+/xwqpgBXmoArC/Q7JsCOToBSwQI3/BeC8FMa2NOT2C6WzBs3fDNC7AvHsCcO2BfH1Bf69AoKwDKjAEumCBY6VAbi1Ga7tJpOtd8vPEITpKN/ZLtRvsOEX25wOxaAVwOQIlOwShMoF8v8jqI0Zy4UM2PcH+IoKptgQn6oO3fYOnZ0Eq78z0tUDleMNzdIjivcHupwD16sTw80cnY0CjIASsMYYteUGvX2I6x61rwfmpwuj5BXa0AzL0QifiwP0qAPsrQm+gxK8wAu/hgapgzLerwWXqQOWggHqiwuSV8bMFd3XBeynB/6mAZyFE4/wA+j1BrOqCqveB5CBF4imB934Arz2DYaEAvH9OI2wJbnOCcDqFOzoFpy6M46fAoa3Bb2/HdTNBar2HZqbE9ATsJQNrdEK1PIawtsEhr4csMsbubAP5LA8/N4G56kdw/AChosv15YD2fQ2kboJ9uYNhxGU9QLauA2DkQnl4APrzQLC5BufLfDSC6U2s4gb3oUT35sJosAD1Wn1oCOM3A7d9wKLygKZ4wSvjwqT4BShkRGrQIHOFpd17cYGoug82NMG4fQBj/4H8vQPluEj9LEKg7Amx5EMq6IG//UCg8oG+o0HlqcCsUCzxRnjvhf9zhbcxAi82Aq/oQj7pAuI5w2urgfg4gbY9Bvb4AOogQeykx6dbqXDEbpu5/ULqPgDm/wDu5kN3IgB4eMHvIENhuIHsZAF0VzX5AvkoQ35vweZiQ+TjBz87BPilRnItAGFnCqTxRXB6Rq0ugm3wxC8/AbHwQ7Uqgi3mwvOmguBtw2RyCHEpDSMnAzOlR3+rQKw/y3K+ASMoAG0jgfl2hboogzOmhTIyAP4zwGmqBzh8AH4iQODpBTX8RLi2AT2gBDqrw+WigSxwBqmuBT+mgLJ3AKrpwvehCqNggvuvRvpwAyIsAzD0gOOmRSaoCW/1g2/2hHLkAaZqwe9shSshAOM5QmfgQXUyAPwuBipA+nsEP4S9O8H55cyx+sX2d4J3qwNxgev+Qzn6hLhwwakwAH2zTf/8Byb4gyU0gfcqg2vkAf08wrdxgmo5w32Kt/KFLi1Et/TBdnfCsPvC+yPA+qKE+mjA5QXktILwfYGo/sElaAC2I8U4sUH/aUEtH/jzxGF8wSpuSTJrgP3qCDK2gTllB/w2wvYhxqivg/GrAPr8ATWkSOu2xrz/QKVhAyu9BqA6AuwxSPqmg2j3ASk9w2jqAmBhwblS+H/BK3ICvvsAvAUqsUByPAH0IME9awBpcIC59Ml/rAG5ZUF8FOQ9wGc5gj1lyP+cIr+DInpBNe/G7HbG+87loob3+oM17EqhIUIqY8crN0F3vwH5fYPz/4F1/Yj8MEB8MULtm+SvhOm7QTMxhfukAqdtBD8swOy7werywnVuAztrwrynBq7yQSeihXz6APvrwHWmxmE+xeGuwGS8Arw8wGrqRqQ/ArhtA2RxQHb+wWYlRXrqATdign+5wjwuQLge6nZCcu8BdTuAsLTDIyeW6HhGpCuBMT1DJ6zJ/O3CfCBNOX/CaPrBuG0AbytF8noEIP8A8ayBfuvEJXxC5bTAajqFbySCOSlG9fBBOLlB8zwGMrVBfHkBJ2WDIbCEaRr14gBmAGPvyHm+RPV6gTgpgS/iwzBlASSFs+0A6+YDoyLB7L7J/u7HPb/AYJ3nuMFsNsKyLgJuo4dxYQE270DtdQViYgeiHuyyg6jhUqcpQXDuC7K7wfXwwfi0RvGxg3n1AXPLvLEFJXbEKnLLZSfEYroA63zA9DQCajTF6fpCamABP7LDrvVAsHXEt6tCa/fAeP4CYHrBrDVFM9gkY9Lx90BpNMGlPgC86AKndEetPoPj58Hvu8C/IQUymvW1hyRuhSgoArG4QnL4gWL1wjVvwbsxy/66ATa3AXR2DzJlAapwQukugGl0hXElRj6txa33wTt+yLFgQPWqizsP8ODCtO7Eaz+LpvLE5mhDOzCIviOAbCwC9/xB5+/AbGiAZuqBoLKB6C1GafqAbboBraMI8GgAfTMBabyB5uYAsmfApqBCqquCKPAKIzYBZLVD6TmA+mdBpqXBr7oC/HlAdnGBY3kBOzIDczeB+DZCd7qA4W9Ap7jEq3OAZzaCtnWDfyeK/G1BZyKDpCmIqeyHpDMJYzAGuXXFL26CvaXGOnkEfC/Dt5zj7sEifAkqPMIqKMd3Gfv2AH6uAqqqCrOEea7Mqu9CKajKPqQAazwDcS4Ac7pB6PWHbCMEqKIELmdFdnYGKfqCc3dDeGLAZ3SBYjiFrKEAbv6CuK9EP/RA4ruFNn2EL2iCtSXCKTqA5PwApmjFNuBHenVHeKbF4GmBqamGfHRHKCQSo3IJILhIcW9LaB3+MYHpQTfN+mnDOzAB5GyEdnKAZRL0IkTi9QI/a0yidUX4PECzxfqnhXP1QPGszKj8Quu9QOSmgLDmQGy2AXH9ieEggmyrwy05A3MBsP8B9TBAaqdAfuwGdvANb2tApfxELeiDJPxEeqtDu9tq90Wr/srlY0Dko0dtpkfhr4NvJMg/OsLga4QstENnesFvbUWt6cCppUL5Z0Ml6ITmR3qoAntnx739Q2ywx/GabOtG8yKAbKYC86fJp+AIYqqH4mPBMIVg7QQsM0cuR/vlQnryxfpxx2Q6wf/4gm2jAWONLvOEt/vBNalCrexDvrNJab2A9r1BuPhE6WHBKipAandA7++Fu/CAqhKop8BhaoIv/ADiKUB7f4DtrMT7qwFnuMHiuUGx/UK7N8E05MH68YSz4AKk5Mn8oUCvyTjR9SqGruQBc2/BdDjCrxYi7QL3JVCmrQhwIcLzR7M8Smnihz91ALjiALXggXogQuEjwT9vAKmiR2U+BOygA+DevC4FtKCEoi0A7avI6XnGOO4A93SMNS6BvZpn+8H4KcN46owh9QByJML3s4Ukr4Es84HpJIOnMwBuJsC7YgOhNMVkIYDpJwFq7oP6pkLjMwCxq0OobYL1dsIgP4EjULAjASlmQjujQbv8wLU4z2yyzufygOUxwL9whHlygqTqwTOkxWbCOq5VKWFDZvLJebmDeHiEthgkLYKsYMEq/oPyv8Ig4Uk9sAYj5wEhusC88MGnL0OtYgRrb0Pu4wCmJsD+YgI8YwK3uoH1+IB8NEI/JIB9fsX4K8w9nzRoxaitwTrtRrczwzByCzp4grxoQGs8gK74gvdiTbz5gGk3giP5gPopgSukgOTkwWphyObzAHE9guw1Rjx2QmMwCXWsAO4tQiRiQPOtQ/43RnFjw6YzQffwQPx5AP4xQKKhAOCxwvmpgjf9xuTmRX7swKjoASyiBHCnQHW0BSK6g+MpxmayxDFwQz6twvEigeHpgH9/AGdoRbVqwqb0wawyy2akgKqphecjgLp+BOm5AbtwRr/kR2a6wHZ3xCyggGxljXo2w2cvx/q7QO+fYPDAYyzFIitAY6WBtuZDOPLBay/DKy4Er6rAac5yo8biskB/t8Eu6EDjfAcpPoHrOAXspYC57gB/4AMno0CvpUNsMIKscwc2O8K1MQl1N4Tmvo3/vAO9p0LxvAF5c8do/AJpcsSgO4/hdcF68ELoFWTgh7Akg31yxKGqyDt5ATd4AvIhDD9sBC6gEbe9zGG8ALBigPO3ASUsALBR4X1CZKpGfHdCJ+dKJrSD/qWAdjjAc+0BpPmCv6tC9WzDMqKDol+9qELmOEH3PgekM4U4tsFmcwBxqUqvLEpg9gG1cYNsnfl1xDsnBaUygbKwhaljxrfwQqNogGq8Aqh7QPfijypgwbhVfrFG+aSFaazAuezGpwmt9EQ35oZ3fcQ5aUIrqgDnWbUnwfR5QWRowSKywTiuwHjjAL7zxSprRCChQvxsAmz8w+yjXqIhRTFZP2QJtytAfOiBsb2D7bCDoCHCbCDCaOxD/bLK/b1B7n0CobNAoK6CtmDDuuUB6z8A82LFse7Ca6vBOO7KbJjwIYHlc0V96QN6Y0s0bAZycAd4PsNmiOAErSFF7r/G7bEBsLxBIajHfnUB/q3B+y/FOugDarJEKPqCvlZ4e0CxpIjow+e3wiB/gud0xHDgxLRtQzn1weO6gPJvAq1mRnAjyjx0gL4qiOvwxOukwTuhhqBpS/hyATkrBLusRLY4VS8lgPW+QusQI7GA/DJCqpF/KQCwIwGjIUD6e0DgKsl2KwHltAKhI4F68cTgZEKvcoV8KQWxZgevcICj70QrLkHrZoWrMomwo8Zkeg44bwF66kD/26w5CGIhgK68gPXywKJ4Aa7O6idEr7tA7enDsqhHZHWIODPDaffA4qpFOmUBIL1GaSIA92zIdSaMdanA4yKAZwKqrkcpI4E6acB7CGo+RWDygao3AX6qwq61Qi3lBLb9gmfsQeLzw+L0AGsxRa76ATc+Qn/pCa48xzkkB6bQdXbA8iyYp6+QoLHBeipAruuBd3hHpnbDYGdHeCQLpuEAeiTFpjNB4T0Cd60KtnOBabnCqGlF+LiGpOUCf7aDMLOAYfhCe+lAY2AIrq/CPcOp/wB5YQM8uEC4tET2tAPjuwBnJAwzq8CsaMFuqAEvKwBjdghp5QB6oMHgWWdwAP7gw604AT1yQOsoReslgT95xyq5BaNwBibrxvL8AOOmAfmFYeKA7W0A/OUA5j2HpDgAo3bE8qdBNT4A4aMCJXvBe28Bej7AZLkF6nDAoTGFci+FMawAuyhNvCLBpiOBKaCB/e1If+/M4WBHffQBpv9F+a/AdDYEpyHIq24BqykAZqICoGqApmvEeDHB6+gFJ3nH6aWKeG5DYHXFJvhFuzpMtXqDsnacpr2Con3AfrANrCHIKr8Aqr6AcWIAerkF4m+C5a7DLixGqKsGaDOE5GDD7eJBr3fF+/+GJyuH6zVAa6GObOKA+/TAt3gBIy6B+yHEfXoD+XxBLy+IMb9GOPMCtD9Edb7ENQ26twFlsEQ902/gxGxyzmf0ATd4QPjpwu5/Q/n6wqn9QiG8w2DkgOigTHrkUL9ngmcoAHjpgaewxmTwRL5buzZBpmmN58tmNICnf8R8dgK7sYGi7QFyf4G2aYK664Rqb0KxCWVuArGtAWg7RmBsBiUqgu5swKPygasrQm67hLphQuGrAvW5g/W9QTljwX/0gmjnhOuowLq+xTV2Qvh0AatpRnetALqzgWs+wGXpgjLkgLK7wThrTjmmSeX2AvJswS2xwr+thPdL/qYDtjLFeyADJO3CcvKAcbXBODPCK9vqKUN3vkN84sCvIICiMYQ4bcJmfolpZQCzZQchKIDtuQCtqYQgs0LxfEnx+8JlagKhewIm7gRn58I/cEI8tcDj2P02Ti/2QO+6wXCogPNjwPMwQenyAf1rhCKkBitowed0xCrngqSoAnI3EfJiwqPiAG7iAvKxhP7+BSM3iahsRKmohXnhBO3+ynvpCaliAKFQ4SiFurID77zCOD6EbnABd+GAuvWD7unK9POCZqtD7zrDPWeBaCTENGhA5ecCNsF35kw5LkU9rIC08cT+5EDwgHI6Aik2xXxghCssxPCRvO/FdCkTf7tB4uIIJ8Z+ZsQjMEX+6YBoOYEz48T9JgBru8OtOYDgNAd5qca8aQUvtUK89cExqAC2K4HlaUF45QKreUQt60dmzGC3gvK3gK/mQLxlwbG3xWj5QGgkBH96Qn9sWOVvAyugALvhxK86gSooSa66guMRLaWDZTmCdFczZcQzPMBpsQisgrMvhbRuAmDiRyRpA7X8AOfIqjVAaAekboC/vsJ0NIC5vYBofQU888QzJgC/asistEgr5UIkvwJwpJB4vwCmMEJtqcF1YgGqMEK2asG0bQ2v+UNy4YKy91H4N0I9esLj/wSwNAIoLgGsocSiMEEyO0B+JYHrt4DzuELmJIhhM0S67gcyYQNv/oM7MENp68OvdEEls0U1/sQv8wL+aALoSiyxAGKnRmDrTDf7wrtqQTV4wrbzhPuvwOBuxKOOOxviZobgdAL0YEItOcHhfoLnuEEwvsLis0Gmv0Bza4Ssf4TkJUGrJsDsKkZ0KoC3MQLhOEOkNAO5K8OwYIZr4sWjc4Ivb85rb9lq7YSpZYBjugBk/RJ75Ih0t4tp+1G9MkKzowPqZoZjKkH85kUwJkIid8CjcUdwcIOrvsO0K4S688Kja8G8e4F0Poa3rUk3jGR4QTZzwabZZ7PNs6wFPu3AdHBDqIYpbsUgtMK+8kKhqgb9DG3A6myDfYwzIYDposC2PgJ3o0NwLgfjMkO1+cHnbcHiI0I4bkEgqwQ7iuM5QeB6wavsgKu5AOIvgbG/w7RijfggQXD6xOGrCaUkwGM+ArB1QTtpwnG1AOPlRuM0QGNnAWquRPyzSD4zAmPDPOuAfKKE53mCMDPIK2AIdP/EeGtG9u8CPDbGcKaDselAZLoGfDiEoAhn/MCh9oL1rMC68kTyaQn5/gGqf4Kt4sxmQ21kRqeoQmYkBn+pxX71wHqbJzkG/raCOTgA420A6ClBuOIC56mB4WzBs3xCpHiF4y7DonyBpj8FKzjD/ybCpPpH9f8EIiIAdCyDZmyEbjABbWLBY/wEtWmHNlwo9UM2Z8FgNUOns0By8IO6JsYq6AJzskG6vES/ecPlPIGlogRotAD8cQEnsMRgb8KkIcCnrFEo94O7+8MiYAW18gJn8wPk5wCnZoC4mO64BCauhHZwAiboRfpzAORwQKElAjP+gS26gap3QamuRDDvgHFxA2R0x3yjzPxsBafyhH6mQPDOavuH7P7CfrBBsT8C5v9BPTWKdXGFIqtF+PGCceEC7fPFOeBJNf1D6SgAtTHDPecCoOjYbemDbn2CI3jHbTFB+OIFeXPFb7VCql8xNYNpvQNr4gC7/YNiL4HucQB08sJj9YclLoI4LYB6O8M9akCkfIN2bEB29kN3uUI3Y8Ju6Ad48sPrvgM8/0DrbwduqVPxKwkkOwt/vQEv4cgutYQ9Z8a6sAM04gs1bEb0MgNmY8Kmb8CpLkFhrAJiaAHpoQmt78nv+UCobUMscoR67Mam8YDorcChJ0QlLtd+awPnvUCreII5v4Sv+4kjHGigALKt0aU7AyFpwX7ogXvugbCtR6fxQ/k8Qz61QLpoAGlMtDXCeaYEp+jArOMH9nGQNn5BrfcH73yEZL3A6roKfCxZo+6A5zjAvfgA5CEM6PGAbq8JbfHBZ27AePtHuG0CJHWFbuLQ7CSEuKmB9CXDYjuC+HiBaCSDdOWA/uPMfzIBYDQAtK+CKqPGLOUF+Bu+MAMgJQOjd0HnOcLpLQR6o8G3ZgEntMH8e8K2qQQi9AU4wGBzA7BxQmbxwKUwgTaMMzMFcr8BovtCIaaGaGACeP0HdXjBLL0BKtc3+8o/NEEnroDv4AN1OwN4JAK2OUNoN0C3wb14wGfigL1iwyypwKYmAyr8QWuaOSHC4iLGLW/TKHWG5P4BJOuKcfDDISaDKPTWPOGO82pBeaED+XOAb6mGOH7MYOdD/OHIajsM8L5D4CMCMimBsaTCpqHB+igJabRCrvhGqDmKOLsIZqJDLyNAoriP+q+AsuoAvqrJf3lBeLfAabvEojuGtyqKNH4D7HHFLH6F7HFB72eA+WmGezbC+vQE7bjBNu5B565E5+MIaeTD/qeBtK0CdrtGeDuGJ+lAq/3FfquCefZAp29Cce4AYSXBOjDItKlEOiHFbPINd/qAo7MAa7gMZfbBPXeAuj+BNryEfbIOMLcDJHmAozWEbXMEoW8BPiQDsOyC6r4DPTxHpLkDJPfEuuJEKTiEa3IKISkBoHxJMuPEqbuBPtCi7Eu7ewNg+MOoL0S9qYm36MgqfAWoLgJ+a8Glp5R1Wnb3ALL3RDV4AnQgx6L6Aqm/hjnpzG+ngbd7QnFgw6L/wPX0TPYvBqdywaruxaU3Qe7+ReCjgL9vQLDsg3s1wmcHcDWDuzXFZrfBt/QBJCNFsORPefcBLvIMv+fKeC9P//jDoCDAcpwo8gPur0FiJYFoqAPnpoVs/IDyLo4kDibnzjEggbqngiOuAL4qwfBV4/9CvytDOfmJKyGDOyZFqvPEsKlCb/WAqHZCKnUEu7uCPLZA+L+ONu7HLnODITzBenQA5W0Fe2TBIrdAcm/G5qHCOccydoTwdcPy6oKrsAsuswGs/cNtrsdhpAp174l1Z8Uh6EWs7IGw6AP1sEDpeUEsooJ8eoK+NIJ2sMG1cQM99oD3K8N6eYDzf8Om4kE64MZ4o4FtPIcjqoT3O0IiMESqewNyjyszAXS/QSBsA6B5ge/pRe0pBjCyATQvQzs3wivhBiAgQmqiAeohQHAwQHzvQep8wfhsBnXqR2TywvQ2wLepQLkph2gpyy9qwns4A+3ygKEhhTvow7vgROWvAKLqwu42wKt7Qzc4we1qQbFkxL3xBunmAL41QSJ8ASv9gLisAPS8AOCjA2B2BTzgB69oSfvzgSYgiaWozW4+yf4hQKe9wPXxxPM6gXX0xP4rAPxogTOnQezyQfQtgbX5xyY+wjsuAeu/AzEoQ3T8CaRyiLpMIGLFuyZBOflAp3ODqyvB6rZFoWbIr/pF5veCdqUBJ+rBYWjA+/zHu/BFqXVBpimDvm1Ad3xBYmcGYalD5bMB/W1AdLTEbCYAfq0A5uRCIiyBejhA4q6FM/hBfeOCc3dCaTlCoyoHIiUC+7dHMb3HeHJBKBntbAXlI8DuaAc29MQ1+8G1MsM+/QL64Af4OQwm/IH0eEE+5QG49gLsdAE6AqPiQmvrwjgx1CCvj/YhBXdthjGpR/tgBOWvwKbpgzkxQylpgSDGbLNEZ/mA4v6IqSIJb6NCeP5AqqNBaOIAsqsCsveBeboBbLAFKGlFI+SCcCACP+JGozvHNGhAbXsAbfSA5TSBI7dBOvgKLK1Hrz7BL6gBbs92yLY0QjfmRrnjBePgQS0rAewqxf7iBLXZKCHA+bGAZ6kDPmOQeexCfKkCJ+9HL23AdqmBYDdC+y3As6nBJ2UDuLIDJidAsHzDsK7GcmyEYzoFf/YDOX4AZOAA4jlLr6SDNz6FJDICMmUAvXoJduUB5MI14gZj6Qlz5sevZgE2NcIufQagfIOs5gLuZsE9SXJL4mNAYLBDZryBrTfEcC7FotWs+op7qIJ7sUJou8Bo68Wz6oG5oMnpuYM8LUPlpgN+b4D/9wBieoRoN4LzJ0EhroqkJEvpK0Z1KMBr/kI94MGp6Uf+MMX148Lj4gTgMoahP0dvoQK2e0Pr/YH/f4ysqcDtJ4syuwFoL4O28sWl7EH+ZkE9rYHpo4EnZsQvNgFm8ESv/cCkYcHkKAZsdcE9p4BpJklhw+09Q/QjwS7sw3KvgW6shKJ9Q7Hrwr65yX4sAerhxWD3BHg8SSW2C7K8QTn/Q3zxAuejRDkmQjEmQTa9gKCIPWUAb+UJKCPGJ7uIJ2TCtq3B+TLE/OUBO+DLp7TBMTwFuWFBvv8FrvXQPLkKvQ7+pUVuK0V/NwYpdIO4rQH+hzeI5PuBcWLF73lA6o38sQDpesSlNIJupAByrUR4vME2cAMt6kD8bMMnLEajOIP4dMn/aMRkoACsKAwg4ML6W/HOode+KMXuPQIyKoZ7vIExdAJqrMGg/wNgcwti8ME5dQBjrEEqMcJ+6YGm94Wzf0H2JIRm+sEtbUE3JAkgY0GwdoP9eYIltgVmo8Fj7EEtLcO69oFlLgVgsoHm+s9z4II9cBeoYII+L8gy4EQnKsXkdsGmPILj54CqM0B4boCuF+eqQW3zwbC4xiEjxbtrRahUI8avLYMu7gM7/Aoi4oLvswDpIw1vKYOn8EKgo4a+P4BtNUN3eYBnIsO7c8Fw7UMmOgOlpEFlLABrdEEk5gOgP8u0ZEUrKwH3pcO6q8K0rAK9IsTkqck0tUi2LoGhtAcl4IykqsEp6FB/+oD4JoHn5oBrYoVzegEjfoTv4Yp4IkTrLsk360K3JURhoQQzv4O89gHy9QHl/MLyb0LhIgt0pMI5YMNzpBbsvkCxbMVt7UGv2OkgAvzoQzUxxe/wAOGoQv7ugr8vQ3Rgxy54AOn2wSs6hvIwQakhTXFgw2G3gil+A/f0wbC7ASE+wS2L+LNDaiUA/SNGYW6ENzDJOmBA9nkIvesD6lo6+IH5scTo5QFzZEK8M8GzfUJ3agS19k8iLMOuNcl9qoIpqUa9xC6pw70hQahlBGa5RWG+x3zvAnznQLIiBG73R/9ugfISo2QBaW0DP/XBIdcuoQXwcsKrosBvLwIqOwBztwFx5wIkagc394Cwt4C/6AH1K0KiusF+e4M9JEou+kRx6cNsrAcvNsChoEKzju0rByBnwXt4AK8ZYOnF/bHENijDrLpBsStD++3CN+kLd+cFb9Ji8YE87MjyKgXhcYYk9IigNUQpcwElrgUkeMG6LEUtfpb74YBz5kC+c8YiMci2owBo6Ajt7k2qvkCg+YB63aTwgOHwhXg7AXkwQeDwwjG+wXAsw6BjwLJ8gvExCSQqQLO5gyGlQiKuAi61ASzvDbd6SiMgjXmaeerAbWiBtGPTcjIAdyyB7aiDLi7AuyoBp64Mvb7Dp7mG/hWtPEGnMoNlOQa9pQLywjRhwH6gQSJngHbuBnshwX88AGPlgSQpSH0nRqQ6wO+f4ycCfuUGbKhG+vBGMilGuIJpxjLnRmBtwf90wacvgPInAbZgQTjlS/cxyGariia7xO1nwzdoRLr9QqizgiI3AndgA6j5Q3d1BLI9RnVkALJxAbVjQmG0w+RkQ3t+Qm/gQiw3A3A4xCEzASXqxyd3hzjmALl/Q280xu82AfE2xPN0yO81QHvgi3fzAOW0wy79EnzoiHx6hDc1AXNzgWhmgS6xhPaqSexwAKI0BP4rC/S8hLTuB6yxAHF5gS8xBTy2Avm7wPaOflkyaQHpKcGkpoSjEW12wiC0wb2qgWFHN3fAZf9Eu7iAeKcC+HEGMaZJIzmBdjHFbrTA7HrBsPCAuu8A6vhBfX7Bob7B7KSEevbG+vCA621A9n6C9OECfO4FcbyENnWDpKpIb2oA5DQG+mbH5PEFNmKAsKWCqfTDaGjIbHdBeiyDIuVF9+wBZHKHcSmA73tBrHrB/+FBYvNDf/iFPalApbwFZPnE+acCc+5Ls/JAaqlC9SfCbK4F+nkAbH8B6G3HNHWE/f6KbLHDJX3JM/NB5fOA53lIuzFA9iuB8WiAcC0CvG/JcdU0rQEle0M1vAQotkJv7UF3NoNz4oB3fIN50LZ4BO6gwqqxAODsQmLtwjI/STTpQT7wQ27owLyyCWW3AGGmC3kiAbh2QHquAfN1hv1oAmixwKg8gGsnA2U7jHJhgTjhQnJrQPVszibqA6vngLrnwPcuSXYkAy6vwi63Ar+6xK11QHycrC4JPWOLK2FAraFJcOICMmCAbCEAY70BvnYH6bWGfxt2MMI68sIgtkHwJIW7LYYkbQQ9Og5tMoRnKYKxKcVtbEH5vwD/cMKo4AO5dwPsqEE/YsI64EKuIALusYBkrUb+kqQlwXd4Bz1xQjyHJeKA5aeEdA/mocW91WHqBCQbqP6Bt2ZDqSyBK3KQ+a2Cf+5B5PmBpGeB5HIA9SqC6/ERJW1CfCXE4LdBafENJyDA/iwDZW/AubwFI+cEKboB5aMCqTdDPDDKJ3oCI6FCvyLBeDhErbvHoKTEswtwxjVkSPF1QOgvQrdyQ/0wAaI8hja4xDMzQPKqjeQsBrcvhf9swKssSzDgj3JhAHgrAXI4w2JrAvRrQKUmxPomAz+2gST3wnU1QPCxRCfgAbd8AGTuGaS0AG7uAGtgwXi+AW25hG4yASv8AHFGr5B978Cw/8EktUZ5+UNjX2R9hn+1hys8Aj9ywKv6waIvA+s9QGGtgnlkiqAlgOA/wPOsyiTjSurvCPUgTnYjAKP5wmzuwmynxWtxCbvvAHhuA7WshKBrAy99QeF+hnI1Qil1wSt9RrAzAvp4Qja/w2Q10vpvgaM4g7DgxCxmxkHz4MNucAJqdESme4RkekC9JQMpdkGnuIC44o90dsd6JIHp7kd/bxk+4kC2xnZlg6+3R725wmED/rAAsPYEP1j55QM3HTn5yqQ/AmU2gmDmS6n+Af3zw6ZswfMtASJMam1AdjIErOTBMj2L92aBeKnJM8G0NILlbxWmMEI4r8J7IYJvdIW3oMh48EG/YUB/s4XoKoH94EEiN0F24IUivkT4aAe/rMPtM4j24EB6KQE+68CuWra6kW05wvGqwSALausIIXACdmcBP2YDJbqAsLcCbroA52bAf3OErLgFOBP38EItM4EktYKzboBu4cVr/EJ8r4LzugG4ZEV6ZYD4ZAE6+YCyuAbseQaisIBxMw6+tEK49kE1LECwakQ9LUV9tQdpKYC0NMB+yPd7CiTsiichRGU0xfD5wfm/gK/hAaKthfG0BXjiAiWvh6xrQ3LmAnJhxT7vAX/pwGZtB/Diw/QgCDDiAjV7QnOLvKKDdSrDLuGCq6NBZu8COL1H/vHBuz8B7+tENS9K8DzF73cB4f4EOqOBMSxA8LwAqTPduXgBMWkC9yaCNDiAavYaKCUDf3jD9uYBPTeGoysBvvlBYmoBK/4GcqECoLxGJTzGIyOCqShBJvdApXsBtygGt/rAp4shb4IqeQXmPUI/qULHoz6BZ3RIavAEMzqDdULlYZeu5IPjoIMs/UKpe4e+IsIh/Anq6oF2u8NpMMCvbcbi8gzzIUO2sMmju8EnG6ktTqjsAKd6BSX+Ar7hAGV0gS2lwvdT6E664YYkfAdxIUYlY4et1zarwHlpSTD2iLs2A3b6g35lwXRtwuo1QToygOW7AOc9QyyGu2fAev4HJriDs6FFe/CCc+ZCZOjCP2BGr+yAt+1Bv2FEdaOBdrfBvnlCavPJNe2EviHA7WXIKmUCcydDKeyAY14kIgN04YmysQPve5RjPIrxJcExIkK82rnngyv5hj5wQ6TvUeUiRD+ixKOnwPkqgaokQz/4AmY1Tad+B7Jiibbnhax2BzL1wLdwxS3vRb+nhKNwTDjN6zRFuDUCZexDJ/YAYmfLMH5BbeLA8iAAcXtCdi3Afn1S86ODPDLP4OvCrGcEbKEA+y3CKK3Bt6OAcPlBvPcCvCNCIL1A97KF6fJCovXGLqEEtioLrvXCbsw/rgc240TlvcEypMH3s0IupwI7+kW7P8HqGuahS2n7jDamRehlQSW3AHlPuXPEI7YDI+pBLHCIKP+BYmtG/GLCOvVAfWuDrKwAvGlFcLMAvOYCfyTAcfoBMv9GNrwHrrACILXA+GbWfC4EIWfHvPhAb3PEfabFoKaAbuVE9DuB6nXA9CjHNKICaCAB5uMD+nGCa+RBb6pKY3NB7fnEYKgBbG3ApMLr8gG9uwOi7UT/Kwbl/YdhDig1Qn54QeyuQHc2APEzQLp9QSquifAlgXglxOgzgGGvQbXsxbRnASK4QeEwQHYyDDlgRfhghbngg6tMbrNCvjGCoe9ArW0FNi4GpO0CcKhBpnwBN+oA6XUFPzSAd4X0pgawOAF4MINv5QJiVLa9gPNjxDAqQe/Ze98gYsw/YgS1cIW2OANzlzRmweGf7+QB+3xBtm7D9rgBo+2BuiHBZtX7hn/pQHf0gn5pQGJmgvh8w6ajwmJoAf/6x+IPYyVCrTQG6ajAv/cHc7JB8IPysMStvAV8ssYnIoSr+Yg2YoYo7Yc/cANmbID7FexlhihZ7rcA/VhoYI25uEc8sIMydYUxxPprgHx6ALclBfu9R3W4iqWpwG6ky281gW5rQjwvgSczQiO4y++wRGX/AuCTfzxH4F0yswCrLETjrIQjIgV/K0alf0FgMkG0NEP1+AG+vAEqQG76xP9pw/DhwqAyQLLnwPj1AzJ5AKdkQq3Ld+hA87kDP5qm/4qvc4Eq+AU+I4Ns6IJkNIH55gE+QGGjUKjmh/sowKFmwzulQb+pgip6APmqALVpRL28zOquxaQvQegmQKekAPzqwiLlAmV6Aup3gqZ3wTl1QLO0ATujwKbixb3+gi49Bjp6AWq6gjt2gSzzAqR3wLkyQjj9wH9uCSN5hvVvQ6s/ATXuAWw+gfS/y3mmQ+JjwuLkw776AevogXvtAf8viCHhw3/zQGj3QTiixrp4Qfumgvx3x7/oBnB3AmP2AyZvBv8iCKVlgWKUPitG4mEAeb6C8OaA460B6HgPpnEKJ2HEryWEb7PC/THDunHBfjrFdnzA6n3A/CCB+p6t+MCk2/WogXztAPD/gPqmQi6gwveULaeKuxEvr4FqdUqsNgKkTHWzASVqSqb7QGdnB7e2SerlRaZ7xnJvwfT9wWLjgOFtgSwtQK8xw31pgqYnwPvxxLzsRuvrBOLyASoiwnSL/rTAvMZr7cXykeTkA7HmA34/Q6Mxgf4gDnGuxKKmg+LpQHk6QS+rBPuwAbTjwi2xAvlhSekXOmmKeLuH/7oB676CaWiCNXhG7XTCdfTAa0M/usTtIUSko4b2PQHgdcghJQEo50TntEKx8EIgdIZ7NIHtBuUd5/7Gt3SBo7tHPLwAsf2COiZCs/jKMLLAdTGFrWhG56HBYjSEI67F8fBAsTxB+6lCsLsAtHIIbXzCv6+Ap7iHZ+ZIbW8CbvPDe/mBsOtAbegF+rABskJzaQFt4cQuZQBqK8ixY0e8YQR57EBiokOrbAZl8A95vUJjoQm2oUE4LgPtM0g1o8d+sMH7YsPjtQIp6kKmuED4fITzp0YqKEGy7sOkZoGucYD5McbluQRqLcBqq8B0KQJs/gZiZ0Y2bATof8QrqkLg4gVrs5S88EK/JYdldYG9xuQ1gz6xxO7sAXJ/ymP0QO3ogmm4h2+vAn0rRTtyAjMigeV0zmN3AeI0w3akAPWuBf+9A27vQHVngWFlhumkgf0lwzhqAPyvQeI6BL6/BG2mAy6yBCj6xTt7wXjU66OFOqXHdPBAfOHA9vvA8CYF6b5Cbm/FtyQA6a4BfqtHfq0HNiCArXJCJCMAfIkmyGRcoj8B7GoHdy/KoLMCuGzC4bZBrC1Cv7NA8PcDZlh8tsS4O4EqLgPwLoPnY0G0L8K3YsV8PEL/cIbuYkbkI0Elo8K1IwjjbME3tgEmL8S5t4N5fsO+bQpmkXCnR+WqD7hqw668A/f1ALw5zbn+QH04lG5L8PxAaWRDY2cB4G0A4HOC509jKkb6tMbk60D26YIrZ0Eq8Yv8+wUwvMZ9PIL70SdlAmB5RKy1Qa2xw7cggL0lgGF3QTmpwXGhwKN5BqRhxKpvymOLr3YE5mYGcznCa6iHNiaBYzUAbLMG52NCMohup4C6Uj58wLgnQXU3gSY3BGU8QOSkgSK2iDV0QitgRfTXNGPIO6IB9H7BMDtAfmeEYPAFszSHOanDN69AanQB6iRBe+/F7/FBbqlCbP2Dc7TDsuRCdfoOd3IA+26BbfaGtK2D8KlEqS6B4LrGuFbmrANuK8DkuMEhfEWhJ0V2DPYhiTn5wGYbIpXwocOnZ8I6tsBltsEwv0ayLIco7AKkcAEmvkC5o0B7M0FhtEH+N8Kn70E560RrJQNuIwF+asx3v9MveAB9pUgzqQJkJ0I28ItmdsBzcwHzrElof8FsM0b0Okm/b4SiOAhh8cIxaUJnZgnlqAKgeEc88Ma3OYLnJAG+HDApgy9swXDgw7JgAqr7QaalinZqgfgvxGXwQKVgQ2PxiSr/j/lxwPCzwmYoAXdd6rgBeAt/u4vl8YE47kF/4EI0aMEvK0O2YcQqNsctrYBxL8Iv68Yr8IJ7YAGmLwBkP0GlqUBx4QL6a0El6UV8IgKxmrS8x2cohX3rBn6iQnmsQXX0wTX5BO53izb1ALV+QuRkAik3RfWZPCnMfEnzcsH0hzekQqGywSxiwiv2wTNiAXj6wWqkQTH0wTBsgjB6gzExRuPtg7OvQvCoRXUP/nZEqd+g+kJvMkl5L8W+PQBmYIBlYUgo/0fnJYDrtkHraAVk68G8Qfdhh6N4w7NpAP00x2s5weUrw2EoC23iw/t1BS5kgPIvgfdrymOgAPj6RjFvgvBjUyCtiyV4hLotBSI0C3IiQT4oAP7qAS/wi2OyAjvqwjJ0Ai36w7/yh7WlwLpYovdEcrXEPz8ApaSHKwTxtkC1s8GkpYZ7L4syqkb5jv0/QudjgTj1wH3ihf+mwbfrQOXzwux0gjZjBuArQLJowGekyW4a9OcD66cAtzVE7B32cYRtIcal9sFmrYQ+ZACnvkLpJ0F4IEF8YcJz9wChadvlUTNrBPmigbCrAmaKOqMAd20EKpMgpEZ1ZcB+23ahga9rwjhxhuXS9ahA9ha2Y8H2rMyos4GmcYC+toE/v8E7bwGgZUDlqIEp7gJ9sQWi+oDsv4F36wFi5kN958XqYoRkqIDxp44mtkN/LYc9MIBurU3zIcHoLY1mpcTzacUuv0R5f4RhMIGhYYM/OgG4P42xL0NyRqGtQG1xhCKnQTGkRv1xAufoRObtS7/+kDg9wmg5AWG5w/WkgGvoimX2wSBuAO7pAjWNJf1EdPAF/ewHLW5BJbQB8vWD+TiE+OtGtO7DIaHT/L2Catux4Qc/7FF0MAH2qIUo7EBitwJo7ECzYUHpe0b6PAP49wDkZEI5akQneEr8qogub8H1dcYjKsDt4sDvfYj+bUz2+0M5cYIsJAQ9a0Q0RSUowe9VueuGMjOJdiMAt909/QNzcAH49UM+8AJke8U3ZsJ3bYY69E61Y0BmOQHz5IIpYgJ7s46kOEK207GpwrT4w761xX7rCXW4ArVjxnvpy7EvxDTog/Kywrjowz8vAS9owSB7hmEkwj7tQncnw+VrgbvphyE1QqY1wTY/gn60gSQ0BCfmQa9tCba8QeMmRHL4gSHxBfGnQSAuAfL+BSzqgj39RywohevhQjmignb+AWjrgnGxweomg34rwOEzA6+tgW7qwHVlwj2uBb1zQnHiyaTiweabtjJBMWvB4idBaimILy2AaW/DJOaA+/9C/GEAuS4AbDdEeivBPmcG++KErrAAe2JEffjE63aFYImpOgInL4TwuYgv7dhpMpFt+YHyLserTrb1RuuzxW4ogTKwQKv3QfVnxCJgwHnBs6BCObeAbn6FPyYAbrBBrSAA9OcJZT3D5i1BcOrGMDjB6eKA+GwD7rYAb7VEq7EDdSfFOH4CYXaEsfSAs+CH/Ia3KAUkLIDkNsEpOYLoNsVp5kO4ooUodA19NAJq7Yi7JgJ1foBsKAcsc0IsusU5OMgg74JldAYsOY/j/YTipYCpNoQ264D2yPnqRq9Z9bLFpjVEd/AHqzCFc/FELPtE/RWkdEFgscDjv0MnfQF7PwLrZICgrgBgKcO2OsRmt8E14MHnPIWtKIRjK8F5bgE/9wRoOQGoOQFwZAF14EblvwQsckLg8gb7e8C/IAF840C3/QTq4gRrJUU6oYF7KEHotAD3JUO76oI/cUIlYUHzPkEy8sh3YYXsrkGt4Mauoce9s0Hxb0JgbUHwp0T85QKl9Ijr68E0BT/yyuTSMltp5ERndYDgfkHjq0D2+0N64wQkdMNlHDNrQfvlA/h7BTr9iqLzgOvnAHPqx/B0zSYvAjpjR2zrQLbxSD+yhHIkgeDpgKOl1zi6Q6G3QLU6QLCjR+e3R2dygX9UZjOAY7mI9H0BazZFoSJB9aSDrAy4IcVnrYN+eUB89AHmc0J3uMCvqwE9MIK38snpZgR9N0elM4Bs9YC61XqpwHD0BC4oQjeogmahj+SkgPrgxezgAHE+hvylgmG7QGpoQ7YwArN6A2u/SeZCYmABO6PDoHPBOBe0+UDickCtW+qhQXj3wqangPwgA33iQ+t+yfe/AnL7gOEghijtg2h9webwgO0/ALj8BOE4B3H6wHnkxvQshO0Fdr7A8OSAYTrB97eA4ylAdywDe/BBtHYHKbJBPrXELLGEPCVFpDlFaqfHZ62DOTQB9SEHenWCe6jDqXNCfnqA+wxzOoI7qAZv4oC5+kZr/cF664BhcMQnaYToNkW3LEDjqQL0rNCnJoF8IQFgMgHpO4H940WuLcgpuwFvUypvjbcnxbKpgaXSubaAp6hIYvaFKk9z/gnyrUCpNQB6ZAoh6gLv4MLoYUFpI0P4OYB0awCuPkChdEWo50GoYY1waAK8YkYq4Qb/ucEprYVtOQg48oOvcANqM4S09Ax5ZoPqcQDiuUFst8CmP8O3bcD2vwN8Mc9g8cBxJ0DjvwVh54ElIwF9+0N26wo+t0Uk+4Ek5Yxy64EleIEt9gR9NcM3aYLn7IFwtgT4NgI24QT078Hyp0a1MsUlJAH0tQL2bonzZIHy50Bw44H1J4Qy70Hs/8E4MYM38wKn+wG+6IbxNQFqIwCmPwZz6cQg6cqsJ4HhrgV8u8BxWXHoEuptgSdrgnA+zjm3hSYtgaX0wTo0xejhSfHnBzHvB79jgHx0QSlowyZrECWmxGblAWd1QWQohzKqALbhg66qA2NuhH3zR7Q2hD/uhnusAOQkhPP7SHxmgWXwAX3uAr60Q6vrguxxRjwnAqg/geFpTqd8gLInQLStiKu4Rb6oAmkpgP+ngK6rxegxxqk1DDNlwKG9geAoAGFllC+tiXn+gnOrAn9Zrf6JszZPoWHAtCMEefDBKWfKemiCIKaA6L0BPTzCPjzLO7AHvGFAsa7A7LwBsq9D9+OCOekArGaP+jIBunIDOmoBNrpDrnrDpKrBNfJGa+qBODwDOoy9sQFsp4X7fYgvZENxs4Y8fIEmoUd5v0F2PM4ufoFk6wfpswGs+Ub568T4NwK6ekM0awEjoQIx7UK/NYY2+gD+tIwo/YCkuoaoc060osH3pcM3s8S1/EKoKMMw6QB+N8BtcgQ9MAR49cV6sQimPAGxsoMpzfqpQnEuwz2gwiCsi6awQW/lxqOzwm0sBPstATnxgTsg0LU6QzVyjDTogK+3wPAuxKw2CLRggL69Qu/ih2f5Ra7lSbq2wOy5g+wwg+bgwTkyCL/RIa6IKepComaEKa7EteyL/ugD/zjEc7XCdSTEJbRA5XrFbiXBoyIA8e8EM+jH8uACPDkQorcE5uKCuSPCsuBBJPVBJEioew623P+1BWRqASk1wHx5QTJGr7cFOnAA5r6BbmlFaGRGvX7Ab2JCbbvA5XgAjK2lw3b9AuG+h3AqQiHjgXM4xP22QyR1gSeyogBivcdnrYCl48P56cDjac22dooxtMK6JAZyYkekfIJ+5AC2aUN2b0QkZkGyeYftpMT1Lg5gdAVjcIBlc8E/rEIjqwPl/ogyuEH9boKiekO35I9kvAW1ewRhd0DirgPv/sB2dsJx44FicgDiMsKtb8K79EKspMQn/kbk+8F0qAOtqsFmsoIz4UUr44DzL8cnosKzNAQj7AH9/MEz7QUrsQH39MS+40DhY8Im/0It4gCwLoR584D2/QF/sgf1PoDiKUJ/rIY6rcc3/QB/psFxdkKmeEa/pMN/dwF9F7z1gyWmBPD2QSHnAPZAZ61HurgHraiAdyZDPPTNp+3CdOzBPzVO7/GB99x9/khp40B4KgC9UmqtQnc7AfTG9bjJczPCvdKh9AHxOkjtpoboJEQyZcIgIUF684H9LEQ5/YJiKMImpge66oIu94T98wLotEE07MR7qEO0IwByZcWxZ8DzNAUi+Ar1ccthpgE6Y8Bj94F77oCwuEmrakGquAYhAT2jwKR1xnuqgiBugeI8QLimgjaOrv1AsLkAdeVAvToIKekJ+qNCvL6AYmuAuz7B4D+BujUDMWMFMDBBducKr35IPSBHJTsHtT6KPm4At/FBuWfBJm8DY/+GOLUFYuGAaOlIPW7AbCZCb25F8rZBcj7HsKmB7jQBKiXGKcTtO8fyoQa3ecf+rAIj+ctr8AD1sYX+rcE0dIBmpoEhaoV17oEw+sM2ooVya8I58UShbwNt+wC3LEI7cER6M8dxIAFybsC7sgMjXeX1BD25hDeiRmo9QOenh3h4HOywSiNlgei8BibjQeolAzULfWhBqTdHZnOFZ2TGbORCOauS96LAb7KF9rHEPOLDu6aAbmNF+OVCdbVCuKvBpjzA6bGBfq0AsJ+jpsUo5Iw9d4++8UX5ZYQiogDh+UGn5YI0LwK4ukQ36g6/oQuy9QCiJMJtqoJ4twB7pwIu8kXoPEFkaIZkv4Fx+EDtJwo8aYJ4O8Hqt0M0L4L8ugDxcQM9c4CmWyT+ALaKbyIAsHtCMuzB6XQHs6jBs+sE8imCp3eGfvIEv6YB+KHD8rGAdRlj98UqtIF/uovkGa20AzZsQbwqAWslh+Q0SeKukiL5wLNljCNvwPLhQPupCDyjAHBjgPfwyKNIPWlGN1Tl7UDrpwOmQiQsjHOhwm+jxaehBnGhgHNJf7yFO6LBI3xDqygBqe8GOC5G+DyBb/rA4O4CbnQEtLrBtjsAfuIDKG9CN6jAamtBezKCJXMEtqSA7XbAv+XBNGDBc6dFKHKGNXcTMjpDpuRBbNYuNsgwrkIy/oKsfQHsdME4MAW4JMDpokD5ewDvLYN7cEYuf0k37AK48IIr8oGl+IEj6cQ5+QqvIgY9IAJ6pcG0cQex58QuKIMvu8C5tsBmt8FkYAFzoAHsuE0vOYKiqAE4NAB8NgB15oO8scF4tAI35EFxsEhreAmnvQEuKwI3fgBwJ4FwpUbwvkMxfYY/5IRwK0Ns5AC4ekRxK8C84sD0J4KzIUDx/sE9o0U3b4eo4wrhM4Dhs4ByO4Y8uIdp84g4uEMss8z1f0LkKhQtp4B2OQC/YoHjb8B2ZwRpbYDobgV3vMJ3Y8TuNof3qMTqLoUnNYXwbYSkN0W7YgPg5ICv+gC2JoGqo4MwMUL/McK26cL6JAg1pkB6cMeg5EEvcQEqK8Fgr0joKgTvOoRqKEL750J5VL9nRKFmALS+wOM6AjUqAbK9zTbrkay0zOO9BLz1QPvxCOKkQPntQq4vA+wkwf36hjtuweB/gr4jgLEiAeTrw7gvQPpiwTPrwLjhgav1wi9yQiKyhnxihLLvAzO0hPHzAr/wQSMxRrx0wiNgwOthhO9ixKQ6xDAjxm0lwa/xwX7zweVownmzgnDjgOrxQ6I0Q3y5wa1Ce2rA/+KGqWbBO6pC/3yELLmBfaxCePTBI7jAp6JHOjzBeGuEILsEKTxHuDsDJzgBrzCBsaRA7aLKfnqDpvTDaBwodsPtfgWtYsGtNsG5fkEowPRmgTEwRG0iBvH6wLpzQXPlg6L60+a5QPH9QSu6xGK0AfS7wPXqxOOg0/OlAW0qAWa2Qrj/QfavAOBpASuiQ7T7gHqHumVAZyDBNX1JY3SA6j/KKHnCczrA8KoFLX2Cby8DdB/9vIH4nW98ge6ownwmRn0+hjGiQbt3QzxzQLZmwXT6BXI+Re8lDSKtQ/g2QTXlQ7D8wnNqwbCwxmR3AibNKjSAriRG66QOYDmE5jaEMo5s7gug40JxNAEg/AKkwfSpAHDrx3epAeClQOWkAnjT7+tAaCREqquB+roM6wg2MgHrKsE2JQN9cAX4YgDweMVivcVjliByxfgtij4pw+a7w2NAfKMGfeYAqyNBe/4HdvdDOnjAv7HGvm3AeivA/OsA9z9BbGWIdGuBKKlAYH/B5avB9qdDPy/CM7yFZL5I+7XGL7yDdqVC+WBCObOEpKYCt/xGo7+NqrMDtD9FqiWBtk81scS+LUKpO4G1JMJz68Ww9oNlegcqeAXvqEBr7wGvzez4lqHkQjU6S6nsQe5SfyMB4byCq3bINeLB5KcIfn0HMn+FZyBEYbYCKqGBPyHBeflELaFArWhCa7lC5P9Bo2LD4KuAfGcGJ/nCuRVt/0Xu5UP9vkI/YwUoMwDz48FsNMM360HnrQL970E4NEJy7gI/J0K3KwGyP4Hgh3h5SGX2BfvqwqDhxCE7RK51CvliwelgBjnrAistAOIUYeXMOv9AoLJEafBBcSmK6a9CPeMGNzbIZj9AuuNAcSfAdXZCMLKBaz5A/LFA88+69UB0J4E7qQIxvUL6Lca3YUCk5cCp4EEsrsG/ssGsKEG55ADy0CsvwLavBHNkgfc4wXf8xL0/RLzpxaS3iLYsgH18AuP/Q2UhQvL0hGxpQXmsAXb9wb/2A78CPfuAqfWI/vGCPWlAchH8I4B6dANz6Mfyq4L/dQqp9Ez948BsO8TkHD40xjKywOCuA2LxRTEvAagwgzw8Qee0w3oiQefwQeIoASosgnYxSDh2RfejwLdnxCT/xDltw6X/xisqg6FhQehnAaS6gKrugKU6AaI/wHb1R7FyAKPedqrCuoJr5AnnBT5kATrgxOcqxTO1gbu5ByfoB34qwreRoLsCaamGoeqDrKqNPW8AbGvBfPrHIe1DN2jCbwS1PoMhO4FkbQet48f/KQIw6oFlfgK8vEd68kBp9Iur+8NhqYPrI8Ei5UR9pcGq+4R68sK490F3KkRhaEO3cAM1PEhvbEE6rQD/c0EmMUN8qgHxt4lrLkG6bYLh+EQ0boH5uAb/eEUxqkIuqwNyJ0C5tcdsa4CuNsxttUTwL0Rzb4H3gSH9gGcixiv3hiblD3G4SSuiBHgRZTJBu+sB8ioCK6HGOuTAt01pokDtagLk7YLsFvCjhWeswSb7C+u8wqkzQOswyq+EuGcAruRGO3jBrv/A6ykDYHiAv/oJrvPAfDzAY2zBeXuB5eCBdnjEc73A+4/mpAJjf4Ljo8Ep7oHntIR84RDze49lecE+aUNs60X/L4KjJMDpbYG4aECh+oaidkK4vwDppgIkvIJi9cMtkHurgueiAfO0Aq5/wORwB7N5BKpggmeKvinKJlYzGjjxhC9zyytiAbq9wWZigmsmQjkwQaD6gGa4Rzmkgfw2gvqxwXzGLusBrKqDufaEujMCeqXApq0D+WrKIXFDrBo/M0Y8fAXkJsGpdIOoIkG2McHgsoQvp8g0JYfpyH+tAO4JoP8K+ScBe7MBLWAEv+GHtmfJOWNGMTfA8AGg+0L17kSsZkHh7oCrNkEtr4m150j5d0KkbMan9wi2KgZ1l23oizEGKnzAZuhB4rjDKzQBKTEA6qsFqiYCqTAHZueENrnHZSSAaveJtC8I+a1AcDfAdXCO/7XQ6dXn6AB9NwFqakLzaYKz+gQmcMJnsEJogyKwSHF/Aakzyv1rAWunibY9hTanxTtkRTc0CLH4g7qtS3I5BC7ngviuxuOmQG2yQvhnxmXrhOPsAXa8AHo/AWMnCWW5RHzpiScuRiz0QrA/Qri9wWOtgGv4SDxqQL1tCzrnSbUmgSu9gj0xyLVlwSP7h2N9gjl9Qn51gTK/wy/gD2LoiKj/AfAwwf1whDAyQLhrQINsM0WlcsB1f0ExfYLi/gbupIEq8kBgZYCjI4QgKAHpp8g5Jgb5s4G898HoEephQPlrhnRD/j1DIXjCoaCBJDtEJv+C8ukG5iNBOCYCKChEcLXCYT0ENvTA7NFnccN68IN/0nPvwbulwWd4B3yswKe6wTJzgyk2BKRhQ6C8QbTnw3f9xLOxy6juQfXO6HiEpmGKMuhGJ+gG7C7DJ2qDbSIAaqIBom9CIkrvdke8tQKzdMJqJcDi7oRyK8Tx7se7jPS+kn7/RS6lQqP9C6zowWxjyfG5weQ9DzVxg25fJUcoo8Fm9AJ6OYno5gX9/EVqYgDu9IFw+kD6t8V6MwH3ugIs6oR298m9ZkO75sO8PQBgGmG+gXhtAmK1AOEadaABqiyCeanDOFQ8d4H/Mof4YUO3KstqI8M+e8F3PsF88QOrvYNyt4U/o8H4YcLhrYUo7YP9rUEx7kHydYDj8w2244UrzDS2wmwvQ333hf9xgPmwyy6vhfQliO4gArie4zCAvzED+JO6KgprusKhLoCmtMLmPcny+sY2LYBrKEInaYY6KEJtcIfgIwC3f0RkbEHzr0SjrcRy4AMju8NsLUU+kWYoiu7lTvwmQulmxGStgL0xwWs8ybj9AXu0AaPxweI3RixY768Bc8G/KgPovofn5UNxe0Zvc0a+kvF/gvd6jbvwjW7uQycww7eix+JkgLDxyjanwSW1RazvBCQ4Si9wQ3w9AGskAPYnAW37gHisg3f1Q26mQScyxWNzQeJ/Aa9gQSR+g2Pswzq1hCo1jLFrgr2lALQ8wLJlgbRwwiP5AWh5Am3xhjogQu8xym43ALj2BmFmAK6gjuJ8xSDmCex0QWj1AXJ/AGkwAvw1yKUuQPGrQHilQzs+gyJrQKRjwOlxwL55Sfx0QGmsAqGuSrE5RLbogGx1RTckgOD4jWp4Qi65By9zweE2wvdzAnKhQe3gBTk8QGK8xff6gv3QonFAvHaFJPwLNvMKJW1AoaiCu4vnKoF5vYS+4UQi6EOvYYFk/Inh6cH++YEnIcq8PEG54UK6M4E89wXusoX/cAG77oJxYsJquMKs5sIxqIL9+YPg8gN0ASyzgec8wPLrxO39gbblAX+rgS78xP9yQXfzwTtyQLI+D++wwuZ1SzCvwji4wq/6wOynQG2+w2uhwuRLbWwAYDRHbTEGZulC62JDIfMD+rNAeW3DYLDB/iGDezMG/uQFprGIrCKGrO4FO5CgK0JyPEb/LgD264Z2oce2xKJqwOF7Qb5pwyEtAPewiCRlwy/9Q706A2dnhrs5BPx1waHlAPKkgqqtgi1sAScqg6Y3BeA9QK8kzryqgaBuweuwQXxhAb4HYzEAa6FDZ6SBLLdE9yLBb5L88Ef2g641wKukDGv9gWXyQuWxhbwwS2yiQfYyBDaPuaLM9aSFqGYAu2aNJSRBJr5E8XLA5zlBbrEHP6kBuTjC5n+C8XHC6TkEIKJAd2pA8qID6jEMoakJf/xA8v2CYXdA4foB9ydFru7HaOFMI3BAry7B6oUq6wf1Vmr0SKm7AjDqyfa+RPO6QLEzTX+xRCX8QGq5Qjy5wLujhXFuBG762u2B93oEpnfF+P8K86mHPTJCvfhCu7HB8TyOv7iCONdtakCx5oPv6AFivkExLQCrYM05RfBySndSNSBA+X5D7DUBJ/4EumAB7f1GqymB6TAEovABYyWA+v6D4buApId3YgN2ZoP2kzNyRbU/wHNzQezsxiEyguF6gHgoQezwA31vzOrXK/gDdGmBb+3BYiyCeeHD5WKB5QN7aQB66Ma4rIJrYQH96sHlPwQ8fMEn/ALjrgKhMghqPIOyuczkZMbla8EkNQFmoRHzegIi+IEi5IJobYb3OgHl9gEjJwUqdgBlOoRorYIveMB4p4F+/IR87gH87Qa/cge/44Qosow+/MDrpwS/Tum+wPVWMKxIvSAA/4KlM8jktARvY0L/MRE6vIKuOkE3rQFwMMNkO0N8fsKot8byrcS14MIlPU2k6MH+LQI+aMFvusB8xOLhATfoSDbiQb7xQf0XtjdBO+jB9G5IvC7OqiEApmlEemrBayuC9L1F5GEBPmYD7rgF6HSGKmYBKGDBJzgAuXEEPSsBb/iAvomtQ6AoR7LgR3j7VabrAyHW5CDJb/lJKiNEN86//MDs64SwrIMzs4N0aES7g3YiiaAyi/1zBmNzQKFwQzWpw7KwA+hrgOlkwW64hmNhQLIqwXL2gP5qArlgAG6qgjshwTSsAXZihTJrROerwTE5xW7zQWrogWuCdj5Eoy8E8ebF/nEBeueHPrmDs/hJKPTGODAGIpNhKco1fIX7MANv78llpoIuM8SyS7JDMb/B+TeA4KfJf3uBuD7At2wBO3EIqPJCqz9DsKJCuCmCOaLFsn4GbXrDLP/DswTjtYB0a0f19oHhq4Xwv4M+oQE2b4L388Uiv0JweU2s9AGypc31K0G0qIN1IAQyrAEo74Gxa4M9NQIvfYE5rIHh4cHusIJkJYC2doEu70M8bs+20q97z6KigfywRzC0wzhoBvigQnX8yHv0RTv7zXo4Byn8BmJggPyxgfJshiNgALE5Sj2+gmtfouMCcZ+woAVlcAXp7kCs/kB+eILkKIdsoMMj9oOx5U/ypkF9aYlkZ0E7vkbsMMEkpsCs+ULy40CoyXu1RW0vhbf3BDF/wTOriil1wSU1AGQ2gH9rQT/+xih5gLFhAW94Aew6TGizQ/B9zDM5AKFtAv2iQbmhhu9hAruuw+PhAfmxyD82wGYrgKV/QWxyQK/NeqFDcOuFdi6AufoGIW3M5X7C+QvuIcK35Ad9Z8GrO0Ki7QCsKoFwIwSqukEptswt90Ptwa2ogyNxQXTtgufmAv5tQXrkiCbqxqL6Ayyaof3C47/E92uDIGuYN+zIqfvAcmrHLWJFZHZBoqcAoLTAojQC67gDeCMAcSaCJK7Bte4DMyEFtDOBID2Bs3BCb21AYqMH9o4mvYF/ZYIif8F8YMC2JAHjvYspIcJ5oENtssN7L4BuMIF6L8u1PEW7MUJ4+ICxcQKoakNhMgG4Pcf+6Ec/LsNy6gPkLURkoEys6kVz8II6+MLoqwFlKQGgMgMsL4T56MQwzfGyzCX2yf4kg3Pnw/JoiqZtBarSLaQL8j9DMTlAp3DE9n4BI7VAvG9EbDCCfwnpYwl5boFheQgj88f4pQB2oQDyOAF/tINqoQGlvgG6rsJjoQZo7oDh5YL1Jgl/X2C8Q2gxRCsxwSYwxbbL7wqw/oGwKsEnqUp0tQElvMj3o8Dl8oCt4UL17kcm84E4rYMvr422JcFmJomw4AEv4kPm9kBuYsMie8Q6vEFq9sFqtoC4JgBuM0HypUU+qQVnO8x8dMI9/kG6KoJxvgB1ZQnnYcasuUQhOUihtQFv/0BjNQX3uYTy/cUrvwB75w4l9oJtIwd18MUkPQEvYcB7KgG3skXiCnTzgy0yhHr/gSkoguumjqBYYPSBZ+BCoHvH6izF4DrC/21F9f7E9TOAazOBaupAv+VF+yEAe3mDcqBF6HMDYKUJ8XAD8aOBquPKbToDffRDM7oGozoEfuLCq7NEva4B4PcIvEcoaYiy8wM7C3E2w/lxga+ecqlBt+WBabwBsTVBIVBsrkE8I0BjPAF//ENv7sE0/UdoCuMpgrViSLXqweEqxDauRH+sTHx6x+alwKX7weLtxvH4waK4yGD8Q6r+QnT2gGs2hGKhhjIlQjb3xDLDeKCDt2WC9eZEI3aFKyiB9joBtaVCc7PDKD2Af+nA9SGDPAgw8QD1Y4C8skT0owtqtMTr/YDp7YBwesqo6oZ5OwM1rEUwrYSsdABu5UJuIELz60Kz4oHseog6oQNn6kBwpER2yHAvw3IiBabrhTRxx23rwSKnSCgtSbVjxKH6Ajyui2KvAq7mhGs00PCqQr36gnaW7q+BdnUEKOmBoquGt+DILnkFpykBvz3CfsCjd4P29ALwoIMwqIDgvYD/Y8XvvgZmsoNm7oJ4r8BtL8V0ugXtBHXtwKbnQOTvQ+tsQTBpA+G0AWD8w7hhyaiZJxHjv4Hu9ENxtMykqQKlZUDkpcxyPoOhtsbm+EF/TORFrnWGNHQA4XvD+ycEMa0EMj+FZmGGtvqFsCYBamXCpGLLcSLD/O4BPAu/fcIsoEGwMMvnpcF0vwkxYAVsrgC6asJ7pErsZ4G8/cjtYIUwdwB3rUFpaUBrNkR7u8DzpsRm9oDg70Eza4ey/gdhZ4hlaUXruEshIwn54AJlvoP8soI7PcJ/lyYrQ7L2Qia2BGsgg7UrRm0PqGTA6iJDOOMMO3iE6PjHO6oA9j3EIakBZyoFY6uO4W0ArnGBeI7zOMM2OsakZcjnbwZkgOPjAKxtgXm3AHpwQri9CqWwAyJCIaDCeLTMM/UCcW+D9eKB7584uEW6DqN3gG53gG/lSSriRCL1gGnnAPkqDP50QGc/RLXrVGp8iLewgS0oQWcvxCV2QGsrwzj5AiWqALQigbXownCggqK/AHGiwP66QezhwWK8wTn3AGW5Arj4w++liDYuALOkwjbkgHc3QeK8wXI7Qj29RTfqA6qkDzflgLOmgi4VPaWBZbbBOrYFfmoBcOQA+XMDcKwKcVb4owMvR2M0AnbtAnx0Afw9hzShwqiswuVnxqB1Q6jsAXvlQz2mR7WqwibSardFP2ZHMbJAvXRCOHnEo22NJyoJYX1DPudCZ7qEcGdGOr5LaDkFvfFBov2BpqYGvKAE8JN3qgM+cc82aALh48In6kyt8UJsGuJpBHPijughgHjtDHN3wWangb8thyR8AL4iRWL+wLf3yvliwiBkQ3CgCv8kSi24gPPpRbGjguE0AaK1QTc9hTX5Q3N9Q3R6ga01A7tGcnoCcjkAa+wEJAU0UTnnQPsqgPrswPo0AGR0gKTigGRszmh+xyHyw3szxXsshTRlxDFpQOS4QPRrQanxB3MpRjPwhexK/bFGvbqDeyZAtO5AqGoB4KaBMS8CYXVAurQBY+zBe3WAawe07cGq40Vl4ECyvgPuuwBuesZwa0ft6oCnJFMjNkOz+gd5PYFt5Uex8kRqJYG4H6Gqgf+8AOZ6wam9Anz9w6JEMW+DJebBpKfDIHnBpvBFrquAtL8AcDADaTuAq1169IGhYcFlIwdvfYFnaAbtKMRz9wruK0KkOoDjZEBu74btpAnsJES65cx8UHO2QalmwnlcaRo2pEBl5kCzsEVtuAUsMAOmvoE7MkCmr0C75cC/NEYrfkKxMAV51jOogf/0CGl9g+HjxDa4AKMog/bxwSprgqA5SWt7A34qgfw4g/hxR+noi6d/hbTtweJjgmWIMuwCLWYHtTTCOQ9uLgLqs83tfoD5uYX888T54cPyuoC9Y4B7MEGgIsCivsG4p4R8e0DgdYUuagFxrEp9F+KrBL28gG/mQP1tBC+9QX9wQbumAKK5Az68QGom0ju3g2T0invD6ekBpPOPPmPKP7RA8btI+mhDLdMtOAc7uQKxfca0/AB86MEsbkFvJof4dIN3Ygi5t0R5NIF3LASg78H2BfUS/73Dsi+DoiOHJG4BcjYCv+iE9qEI/KiC7WnEY3HA7HgDbjbBMXhDvihBPfnCo7dApd1h6cF9doK16IJ9o8dmIET14Mt6MkRjaUP9LILxZoFuKsX5IQEhNkD1JELl+MF0pIC02CErRTAlQ2hsgT0LeaWCpHUDK3EKaX8BIXhA6fvFoHYCIC+DNDECoqPA9uRCOjKDJT/Ep2ABa7RSZy7A/pR94YB4Y8GosEMzfIN9boCpe4Di/8BoqsI8LwCnZsUtb4S/ZoFu7gYsuQJqawK4sMIqeQF3akP6oQJ5/AwsI0Htu4CotEFl/ILyccb75sRlqkQ49Yc/O0L81+1nU2zkBPs5ROSONiZCrmbCs+fA/aHDuol/7QNs4MPhaMPkpANmfot5LBRpb0L1K0P54MKjfUFst8O4c4Cm8AegJkMssMV8N0E3+sTq6cE9qcIlzbmox7Y9xiYxgTlgA7P/gnMtQPO+AH+2guYpQzOvhjvGvjWLrSSBZrlA+T0Afy4AoaWNbevA9rQD9/qBKSfCL/LBerNAcThG+nzEcGaCPe1A9mhDbWiGPXEGtepYtTxFKPTCuyYCZe+A9uUDI60BKTQC/LcA+f8MIewBcCtB828Bf60FJjpBfKyCfTmJa3QC8rpAq+lCffuL6Nn2fwlwfcC+c0G6tESmfwC+cMW24QTiOkOuskF8Z0pj4oC5LIawr4ljZ0B9cACsokCiPwjtaQN9cdLx64Ctu8FmNoR+IkOtsQQrekO3+YMzq4S2NcO79IFtNMIpvcdz5oI97oLresWlbEhvI0B4tQVzfMT3pkBtdIKu7AP36cgn7cIyZkLsfwLgckavZgP8eMo3fcBvagCxYQCvu0kuA3BuAjG/QLOtwTOpRPotgGllw7BnhGU7BfxtQv9/Qj+KIThC7XLCPPkDczDAcCkIPXPAePyC938CJsvh+wCgoUm6xamoSql/RHQrSOvsQSmzAjLoQi8xgKsuAHblxfejgXuvgqKlAG5wxv5mw6O/h2s6Rr67QHwyQjsgB68UeqAAaS/GKqnDI6iCYT3BYXqEb2NAeyMKZSFCOO/SPuIA+/XDvjiB6TqA9/2A+bABva0BpLcCtPAL5frA87BBbCLBoKECcOYBKr9B+SdEP3uBL62Ao3WG83JB9XpDYHRHeXHLOL9A7XiBtCaFtTSCO+PFOqBBqWEJ4SwAp3mBOS4CJXhD82tFMXABoG9RKZv7acBtcoEn/MBkeob4LgK8bsMuPQD35gZo6AC6LARu4gE/m2Wsx/frgi13yGAqwPI7RGckwrljgLz9QjAMrWDBOxExZsHmLQY7LEqgNwzvPIIykecyAedpEDHiAWW3wLNuyvAvgv8hEeTyiSg/ATHrBucyBiHix7OyETusQWYO/3DDKedCK+bGI+aBvibBbyBBq/1BKDIAs+ZBaO5JrmlQI6OCY8L7N0F0e0PhcwKteISj/IZy70Ms88EqP0HmZsZ7tAl5KALv5kg3+ocx+9NtK4OjMoF1t8QyeAUtWf9nhf9uBPtxALsqSSHyQyG0AGcnwPZlwO+qAP+owizsAjIiQqmwhLd4A337w705QirCrfiA9qZH9znF/OAEpKkMP+kB+pMt94BsxuckhiC7hHYkBCWpDPpHbO2E62XRvmfC5rkFPbWBJi/AfrwB9TCB4+wELLrAc7KCp3/EsXiEcXeR7juFMmUC+PUBbJP44sT15AR4a4Z2eogiQb53heaown++QfuiRL/tw23rAT6ygixwwGMgwyUhAjwxxuuzx7WqST8CtbACYfRGO/BH4aXDMrSG8asD7iZC/eMBYrWGOj0A/yuDtPiBbP2BpveBfO4BNZ5+48Co/YloIcPvfwWtpscrDnu7CyD2RCXpBvlmiHxqQGy7CDgowK8hw3r/Rq9jibd/gWa4ALx7Bah+yOK6ArOzR/18QfirQShjwGvOcBP62mF0Ay0ugvujwSR7QTXogH4qyio3Be9iSatwS3bwAOSjQit50bbkgK6sw2Hwgn0zQLRXvz+Ap5Yke4Mj9cKl4UcpuMC2uMHpJoLjsAF554a6LwCuMcpm9wV7YsO/5Ad0roSzk/cwAS1yxvk2ALbuQ7g6QriuAGQ6QXoqwu3hxLrqwSIpgvCsiS5lQf//wm63AampgT/9RSRnQHRoA+V6h72mwSYzwyP4RCKmxHE7Q2bkwngzwXZ5gj80hD49gGvhwX4+wWzzAyYnQyX8g2N2g6XowvwuhjSSsRZ0JgEr70B9NUEh6lE8uIDx0btjALcvQHlgArE/wS+yD/egB2psAG0rAnapBHDngbyiRq7AtO6CqzzD4DkBNHkA8NRt9Eijq8S6doikIYEqfMUi/MOs9sVlsIQ/O0GlNQpicMV4YAMoMMFzNUJzeUD2IURsMQGh5IJiZQI+/kElYgC+7YNjuIWms0KtecXqLgEoZoKwogCuccI/YsWquEah88Kls4dzaMlusYp0v4C5KADgfkVoZgP87YF/KcKxrYFj5II2KoNh/MSseEC8KAL678F+4smhOsUhaYN2MUgy6cWl7YWkaICoJ0VgKMtpOsIg8MFxuICxcEC5KkQ4aQDkLUHnOsfiPEK+PgKp7kG6ZEC/6kGv7gGiuAG03zD6wuumRak9yCrhhb86B+L1hTXqwH0hAj8oyiv/ASZ8QnDygHC+gLD9giT/Q/j1gOxnQyo2gXHrAyHuwn0iwnliBmO1xfhLIHyJtCSBpjKDJTQHb6XGOKmIeX3AcShHtL5FOjXDZfmG9O2Aam1F9XoDa6kDpOuCcm0DPffCKTnGNShEOnzVuX+A4CAJenNII3eCNPNEfw/0O0Gza4Urc4EtH3ZrAqlN5q+A6mgKOr8G5S2B/ShG4fDGOXfCp6iAoH7EKS+HbzjCoCtCYExtegw09oM0IIE19AatasC6ssWkM4NleMBtfMN6KMDoo4Iu6EMrsMjj9cLgbYJhKQYxagQw78GyI4Ons0Jz/gB+ZUWlpMQk8cQru8c7vUKldkHoqMJ2/YXurUKotYRmS2WvgaHpgPxsiG2vgqM9AyMshSCuxjWlQXzhg+T+R6IvEGZ7R38ugKewBfPwQ2r5gqc2xatywjr2gKHyQ2zOJCUG/zgE8GjCJeOA5vgAsugE/2PKbrTCdAI74wG7c4BreYUtrUSkYkJuY0O5tQb36sQ16cCxKEDpJ8Q05cK+JsTvA+p5RSC3QO/kQfrrST/wwSzphi28Qj+4BvD0wX1nAPDoAbUtgeiDorPHveDIeaxJaq6DaulCNTHErKqA5OPAcKDF+q+BK/XIK/KBOfwBoS1A5mcBNjPBbvKB4nvBdnED7PgB72WBKfhNMzpA62rG522CIKpAZ6HMei/AvzTBZXtEYaIBrE+9YAbx6IJ8M8LxoACz5M3vYAL+P0b2qQCoxzdqwywty7X2AL57gHMmSCyuQ3s3BXy6hCX8AKgrwKWoh6/hgnesCSVpwODxw/fZqvnBLyJCemABuvrDI3GBZ9S/q0DvecJ/4ARssQK0p0DzdAcl9kK2MQEksAUgYsM5TGGqRuNlAyMqgP14g6Dvg3nowqO9xrR0gG0oCXBFKJT0ZsB0Y8N/+kIjBjo6gbZiwiC5A23zheUowOdrxuv+BHi6Aed0gjajQKl2g2upxOK2hy1uAebuwLE3xKI6Bjxsge4lgn5/zzOvwTZpQmEkAW1nAHmwgOIUvzkFrquDcu3AfSjBIdsyNoWkv8E6B+b0QG/6wqckiC/7wq8liTFD4CEQ4PuBN2sD62vHfysA5C2F6Qhz8oC9NYEktMGyZowwukEik6QiC74swf5uwSpsgeBlCWM0QGAvAzbpRy26RTJ0Am0pAPG2AjM4gbj0zKamQO44gqy2gjy3h+H4ULl9wjArA/uvS+VlQL8sgHnuQSa3ASgvAmN+QeZqAbYtxeJ1ASp+QKU0BXf3wiA0l36pA3lkReVixXKshCPoQL57helnCHsohK6pwrl5h6o9AOTshXF0QjHwAa6ngHxnkGFywW75xmmjgzQM/W8C6lm6OICwIEfqqEGyd0T2YQclO4CjMQChMcEsesD6JEUp7MK8d8H4l7bqiie9wTG7grcogiRCJTbA5vIAqnMBPyvEvbuGZ/9FdOxEJ8KzqYHmvcm1v8PsPwVrpAd7p4pzrYQ6LMHkqYQruYFuqcchIEH2bY447QWx6Ek26cB9o8q+cEk9dAG18opwf0E7MUNzOcCntECyZAEjKAsmuMNzJcEyJMCp/0O2b8bi9kQ1bUJ2bEQ8NwGj+UEirQK8rcgzpIv0/YbtuMRyKgGsOsZrJQZ7NsHu74c9ZQBsaUNpNABntASn+8MhMMT9O8Hy6Ie+uEMnd0Cv8YYo6ED/ZcL7rQRl9AVq1Pr+hbvqgTMkQelU82WIfvxEY6CC6OjGb3hAomZI8zACc6qKvrjA5PbBKQRvJsH/KcEvLgGmdkB0t0EnfkdlocO/NoL4JEC/MsBsaoLpYck3qEK1tcfkcsRv2rWzwmfoSCitwP+6Qy82RixbZPcAZPlE+G7E/H3CPbOB56PD5zdC+zCGYebDuqVCqKTNOCvEa2IE7ruLPyMDdvwDfss/oAx8B7jlAv9tgTptxmbmGKR2gTlzA/E3AfnmQzl0gulkSa20QKTvQOqXfbEC4T5CffjGf61AbPCAbDCAoGhPbbhAa69DYrSD5/kDpyMBuuyC7/3AtzTDP77AovOCfLoA4+bAvLuBZKaC6uaLoPVF9fjBbDZFbv3FoqeDYL9BqzyC5qfFr/sR5PjA9f/DI2JINfrB/OMFdCwB6iXAqaVGKHFBuP8CqmiBuyMFamDHaybBZPoEt7YHaWxBePBEKLSAdrRCqzgBcmXDuqnDYPTApr7OItl6dkJ8Okh8sYD16MIgr8R8eYF1rwFqZwH1Pch788DreMIqZ4m90LJhAumxSjFuBLHwhGc/RProwWdlxDdpgWi0hKzwhTM/QSr5QGN6QqBwgqz4AHUzwGjtQ2Q1g66nAbwlwfKwwm8hxGdmQ3AxQuUywz0oxCpwA3qxQPBpw35zQSUsg6m4QKD8xbomhD4oRyu9hbTsQbKuAv8wgr3nhDR6RDa1QajiwrBsRb78xDdlATQ/AL1jhaEowfeoxr43xe58y/U3ibVsAG5Fr+lCJCuEJDlCveCH/euD6mPDbD/BojrGLbyEsWVBZuiGJrWJuWiAfmhBbSrGODzIZZZt+YDtYcg0toBzb8X0r8J8yL/kROT9Q748gn6vi3Tox2C3wbUvhSCygyc5QOwoAPW9h2U5QT1xiSGhAKc6TzS/guStwPBxQL8gA+s9QeeoQ/JCK7CEJVw4uoC6YUQif4qyfYS1d4U7IQEmIwBwZ8JoroZkLwL84Eq+YoEs6QygroD2IUFx8ADjs0Ky8IE2mj1yxCXkQyBihPjyASvvwzcoAzAlwOfgx3fT8WnB+f6B7ucFqC/EO/VCYGnBbbwCrC7B97UDPWEDYK6Duu+EoHXC4ngE9rKAuejDenrIbzYKf/TAbylA7TXFMW9DNjODLySB7i4ApTRDreBKMvLEb8C74wBg9sKnOlG9pQGtuIf6uQHjf0NiqwNvK0bz4YJ1r8Dvo8WpsQM7JABqaUE26Atq+ENkHeZjQTlkweS5QL/zj66/Ajp0Sa68iL/5xXamhSq0wT15gyxgRChpwffuw3i4CSP8ga86xblzCeouwyyoBCwkwroqAGXsRiCvwPg8AyF9xOtrgKZaM/mC7bHC4a8AoOMBeLwFN5g7qwqrPo3qK4LiFmnwAfpwSKgvRLD6jXmkhbncb72AqXYE+qrBMrRCuGbCaHWDYavAYSWCImGE4auAenUAqyoAamMDf75DKSXBvTwOIbwCZecL/KNBoWVB7fhF+DKB+DbFOarD/mqAr3ICoeTFObCCaHLEdqiD9TuObSWAZSsBab0D/i1Jf3tCMKiFID+BoqHGMWzB+aAJvS4AcjoF9mgBfOWEP/4BavBBNHDBc+QGZzAHtS0A9GEEa3LFo+dG9GxC7zwApyWOPfPB+fvGJ2ZGtG3GsGnDIuCA9vcC8bQCOPTBpH9A/XENculA7YSs4YR38EMxfYT2doFqKAN58cc96Qc6fsB1MwHl1Wamg7szQWk9AnJjQ3YvwrzwAPqoQ/r/AftpTuU8AfO3Aarkw6d7yDxvAHx0xa1rRSK6gWjyjSEhwSolRjg9xCZqgz26Qjt3iHEkAzb5hXc5xqhiga0mRPRhwKS3xer3BOY9gS+1wKxlw7P+wuGwwfIpxuH/TX25Cf17grUhAi+1xmGyweKjRzlsSe99B7G3AXv6gre5AnSpwb8swKeryC08gzswAKQ3AnmFaWkBrHPBtXBEff7D8T/Fva1A8/tAaTTHpD/KZ69HtqzCsq9KbDWApuuArnsDbipEvPIBYmHGt6NAcjPMefJAeyOBaHuCsPPAqn+CfDEDcrHB7zNEIajIPesAf3sCpXVXdYDzrUG+OgSj7sV+eYQ4M0nu54N8489wMcZ0v9bsdwS5rES+/sH2eMQqr0Gv4EEyJIF7ucSgfUD7aMXxaEBxtgkn40TnP0TjrRGs9YWiI4FlrsDuIsXxla9gAaf6QGE2BmBiRXq7QuMpALuzRaffOmHCN7+KazYD4CLDtvfHuaBEv7YAeWcGJayB5+FCZm0BM+UBPHiDfC4JpnBEKv9CPuIArTBG7SCE/SpDNOcB8q5M/K3HfWQDcftGM/UE8z2AdXOBqVe4fcNoMQJ5+QV8PwS4IYU0s8CwMMO46wPxtcDpvMItHrszxTXww22uAOMwwT4lQv5I57MA4CWBfejAsnwEKPGCL3jCPNV678g3OcjtLsFjPwMieQOl/wQ2YRIsecF2+Ar36sEzYEB5+MR+acMgUHWzi7goQqpxRTY1EvQ0gHqnhqeqALjnwvJswu0tgK0qAqajAimHZi4B7NN8ZUFzKsI+8cI9jLjuRq3lwmBW/pej9IHn9Ae7+YK2LQH2P0FueEFoM0GrOsO2pYx84orgsUBiLQBoPweuL4EiK4Q1ZgIyYofuAL54jbb7wOVmQfRcO1Hy8UDv6cFjP0Gjakk86tGk+ITxJcmvoA8rbwC6f0Kh7wG7PYDgfoX98gCwIsh190OoLUN9Isju5wEtMsFjqgN0Z8Drq0I1Ok91NoLw8ID/p8GvQucjgKS7hHClSXvlQuZnwTbrgSg/gvqoAWWi1zGOe5O09RLze4IzKMJ4ewEiJILuPMEkI0C/qUq7LoC6tgB9PAbxJYQ/uMIjvkLieIB9L0Fvrkb4P0f/rgM87wQvssc7/A72NEV9oMQuNoE5JQO/N0M2N8SopoH0+cipp4g0osK5WbhoQqPxUT4mi76KJvLBcPCYZGjFJ/GFcqwEPXhDMK5DpOBBsaHFqrTB9/zI/byCrCuB97pD9i6CbOMBc2eC6MK8esF98IMwOMUoeoDoqIIwrYE3osWtIwQt3yOlxqH7wG8whCX/xnHvBW37gybxgjwpSO0qgaS9A3m/waClAmYjBq7Gfe9Ce/5Arpj0f0S9q4Bs88n6NwJt58D9McN1bAC5MABjzHLjwHBgAbRlAWI2xSuAYKRC9y+A7uFDq23DNfaBqW4AfyWCOyZVtSGEuN58Y4PhN8JpbUhqNcE8PED7b8B1fYDk8YEpK0m85oH94wyvsYU0LUYoK0ElswDsfkFocwR++oH0eARy90M/98Uju4Wx+wRrMwf4OUUuqoKlMMP4dgIwPYCpP4L0wPLsA+BxwHX5QXBzw37zhW61ATDuBqFmwmDqQf+gxfl2Q7Ggw/W7AGWsQqf8A6y/wHAvQ3SxAb4mSGIuQLArQXguTOVmAqwwgK19was2x/AjgTJ3gXU7AyX9wbspwSJygO95g7KrgXJowTnzQOnYpntCJDfCY2kFKG+G5TiCbq8J/ggzq5OstgZ5YcE3ccJ0Z8B9fAtmvgDio4C5p0S9uIa0eUimK8D0cYKia8InaID86UhxP0Q7K0n05obrYMUwrgHy4IB7NQ12ukD6dsXouQG0JcCof4B8oUJroEG+L4b3dM5qOoBi+gN9ZIN0fUKz9UMgegFrIYn9BD8WvLQUI2oCLS/GoyTEq2TJ9XuBMn0A5mYBrOZBMCpIvahC9yhAf30A4DzAvafA5fuA6teqZ4dvaMCj5URnqcN4qwGtPQLkgaz7hru9QKy2BPLrgKvoA6swgrymgP03g3ipSfm7gOB0wmRyBjr4B69vQLTjAnTowWIoRSYEvO1FKqLCZ7lGZmeA/O4B7ftH47VBc3AC5eCDOyRHOmVCrz4D6HzB/yPD9vnGczXAt4Z6+QXr+QYzL0N3JMDmusjhfYN3ZwGobYD4JoL6oYU5uMExPEU66cDqZYH4bELu5YE4LUBkecVs4QPleFmz/UVycwJnP4Bnogm9cENg6Q2rcEDkNsN0+kbm94Gi+grgcURprsEos8E5K8a7fIC49QY59g760TIrAjV2A37X8D3Ba9Pr/cLt4YczpsXsM4FhmKDPdaECv2FBqzHB7eXB7SoB+rWBLurB97HA6+MEdrCIaumBuuNAe2NB7inD4hX0/YI9ZYB6/s36LkLk6wqrJMOreIYlpwJqpQDoM8I0YUdzIQJqqgDlq8I5rkI4ZcQ39oOk8QKgX35vw6wvh/O2hTungb9gAP8mgaPoBPNzg6bjwLUhwng6g/MmBnJA43TBvqkCpWPAa+CDZz+ENH/BZq2Uf6jA/HNC/eoArKtDun0B73dFvrDE9jKOJSIAuzlCfGiCsCeCp2DAY+oA8ymEMWJI8vrCeSVEOGHBKrpGejmEMH+DfO5Iv2eBZrDF9DZAbuZAan9F5aEAoO/AbC3GIuTCab9CI6sCPLCCb+8CcahAqC3BuHoCruWBI2eFLXNAcjmHfbFAYz2BZmGFJ+qCfjoDuepP+TmLYW1AqHaGPeACuHrF4+EEu3fJ9jsFd74Fvu4AZLMEYcOvKkJy/0Hn+sOyIAW/L8Wh/cJ9I4Dz4YO98YF1KoB7N0Rr90D5KkOh/8G384Hz5AqqSG0tSbJlQXmngqm7wW6nBWHsArc3wL+lRum7gKS2BiD8AP41wPjsxvdiQuW3QLM6AqnzhvXhgaqoRHTog67whm12wqMrw7Q8Q7tzBjDihGvrQTirSWo1AXKyQO3+zqdmwfQogPsowKI0wOmyg3vdZC6BInfCoaoC/avVpCUCaS+AqbCG/HCEIjmFqWLBt2ND9tVsIYFxcMO5NwQudYIzbUDuK8Fr6AS9vsB1YoblKwd1MwOrJsS9+MBhswUx5ATu+wWlt0HhrkGwMAK8S2/5wOA9ij5jQPydp+mI6HCD/rgI+7vF/T7BoeKCqeJHZe1A8jOBqSMF8SHB6CECOSvTMiQCuJJt/8L45INiMwM0PIc1r8BuNIL3IMBvbAN5dEYyq8NvsYCi40W1rkDzucPmuIL4ogglrgOgosRlY0JrK8DtPcC4N4Nn6o+sfACiesHk7YN4/UC4e0cpfQDqJgH+NcCwsoOo7cOqOwSmrsJ1uUCvf0G1fov4I0dwbcClIg96PsDqJAI5bAJk843r6MXjdkFzZMX46kJ1Uip1Ryv5geWiwP5wgT2ngT95gi48AarjzPjlgKgFMrSBOm0AqKKAbQb1YkD8+8yuJMHpOUGy+QJt5MQ4+MBsMYKjLMDu6IBrtcNoNwBxugOx5II4qELwOkahMECjuEN4qUS/okI1okWkLoH3+YI/rUBxfMThOYrs8IXlvIDiZQDwfcplI8F/rMDgNAfu7E7wOsRjfoBldMD2bwNio4GxtsC7OcZgKABysgR0qMi/vMGhO0B/KUDnq4D8rgi7M4bmyrc1geZ/BTDhxrMrybX4wnowA6F1x+anAacvw+sXOCDMJ6xBfIf3MML5mne6AS+1gap5yrS5BzsoAGn3B+xqxSqpxib5RLR5hKF2Ae17SGJ2wToiAivuAbYlwLkwA6dU+zNBsHXJ6nkBcizLraEBajrBcGuIri8HNaRCPm1IIeeC5KGA9zzHdP7BaTQB5OnCN3cDL/MArj6Bu7OCca/FuSuCakD9MgGidsfjyza/AmE/gm9pRekoRW6ohqd2gyi1BCq5xbtqQOrrgSI1wS73gH/EsagC8qmEdqGDvb2CJyqLZvwB6PqHfnUHbXJIpvFCpTUJKyjA8HiHNZXyhzmqQzYgBPxnQ+PoAiahByklQzTOuL6C+2/Ae//CpvvGcW0D6HQIfa5F6T0BpmlEfDABszhA+D+FZCYA/HfFLiUG/uVEJnhE/OJBbDDBoyQE6ayEqjkB54k2CzJuAO94gP8+zTktTPrrQjMmgrKmQKfVerRA7ibA5z2E/tZrWP6zwm60wn48BHevwHC1RKdywbPRqrlGbi8CI7QBNYKmO4Prog03N4Jlkab0gTH1w/nkhmyNuzhAcfNGJTwCf26T62PA8PSEuyxF+jtJdb0C5bdAe6kCJ26DZj9ArveApz0Cf6aAvXzB82KBLSIAb+kEr+7F9ueCrqJDInPEbHpCNiOBouSI/ndBr3IIPaqAdGbAvuyDce7DKufBcLvCvngCdJ76FP02gzksgqs1AH41xbPb+HJAtso5owE0bQZ+6AVts8E7YQDnLUC2aECq6gB3ZYI2c8Cm7gM/KcD59QdnV3UywmcqAP0uhfG0gnI0ATigA3epiSr/wLvzQe9wwe4rh6axDGbhwrspQHYsQ2l2gHc+Q+B9AiXtQSgzRn69B6yhBv6gwmjiQOXjhS+thTmhwHU0QfY1QjzwhXrhAKopRyiSpmaF679BezoC4iSTtPqI4bAJuqXArWABNmtBr2HDJrECZ7kDKLKCN+2A7CfFdf5AsG6DLPZH8aTLNegCY6LCpXcFeihAsbeConHA9aWCeqoD9VhzdQNya8Nl6Md5p0H19oMxM4NnroIp6AGovgVmNIG5/oBw8FJs8UQx6Y25/QBzeMI9Z0XtOAkj9QC5/IZ4L4BuJMV3YEOv9IFxO4WtLQFg/QOhusg6/cK+NYero0Eh7cnzYkIwvoC3IIF9I0kuroP9vcR+YMYr5wH5N8F4vUC5h786j7WuQrJhAGApAnlkgyD6gaMnRuWigeurwS+2A+rnhPf3RzWA+LoCsKrDIisC4WtC5CKB/7fBf7PBqTxCLLgEemLBqvuCICZB7qDCYDZEaz1CcQb/Arb1QGtjRPgygTbjQLIpCfw1QXHlQSv0SiLhQL1G+CnAZH5BpG3A+7VA9uhHcJlhIwQmNAJ/+8NxvcZkPw6m/AFjMwE7aEHxcwGiiexlAvHoRSmVN2QENykFtzABIOwF7D4BPu8I8H9BL3FAt/EFJ6fBZXHNOSSBrPdB9uNA+9klNwJjIcDjqkPxf4IvIEBk/4RqocZpKoZ9PwR9osEoMkvxrEc674CvfgCq9sLgYQTiIUlx64OssoFo74Ek7gK/KsB/78VvqYJrknJywLX2QWl0hug/gKyiQLc3iee1hDhuwmFuyeh3hXL1D27ggKs+R38+gXo1RTY2SPowAOQpim19gWf8wGP2ie0qBP2yCD/3g7BnRD2oBCi7wnR9wbJhwWq0guRsATbjwG9gwOkzgSvXsreCPHTA9nSBunzH5G7BITaGtT4JamHB5qIAo2aB/qyCKqmCPigA+HxCp+7CauqTorCBbLvC6WlAs61N6mfCND4CYQ+4tQP6YQbwpUOtKQBq7gV4a4PyqAQ5MwQq5gQxPEBjZkSloELw54Iw+kp5scGzZACtusd9MgLi+kX3dQgmJsH2+QL0IIO/+QBpM4DqdwG2YAFh5cVy4ENpbwRlLID19kZ0YoB7q4BpYcD6Jsflq8Pn8EerOQFsNkZnNgRnZ8SvfcJ0ZoDjM8aiMQKlN8o5K4I2IkGgfsH2McQmlexlzOImAbWlAvs5BLntxGsrBOxjQqH/gem0hnmrw3E5xeA+hGbjwPkmRaa4ha2hRmr7APewB3okBHc/QO7+gKy90jtuxOSNcfABt2KB+jVAcDDB5+ECerZB+PgF83lD+fSI4zzAfvVH5KaC+H8DMGtAY8cnYkFlPMtr+gllsYI84tLvO0PkMQayvUEvMEakLcEtOgHlJIpwK8Ytf0E0+8E7u0Qx4gP8I8Nl5sK0Z0fv6wOmf8NicsH7OgE5ZgH54gIhtslrOIDqcECnIUO7ccEi/gGq6kFj5cd674ZoWGbxAnW7QeQnAvu6wGKmRTX+AfT+yGD2A25DtzzAb71E/imB6qcCb/MCNOaC9erF5OTDNTCFLD/Brf8IffTA4ajOs/fDs/1ArbKEOOxBKvsEf/TBvclqp4I3LINodcbp+sYr9IRx5cLgO4MgbUEsL4R0eEIuIIJ15oJggHfjQGKhAT3hx3dkRbKkQXr3CPV0gzk2wvdqgOBugO3Q5fjDISYPPMds4YIzeUJ2uQYvoUp+60Xu4MCveEF1tYD2OQCuqsGnIgH16AC23yF3Az8+wz98x7SOpq8A9J1raoI5MAN0sIZkdsOnv4EydAP0lbPgRGK+Qy3jjzE8x/12h+y9QLu8RKewxbg/wnc/hj6qQOy8xr+gA2slQW7owGwK+/aAq1t/MsjvIcZlqoO0vkF2Zka+68H6JEQjJQLhtkLlLgKxNYHkP4E2PEs1LkBjYELuvARvug5xewL8tkIq48a69MWp5sKteoB0t4fjNwBoPwv8iGiqxScmSLP3ALMizj6zh7ZgwSTrCCmjASOkBSeKqKzA4q1CYbHFNvyKd3UDb2QAdj1A7KIFuHBBq2cAZHEDbOGNJHQAf+bEsK9EazUCOLKI/aZAd2GAcvoHsYxns0WgsQCqJIF1tEenYwK/80StfIJpt8Ik6MC7oYHqaUMrKICvtgugN0Dxa5UpJ4E4P8CvqARtv0g5J8YoY4EyVOWjwHwgQP29gS57gOvsgj6yhDV2wjT7zHLwQvVvRTakBmQtQiY9BLJ1A7P9Qb/oS3I6QyT5wiT+hnMygH6uwSvrhnp9yClnAGZ2y2A9AbC1AfcuAT62hPs9Qj3qRrc1yCb1wSWqzrWvQO9kh7X5zawvwLKmwKa6AX8XYjyGfiTCr3SAsnhBZ2fEfzJEO+XB8ezB/SrAsiCC6GgI6eqA/mSBu2UB9LTDNTCA8D3EIB0vtUll5gUnocC2KoBmLMBl+cDqJQa9tAIsPwEy+gVupwBlpAHnoEGycshmYIE+RGA7hDXiBHDpxGqwA6FrAiJ1gaHsxnrkwn0uAaYpxvR0gO+2wffzhyB2RDsigP56Am/ogGYuQjV5RaV5wy0/gvW0CiYuwm4sQeR+hOuohLJ8AafjTz3mAK7uhmKzSO7igyH4ASU1y3HmhzS3QO6xhjs5iedyQvstwPzkAuG2wyV3iGwowmdxgemxAyHgQvzigro+w/7hAmXmhWikRut8QibzwLMwhKbziSvjwHUsQKEmBHgjQOZx1nS5BKD9AWKhAGoF+yNFPf1DP62ApL/BMBy6PkCurYS6aANvbsLiZcVoY0B26Y50dcYrqIcgnigphG4lw3XzAe/xAbCjQrlTby9BsidBo+cEZa/DubhLsO9NeL+RufiJ5nUAcnlFtQuhvcrlNsZjdUGoN4Rlrs6yKw+ksos1s8N0sEijZwF0OsV4U2Qqib10gWQ2Aig9BzreIHMEfSiAq6uHO3PB6G+ApOcEe/5E/KPBMryBJ9QsM4BtogBg78myt0zh94GurEUnJYO5tYDw44I+64HpNQJ768r84kI1cQF7IcVtrsR0pgDjaYJtNkButEB4boS278u1bQWqNEQy9QSjI4F54QGn+4MwccRo+MB75YMwdYJ6IYqvPMUpJwXn80Ig70B9awFyPsQwTyl8hO2swWOkAbOuQq0yhGmaYCYCK6SC+/SBZHmC+z5CNHdF+2fDdXpAdDiONaxDv+oBbSmLvSnCIOqAsyjBtnyJ5riC9qqJ6vgDd6sAYPICJG2Dv+yB9OXEvOkBfvDKd0XyvUrk4QInPUo7ZEBqoIlrXOF6RbPkAuvuQKMiwmC5geu7AHq5QHFhg7YiBrblQHl9QrXuAOvjAT1xAKWggnd4xiGBobuC43XCZ2vPqwMpLMR6IMLhJ4GnRDXhw6RoQe3sQSU1Anf1BHGkgqa/wXHvg/eqwX1oxfo6ArKxxHckwefRL26DLj7BbnBBouZDefbCdTSGbDQDfT/I93TCPOhC4GpBtq0EYDFA+ruAY/fEv2tJOTmBoZKyvwqv7MJ3s4EyOIF77YdwccNv6IEjuYMrHDHugzjwAaxkAWqmgeZhQTVxQeW2xKA+AHkkwPfjgK51wGBrBjUySH6pxa8igb25BmemCTD6AKr7BD4xw/Hyxm29g3KwQaB5gTZ6Ar9ghmkhQvC+Q2aqBrB9wLj5Q2ezwW2lwGq7Qf7nQrh5AyMIdzPD4ofqN8Q0+wR3PcL+v8SnNcFgIUOjIELu8UK+bYehssLtIAU89slk84E5LMChcwOr7cdpOQYmeEp468D5egFtqgGgI0O3ZEG5M0DroEF2KUN6IYMvjmnrwH/qw+rkgel9xGs+T+bwgKEhQTZmQ/88gO+R6OHJN6uAvjBF9Ep+1CcXJr7BoOAFJn1HsW9BcuEF+3YDc+GEYH9DvLzMOfQEoT6BNn9A962Bc26FoDcFpfOB6WKIuX/K7W6AdW9BpX1DcXGIvmCH9TvDpDWDJepCOXwAtviGaW+KML5CJ6+Jq3AC9T8DqBSzNBNgYYWz+QllbIKuLYDq7VRwM0Nx4UF+NoL1n7XhAPVwgScmSnDyAzinAzSTsugJ8TfD7mmAffqHIT8CMX4LfGeN4OpG5T8A4qbBsbzA8mTCLTnE7SzDfrxEZWnDKqOCuGsAe+LDNjnCZ/9BKyvAviRApSJFPKKCcrjDq6uNY2yBdyOEaqbA/aZA4v8CpuVAqj6C/PYEJOOAcP4CKTLCJT5CP2zBsDcBZrRBJfNA8XkIYaXCdavD+q/Hqc6/dQMpuITiJsRxXGSrwSM9wOk2gHXnC+u1gz+iQuhsQWilTK6nA68/QzejgyH7wLXhAKiX7aFBIHOFpaJCPhO/fEOnvIukNQGgOMRk4dBlfgJ9YQIwZ0P1f4c/9kC2f8ggbQDwY0V+MsHhoIF47EJsasKocsKtNwNg8UK0r8Mo/YGza8Oz3WYDv/aBJn6G9QtgL4fs9ME27ELxOMJx+ULqjTS2gr5zBjlhg6F2wH65wGlowf00BC95gmt/Aehvzij8A6Z+gqvggem0QznrRfatxvzjA6X+g7WrwOflQGVnR6crAaJqAf84gufggSirAXDhQzu8QGT1huxwAGb0S+D8hSU7QWpnEeJwgPGwwqm0gGozAP52wbIqEOK1xuahxHN3gHC1AWF9x/ToQnv1R6SoS76iwH97gPGviG9/wvw5hrVwgzk5RKi8wXx3SLm3hS18Qbn+hPCxi3GpAfYxDTYjAWhmgOTxhbp7gKQoALuowHvrg/Zb84Sis8j3KcTvqQGyu8Fi7cmxPoM+Wzvxx+SnAb9kRSS1CbW2ASTtBG6khSmpgODiBKHtwT49mvytgLyqRnwux3A5Q/42RWmihqshAHVngbmqg+y3QyegQu5oBKy5BODiyTflhTulQ7M3hHz9QL3ugK+0QeGvhqpvCGCwCyf7SeunR7l9wTBrQXF3gvpkgLemhKqmxOviRnxxwj3mQyO3gPc0wKAkTHuog7jlBXdJZ6gAoqNBo77A9rUI8HyBqCQI5LoHdrFBciRA+3CIYSUBfTDFO+XFauSDKSPF4+GAbWnA5r1GeflA7ziEoK+AfzSCImHAfa6FKyrArj5IubxBpDCBupYjZcZ5gqxqQj15QHGwRLgyhnidfmvCsKeG93rKKuRAo6vC++TFuiSAduzAYGWA+lu0rQCuwzszxOF/AXv81LmxQb6rwTgsRf7uxnloAfIyQqq8h3GtgiGgQur/CHuxRSP2gamiAj5hAOxoizzvAXg5xXRSdK5CbXNEsrMEYzOGorNCofuArq1CunSILO0EcmTCvOZCKyhCaSPErm2AqupFfrlJMCjB52rCoDMC5PbIOb3BeTHA6q9D97GCe6FFcusD5LvGLTBGK+aCb4FgdkR34oBhsIY5/UHjZcXxssdjhOq/zuSsQaJgRj9shjZqAyFyQL6shPFb/iICoLtEp9UzqQEhs1E8ecEzpQdoKoDpKEBguMKg9sBpr4EnvIr/68BnrAFoLoJ2WuR5gnv+xLx1gf1mCCp4S6koQGh/hngvwWa3B6hzAKqkAT64w3bghKzqgWcywHFpA+H+giyqAjO8COFxRGH/BGzrwz7iQPD+Q320BiqugXx+AK1siHh2AG53waIywWvkBLrxUjHjhXszgT8xQjWbMb+BeXNE9KDB6q4Abu5D7PoA873E++OFvXeFbm2J4LsAtzUAokMlokInZkC/escwsoLmqQWwOQGpOQlo5cMoMwW7LgQu84N5Pgh/uwJ8ecTgM0F7uMJsbwW2PQNsf8Fp7UIj5YNlaEEkekF/NsB2HzPowKgggWZvhnk4QKZlAS2lQPP2wTO6w+k3A6MjRHBigK3lgTdsQP4sgrjtBrHrRGX2gvO1APexQHZlh2T8gHxkxDDkRqOsAKexwr+kAX01QKyqwKezAyiiCW07Q6Z2iPwwBKJsR68vwuvaYmlAvPZD9WxDNzvHpy1A70bk4AcpKwOm8IX67UO1/oGjbMD/uEN5NUQ8aYTk5EO0ckG3/IQ6N0DnegF/twbsqoYjqARpu8axZUCpJANlp0LumKhugeMnQrH0QH2xh3WyQje3BHopAvqsQOIB+bSCf77A+qHDtH8BpnkE4CPJdbTA/ikB4rVC6iIMoypEcT4BMzaFrbpDJGBAeTTQ+GWBMLnD7qUAqqBCvmUAaCGBpjsC6/FGM7zHYjfCbfIJamCGeb2DdTDA+e2A8rjCd/vBKe1AtyRLu2XBtrnBo+KEqmXCJO7Gv32DJz4AeGUApidBdyKCeHgE66QC/6CDpD7B4eYCLchh/Iu2MsD6qMC1qEB1+0G7cEH0ZURrP4Bv80Bz6UTkLULqfgIwo8F5p8I9Y4MtoID8pEF38kIweYL3qUgw5Ep7c4K1eUPlKYttcY4o+4szM4CqtgQo6cE784g5OELyqIHq6gNvPEf+UHyvhPi9gyWD4yHHY6QA9aiF8e/DseuBe+wHKb+BNT/Bb8fyqoLy90CoP4BhrgNsZQP7KEBmOwCqaERkfQR7+IE/8EUo4Ynh5AF39sBuIcBh74Wlski9qEpxOIVz+IDlZwBh5cV9JYJ6csG1/oT5ssUwuUIirkQnJcEntsYspoW7Zkd/I0Xx9EKrJgKs+EapvsFpd0BkvkZ7KEG9PAD1c0PhJQnkcYUjpsM/uwGpKoYob03vcwBzpELnrQuyKoHkNAK9JIUpPoB0PAS+vcNiKMK64QH2poM66QF+cMN+tsB44AnkfgJnIgQvJUD678Irdso96sg5O8DpMANgI0J8NMDuYkL170M2qYOx5QIr7YEvvURpe0Zpe8D7tIEqoMFsrId2acDmK0HgEnaNLaLEuT1BKjfCfjPFNWoM/SvCbXqCsC+CY+2A8nLKcbBDP6aHs7CA9uoDr2VAeysG9rBA9apI4jxC+jCEv2xGbjmFcOYDeG2IdfwHK2wE+THL4uiNPzqI+rwA47rEseNA4CHD72jBt6YCO2RAfLWC8f9GI70IZyVDJadFrS7E92+BrJr+NQNvtYByL0Os/IgyJECwO8K08YDiOsOtsID2bcEhdkIvosD0tkb6ZsHsMcO+qgL1pIDg7QP48cIzLoS5LUN0YoBlr8IoRXM4xSr+SSu1RPukw/EgQrhhwTs8QK91A2Y1iynvBa0xCPemQesugmf/gfbmgqmih3XtgGj5wO5nCC20hyEpQH+pA/vrQTTjSbBzxLftBOAngyOnC7H3ASOwAKX/RjKBaOECZXQOLvZD6PLHPuPAYG+Bv3JAdryCoNeyi6uuQiK2QGkthChvwSdlgmk/wG8qQ6EphbYpgqlygzFrAbq2g23uwuohhLK7A+yxQySvh3C8gT7ixq4vwT/kxnfugKEgALK0AXvyAqx/RTDjCyA6h39mASBnwjWuQOo0CaSqQO2oQj9hBCplQKw+w6WnALmYZu0PPKJCIDVAuT+BqffI7O4Mf7sF/PaGYKEBbuAGJzTBcLnCdjYBrTBCYjQBOv5BryvBaPBc66VOsnDGfihA9u2AYyNB6C/D/mSBKDVDaOtCL7CF5j8JYrcCpKaC9+DPt6tAboEozeKoiLNuzvQsAy80g3Vpgu65g7xyjuvpRO50QTysArR0QTOuALFhx7nrg3Y/RXWhgTQnRGSqSHhjgTu1A2EtgjL2gS31QmkrwS7xzy0xwqZ9xPMwgGmlAq+zAWYugqP1BeynAusuAKVggvN4hTp4hCryiPVgQeH4xi5wgPHogXFpzCKpgWb9AHy3w7GwAGNrAPEygOBpwG67grexgfA4AeHzgGKkAvanQLosxyP0SCAuAiN7Res0gjzpgaE9xLu5AT/qw3awV32pCbhxwaNrhqTwAK4vgzW8AGPsR7WthKV+RqPpw3qkxPXnRGQwwWCFs+dE97pB9WBD+bCDdKoAvTyEra6IMKcC9j0IZeECc+UHbmIMq6NBJirHJ/MFODzHPfQBLjNE/nmCcK7JJnvGufRHpOrA7vJArSGEabVCbfVCpKQDqGBAu2cAY/jCqjXCduMAfiNCNW5AZ/KB8LoBIGEFqXcEf2uGY/xA6yPEdyaCMuPCcyJEv2aBs+TA56QF5DGCYXNB6jtAZu9B5vqBcOMQpLzCP/XBJ4G8ZcW7JYqo9cJj94Jo5UM5PEJhJgIr5EGrpsLmSL2kxL7zw+MggPbGv6HF+2qAvnZDMntAdmYHsCnD9rTAoj0I8KXAfazJoaKJ9fINMLsAvyREZcHufQIxpEB/roFhYECoawN2a0Lkv0BltQN5NoDzvAGlQSRlALH6guHrzH8kQTYM4TVGIqKFdSJBLq5A/zsE6H8Eo23BK35JqbcHaWEIIs/tpIHyKIX5rUC0PscirsGsiqmy0Hj0g607ASL/RH39gnw8BrM5Bj/jwqxkgrZrxXW5xuRd+7wDbucBJ3wAfj5CvqFEpO0ErXIDsKFAaXzEvCtCLEy5v0H8NMKp6kP2vgMmLgBxLwOkPkpnecImpYD3pMnqrgE+4kZvcIBsv0BiNIk6qsQ7sgBpPkJpZUIgcIZ7ogEgrMCvM0D1QSiuwXfowKGjwOhoQ7KqQX94gKi6AX9iAix4hz3zwj+hxTayRrlzSPuHtbXB929Csz/GJfiI5CfBpHkCuexA7CAAq36A6bKAYuMCYn1AfXwEc2gBO35Ka64H7jBAfP2AbagCI3bMP61FumXAdq5BcKgFdaeBPLCHLj+FiGUoQGEhQnZolDWwzaR0ASLmwm+c8Ik9aIcje0Y6YkbsMYU0dMP1cANs9cM7bwLk+QFw+kvxf8yq/4Kmpo6zZ4KmrcIpMUG3YgI/MIKh84RsJUC1okE0/ICugqi5Qa73wiEjgXAwQX2vgX92Bbv/x+gDb2UCMWzB7OKGN2tL/viBverGae+BLnNBeSaE9CsAZ3pG9KTCNueI/riDsaaFNjqDPWlDdrHEJSOC/6aF7LHKaGPLNnUHaX8N4nCB/7PAdSXB8+oBLX1Fc6cA++fC9SVC6aVBambA47cCu+rDOyOCO/BAaKjC/G8EeyoDOa5BY2fH8erBa2PE4qBDIXoCeKiDEW7yyHNsAqW/wPysRDV1wH5zAK2wTnKjwOk9Qbu5QGAU/b3AYjMAdekGb7mBJmgAaiPEeWsB/CDAYCHGON62PAK5f8Y/8ETssEF2LgWwtYEmc0B+fsW5pYBn5wKrKMasI4W94kNlfEF+KECvaggw4IP1OMU8s4jwOwL59UX/IcIs9UDwJUE+pEDxsERzrkuqLYM9LsLk64GquYXoaUT8xjBuQbqwS6XywaywCesyg6Uvwab8QPYwwSsjQK/NI3pDNv+BLCRDv7EI/H5OuDyCL7aGuK9E5OzCealPu+2E/HRBaLTAq+LHKTkFKWODtTYGrLeJ7jYBeDGFK35EqnpAvP5CtWpCojWFeG6GJjMEezsAsyIFr6rJ6fIB7OEE7qmBbqbCPeDBcy9DsjNFY2zBYr2LY6pSJeQB7+jCb2PFKelErnID6a9CfDsHZ+bH92XB6+eBczuDcXfFa7ACLasBL6qB+j9C8HNGrHMAqjxAuN23YYPoekYkOoJiNAZsPgQyKUHjYgG/aYLqlfv/xKP4AWXvAHFqEHgsw7j7RaD1Qjb+xG7+BHMvQqflAqz2QnMnieaggHUogOn7R7n2ALklwOcuAiZswXILLuKDdSwJ97RQ8OuEbyWEPfGA/K+CqTlGaT6Aboq68gl7P4Grd0Foh/20hHX/QTO+AGwkQWu/hPa9hLnygHqsA2l4hSLsCS4sBuS3QrdjALLtQHdqATBzBOSpgvhkQHLjwG+6AaFI+r3Bfe6CNILs+IvtcQaouQp5P0D0vsCraYClNQKzZ4K0uMQn/ID/cIRkIYV+pcYqp4Ut4gDpusN6QrOyAfs+QKAhgObsgnx+jH7DeWBA92qBNLOA4bQD7KSEqDyBfCBDbjtBpDxE971C4JpoEvdqQTYrBWOuQ+J8AmZyA6hyBC2nzaw3QjojQin8C+2nw6ohw3G7gaa3Ae3jgqGtAHWvwT4iAPIrBD3HYrIHbKoB4OrDvHQBpC6Cd6XDuEuw9EhjMEIxNkIzK0Ig84Vva0FmYoG4MIMypUQ/rYMo8cGpMQN6agGps4Kp9pDp2f25gHnvRCme7fGAdOCApvMAamJGbz/BtF0mbge1/A09r4EwJcSxz2+6Qat6APkrQmtoQjUM7zXHYnhBfGnBaSWFcyBBuL5OPsQ6IoEodcDnvcj2Y8J7OcH+tQS78Q6w84B3a4CzKYExYkUiKFM5muq0gfUwQeyiQyksxHkzgLMnweQ2QTwxh+q+gP0pBPwpCG09xKXxw3IsSbgswvssxO33hauvheJlRbSyxjezA2f8iP1gBGntxWJ6RHatwXxswLe2xDQvAzIgAeR5waJmRbwtgzK6wS23Q/x2A3cpBfIxBnB7AGbsAXzpQLL9BLVyASmnhSq4RvWiga2zQKXzgLyrgut8wHLvRTv1CfLhiD4szb3Y+imH4HjAtPZD9qGUIurDKXhDp+xAa+4ELujD6vpC/G8CMRExfk077Amo/cbqbkP2O9GhoQD9PkH/9o2079Nrt0DoIoex4QSi8YQ1PQF67IJ/qgIkakM78wQ1soXl/kvts0Z/IAP6P8S5N4FhbcpvIEFxMMNzIcGzKMH1P4G9YYBzdYEhIYDiPkH374Gm5gnuYoalbMT3eICmqQc9NISo40S04kD6kLErAWv/RKFzwPEhBa0rDOAlQXJeNblGs/2BtiTGtiEA+f2B8IIhPQBpIwP0PMU9qQGj4YBm2mgsRe5xQ/WvRCf5wPLqhuRmzGh6QeMtwek7QyczAGF1gn8rAethRL70waFHoe5B5SvFZzBGMn+E7ziE6OUAq/CFdiMBuqpLPKqD8/mD+p15NUK98UG4ZEG2OMQzv0Bh4YNlvgYgtQHnqYBx8IR87EZwKYBw/ACvKYFkJYW94YJsIoZ4zrdjQjoDtj3FcuNBdyOAbm0CPKRCZ/EBsP5CtPDLY6QA+GxAbLPCYcNupIUw9olk6op654og4YGkjurgxCSrRLtjwb5+wTEpR/q1hzVvw/zzgHOygO3lxHdiAeUohvJhQ7wrAODNNrWHoE+84MExo8I6IIX8bUCl8ECqukFn+AGmY8LnY8NtZUk07Yav48BnjiTjwnvvxqLqwjEkxPh5gXLrwK5+hHp0SLJpkbK5Bj1hBXThQrX/R+byw6fvwuM0gTEswP3mUDBtAGglQe7lAj8zwPuow6ikwbcpgTwlBDhW/CGDJXIFeWpCs7nELDZAoqPEtfNFL9siKUG6DLDnATNfq/5FqmsHvOxGdukEORysfspnYYXyPoQ0m2nwgbrjRGVlwfoxDrJtwbMwQGo3D6WmwG22hrEow7gaeiuHb6GCYC4COTSM6LAAfGUBpfICYKyCfr5AuG9AbXTAoXyEJfEG/qIEvImhMEehaAE5tYYhOYU3acZ8eYNwasDzaQPvvYOwK4ZzJAK7fEXy7wNn94X1voY8ZEIorwKitsHj7Mfv4wG8/EYsPwY16oLwK4jhtcHtZQI9rUDxbgS4doY0JEk+upQmscutvcxycUHoPsBxv8Hq/QQ0OcGq+4JoKYV7uwJ8Y0BjZEJrnOFgiH7/x/rvyr6jRin1QLiog/tvxiWtQGqwAbr+kLd9Q3p+AmtlhG6uRXTvhn3hQbl0w/diwjRtQHtpAvRtyzfXpyYIuaBFfGmDKDPCaztD8CfApvqGdv8E+THCJPRIOm8CLjLDKY49ZIN7FuE1w3Psga63Qv+uAuvlAW4pUHZmAuilwW72gignBDwcKzTApylBJ7HCb0a7IEy7dUKwv0i9/IF2Z8ByrcI/KYMmdsO4qcVrGuMmAOGjhv7+QmAvgj6+wjHmASq9wie+BKPngbz4xCk7w7z0Qj82gLBoCOpCLK4CqRu+YwSyvYJsb4Gmb0Jn1vvnQmZ+gPsuxj2W6SoCMSSArD1D+y2A6q+He2LDaT+D5X/DuCdCLOTJIeQHL+6FausJNixBLmFCovgBMeTBPyoA5LDFqCcCKP8B+eiBsqZC4PqCOHMBoeZBInbAaPjAvSjD/IW7NUDkIwZm8kEu9MJ7XKk6wzS2gSRvALYpwb9yQXR0QXJ9AHdkw3xjg/gtx2RhQqpsAfw6wnctCiEoxWNlAHcep3jBYq5EOPWAtW5FOTPCNyULoCrAYfrBpauLLuSA/3iA+qPBun2DueLKpnEDorgAcUWppw8gd0Q2uIFsccYxtMQ7/YYqZAnmoYQ0tUBpqYGhb8yv/IU7rkM7aMB/MMg0e4BmqMKkNYLvPME/bEfvroJo9YP4qAM5vsVmOICyNUFlagDpuYLsL8Cj7oBuOMHztUIu7UE/58l2d4FiYkDmbg4y9IU9tUJx78F3r8FmYEHv7cV2qQNmfQGg50L4hTnyB2gggL2mgHM3A6izBCLhASppRzVUs/fBuLxAYpfm7oBndYbsMEC3ZQLn/IX6YsM1JkQp9gEhLoGu602occNnfsFu8MbiY8KtOQK8MockKMJ5s4Y6fUN0JAFmZgDqowDjuIC1LgK4Y0CqosD0+wOy80FkugEi7UZyLsCqPYTtosBmagXrscF2cwB2J8W3bULsMkK1aEOlJwVm+UBmJ4CpIcB9vAImMQNnaEEiOkGguEI854g1qgij2iL2Qny4AaHpA7aswGY/QWpDYnJAfetMs6FBciyDsYp1pQonf8EgeEOqd4N2N4O2cQQiJoEz5oO1K4X78UBwc8DgZADxMwMyOEFlv4Jiqodwc4D1t4D+sQCgcYG3tIDjckI/toO/ZISiqob5e0dp5Ee594emJML9cgkosQHp6cj8Z5U/7IEgbsu5wig9xCHkw/CpgW2tgXOzSvSYO6UH/r5B5XxEMe0Ct7wQNikHZ+NAY+5AvrjB4XKA6PCAqWdIbiQEYSJDtzPBab/CICJCOyrCrzTFrn1A57vAoTtB7q6DZnsGpfMDtTlEYr+CumGDrvBBeuoJ7H6BJS+CsztC6rLBb2zAo/1Ero1xN4NlJ0GuMUQ49QIyroSsF/xlQak9wGwiwLE8Ait0SHEiS3iwgKC8ALH0S7wuAu7swXa7xiY5BTVmgrM8B+mzgHk9ATB5x/suAjD7Aml2wiGxw3igg7/hgaPqgS4nAblpSvIkjHyvgXKqA/7mgHqoxK4mguP6gzz1iOd1wLTKPKmArX2IsKXBvijB/K7C+bfBMWVHcbxL73LBYvaDtecCrDOA5OgCcKsGbHXAZaqBZWaHvqKC/qSEqKvA9SdBvgagpcEoPsd56MHk7dB6elFubQs3NIG78oFsdcd+YsRw98BjukOwooL8qQ1oeYD988Ti8sFn6wNgZE2+ckQ2Jof548CvPELrLAEyYMBmdkN3KIS4MMH4t9A9/AO0cUG/LkD0pMchkjRshO/lwz47wXP2wbb4gmU6A7RiQ6fqA+6nArmhgjB2Q64nDHRiRKd0QeI8ge3HqmFT+KDA8jTEfjsHKvcB86xMOmdHJfMBoWyCZfWJ7zVA6+WAd7QAuCZGuS7B6exBZiIAt6vIaLeI5rvAcDhApRRx94anN4YlsAM/8cEkpc64fUF7+UrwowQgK0Qz4ESkyKroASKlArmzw/9iQT5qQ7O+QmQnhWV7QicsAbxxB2v2SWIvQHHoDDh3QXAqAeJlC6rwwPH2BuOphK4mAyQ1QHevgKL5gTcxwSB4gKPrUeX5ATHngexa9GmBtCLCInKIpuGGK6tAt2RBJWdA+WLGMbPAtiKBaGOAs/qCcy+DsDDB76UBezvAsH4K6YByuQOjLgbuPsJ/ecK4yrc/wHmM9uaBNaBDfSSAet5iKMQtpMIhLkB5okEmoUNlbgNzrYCkqAD2uQMi4oE5dEaqdET3c8HlNoDtacQheoKh/wHkYEa2hm55RyXoyre7wj46U6u7RHF3xHFtBGyuxOQqhigBr/1A6vOEuH2Auf6HfrXDL76CaCGHdXPG5igT4HmDIjABIK+D7OsCfeFCeqWA/y0AtDIBYj6DfXbBfTPDdfGBKWgA+f6Af34BIrHBsSIDZBep58Cr+IM+bcH8fIN6YgOhOtI1y6o1we9kAzgKdPaBebYF5n4A93bCKzGA7HIGrDzEarCN6v+EZHXBJngFZiRA/TODr6xBtXKDt/uA7bBAqyzFLymDqP6AbGJF/KFD+VX+wiemRTOgBfe5QjHowOL8xuCwyjyhwf6vAf+pAWYsAWilw795BDl/wOisBDEnwKFsAaY5QiopQ2p3QjReIrhG860BvbcAs3KA6SXBIvTAZbfEpikCLr2BYOaD4itBsL1A9aYEby4FM7gEZDIIqiWBo6pJ6/uAuHXBYKwB+nCDNnPE8LVAv6DBNTFE7D/BegjypwRtLcKjYklioIIqrky/dMB59gx47cB7dgO4vYEvOUJkIAG/bcEjsgB+IQCuu4Dv+QdlqsHynS/9ETWggaC5QaT2QWOow2boQv9iwefuBadogSqzAW9oi+MHfWEDpirDKjqP6qJBP/yA5imDffBCpzSD5vKApbVA4mMDdL0BJi6De2MDs6KD/3bFq/kFoq1BfypDpOqC/jpJeCOCPHWEYytApDXGuPFENO4Ee25Brf3JMhggqRG7ZwH17AJsLQNlL8YhdsTp6EPsZ4D1cYe8NMCnfkJreQVmJ4WnacBuJUDm4QN26o42kmD8C7onAaP/wvulRfU8wiP9QHBJuzUD/aqH8q3E4TnFfXWA+SzAbdUvL0Gv3vPwAuc9Rf4kCPUkRz3Nqv6HI7lB8LZJujyF7GdHYaUFYTAHpe8DozaEcjNFqLMDtjyAZGoAurfCNqsCO2NAdDuA4rRE6rzDIGDA5q1H5isBOiiDteWBKD7AbKWDtHjDbu8BdCzF6HTBfyzEsiODfLeAYDSA6yZiwHZ0AjXgArq6wT1qjPzyhOMgQvHrwK97xzUpC+sjAS8tgXulwKhJq2kBfnGJ+bDAaq7BJj2FYybBvmXCIXtDqusB9vSAfP7AfwCm/QJlNEH2pAI9/EOyqAHxrwwqt4D7IEbppUKyYYC0PcJuZ4H6foDl5cEvoERzK4Qvb0G89IC5a4Ms+QMjtsH7/YWt5wV9+kat90PmpsIqp8D8L4HoljtrRTnjwbLqwuYugqk4B2H9Q6XkQjSjQ/C7SewrQjO7AiTpQPM0BnelgGH1xSilgOt+wX39xL0Kq+RIaanFoLlFrzmH6iBCvflA7+BBIy3BfqkA7JOs+EH6c8BmtUOmpUxnM8KkJ8Y0N8P5sIa18sL7O0V3sYFzJkS/qozz7Ui/oARrc0DvpgKjdwPiqYCh9cc17QpwfIQ9YoFz7EDpsIGussNrKwGivAO5aYEq4MIgrQF0e0GjLkL++QFzIYBjdoMnu0CiMgHwuAxsfEluo8Dvucb0ZA0j54QtfQVrPJgqBqishSxlCTEhCuHyAel6gOHqieB/gKI4AOizAjNmxartAuVnCX12Sy8oBKS3CPs5xv1kROJb5qtHO/dEMazLPbjAYfaAaXpBLivGLCUBKPZDrvAA/PDDIGTArvOCZHUDO3HA6GwLeXjINihBY+NHfTcA8PUD/6TCMPlB+XxAcyzFdfNFbD2B4mQBpvpCKK6M7OXGvS/AqyhEqTeB8qYDq7qBLSFCc2dCdK4AfXaGcbEC5/zCv2+Aou2HN7YD/TAGOsSxfQE3MEIyJkUgTC5/wjS5wqJsw+t8A2Q2wjyxAiQmxKpkRKHwRDelwuZhgGw/gTxrAPt9QKfxwusqQaf/gvP4QLq3wHXItLdBO6WCbRpg+8nsvUW+Z0Eh+QZ7NIHueIx+tYa3JwB1MQm5vMMtNwZ4xrGhiGAkguLUImoApKEAcT1F/OvDozDHenHEvj7EcbdDfeNDK+0IOHdE9bNEdCtEJu3BrW3AeibCIW8GufMMIiRBq+sCLixGNasDPHBAbWGF/+RDsOmG8DICPbPDaKFAYpOycIRjMgGsrUNyrsPiOMXtPMN6yGs5VLK5gaAeObFBMChDpi1CeHkBO+YD5yRDL/eC8njCaPgQ+5B6K8F0dMLjj309w2x9Am98Qn4qwmf8QLksgX8+CXt0hGfrQGzxgufyxLUsRT0sQ7hxzjhoQKU0Rrrw064c4CtBcqQBpjnBM+BBf2zEIqRH67CAuvjDeKfBaeZJOLbA4niEK/IAf/VHpC8GKKcEt+nFq/mB//WAb6zA/KPDuXrA/u/FJK2HbGIF5aDAYCZBOqsAtkTnoAI1/cY2skIk+sL/ewjy+UjwMwY48kB0sMSg8oki+Unpvoex4E85Z0Eun3hyxGlzB2BmwTSrAvj7wL51xOaswLk3Bmf0QveqAbqjwqgmRSkggH4ywu5+gaSiQ7P5Qf8wBvrqwiN1wGfnlbsrQeykiy+/Qjx6lKvmRK55BHCrgazggXl0w6WmRybrS6fvxHjnQ/Q2wKZ8weKpyHE3Q+Vtg7T1Qn/8hqLmQO46g3HrA+3qgW2rwg="
  };

  // shared/js/background/components/native-messaging.js
  var import_webextension_polyfill7 = __toESM(require_browser_polyfill());
  var DEFAULT_NATIVE_APP_ID = "com.duckduckgo.macos.browser";
  var NATIVE_EVENT_COMMAND = "ddg-native-event";
  var NATIVE_EVENTS_FEATURE = "nativeEvents";
  var NATIVE_EVENTS_CONTEXT = "ddgInternalExtension";
  var sharedTransport = null;
  var NativeMessagingTransport = class _NativeMessagingTransport {
    /**
     * The transport, created on first use. `NativeMessaging` instances are created during the background's first
     * turn, so this registers the command listener in time for WebKit to wake the background for it.
     * @returns {NativeMessagingTransport}
     */
    static shared() {
      return sharedTransport ?? new _NativeMessagingTransport();
    }
    /**
     * Forgets the shared transport, so tests can create a fresh one.
     */
    static resetSharedForTesting() {
      sharedTransport = null;
    }
    /**
     * @param {object} [options]
     * @param {string} [options.appId]
     * @param {CommandsApi | undefined} [options.commands] - defaults to `browser.commands`
     * @param {SendNativeMessage} [options.sendNativeMessage] - defaults to `browser.runtime.sendNativeMessage`
     */
    constructor({
      appId = DEFAULT_NATIVE_APP_ID,
      commands = import_webextension_polyfill7.default.commands,
      sendNativeMessage = (id, message) => import_webextension_polyfill7.default.runtime.sendNativeMessage(id, message)
    } = {}) {
      if (sharedTransport) {
        throw new Error("NativeMessagingTransport already exists: use NativeMessagingTransport.shared()");
      }
      sharedTransport = this;
      this._appId = appId;
      this._sendNativeMessage = sendNativeMessage;
      this._subscriptions = /* @__PURE__ */ new Map();
      this._draining = null;
      this._drainRequested = false;
      commands?.onCommand.addListener((command) => {
        if (command === NATIVE_EVENT_COMMAND) {
          this.drain();
        }
      });
      this.ready = Promise.resolve().then(() => this.drain());
    }
    /**
     * @param {NotificationMessage} msg
     */
    async notify(msg) {
      await this._sendNativeMessage(this._appId, msg).catch((e) => {
        throw e;
      });
    }
    /**
     * @param {RequestMessage} msg
     * @returns {Promise<any>} the response's result
     */
    async request(msg) {
      const { context, featureName, method: method2, id, params } = msg;
      const response = (
        /** @type {MessageResponse} */
        await this._sendNativeMessage(this._appId, msg).catch((e) => {
          return {
            id,
            context,
            featureName,
            error: {
              message: `NativeMessaging request-response error: ${e}`
            }
          };
        })
      );
      if (!response || typeof response !== "object") {
        throw new Error(`NativeMessaging: unexpected response type: ${typeof response}`);
      }
      if ("error" in response && response.error) {
        throw new Error(response.error.message || "Unknown error");
      }
      return response.result || {};
    }
    /**
     * @param {Subscription} msg
     * @param {(params: Record<string, any>) => void} callback
     * @returns {() => void} removes the listener
     */
    subscribe(msg, callback) {
      const key = `${msg.featureName}.${msg.subscriptionName}`;
      let listeners = this._subscriptions.get(key);
      if (!listeners) {
        listeners = /* @__PURE__ */ new Set();
        this._subscriptions.set(key, listeners);
      }
      listeners.add(callback);
      return () => listeners.delete(callback);
    }
    /**
     * Pulls queued subscription events from native and dispatches them. Concurrent calls share one pull; a call made
     * during a pull schedules one more, so events queued mid-pull are not left waiting for the next command.
     * @returns {Promise<void>}
     */
    drain() {
      if (this._draining) {
        this._drainRequested = true;
        return this._draining;
      }
      this._draining = (async () => {
        try {
          do {
            this._drainRequested = false;
            await this._drainOnce();
          } while (this._drainRequested);
        } finally {
          this._draining = null;
        }
      })();
      return this._draining;
    }
    async _drainOnce() {
      let result;
      try {
        result = await this.request({
          context: NATIVE_EVENTS_CONTEXT,
          featureName: NATIVE_EVENTS_FEATURE,
          method: "drainEvents",
          id: crypto.randomUUID(),
          params: {}
        });
      } catch (e) {
        console.error("NativeMessagingTransport: failed to pull events", e);
        return;
      }
      const events = Array.isArray(result?.events) ? result.events : [];
      for (const event of events) {
        this._dispatch(event);
      }
    }
    /**
     * @param {NativeSubscriptionEvent} event
     */
    _dispatch(event) {
      const listeners = this._subscriptions.get(`${event?.featureName}.${event?.subscriptionName}`);
      if (!listeners) {
        return;
      }
      for (const listener of listeners) {
        try {
          listener(event.params ?? {});
        } catch (e) {
          console.error("NativeMessagingTransport: subscriber failed", e);
        }
      }
    }
  };
  var NativeMessaging = class {
    /**
     * @param {string} context
     * @param {string} featureName
     * @param {object} [options]
     * @param {NativeMessagingTransport} [options.transport] - defaults to `NativeMessagingTransport.shared()`
     */
    constructor(context, featureName, { transport = NativeMessagingTransport.shared() } = {}) {
      this._context = context;
      this._featureName = featureName;
      this._transport = transport;
    }
    /**
     * Send a fire-and-forget notification to the native app.
     *
     * @param {string} method - The method name to call on the native side
     * @param {Record<string, any>} [params] - Optional parameters to send
     */
    async notify(method2, params = {}) {
      await this._transport.notify(
        /** @type {NotificationMessage} */
        { context: this._context, featureName: this._featureName, method: method2, params }
      );
    }
    /**
     * Send a request to the native app and wait for a response.
     *
     * @param {string} method - The method name to call on the native side
     * @param {Record<string, any>} [params] - Optional parameters to send
     * @returns {Promise<any>}
     */
    async request(method2, params = {}) {
      return this._transport.request(
        /** @type {RequestMessage} */
        {
          context: this._context,
          featureName: this._featureName,
          id: crypto.randomUUID(),
          method: method2,
          params
        }
      );
    }
    /**
     * Listen for subscription events native sends for this feature.
     *
     * @param {string} subscriptionName
     * @param {(params: Record<string, any>) => void} callback
     * @returns {() => void} removes the listener
     */
    subscribe(subscriptionName, callback) {
      return this._transport.subscribe(
        /** @type {Subscription} */
        { context: this._context, featureName: this._featureName, subscriptionName },
        callback
      );
    }
  };

  // shared/js/background/components/user-allowlist-sync.js
  var import_settings2 = __toESM(require_settings());
  var ALLOWLIST_CHANGED_SUBSCRIPTION = "onAllowlistChanged";
  var ALLOWLIST_SETTING = "allowlisted";
  var ALLOWLIST_VERSION_SETTING = "userAllowlistVersion";
  var UserAllowlistSync = class {
    /**
     * @param {NativeMessagingInterface} nativeMessaging - messaging for the native `userAllowlist` feature
     * @param {object} [options]
     * @param {SettingsApi} [options.settingsApi] - defaults to the extension's settings
     */
    constructor(nativeMessaging2, { settingsApi = import_settings2.default } = {}) {
      this.nativeMessaging = nativeMessaging2;
      this._settings = settingsApi;
      this._eventCount = 0;
      this._settingsReady = Promise.resolve(settingsApi.ready());
      nativeMessaging2.subscribe(ALLOWLIST_CHANGED_SUBSCRIPTION, (params) => this._onChanged(params));
      this.ready = this._settingsReady.then(() => this._pull());
    }
    /**
     * Pulls the allowlist from native if it changed since the version held.
     */
    async _pull() {
      const eventCount = this._eventCount;
      let result;
      try {
        result = await this.nativeMessaging.request("getAllowlistIfNew", { version: this.version });
      } catch (e) {
        console.error("UserAllowlistSync: failed to fetch allowlist", e);
        return;
      }
      if (eventCount === this._eventCount) {
        this._update(result);
      }
    }
    /**
     * @param {AllowlistChangedParams} params
     */
    _onChanged(params) {
      this._eventCount++;
      this._settingsReady.then(() => this._update({ ...params, updated: true }));
    }
    /**
     * Stores a list from native in settings if it is well formed and new. Native's data is checked, not trusted to
     * match the types.
     * @param {GetAllowlistIfNewResult} result
     */
    _update(result) {
      if (!result?.updated || !Array.isArray(result.domains) || typeof result.version !== "string") {
        return;
      }
      if (result.version === this.version) {
        return;
      }
      const allowlist = {};
      for (const domain of result.domains) {
        allowlist[domain] = true;
      }
      this._settings.updateSetting(ALLOWLIST_SETTING, allowlist);
      this._settings.updateSetting(ALLOWLIST_VERSION_SETTING, result.version);
    }
    /** @returns {string[]} */
    get domains() {
      return Object.keys(this._settings.getSetting(ALLOWLIST_SETTING) || {});
    }
    /** @returns {string | null} */
    get version() {
      return this._settings.getSetting(ALLOWLIST_VERSION_SETTING) ?? null;
    }
  };

  // shared/js/background/background-embedded.js
  var nativeMessaging = new NativeMessaging("ddgInternalExtension", "autoconsent");
  globalThis.addEventListener("error", (event) => {
    nativeMessaging.notify("extensionException", {
      message: `Uncaught error: ${event.error?.message ?? event.message}`,
      stack: event.error?.stack
    }).catch((e) => {
    });
  });
  globalThis.addEventListener("unhandledrejection", (event) => {
    nativeMessaging.notify("extensionException", {
      message: `Unhandled promise rejection: ${event.reason}`,
      stack: event.reason?.stack
    }).catch((e) => {
    });
  });
  var cpmMessaging = new CPMEmbeddedMessaging(nativeMessaging);
  var userAllowlist = new UserAllowlistSync(new NativeMessaging("ddgInternalExtension", "userAllowlist"));
  var messaging = new MessageRouter();
  var cpm = new CookiePromptManagement({
    cpmMessaging,
    siteRankLookup: createSiteRankLookup(site_buckets_default)
  });
  var components = {
    messaging,
    cpm,
    userAllowlist
  };
  Promise.all([
    import_webextension_polyfill8.default.scripting.getRegisteredContentScripts(),
    import_webextension_polyfill8.default.alarms.getAll(),
    // @ts-ignore - getBytesInUse is not available in the type
    import_webextension_polyfill8.default.storage.session.getBytesInUse(null)
  ]).then(([scripts, alarms, bytesInSessionStorage]) => {
    const quotaBytes = import_webextension_polyfill8.default.storage.session.QUOTA_BYTES;
    cpmMessaging.logMessage(
      `DuckDuckGo Embedded Extension loaded.
        Content scripts: ${JSON.stringify(scripts)}
        Alarms: ${JSON.stringify(alarms)}
        Current time: ${Date.now()}
        Bytes in session storage: ${bytesInSessionStorage} (Quota ${quotaBytes})
        `
    );
  });
  self.components = components;
})();
/*
 * [js-sha1]{@link https://github.com/emn178/js-sha1}
 *
 * @version 0.6.0
 * @author Chen, Yi-Cyuan [emn178@gmail.com]
 * @copyright Chen, Yi-Cyuan 2014-2017
 * @license MIT
 */

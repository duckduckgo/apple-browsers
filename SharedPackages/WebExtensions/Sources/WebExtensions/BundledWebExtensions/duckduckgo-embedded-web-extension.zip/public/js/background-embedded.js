"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __esm = (fn, res) => function __init() {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  };
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // node_modules/webextension-polyfill/dist/browser-polyfill.js
  var require_browser_polyfill = __commonJS({
    "node_modules/webextension-polyfill/dist/browser-polyfill.js"(exports2, module2) {
      (function(global2, factory) {
        if (typeof define === "function" && define.amd) {
          define("webextension-polyfill", ["module"], factory);
        } else if (typeof exports2 !== "undefined") {
          factory(module2);
        } else {
          var mod = {
            exports: {}
          };
          factory(mod);
          global2.browser = mod.exports;
        }
      })(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : exports2, function(module3) {
        "use strict";
        if (!(globalThis.chrome && globalThis.chrome.runtime && globalThis.chrome.runtime.id)) {
          throw new Error("This script should only be loaded in a browser extension.");
        }
        if (!(globalThis.browser && globalThis.browser.runtime && globalThis.browser.runtime.id)) {
          const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received.";
          const wrapAPIs = (extensionAPIs) => {
            const apiMetadata = {
              "alarms": {
                "clear": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "clearAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "get": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "bookmarks": {
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getChildren": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getRecent": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getSubTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTree": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "browserAction": {
                "disable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "enable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "getBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "openPopup": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "browsingData": {
                "remove": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "removeCache": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCookies": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeDownloads": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFormData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeHistory": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeLocalStorage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePasswords": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePluginData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "settings": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "commands": {
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "contextMenus": {
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "cookies": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAllCookieStores": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "set": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "devtools": {
                "inspectedWindow": {
                  "eval": {
                    "minArgs": 1,
                    "maxArgs": 2,
                    "singleCallbackArg": false
                  }
                },
                "panels": {
                  "create": {
                    "minArgs": 3,
                    "maxArgs": 3,
                    "singleCallbackArg": true
                  },
                  "elements": {
                    "createSidebarPane": {
                      "minArgs": 1,
                      "maxArgs": 1
                    }
                  }
                }
              },
              "downloads": {
                "cancel": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "download": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "erase": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFileIcon": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "open": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "pause": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFile": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "resume": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "extension": {
                "isAllowedFileSchemeAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "isAllowedIncognitoAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "history": {
                "addUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "deleteRange": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getVisits": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "i18n": {
                "detectLanguage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAcceptLanguages": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "identity": {
                "launchWebAuthFlow": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "idle": {
                "queryState": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "management": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getSelf": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setEnabled": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "uninstallSelf": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "notifications": {
                "clear": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPermissionLevel": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "pageAction": {
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "hide": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "permissions": {
                "contains": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "request": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "runtime": {
                "getBackgroundPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPlatformInfo": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "openOptionsPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "requestUpdateCheck": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "sendMessage": {
                  "minArgs": 1,
                  "maxArgs": 3
                },
                "sendNativeMessage": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "setUninstallURL": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "sessions": {
                "getDevices": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getRecentlyClosed": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "restore": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "storage": {
                "local": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                },
                "managed": {
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  }
                },
                "sync": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                }
              },
              "tabs": {
                "captureVisibleTab": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "detectLanguage": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "discard": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "duplicate": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "executeScript": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getZoom": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getZoomSettings": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goBack": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goForward": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "highlight": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "insertCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "query": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "reload": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "sendMessage": {
                  "minArgs": 2,
                  "maxArgs": 3
                },
                "setZoom": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "setZoomSettings": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "update": {
                  "minArgs": 1,
                  "maxArgs": 2
                }
              },
              "topSites": {
                "get": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "webNavigation": {
                "getAllFrames": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFrame": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "webRequest": {
                "handlerBehaviorChanged": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "windows": {
                "create": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getLastFocused": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              }
            };
            if (Object.keys(apiMetadata).length === 0) {
              throw new Error("api-metadata.json has not been included in browser-polyfill");
            }
            class DefaultWeakMap extends WeakMap {
              constructor(createItem, items = void 0) {
                super(items);
                this.createItem = createItem;
              }
              get(key) {
                if (!this.has(key)) {
                  this.set(key, this.createItem(key));
                }
                return super.get(key);
              }
            }
            const isThenable = (value) => {
              return value && typeof value === "object" && typeof value.then === "function";
            };
            const makeCallback = (promise, metadata) => {
              return (...callbackArgs) => {
                if (extensionAPIs.runtime.lastError) {
                  promise.reject(new Error(extensionAPIs.runtime.lastError.message));
                } else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) {
                  promise.resolve(callbackArgs[0]);
                } else {
                  promise.resolve(callbackArgs);
                }
              };
            };
            const pluralizeArguments = (numArgs) => numArgs == 1 ? "argument" : "arguments";
            const wrapAsyncFunction = (name, metadata) => {
              return function asyncFunctionWrapper(target, ...args) {
                if (args.length < metadata.minArgs) {
                  throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
                }
                if (args.length > metadata.maxArgs) {
                  throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
                }
                return new Promise((resolve, reject) => {
                  if (metadata.fallbackToNoCallback) {
                    try {
                      target[name](...args, makeCallback({
                        resolve,
                        reject
                      }, metadata));
                    } catch (cbError) {
                      console.warn(`${name} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `, cbError);
                      target[name](...args);
                      metadata.fallbackToNoCallback = false;
                      metadata.noCallback = true;
                      resolve();
                    }
                  } else if (metadata.noCallback) {
                    target[name](...args);
                    resolve();
                  } else {
                    target[name](...args, makeCallback({
                      resolve,
                      reject
                    }, metadata));
                  }
                });
              };
            };
            const wrapMethod = (target, method2, wrapper) => {
              return new Proxy(method2, {
                apply(targetMethod, thisObj, args) {
                  return wrapper.call(thisObj, target, ...args);
                }
              });
            };
            let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);
            const wrapObject = (target, wrappers = {}, metadata = {}) => {
              let cache = /* @__PURE__ */ Object.create(null);
              let handlers = {
                has(proxyTarget2, prop) {
                  return prop in target || prop in cache;
                },
                get(proxyTarget2, prop, receiver) {
                  if (prop in cache) {
                    return cache[prop];
                  }
                  if (!(prop in target)) {
                    return void 0;
                  }
                  let value = target[prop];
                  if (typeof value === "function") {
                    if (typeof wrappers[prop] === "function") {
                      value = wrapMethod(target, target[prop], wrappers[prop]);
                    } else if (hasOwnProperty(metadata, prop)) {
                      let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                      value = wrapMethod(target, target[prop], wrapper);
                    } else {
                      value = value.bind(target);
                    }
                  } else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) {
                    value = wrapObject(value, wrappers[prop], metadata[prop]);
                  } else if (hasOwnProperty(metadata, "*")) {
                    value = wrapObject(value, wrappers[prop], metadata["*"]);
                  } else {
                    Object.defineProperty(cache, prop, {
                      configurable: true,
                      enumerable: true,
                      get() {
                        return target[prop];
                      },
                      set(value2) {
                        target[prop] = value2;
                      }
                    });
                    return value;
                  }
                  cache[prop] = value;
                  return value;
                },
                set(proxyTarget2, prop, value, receiver) {
                  if (prop in cache) {
                    cache[prop] = value;
                  } else {
                    target[prop] = value;
                  }
                  return true;
                },
                defineProperty(proxyTarget2, prop, desc) {
                  return Reflect.defineProperty(cache, prop, desc);
                },
                deleteProperty(proxyTarget2, prop) {
                  return Reflect.deleteProperty(cache, prop);
                }
              };
              let proxyTarget = Object.create(target);
              return new Proxy(proxyTarget, handlers);
            };
            const wrapEvent = (wrapperMap) => ({
              addListener(target, listener, ...args) {
                target.addListener(wrapperMap.get(listener), ...args);
              },
              hasListener(target, listener) {
                return target.hasListener(wrapperMap.get(listener));
              },
              removeListener(target, listener) {
                target.removeListener(wrapperMap.get(listener));
              }
            });
            const onRequestFinishedWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onRequestFinished(req) {
                const wrappedReq = wrapObject(req, {}, {
                  getContent: {
                    minArgs: 0,
                    maxArgs: 0
                  }
                });
                listener(wrappedReq);
              };
            });
            const onMessageWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onMessage(message, sender, sendResponse) {
                let didCallSendResponse = false;
                let wrappedSendResponse;
                let sendResponsePromise = new Promise((resolve) => {
                  wrappedSendResponse = function(response) {
                    didCallSendResponse = true;
                    resolve(response);
                  };
                });
                let result;
                try {
                  result = listener(message, sender, wrappedSendResponse);
                } catch (err) {
                  result = Promise.reject(err);
                }
                const isResultThenable = result !== true && isThenable(result);
                if (result !== true && !isResultThenable && !didCallSendResponse) {
                  return false;
                }
                const sendPromisedResult = (promise) => {
                  promise.then((msg) => {
                    sendResponse(msg);
                  }, (error) => {
                    let message2;
                    if (error && (error instanceof Error || typeof error.message === "string")) {
                      message2 = error.message;
                    } else {
                      message2 = "An unexpected error occurred";
                    }
                    sendResponse({
                      __mozWebExtensionPolyfillReject__: true,
                      message: message2
                    });
                  }).catch((err) => {
                    console.error("Failed to send onMessage rejected reply", err);
                  });
                };
                if (isResultThenable) {
                  sendPromisedResult(result);
                } else {
                  sendPromisedResult(sendResponsePromise);
                }
                return true;
              };
            });
            const wrappedSendMessageCallback = ({
              reject,
              resolve
            }, reply) => {
              if (extensionAPIs.runtime.lastError) {
                if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) {
                  resolve();
                } else {
                  reject(new Error(extensionAPIs.runtime.lastError.message));
                }
              } else if (reply && reply.__mozWebExtensionPolyfillReject__) {
                reject(new Error(reply.message));
              } else {
                resolve(reply);
              }
            };
            const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
              if (args.length < metadata.minArgs) {
                throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
              }
              if (args.length > metadata.maxArgs) {
                throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
              }
              return new Promise((resolve, reject) => {
                const wrappedCb = wrappedSendMessageCallback.bind(null, {
                  resolve,
                  reject
                });
                args.push(wrappedCb);
                apiNamespaceObj.sendMessage(...args);
              });
            };
            const staticWrappers = {
              devtools: {
                network: {
                  onRequestFinished: wrapEvent(onRequestFinishedWrappers)
                }
              },
              runtime: {
                onMessage: wrapEvent(onMessageWrappers),
                onMessageExternal: wrapEvent(onMessageWrappers),
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 1,
                  maxArgs: 3
                })
              },
              tabs: {
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 2,
                  maxArgs: 3
                })
              }
            };
            const settingMetadata = {
              clear: {
                minArgs: 1,
                maxArgs: 1
              },
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              set: {
                minArgs: 1,
                maxArgs: 1
              }
            };
            apiMetadata.privacy = {
              network: {
                "*": settingMetadata
              },
              services: {
                "*": settingMetadata
              },
              websites: {
                "*": settingMetadata
              }
            };
            return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
          };
          module3.exports = wrapAPIs(chrome);
        } else {
          module3.exports = globalThis.browser;
        }
      });
    }
  });

  // shared/js/background/wrapper.js
  var wrapper_exports = {};
  __export(wrapper_exports, {
    changeTabURL: () => changeTabURL,
    createAlarm: () => createAlarm,
    executeScript: () => executeScript,
    getDDGTabUrls: () => getDDGTabUrls,
    getExtensionId: () => getExtensionId,
    getExtensionURL: () => getExtensionURL,
    getExtensionVersion: () => getExtensionVersion,
    getFromManagedStorage: () => getFromManagedStorage,
    getFromSessionStorage: () => getFromSessionStorage,
    getFromStorage: () => getFromStorage,
    getManifestVersion: () => getManifestVersion,
    insertCSS: () => insertCSS,
    mergeSavedSettings: () => mergeSavedSettings,
    normalizeTabData: () => normalizeTabData,
    openExtensionPage: () => openExtensionPage,
    removeFromSessionStorage: () => removeFromSessionStorage,
    sessionStorageFallback: () => sessionStorageFallback,
    setActionIcon: () => setActionIcon,
    setToSessionStorage: () => setToSessionStorage,
    setUninstallURL: () => setUninstallURL,
    syncToStorage: () => syncToStorage
  });
  function getExtensionURL(path) {
    return import_webextension_polyfill.default.runtime.getURL(path);
  }
  function getExtensionVersion() {
    const manifest = import_webextension_polyfill.default.runtime.getManifest();
    return manifest.version;
  }
  function openExtensionPage(path) {
    import_webextension_polyfill.default.tabs.create({ url: getExtensionURL(path) });
  }
  async function setActionIcon(iconPath, tabId) {
    if (typeof import_webextension_polyfill.default.action === "undefined") {
      return import_webextension_polyfill.default.browserAction.setIcon({ path: iconPath, tabId });
    }
    return import_webextension_polyfill.default.action.setIcon({ path: iconPath, tabId });
  }
  function getManifestVersion() {
    const manifest = import_webextension_polyfill.default.runtime.getManifest();
    return manifest.manifest_version;
  }
  function syncToStorage(data) {
    return import_webextension_polyfill.default.storage.local.set(data);
  }
  async function getFromStorage(key, cb) {
    const result = await import_webextension_polyfill.default.storage.local.get(key);
    return result[key];
  }
  async function getFromManagedStorage(keys, cb) {
    try {
      return await import_webextension_polyfill.default.storage.managed.get(keys);
    } catch (e) {
      console.log("get managed failed", e);
    }
    return {};
  }
  function getExtensionId() {
    return import_webextension_polyfill.default.runtime.id;
  }
  function normalizeTabData(tabData) {
    const tabId = "tabId" in tabData ? tabData.tabId : tabData.id;
    const url = tabData.url;
    const status = "status" in tabData ? tabData.status : null;
    const requestId = "requestId" in tabData ? tabData.requestId : void 0;
    return {
      tabId,
      url,
      requestId,
      status
    };
  }
  function mergeSavedSettings(settings3, results) {
    return Object.assign(settings3, results);
  }
  async function getDDGTabUrls() {
    const tabs = await import_webextension_polyfill.default.tabs.query({ url: "https://*.duckduckgo.com/*" }) || [];
    return tabs.map((tab) => tab.url);
  }
  function setUninstallURL(url) {
    import_webextension_polyfill.default.runtime.setUninstallURL(url);
  }
  function changeTabURL(tabId, url) {
    return import_webextension_polyfill.default.tabs.update(tabId, { url });
  }
  function convertScriptingAPIOptionsForTabsAPI(options) {
    if (typeof options !== "object") {
      throw new Error("Missing/invalid options Object.");
    }
    if (typeof options.file !== "undefined" || typeof options.frameId !== "undefined" || typeof options.runAt !== "undefined" || typeof options.allFrames !== "undefined" || typeof options.code !== "undefined") {
      throw new Error("Please provide options compatible with the (MV3) scripting API, instead of the (MV2) tabs API.");
    }
    if (typeof options.world !== "undefined") {
      throw new Error("World targetting not supported by MV2.");
    }
    const { allFrames, frameIds, tabId } = options.target;
    delete options.target;
    if (Array.isArray(frameIds) && frameIds.length > 0) {
      if (frameIds.length > 1) {
        throw new Error("Targetting multiple frames by ID not supported by MV2.");
      }
      options.frameId = frameIds[0];
    }
    if (typeof options.files !== "undefined") {
      if (Array.isArray(options.files) && options.files.length > 0) {
        if (options.files.length > 1) {
          throw new Error("Inserting multiple stylesheets/scripts in one go not supported by MV2.");
        }
        options.file = options.files[0];
      }
      delete options.files;
    }
    if (typeof allFrames !== "undefined") {
      options.allFrames = allFrames;
    }
    if (typeof options.injectImmediately !== "undefined") {
      if (options.injectImmediately) {
        options.runAt = "document_start";
      }
      delete options.injectImmediately;
    }
    let stringifiedArgs = "";
    if (typeof options.args !== "undefined") {
      if (Array.isArray(options.args)) {
        stringifiedArgs = "..." + JSON.stringify(options.args);
      }
      delete options.args;
    }
    if (typeof options.func !== "undefined") {
      if (typeof options.func === "function") {
        options.code = "(" + options.func.toString() + ")(" + stringifiedArgs + ")";
      }
      delete options.func;
    }
    return [tabId, options];
  }
  async function executeScript(options) {
    if (typeof import_webextension_polyfill.default.scripting === "undefined") {
      return await import_webextension_polyfill.default.tabs.executeScript(
        ...convertScriptingAPIOptionsForTabsAPI(options)
      );
    }
    return await import_webextension_polyfill.default.scripting.executeScript(options);
  }
  async function insertCSS(options) {
    if (typeof import_webextension_polyfill.default.scripting === "undefined") {
      return await import_webextension_polyfill.default.tabs.insertCSS(
        ...convertScriptingAPIOptionsForTabsAPI(options)
      );
    }
    return await import_webextension_polyfill.default.scripting.insertCSS(options);
  }
  async function setToSessionStorage(key, data) {
    if (typeof key !== "string") {
      throw new Error("Invalid storage key, string expected.");
    }
    if (sessionStorageSupported) {
      return await import_webextension_polyfill.default.storage.session.set({ [key]: data });
    }
    sessionStorageFallback.set(key, data);
  }
  async function getFromSessionStorage(key) {
    if (typeof key !== "string") {
      throw new Error("Invalid storage key, string expected.");
    }
    if (sessionStorageSupported) {
      const result = await import_webextension_polyfill.default.storage.session.get([key]);
      return result[key];
    }
    return sessionStorageFallback.get(key);
  }
  async function removeFromSessionStorage(key) {
    if (typeof key !== "string") {
      throw new Error("Invalid storage key, string expected.");
    }
    if (sessionStorageSupported) {
      return await import_webextension_polyfill.default.storage.session.remove(key);
    }
    return sessionStorageFallback.delete(key);
  }
  async function createAlarm(name, alarmInfo) {
    const existingAlarm = await import_webextension_polyfill.default.alarms.get(name);
    if (!existingAlarm) {
      return await import_webextension_polyfill.default.alarms.create(name, alarmInfo);
    }
  }
  var import_webextension_polyfill, sessionStorageSupported, sessionStorageFallback;
  var init_wrapper = __esm({
    "shared/js/background/wrapper.js"() {
      "use strict";
      import_webextension_polyfill = __toESM(require_browser_polyfill());
      sessionStorageSupported = typeof import_webextension_polyfill.default.storage.session !== "undefined";
      sessionStorageFallback = sessionStorageSupported ? null : /* @__PURE__ */ new Map();
    }
  });

  // shared/data/defaultSettings.js
  var require_defaultSettings = __commonJS({
    "shared/data/defaultSettings.js"(exports2, module2) {
      "use strict";
      module2.exports = {
        httpsEverywhereEnabled: true,
        embeddedTweetsEnabled: false,
        GPC: true,
        youtubePreviewsEnabled: false,
        atb: null,
        set_atb: null,
        "config-etag": null,
        "httpsUpgradeBloomFilter-etag": null,
        "httpsDontUpgradeBloomFilters-etag": null,
        "httpsUpgradeList-etag": null,
        "httpsDontUpgradeList-etag": null,
        hasSeenPostInstall: false,
        extiSent: false,
        "tds-etag": null,
        lastTdsUpdate: 0,
        fireButtonClearHistoryEnabled: true,
        fireButtonTabClearEnabled: true,
        useNoAiSearch: false
      };
    }
  });

  // shared/js/background/settings.js
  var require_settings = __commonJS({
    "shared/js/background/settings.js"(exports2, module2) {
      "use strict";
      var defaultSettings = require_defaultSettings();
      var browserWrapper = (init_wrapper(), __toCommonJS(wrapper_exports));
      var onSettingUpdate = new EventTarget();
      if (typeof CustomEvent === "undefined") globalThis.CustomEvent = Event;
      var MANAGED_SETTINGS = ["hasSeenPostInstall"];
      var settings3 = {};
      var isReady = false;
      var _ready = init().then(() => {
        isReady = true;
        console.log("Settings are loaded");
      });
      async function init() {
        buildSettingsFromDefaults();
        await buildSettingsFromManagedStorage();
        await buildSettingsFromLocalStorage();
      }
      function ready() {
        return _ready;
      }
      function checkForLegacyKeys() {
        const legacyKeys = {
          // Keys to migrate
          whitelisted: "allowlisted",
          whitelistOptIn: "allowlistOptIn",
          // Keys to remove
          advanced_options: null,
          clickToLoadClicks: null,
          cookieExcludeList: null,
          dev: null,
          ducky: null,
          extensionIsEnabled: null,
          failedUpgrades: null,
          last_search: null,
          lastsearch_enabled: null,
          meanings: null,
          safesearch: null,
          socialBlockingIsEnabled: null,
          totalUpgrades: null,
          trackerBlockingEnabled: null,
          use_post: null,
          version: null,
          zeroclick_google_right: null,
          "surrogates-etag": null,
          "brokenSiteList-etag": null,
          "surrogateList-etag": null,
          "trackersWhitelist-etag": null,
          "trackersWhitelistTemporary-etag": null
        };
        let syncNeeded = false;
        for (const legacyKey in legacyKeys) {
          const key = legacyKeys[legacyKey];
          if (!(legacyKey in settings3)) {
            continue;
          }
          syncNeeded = true;
          const legacyValue = settings3[legacyKey];
          if (key && legacyValue) {
            settings3[key] = legacyValue;
          }
          delete settings3[legacyKey];
        }
        if (syncNeeded) {
          syncSettingTolocalStorage();
        }
      }
      async function buildSettingsFromLocalStorage() {
        const results = await browserWrapper.getFromStorage(["settings"]);
        if (!results) return;
        settings3 = browserWrapper.mergeSavedSettings(settings3, results);
        checkForLegacyKeys();
      }
      async function buildSettingsFromManagedStorage() {
        const results = await browserWrapper.getFromManagedStorage(MANAGED_SETTINGS);
        settings3 = browserWrapper.mergeSavedSettings(settings3, results);
      }
      function buildSettingsFromDefaults() {
        settings3 = Object.assign({}, defaultSettings);
      }
      function syncSettingTolocalStorage() {
        return browserWrapper.syncToStorage({ settings: settings3 });
      }
      function getSetting(name) {
        if (!isReady) {
          console.warn(`Settings: getSetting() Settings not loaded: ${name}`);
          return;
        }
        if (name === "all") name = null;
        if (name) {
          return settings3[name];
        } else {
          return settings3;
        }
      }
      function updateSetting(name, value) {
        if (!isReady) {
          console.warn(`Settings: updateSetting() Setting not loaded: ${name}`);
          return;
        }
        settings3[name] = value;
        syncSettingTolocalStorage().then(() => {
          onSettingUpdate.dispatchEvent(new CustomEvent(name, { detail: value }));
        });
      }
      function incrementNumericSetting(name, increment = 1) {
        if (!isReady) {
          console.warn("Settings: incrementNumericSetting() Setting not loaded:", name);
          return;
        }
        let value = settings3[name];
        if (typeof value !== "number" || isNaN(value)) {
          value = 0;
        }
        updateSetting(name, value + increment);
      }
      function removeSetting(name) {
        if (!isReady) {
          console.warn(`Settings: removeSetting() Setting not loaded: ${name}`);
          return;
        }
        if (settings3[name]) {
          delete settings3[name];
          syncSettingTolocalStorage();
        }
      }
      function logSettings() {
        browserWrapper.getFromStorage(["settings"]).then((s) => {
          console.log(s.settings);
        });
      }
      module2.exports = {
        getSetting,
        updateSetting,
        incrementNumericSetting,
        removeSetting,
        logSettings,
        ready,
        onSettingUpdate
      };
    }
  });

  // shared/js/shared-utils/parse-user-agent-string.js
  var require_parse_user_agent_string = __commonJS({
    "shared/js/shared-utils/parse-user-agent-string.js"(exports2, module2) {
      "use strict";
      module2.exports = (uaString) => {
        if (!globalThis.navigator) return {};
        if (!uaString) uaString = globalThis.navigator.userAgent;
        let browser9;
        let version;
        try {
          let parsedUaParts = uaString.match(/(Firefox|Chrome|Edg)\/([0-9]+)/);
          const isEdge = /(Edge?)\/([0-9]+)/;
          const isOpera = /(OPR)\/([0-9]+)/;
          if (uaString.match(isEdge)) {
            parsedUaParts = uaString.match(isEdge);
          } else if (uaString.match(isOpera)) {
            parsedUaParts = uaString.match(isOpera);
            parsedUaParts[1] = "Opera";
          }
          browser9 = parsedUaParts[1];
          version = parsedUaParts[2];
          if (globalThis.navigator.brave) {
            browser9 = "Brave";
          }
        } catch (e) {
          browser9 = version = "";
        }
        let os = "o";
        if (globalThis.navigator.userAgent.indexOf("Windows") !== -1) os = "w";
        if (globalThis.navigator.userAgent.indexOf("Mac") !== -1) os = "m";
        if (globalThis.navigator.userAgent.indexOf("Linux") !== -1) os = "l";
        return {
          os,
          browser: browser9,
          version
        };
      };
    }
  });

  // shared/js/shared-utils/sha1.js
  var require_sha1 = __commonJS({
    "shared/js/shared-utils/sha1.js"(exports, module) {
      "use strict";
      (function() {
        "use strict";
        var root = typeof window === "object" ? window : {};
        var NODE_JS = !root.JS_SHA1_NO_NODE_JS && typeof process === "object" && process.versions && process.versions.node;
        if (NODE_JS) {
          root = global;
        }
        var COMMON_JS = !root.JS_SHA1_NO_COMMON_JS && typeof module === "object" && module.exports;
        var AMD = typeof define === "function" && define.amd;
        var HEX_CHARS = "0123456789abcdef".split("");
        var EXTRA = [-2147483648, 8388608, 32768, 128];
        var SHIFT = [24, 16, 8, 0];
        var OUTPUT_TYPES = ["hex", "array", "digest", "arrayBuffer"];
        var blocks = [];
        var createOutputMethod = function(outputType) {
          return function(message) {
            return new Sha1(true).update(message)[outputType]();
          };
        };
        var createMethod = function() {
          var method2 = createOutputMethod("hex");
          if (NODE_JS) {
            method2 = nodeWrap(method2);
          }
          method2.create = function() {
            return new Sha1();
          };
          method2.update = function(message) {
            return method2.create().update(message);
          };
          for (var i = 0; i < OUTPUT_TYPES.length; ++i) {
            var type = OUTPUT_TYPES[i];
            method2[type] = createOutputMethod(type);
          }
          return method2;
        };
        var nodeWrap = function(method) {
          var crypto = eval("require('crypto')");
          var Buffer = eval("require('buffer').Buffer");
          var nodeMethod = function(message) {
            if (typeof message === "string") {
              return crypto.createHash("sha1").update(message, "utf8").digest("hex");
            } else if (message.constructor === ArrayBuffer) {
              message = new Uint8Array(message);
            } else if (message.length === void 0) {
              return method(message);
            }
            return crypto.createHash("sha1").update(new Buffer(message)).digest("hex");
          };
          return nodeMethod;
        };
        function Sha1(sharedMemory) {
          if (sharedMemory) {
            blocks[0] = blocks[16] = blocks[1] = blocks[2] = blocks[3] = blocks[4] = blocks[5] = blocks[6] = blocks[7] = blocks[8] = blocks[9] = blocks[10] = blocks[11] = blocks[12] = blocks[13] = blocks[14] = blocks[15] = 0;
            this.blocks = blocks;
          } else {
            this.blocks = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
          }
          this.h0 = 1732584193;
          this.h1 = 4023233417;
          this.h2 = 2562383102;
          this.h3 = 271733878;
          this.h4 = 3285377520;
          this.block = this.start = this.bytes = this.hBytes = 0;
          this.finalized = this.hashed = false;
          this.first = true;
        }
        Sha1.prototype.update = function(message) {
          if (this.finalized) {
            return;
          }
          var notString = typeof message !== "string";
          if (notString && message.constructor === root.ArrayBuffer) {
            message = new Uint8Array(message);
          }
          var code, index = 0, i, length = message.length || 0, blocks2 = this.blocks;
          while (index < length) {
            if (this.hashed) {
              this.hashed = false;
              blocks2[0] = this.block;
              blocks2[16] = blocks2[1] = blocks2[2] = blocks2[3] = blocks2[4] = blocks2[5] = blocks2[6] = blocks2[7] = blocks2[8] = blocks2[9] = blocks2[10] = blocks2[11] = blocks2[12] = blocks2[13] = blocks2[14] = blocks2[15] = 0;
            }
            if (notString) {
              for (i = this.start; index < length && i < 64; ++index) {
                blocks2[i >> 2] |= message[index] << SHIFT[i++ & 3];
              }
            } else {
              for (i = this.start; index < length && i < 64; ++index) {
                code = message.charCodeAt(index);
                if (code < 128) {
                  blocks2[i >> 2] |= code << SHIFT[i++ & 3];
                } else if (code < 2048) {
                  blocks2[i >> 2] |= (192 | code >> 6) << SHIFT[i++ & 3];
                  blocks2[i >> 2] |= (128 | code & 63) << SHIFT[i++ & 3];
                } else if (code < 55296 || code >= 57344) {
                  blocks2[i >> 2] |= (224 | code >> 12) << SHIFT[i++ & 3];
                  blocks2[i >> 2] |= (128 | code >> 6 & 63) << SHIFT[i++ & 3];
                  blocks2[i >> 2] |= (128 | code & 63) << SHIFT[i++ & 3];
                } else {
                  code = 65536 + ((code & 1023) << 10 | message.charCodeAt(++index) & 1023);
                  blocks2[i >> 2] |= (240 | code >> 18) << SHIFT[i++ & 3];
                  blocks2[i >> 2] |= (128 | code >> 12 & 63) << SHIFT[i++ & 3];
                  blocks2[i >> 2] |= (128 | code >> 6 & 63) << SHIFT[i++ & 3];
                  blocks2[i >> 2] |= (128 | code & 63) << SHIFT[i++ & 3];
                }
              }
            }
            this.lastByteIndex = i;
            this.bytes += i - this.start;
            if (i >= 64) {
              this.block = blocks2[16];
              this.start = i - 64;
              this.hash();
              this.hashed = true;
            } else {
              this.start = i;
            }
          }
          if (this.bytes > 4294967295) {
            this.hBytes += this.bytes / 4294967296 << 0;
            this.bytes = this.bytes % 4294967296;
          }
          return this;
        };
        Sha1.prototype.finalize = function() {
          if (this.finalized) {
            return;
          }
          this.finalized = true;
          var blocks2 = this.blocks, i = this.lastByteIndex;
          blocks2[16] = this.block;
          blocks2[i >> 2] |= EXTRA[i & 3];
          this.block = blocks2[16];
          if (i >= 56) {
            if (!this.hashed) {
              this.hash();
            }
            blocks2[0] = this.block;
            blocks2[16] = blocks2[1] = blocks2[2] = blocks2[3] = blocks2[4] = blocks2[5] = blocks2[6] = blocks2[7] = blocks2[8] = blocks2[9] = blocks2[10] = blocks2[11] = blocks2[12] = blocks2[13] = blocks2[14] = blocks2[15] = 0;
          }
          blocks2[14] = this.hBytes << 3 | this.bytes >>> 29;
          blocks2[15] = this.bytes << 3;
          this.hash();
        };
        Sha1.prototype.hash = function() {
          var a = this.h0, b = this.h1, c = this.h2, d = this.h3, e = this.h4;
          var f, j, t, blocks2 = this.blocks;
          for (j = 16; j < 80; ++j) {
            t = blocks2[j - 3] ^ blocks2[j - 8] ^ blocks2[j - 14] ^ blocks2[j - 16];
            blocks2[j] = t << 1 | t >>> 31;
          }
          for (j = 0; j < 20; j += 5) {
            f = b & c | ~b & d;
            t = a << 5 | a >>> 27;
            e = t + f + e + 1518500249 + blocks2[j] << 0;
            b = b << 30 | b >>> 2;
            f = a & b | ~a & c;
            t = e << 5 | e >>> 27;
            d = t + f + d + 1518500249 + blocks2[j + 1] << 0;
            a = a << 30 | a >>> 2;
            f = e & a | ~e & b;
            t = d << 5 | d >>> 27;
            c = t + f + c + 1518500249 + blocks2[j + 2] << 0;
            e = e << 30 | e >>> 2;
            f = d & e | ~d & a;
            t = c << 5 | c >>> 27;
            b = t + f + b + 1518500249 + blocks2[j + 3] << 0;
            d = d << 30 | d >>> 2;
            f = c & d | ~c & e;
            t = b << 5 | b >>> 27;
            a = t + f + a + 1518500249 + blocks2[j + 4] << 0;
            c = c << 30 | c >>> 2;
          }
          for (; j < 40; j += 5) {
            f = b ^ c ^ d;
            t = a << 5 | a >>> 27;
            e = t + f + e + 1859775393 + blocks2[j] << 0;
            b = b << 30 | b >>> 2;
            f = a ^ b ^ c;
            t = e << 5 | e >>> 27;
            d = t + f + d + 1859775393 + blocks2[j + 1] << 0;
            a = a << 30 | a >>> 2;
            f = e ^ a ^ b;
            t = d << 5 | d >>> 27;
            c = t + f + c + 1859775393 + blocks2[j + 2] << 0;
            e = e << 30 | e >>> 2;
            f = d ^ e ^ a;
            t = c << 5 | c >>> 27;
            b = t + f + b + 1859775393 + blocks2[j + 3] << 0;
            d = d << 30 | d >>> 2;
            f = c ^ d ^ e;
            t = b << 5 | b >>> 27;
            a = t + f + a + 1859775393 + blocks2[j + 4] << 0;
            c = c << 30 | c >>> 2;
          }
          for (; j < 60; j += 5) {
            f = b & c | b & d | c & d;
            t = a << 5 | a >>> 27;
            e = t + f + e - 1894007588 + blocks2[j] << 0;
            b = b << 30 | b >>> 2;
            f = a & b | a & c | b & c;
            t = e << 5 | e >>> 27;
            d = t + f + d - 1894007588 + blocks2[j + 1] << 0;
            a = a << 30 | a >>> 2;
            f = e & a | e & b | a & b;
            t = d << 5 | d >>> 27;
            c = t + f + c - 1894007588 + blocks2[j + 2] << 0;
            e = e << 30 | e >>> 2;
            f = d & e | d & a | e & a;
            t = c << 5 | c >>> 27;
            b = t + f + b - 1894007588 + blocks2[j + 3] << 0;
            d = d << 30 | d >>> 2;
            f = c & d | c & e | d & e;
            t = b << 5 | b >>> 27;
            a = t + f + a - 1894007588 + blocks2[j + 4] << 0;
            c = c << 30 | c >>> 2;
          }
          for (; j < 80; j += 5) {
            f = b ^ c ^ d;
            t = a << 5 | a >>> 27;
            e = t + f + e - 899497514 + blocks2[j] << 0;
            b = b << 30 | b >>> 2;
            f = a ^ b ^ c;
            t = e << 5 | e >>> 27;
            d = t + f + d - 899497514 + blocks2[j + 1] << 0;
            a = a << 30 | a >>> 2;
            f = e ^ a ^ b;
            t = d << 5 | d >>> 27;
            c = t + f + c - 899497514 + blocks2[j + 2] << 0;
            e = e << 30 | e >>> 2;
            f = d ^ e ^ a;
            t = c << 5 | c >>> 27;
            b = t + f + b - 899497514 + blocks2[j + 3] << 0;
            d = d << 30 | d >>> 2;
            f = c ^ d ^ e;
            t = b << 5 | b >>> 27;
            a = t + f + a - 899497514 + blocks2[j + 4] << 0;
            c = c << 30 | c >>> 2;
          }
          this.h0 = this.h0 + a << 0;
          this.h1 = this.h1 + b << 0;
          this.h2 = this.h2 + c << 0;
          this.h3 = this.h3 + d << 0;
          this.h4 = this.h4 + e << 0;
        };
        Sha1.prototype.hex = function() {
          this.finalize();
          var h0 = this.h0, h1 = this.h1, h2 = this.h2, h3 = this.h3, h4 = this.h4;
          return HEX_CHARS[h0 >> 28 & 15] + HEX_CHARS[h0 >> 24 & 15] + HEX_CHARS[h0 >> 20 & 15] + HEX_CHARS[h0 >> 16 & 15] + HEX_CHARS[h0 >> 12 & 15] + HEX_CHARS[h0 >> 8 & 15] + HEX_CHARS[h0 >> 4 & 15] + HEX_CHARS[h0 & 15] + HEX_CHARS[h1 >> 28 & 15] + HEX_CHARS[h1 >> 24 & 15] + HEX_CHARS[h1 >> 20 & 15] + HEX_CHARS[h1 >> 16 & 15] + HEX_CHARS[h1 >> 12 & 15] + HEX_CHARS[h1 >> 8 & 15] + HEX_CHARS[h1 >> 4 & 15] + HEX_CHARS[h1 & 15] + HEX_CHARS[h2 >> 28 & 15] + HEX_CHARS[h2 >> 24 & 15] + HEX_CHARS[h2 >> 20 & 15] + HEX_CHARS[h2 >> 16 & 15] + HEX_CHARS[h2 >> 12 & 15] + HEX_CHARS[h2 >> 8 & 15] + HEX_CHARS[h2 >> 4 & 15] + HEX_CHARS[h2 & 15] + HEX_CHARS[h3 >> 28 & 15] + HEX_CHARS[h3 >> 24 & 15] + HEX_CHARS[h3 >> 20 & 15] + HEX_CHARS[h3 >> 16 & 15] + HEX_CHARS[h3 >> 12 & 15] + HEX_CHARS[h3 >> 8 & 15] + HEX_CHARS[h3 >> 4 & 15] + HEX_CHARS[h3 & 15] + HEX_CHARS[h4 >> 28 & 15] + HEX_CHARS[h4 >> 24 & 15] + HEX_CHARS[h4 >> 20 & 15] + HEX_CHARS[h4 >> 16 & 15] + HEX_CHARS[h4 >> 12 & 15] + HEX_CHARS[h4 >> 8 & 15] + HEX_CHARS[h4 >> 4 & 15] + HEX_CHARS[h4 & 15];
        };
        Sha1.prototype.toString = Sha1.prototype.hex;
        Sha1.prototype.digest = function() {
          this.finalize();
          var h0 = this.h0, h1 = this.h1, h2 = this.h2, h3 = this.h3, h4 = this.h4;
          return [
            h0 >> 24 & 255,
            h0 >> 16 & 255,
            h0 >> 8 & 255,
            h0 & 255,
            h1 >> 24 & 255,
            h1 >> 16 & 255,
            h1 >> 8 & 255,
            h1 & 255,
            h2 >> 24 & 255,
            h2 >> 16 & 255,
            h2 >> 8 & 255,
            h2 & 255,
            h3 >> 24 & 255,
            h3 >> 16 & 255,
            h3 >> 8 & 255,
            h3 & 255,
            h4 >> 24 & 255,
            h4 >> 16 & 255,
            h4 >> 8 & 255,
            h4 & 255
          ];
        };
        Sha1.prototype.array = Sha1.prototype.digest;
        Sha1.prototype.arrayBuffer = function() {
          this.finalize();
          var buffer = new ArrayBuffer(20);
          var dataView = new DataView(buffer);
          dataView.setUint32(0, this.h0);
          dataView.setUint32(4, this.h1);
          dataView.setUint32(8, this.h2);
          dataView.setUint32(12, this.h3);
          dataView.setUint32(16, this.h4);
          return buffer;
        };
        var exports = createMethod();
        if (COMMON_JS) {
          module.exports = exports;
        } else {
          root.sha1 = exports;
          if (AMD) {
            define(function() {
              return exports;
            });
          }
        }
      })();
    }
  });

  // shared/js/background/background-embedded.js
  var import_webextension_polyfill8 = __toESM(require_browser_polyfill());

  // node_modules/@duckduckgo/autoconsent/dist/autoconsent.esm.js
  var snippets = {
    // code-based rules
    EVAL_0: () => console.log(1),
    EVAL_DIDOMI_OPT_OUT: () => {
      if (window.Didomi) {
        window.Didomi.setUserDisagreeToAll();
        return true;
      }
      return false;
    },
    EVAL_DIDOMI_TEST: () => {
      const purposes = window.Didomi?.getCurrentUserStatus?.()?.purposes;
      if (purposes) {
        return Object.values(purposes).some((p) => !p.enabled);
      }
      const disabled = window.Didomi?.getUserConsentStatusForAll?.()?.purposes?.disabled;
      return Array.isArray(disabled) && disabled.length > 0;
    },
    EVAL_CONSENTMANAGER_1: () => window.__cmp && typeof __cmp("getCMPData") === "object",
    EVAL_CONSENTMANAGER_2: () => !__cmp("consentStatus").userChoiceExists,
    EVAL_CONSENTMANAGER_3: () => __cmp("setConsent", 0),
    EVAL_CONSENTMANAGER_4: () => __cmp("setConsent", 1),
    EVAL_CONSENTMANAGER_5: () => __cmp("consentStatus").userChoiceExists,
    EVAL_COOKIEBOT_1: () => !!window.Cookiebot,
    EVAL_COOKIEBOT_2: () => !window.Cookiebot.hasResponse && window.Cookiebot.dialog?.visible === true,
    EVAL_COOKIEBOT_3: () => window.Cookiebot.withdraw() || true,
    EVAL_COOKIEBOT_4: () => window.Cookiebot.hide() || true,
    EVAL_COOKIEBOT_5: () => window.Cookiebot.declined === true,
    EVAL_KLARO_1: () => {
      const config = globalThis.klaroConfig || globalThis.klaro?.getManager && globalThis.klaro.getManager().config;
      if (!config) {
        return true;
      }
      const optionalServices = (config.services || config.apps).filter((s) => !s.required).map((s) => s.name);
      if (klaro && klaro.getManager) {
        const manager = klaro.getManager();
        return optionalServices.every((name) => !manager.consents[name]);
      } else if (klaroConfig && klaroConfig.storageMethod === "cookie") {
        const cookieName = klaroConfig.cookieName || klaroConfig.storageName;
        const consents = JSON.parse(
          decodeURIComponent(
            document.cookie.split(";").find((c) => c.trim().startsWith(cookieName)).split("=")[1]
          )
        );
        return Object.keys(consents).filter((k) => optionalServices.includes(k)).every((k) => consents[k] === false);
      }
    },
    EVAL_KLARO_OPEN_POPUP: () => {
      klaro.show(void 0, true);
    },
    EVAL_KLARO_TRY_API_OPT_OUT: () => {
      if (window.klaro && typeof klaro.show === "function" && typeof klaro.getManager === "function") {
        try {
          klaro.getManager().changeAll(false);
          klaro.getManager().saveAndApplyConsents();
          return true;
        } catch (e) {
          console.warn(e);
          return false;
        }
      }
      return false;
    },
    EVAL_ONETRUST_1: () => window.OnetrustActiveGroups.split(",").filter((s) => s.length > 0).length <= 1,
    EVAL_TRUSTARC_TOP: () => window && window.truste && window.truste.eu.bindMap.prefCookie === "0",
    EVAL_TRUSTARC_FRAME_TEST: () => window && window.QueryString && window.QueryString.preferences === "0",
    EVAL_TRUSTARC_FRAME_GTM: () => window && window.QueryString && window.QueryString.gtm === "1",
    // declarative rules
    EVAL_ADOPT_TEST: () => !!localStorage.getItem("adoptConsentMode"),
    EVAL_ADULTFRIENDFINDER_TEST: () => !!localStorage.getItem("cookieConsent"),
    EVAL_BAHN_TEST: () => utag.gdpr.getSelectedCategories().length === 1,
    EVAL_BIGCOMMERCE_CONSENT_MANAGER_DETECT: () => !!(window.consentManager && window.consentManager.version),
    EVAL_BORLABS_0: () => !JSON.parse(
      decodeURIComponent(
        document.cookie.split(";").find((c) => c.indexOf("borlabs-cookie") !== -1).split("=", 2)[1]
      )
    ).consents.statistics,
    EVAL_CC_BANNER2_0: () => !!document.cookie.match(/sncc=[^;]+D%3Dtrue/),
    EVAL_COINBASE_0: () => JSON.parse(decodeURIComponent(document.cookie.match(/cm_(eu|default)_preferences=([0-9a-zA-Z\\{\\}\\[\\]%:]*);?/)[2])).consent.length <= 1,
    EVAL_COOKIE_LAW_INFO_0: () => {
      if (CLI.disableAllCookies) CLI.disableAllCookies();
      if (CLI.reject_close) CLI.reject_close();
      document.body.classList.remove("cli-barmodal-open");
      return true;
    },
    EVAL_COOKIE_LAW_INFO_DETECT: () => !!window.CLI,
    EVAL_COOKIE_MANAGER_POPUP_0: () => JSON.parse(
      document.cookie.split(";").find((c) => c.trim().startsWith("CookieLevel")).split("=")[1]
    ).social === false,
    EVAL_COOKIEALERT_0: () => document.querySelector("body").removeAttribute("style") || true,
    EVAL_COOKIEALERT_1: () => document.querySelector("body").removeAttribute("style") || true,
    EVAL_COOKIEALERT_2: () => window.CookieConsent.declined === true,
    EVAL_COOKIEFIRST_0: () => ((o) => o.performance === false && o.functional === false && o.advertising === false)(
      JSON.parse(
        decodeURIComponent(
          document.cookie.split(";").find((c) => c.indexOf("cookiefirst") !== -1).trim()
        ).split("=")[1]
      )
    ),
    EVAL_COOKIEFIRST_1: () => document.querySelectorAll("button[data-cookiefirst-accent-color=true][role=checkbox]:not([disabled])").forEach((i) => i.getAttribute("aria-checked") === "true" && i.click()) || true,
    EVAL_COOKIEINFORMATION_0: () => CookieInformation.declineAllCategories() || true,
    EVAL_COOKIEINFORMATION_1: () => CookieInformation.submitAllCategories() || true,
    EVAL_ETSY_0: () => document.querySelectorAll(".gdpr-overlay-body input").forEach((toggle) => {
      toggle.checked = false;
    }) || true,
    EVAL_ETSY_1: () => document.querySelector(".gdpr-overlay-view button[data-wt-overlay-close]").click() || true,
    EVAL_EZOIC_0: () => ezCMP.handleAcceptAllClick(),
    EVAL_FIDES_DETECT_POPUP: () => window.Fides?.initialized,
    EVAL_GDPR_LEGAL_COOKIE_DETECT_CMP: () => !!window.GDPR_LC,
    EVAL_GDPR_LEGAL_COOKIE_TEST: () => !!window.GDPR_LC?.userConsentSetting,
    EVAL_IUBENDA_0: () => document.querySelectorAll(".purposes-item input[type=checkbox]:not([disabled])").forEach((x) => {
      if (x.checked) x.click();
    }) || true,
    EVAL_IUBENDA_1: () => !!document.cookie.match(/_iub_cs-\d+=/),
    EVAL_MICROSOFT_0: () => Array.from(document.querySelectorAll("div > button")).filter((el) => el.innerText.match("Reject|Ablehnen"))[0].click() || true,
    EVAL_MICROSOFT_1: () => Array.from(document.querySelectorAll("div > button")).filter((el) => el.innerText.match("Accept|Annehmen"))[0].click() || true,
    EVAL_MICROSOFT_2: () => !!document.cookie.match("MSCC|GHCC"),
    EVAL_MOOVE_0: () => document.querySelectorAll("#moove_gdpr_cookie_modal input").forEach((i) => {
      if (!i.disabled) i.checked = i.name === "moove_gdpr_strict_cookies" || i.id === "moove_gdpr_strict_cookies";
    }) || true,
    EVAL_NHNIEUWS_TEST: () => !!localStorage.getItem("psh:cookies-seen"),
    EVAL_OSANO_DETECT: () => !!window.Osano?.cm?.dialogOpen,
    EVAL_PANDECTES_TEST: () => document.cookie.includes("_pandectes_gdpr=") && JSON.parse(
      atob(
        document.cookie.split(";").find((s) => s.trim().startsWith("_pandectes_gdpr")).split("=")[1]
      )
    ).status === "deny",
    EVAL_POVR_GOBACK: () => window.history.back() || true,
    EVAL_PUBTECH_0: () => document.cookie.includes("euconsent-v2") && (document.cookie.match(/.YAAAAAAAAAAA/) || document.cookie.match(/.aAAAAAAAAAAA/) || document.cookie.match(/.YAAACFgAAAAA/)),
    EVAL_SHOPIFY_TEST: () => document.cookie.includes("gdpr_cookie_consent=0") || document.cookie.includes("_tracking_consent=") && JSON.parse(
      decodeURIComponent(
        document.cookie.split(";").find((s) => s.trim().startsWith("_tracking_consent")).split("=")[1]
      )
    ).purposes.a === false,
    EVAL_SKYSCANNER_TEST: () => document.cookie.match(/gdpr=[^;]*adverts:::false/) && !document.cookie.match(/gdpr=[^;]*init:::true/),
    EVAL_SIRDATA_UNBLOCK_SCROLL: () => {
      document.documentElement.classList.forEach((cls) => {
        if (cls.startsWith("sd-cmp-")) document.documentElement.classList.remove(cls);
      });
      return true;
    },
    EVAL_STEAMPOWERED_0: () => JSON.parse(
      decodeURIComponent(
        document.cookie.split(";").find((s) => s.trim().startsWith("cookieSettings")).split("=")[1]
      )
    ).preference_state === 2,
    EVAL_TAKEALOT_0: () => document.body.classList.remove("freeze") || (document.body.style = "") || true,
    EVAL_TARTEAUCITRON_0: () => tarteaucitron.userInterface.respondAll(false) || true,
    EVAL_TARTEAUCITRON_1: () => tarteaucitron.userInterface.respondAll(true) || true,
    EVAL_TARTEAUCITRON_2: () => document.cookie.match(/tarteaucitron=[^;]*/)?.[0].includes("false"),
    EVAL_TEALIUM_0: () => typeof window.utag !== "undefined" && typeof utag.gdpr === "object",
    EVAL_TEALIUM_1: () => utag.gdpr.setConsentValue(false) || true,
    EVAL_TEALIUM_DONOTSELL: () => utag.gdpr.dns?.setDnsState(false) || true,
    EVAL_TEALIUM_2: () => utag.gdpr.setConsentValue(true) || true,
    EVAL_TEALIUM_3: () => utag.gdpr.getConsentState() !== 1,
    EVAL_TEALIUM_DONOTSELL_CHECK: () => utag.gdpr.dns?.getDnsState() !== 1,
    EVAL_TESTCMP_STEP: () => !!document.querySelector("#reject-all"),
    EVAL_TESTCMP_0: () => window.results.results[0] === "button_clicked",
    EVAL_TESTCMP_COSMETIC_0: () => window.results.results[0] === "banner_hidden",
    EVAL_THEFREEDICTIONARY_0: () => cmpUi.showPurposes() || cmpUi.rejectAll() || true,
    EVAL_THEFREEDICTIONARY_1: () => cmpUi.allowAll() || true,
    EVAL_USERCENTRICS_API_0: () => typeof UC_UI === "object",
    EVAL_USERCENTRICS_API_1: () => !!UC_UI.closeCMP(),
    EVAL_USERCENTRICS_API_2: () => !!UC_UI.denyAllConsents(),
    EVAL_USERCENTRICS_API_3: () => !!UC_UI.acceptAllConsents(),
    EVAL_USERCENTRICS_API_4: () => !!UC_UI.closeCMP(),
    EVAL_USERCENTRICS_API_5: () => UC_UI.areAllConsentsAccepted() === true,
    EVAL_USERCENTRICS_API_6: () => UC_UI.areAllConsentsAccepted() === false,
    EVAL_USERCENTRICS_BUTTON_0: () => JSON.parse(localStorage.getItem("usercentrics")).consents.every((c) => c.isEssential || !c.consentStatus),
    EVAL_WAITROSE_0: () => Array.from(document.querySelectorAll("label[id$=cookies-deny-label]")).forEach((e) => e.click()) || true
  };
  var REJECT_PATTERNS_ENGLISH = [
    // e.g. "i reject cookies", "reject all", "reject all cookies", "reject cookies", "deny all", "deny all cookies", "refuse", "refuse all", "refuse cookies", "refuse all cookies", "deny", "reject all and close", "deny all and close", "reject non-essential cookies", "reject all non-essential cookies and continue", "reject optional cookies", "reject additional cookies", "reject targeting cookies", "reject marketing cookies", "reject analytics cookies", "reject tracking cookies", "reject advertising cookies", "reject all and close", "deny all and close", "i reject all (except strictly necessary)"
    // note that "reject and subscribe" and "reject and pay" are excluded
    /^\s*(i)?\s*(reject|deny|refuse|decline|disable)\s*(all)?\s*(non-essential|optional|additional|targeting|analytics|marketing|unrequired|non-necessary|extra|tracking|advertising)?\s*(cookies)?\s*(\(?\s*except\s+(strictly\s+)?(necessary|essential)\s*\)?)?\s*$/is,
    // e.g. "i do not accept", "i do not accept cookies", "do not accept", "do not accept cookies"
    /^\s*(i)?\s*do\s+not\s+accept\s*(cookies)?\s*$/is,
    // e.g. "continue without accepting", "continue without agreeing", "continue without agreeing →"
    /^\s*(continue|proceed|continue\s+browsing)\s+without\s+(accepting|agreeing|consent|cookies|tracking)(\s*→)?\s*$/is,
    // e.g. "strictly necessary cookies only", "essential cookies only", "required only", "use necessary cookies only", "essentials only"
    // note that "only" is required
    /^\s*(use|accept|allow|continue\s+with)?\s*(strictly)?\s*(necessary|essentials?|required)?\s*(cookies)?\s*only\s*$/is,
    // e.g. "allow essential cookies", "allow necessary", "allow essentials", "allow essentials only"
    // note that "essential" is required
    /^\s*(use|accept|allow|continue\s+with)?\s*(strictly)?\s*(necessary|essentials?|required)\s*(cookies)?\s*$/is,
    // e.g. "accept only essential cookies", "use only necessary cookies", "allow only essential", "only essentials", "continue with only essential cookies"
    // note that "only" is required
    /^\s*(use|accept|allow|continue\s+with)?\s*only\s*(strictly)?\s*(necessary|essentials?|required)?\s*(cookies)?\s*$/is,
    // e.g. "do not sell or share my personal information", "do not sell my personal information"
    // often used in CCPA
    /^\s*do\s+not\s+sell(\s+or\s+share)?\s*my\s*personal\s*info(rmation)?\s*$/is,
    "allow selection",
    "disagree and close",
    // These are impactful, but look error-prone
    // // e.g. "disagree"
    /^(i)?\s*disagree\s*(and\s+close)?$/i,
    // // e.g. "i do not agree"
    // /^\s*(i\s+)?do\s+not\s+agree\s*$/i,
    "no",
    /^no,? thanks$/is,
    /^opt[ -]out$/is
  ];
  var REJECT_PATTERNS_DUTCH = [
    "weigeren",
    "alles afwijzen",
    "alleen noodzakelijke cookies",
    "afwijzen",
    "alles weigeren",
    "cookies weigeren",
    "alleen noodzakelijk",
    "weiger",
    "weiger cookies",
    "selectie toestaan",
    "doorgaan zonder te accepteren",
    "alleen functionele cookies",
    "alleen functioneel",
    "alleen noodzakelijke",
    "alleen essenti\xEBle cookies",
    "functioneel",
    "alle cookies verwerpen",
    "doorgaan zonder akkoord te gaan",
    "weiger alles",
    "nee, bedankt",
    "alle cookies weigeren",
    "weiger alle cookies",
    "alleen noodzakelijke cookies accepteren",
    "alleen strikt noodzakelijk",
    "ik weiger",
    "optionele cookies weigeren",
    "alle weigeren",
    "accepteer alleen noodzakelijke cookies",
    "alleen functionele cookies accepteren",
    "enkel noodzakelijke cookies",
    "niet accepteren",
    "weiger niet-essenti\xEBle cookies",
    "weiger niet-noodzakelijke cookies",
    "wijs alles af",
    "alle cookies afwijzen",
    "alleen vereiste cookies",
    "cookies afwijzen",
    "doorgaan zonder accepteren",
    "hier weigeren",
    "weiger alle",
    "aanvaard enkel essenti\xEBle cookies",
    "aanvullende cookies weigeren",
    "accepteren weigeren",
    "alle afwijzen",
    "alle niet functionele afwijzen",
    "alle optionele weigeren",
    "alleen noodzakelijke accepteren",
    "alleen strikt noodzakelijke cookies",
    "allen afwijzen",
    "clear weigeren",
    "enkel functioneel",
    "enkel noodzakelijke cookies aanvaarden",
    "functioneel altijd actief",
    "nee, accepteer alleen de noodzakelijke",
    "nee, geen cookies a.u.b.",
    "nee, weiger cookies",
    "nee, weigeren",
    "niet-noodzakelijke cookies weigeren",
    "optioneel afwijzen",
    "tracking cookies weigeren",
    "weigeren cookies",
    "weigeren?",
    "weigeren.",
    "strikt noodzakelijk",
    "weiger optionele cookies",
    "noodzakelijke cookies",
    "essenti\xEBle cookies",
    "ga verder zonder aanvaarden",
    "doorgaan zonder cookies",
    "accepteer noodzakelijke cookies",
    "noodzakelijke",
    "indien je enkel technisch noodzakelijke cookies wenst te accepteren, klik dan hier",
    "weiger",
    "alleen de noodzakelijke cookies",
    "alleen noodzakelijk",
    "alleen verplichte cookies",
    "ik wil alleen minimale cookies",
    "doorgaan zonder te accepteren",
    "geen cookies toestaan",
    "liever geen cookies",
    "nee, geen persoonlijke cookies",
    "nee, liever geen cookies",
    "ga door zonder te accepteren",
    "verder zonder accepteren",
    "essenti\xEBle accepteren",
    "functionele cookies",
    "strikt noodzakelijke cookies",
    "alleen basic cookies",
    "alleen basiscookies",
    "alleen standaard cookies",
    "alle cookies verwerpen",
    "noodzakelijk",
    "noodzakelijk cookies accepteren",
    "noodzakelijke cookies accepteren",
    "accepteer alleen noodzakelijk",
    "enkel noodzakelijke toestaan",
    "enkel strikt noodzakelijke cookies",
    "ik wijs ze liever af",
    "ik weiger cookies",
    "ik weiger optionele cookies",
    "weiger alle cookies",
    "weiger alle niet-noodzakelijke cookies",
    "weiger alle onnodige cookies",
    "weiger alle optionele",
    "weiger alles",
    "weiger targeting en third party cookies."
  ];
  var REJECT_PATTERNS_FRENCH = [
    "continuer sans accepter",
    "tout refuser",
    "refuser",
    "refuser tous les cookies",
    "non merci",
    "interdire tous les cookies",
    "je refuse",
    "refuser tout",
    "tout rejeter",
    "refuser et continuer",
    "rejeter",
    "refuser les cookies",
    "cookies n\xE9cessaires uniquement",
    "seulement n\xE9cessaires",
    "rejeter tout",
    "refuser les cookies optionnels",
    "je d\xE9sactive les finalit\xE9s non essentielles",
    "refuser les cookies non n\xE9cessaires",
    "rejeter tous les cookies",
    "cookies essentiels uniquement",
    "n\xE9cessaires uniquement",
    "refuser les cookies non essentiels",
    "tout refuser et fermer",
    "tout refuser sauf les cookies techniques",
    "continuer sans accepter x",
    "je refuse lutilisation de cookies",
    "non merci, seulement des cookies techniques",
    "non, tout refuser",
    "refuser tous les cookies non n\xE9cessaires",
    "rejeter les cookies",
    "uniquement les essentiels",
    "refuser tous",
    "accepter uniquement les n\xE9cessaires",
    "allow anonymous analytics",
    "autoriser les cookies essentiels uniquement",
    "autoriser uniquement les n\xE9cessaires",
    "cookies essentiels seulement",
    "cookies n\xE9cessaires seulement",
    "cookies techniques uniquement",
    "je pr\xE9f\xE8re les rejeter",
    "je refuse :(",
    "je refuse les cookies",
    "je refuse tous les cookies",
    "je refuse tout",
    "ne pas accepter",
    "non, accepter les n\xE9cessaires uniquement",
    "refuser (sauf cookies n\xE9cessaires)",
    "refuser ce cookie",
    "refuser les coockies",
    "refuser les cookies facultatifs",
    "refuser tout, sauf les cookies techniques",
    "refuser toutes",
    "refuser toutes les options",
    "rejeter la banni\xE8re",
    "rejeter les cookies non essentiels",
    "rejeter les cookies optionnels",
    "rejeter tous les non fonctionnels",
    "rejeter tout optionnel",
    "tout refuser, sauf les cookies techniques",
    "uniquement n\xE9cessaires",
    "x continuer sans accepter",
    "strictement n\xE9cessaires",
    "utiliser uniquement les cookies n\xE9cessaires",
    "cookies n\xE9cessaires",
    "accepter uniquement les cookies essentiels",
    "accepter les cookies n\xE9cessaires",
    "uniquement les cookies n\xE9cessaires",
    "autoriser uniquement les cookies essentiels",
    "autoriser uniquement les cookies n\xE9cessaires",
    "si vous ne souhaitez pas accepter les cookies \xE0 lexception des cookies techniquement n\xE9cessaires, veuillez cliquer ici",
    "cookies strictement n\xE9cessaires",
    "accepter les cookies strictement n\xE9cessaires",
    "autoriser les cookies essentiels",
    "non, merci, uniquement les cookies n\xE9cessaires",
    "indispensable uniquement",
    "uniquement autoriser les cookies essentiels",
    "utiliser que les cookies n\xE9cessaires",
    "uniquement les sdk n\xE9cessaires",
    "uniquement n\xE9cessaire",
    "utiliser uniquement les cookies fonctionnels",
    "refus",
    "refusez",
    "naccepter que les cookies indispensables",
    "naccepter que les cookies n\xE9cessaires",
    "naccepter que les cookies techniques",
    "n\xE9cessaires seulement"
  ];
  var REJECT_PATTERNS_GERMAN = [
    "ablehnen",
    "alle ablehnen",
    "nur notwendige cookies",
    "nur essenzielle cookies akzeptieren",
    "nur notwendige cookies verwenden",
    "nur technisch notwendige",
    "nur essentielle cookies akzeptieren",
    "alles ablehnen",
    "nur notwendige",
    "alle cookies ablehnen",
    "weiter ohne einwilligung",
    "mit diesem button wird der dialog geschlossen. seine funktionalit\xE4t ist identisch mit der des buttons nur essenzielle cookies akzeptieren.",
    "cookies ablehnen",
    "optionale cookies ablehnen",
    "nur erforderliche cookies",
    "einwilligung ablehnen",
    "nur erforderliche",
    "nur notwendige cookies zulassen",
    "nur funktionale cookies akzeptieren",
    "nur notwendige cookies akzeptieren",
    "nur notwendige technologien",
    "verweigern",
    "webanalyse ablehnen",
    "weiter ohne zustimmung",
    "optionale ablehnen",
    "nur notwendige akzeptieren",
    "nur funktionale cookies",
    "mit diesem button wird der dialog geschlossen. seine funktionalit\xE4t ist identisch mit der des buttons ablehnen.",
    "nur notwendige cookies erlauben",
    "zustimmung verweigern",
    "nein, danke",
    "nur erforderliche cookies akzeptieren",
    "zus\xE4tzliche cookies ablehnen",
    "ablehnen und nur essenzielle cookies akzeptieren",
    "nicht erforderliche ablehnen",
    "nicht essenzielle cookies daten ablehnen",
    "nur technisch notwendige cookies",
    "nur technisch notwendige cookies akzeptieren",
    "ablehnen speichern",
    "alle funktionen ablehnen",
    "alle optionalen cookies ablehnen",
    "alles verweigern",
    "mit erforderlichen einstellungen fortfahren",
    "nicht notwendige ablehnen",
    "notwendige cookies akzeptieren",
    "nur erforderliche technologien",
    "nur essenzielle cookies",
    "nur essenzielle cookies erlauben",
    "technisch nicht notwendige cookies ablehnen",
    "tippen sie zum ablehnen bitte hier",
    "ablehnen deny",
    "fortfahren ohne zu akzeptieren",
    "nur erforderliche akzeptieren",
    "nur notwendige erlauben",
    "ablehnen ...nur technisch notwendige cookies verwendet werden",
    "ablehnen (au\xDFer notwendige cookies)",
    "ablehnen und fortfahren",
    "ablehnen und schlie\xDFen",
    "ablehnen: nur grundfunktionen",
    "akzeptieren nur notwendige cookies",
    "alle ablehnen (au\xDFer notwendige cookies)",
    "alle nicht essenziellen cookies ablehnen",
    "alle nicht notwendigen cookies ablehnen",
    "alle optionale ablehnen",
    "alle optionalen ablehnen",
    "alle verweigern",
    "analyse cookies ablehnen",
    "cookie einstellungenablehnen",
    "erforderliche cookies akzeptieren",
    "erforderliche cookies zulassen",
    "externe inhalte ablehnen",
    "mit diesem button wird der dialog geschlossen. seine funktionalit\xE4t ist identisch mit der des buttons ablehnen und nur essenzielle cookies akzeptieren.",
    "mit diesem button wird der dialog geschlossen. seine funktionalit\xE4t ist identisch mit der des buttons nicht-essenzielle cookies verweigern.",
    "mit diesem button wird der dialog geschlossen. seine funktionalit\xE4t ist identisch mit der des buttons nur essenzielle akzeptieren.",
    "mit erforderlichen cookies fortfahren",
    "mit notwendigen fortfahren",
    "nein, bitte nicht",
    "nein, ich stimme nicht zu",
    "nicht funktionale cookies ablehnen",
    "nicht notwendige cookies ablehnen",
    "nicht-essenzielle cookies ablehnen",
    "nicht-essenzielle cookies verweigern",
    "notwendige cookies zulassen",
    "nur erforderliche cookies erlauben",
    "nur erforderliche cookies setzen",
    "nur erforderliche cookies verwenden",
    "nur essenzielle akzeptieren",
    "nur notwendige cookies annehmen",
    "nur notwendige cookies speichern",
    "nur notwendige cookies verwenden.",
    "nur notwendige funktionscookies akzeptieren",
    "nur notwendigen cookies zustimmen",
    "nur notwendiges akzeptieren",
    "nur wesentliche cookies annehmen",
    "opt. cookies ablehnen",
    "optionale dienste ablehnen",
    "optionale tools ablehnen",
    "sie alle cookies ablehnen",
    "technisch notwendige annehmen",
    "nur essentielle cookies",
    "nur essentielle",
    "nur funktionale akzeptieren",
    "nur technisch notwendige akzeptieren",
    "nur technisch notwendige daten und cookies ...",
    "nur technisch notwendige zulassen",
    "nur wesentliche",
    "ohne einverst\xE4ndnis fortfahren",
    "ohne einwilligung",
    "ohne zustimmung fortfahren",
    "ohne zustimmung weiter",
    "weiter mit essentiellen cookies",
    "weiter ohne annahme",
    "weiter ohne statistische analyse-cookies",
    "weiter ohne statistische cookies",
    "wesentliche cookies",
    "fortfahren ohne zustimmung"
  ];
  var REJECT_PATTERNS_ITALIAN = [
    "rifiuta",
    "rifiuta cookies",
    "rifiuta i cookie",
    "rifiuta i cookies",
    "rifiuta tutti i cookie",
    "rifiuta tutti i cookies",
    "rifiuta cookie non necessari",
    "rifiuta i cookie non tecnici",
    "rifiuta non necessari",
    "rifiuta tutto",
    "rifiuta tutti",
    "rifiuta e chiudi",
    "chiudi rifiuta tutti i cookie",
    "chiudi e rifiuta tutti i cookie",
    "chiudi e rifiuta tutto",
    "nega",
    "nega tutti",
    "negare",
    "non accetto",
    "accetta solo i necessari",
    "usa solo i cookie necessari",
    "accetta solo necessari",
    "solo necessari",
    "continua senza accettare x",
    "continua senza accettare",
    "rifiutare",
    "rifiutare i cookie",
    "rifiutare tutti i cookie",
    "rifiutare tutti",
    "rifiutare e continuare",
    "installa solo i cookie strettamente necessari",
    "solo cookies tecnici",
    "accetta necessari",
    "solo cookie tecnici",
    "solo cookie necessari",
    "strettamente necessari",
    "tecnici",
    "accetta solo cookie di navigazione",
    "chiudi e prosegui solo con i cookies tecnici necessari",
    "consenti solo i cookie tecnici",
    "solo cookie essenziali",
    "blocca i cookie non essenziali",
    "accetta i cookie necessari",
    "accetta solo cookie tecnici",
    "accetta solo i cookie essenziali",
    "accetta solo i cookie necessari",
    "accetta solo i necessary",
    "accetta i cookie essenziali",
    "accetta cookie tecnici",
    "necessari",
    "usa solo i cookie tecnici",
    "usa solo i necessari",
    "rifiuto",
    "essenziali",
    "accetta cookie essenziali",
    "accetta cookie necessari",
    "accetta solo cookie essenziali",
    "accetta solo cookie necessari",
    "rifiuta cookie non necessari",
    "rifiuta cookie non essenziali",
    "rifiuta i cookie non necessari",
    "rifiuta i cookie non essenziali",
    "rifiuta tutti i cookie e chiudi",
    "rifiuta tutto e chiudi",
    "rifiuta tutti i cookie chiudi",
    "continuare senza accettare",
    "rifiutare cookies",
    "rifiutare i cookies",
    "rifiutare non necessari",
    "rifiutare tutto",
    "rifiutare e chiudere",
    "solo essenziali",
    "solo tecnici",
    "negare tutti"
  ];
  var REJECT_PATTERNS_BRAZILIAN_PORTUGUESE = [
    // (deny)
    /^\s*(rejeitar|recusar|desativar|bloquear|negar|não\s*aceito|não \s*aceitar)\s*$/is,
    // (proceed) (without accepting)
    /^\s*(continuar|prosseguir|seguir)\s*(sem\s*aceitar)\s*$/is,
    // (deny) (everything) (optional)
    /^\s*(rejeitar|recusar|desativar|bloquear|negar|não\s*aceito|não \s*aceitar)\s*(tudo|o)?\s*(opcional|(não[-\s](essencial|funcional|obrigatório|necessário)))?\s*$/is,
    // (deny) (all) (the) (optional) (cookies)
    /^\s*(rejeitar|recusar|desativar|bloquear|negar|não\s*aceito|não \s*aceitar)\s*(todos)?\s*(os)?\s*(cookies)?\s*(opcionais|(não[-\s](essenciais|funcionais|obrigatórios|necessários)))?\s*$/is,
    // (accept) (only) (the) (essential)
    /^\s*(aceitar|utilizar)?\s*(apenas|somente|só)?\s*(o)?\s*(essencial|funcional|obrigatório|necessário)\s*$/is,
    // (accept) (only) (the) (essential) (cookies)
    /^\s*(aceitar|utilizar)?\s*(apenas|somente|só)?\s*(os)?\s*(cookies)?\s*(essenciais|funcionais|obrigatórios|necessários)\s*$/is
  ];
  var REJECT_PATTERNS_SPANISH = [
    "rechazar",
    "rechazar todo",
    "rechazar todas",
    "denegar",
    "rechazar cookies",
    "rechazarlas todas",
    "no acepto",
    "rechazar todas las cookies",
    "rechazar y cerrar",
    "denegar todas",
    "solo necesarias",
    "rechazar cookies opcionales",
    "rechazar opcionales",
    "cookies estrictamente necesarias",
    "aceptar s\xF3lo necesarias",
    "continuar sin aceptar",
    "denegar todo",
    "clear rechazar cookies",
    "configurar rechazar cookies",
    "denegar cookies",
    "rechazar y continuar",
    "rechazar las cookies",
    "clear rechazar",
    "denegar todas las cookies",
    "rechazar cookies no esenciales",
    "rechazarlas",
    "no, no acepto",
    "permitir s\xF3lo necesarias",
    "rechazar cookies adicionales",
    "rechazar cookies anal\xEDticas",
    "rechazar no necesarias",
    "rechazar opcional",
    "rechazar todo lo opcional",
    "solo cookies estrictamente necesarias",
    "solo esenciales",
    "x rechazar todas las cookies",
    "solo usar cookies necesarias",
    "solo cookies necesarias",
    "declinar",
    "aceptar solo las cookies esenciales",
    "necesarias",
    "aceptar cookies opcionales",
    "aceptar solo lo necesario",
    "solo funcionales",
    "declinar y cerrar",
    "d\xE9clin",
    "declina",
    "declinar consentimiento",
    "declinar todas",
    "solo las cookies necesarias",
    "nom\xE9s sutilitzen cookies quan \xE9s necessari",
    "no, s\xF3lo las estrictamente necesarias",
    "solo las necesarias",
    "acceptar nom\xE9s les necess\xE0ries",
    "acepta solo las necesarias",
    "aceptar solo lo esencial",
    "aceptar las obligatorias",
    "permitir solo cookies t\xE9cnicas",
    "cookies t\xE9cnicas",
    "permitir solo cookies t\xE9cnicas",
    "usar solo cookies t\xE9cnicas",
    "aceptar solo las esenciales"
  ];
  var REJECT_PATTERNS_SWEDISH = [
    "avvisa",
    "endast n\xF6dv\xE4ndiga",
    "avvisa alla",
    "endast n\xF6dv\xE4ndiga cookies",
    "neka",
    "neka alla",
    "avvisa allt",
    "avvisa alla cookies",
    "till\xE5t bara n\xF6dv\xE4ndiga cookies",
    "bara n\xF6dv\xE4ndiga",
    "bara n\xF6dv\xE4ndiga cookies",
    "till\xE5t bara n\xF6dv\xE4ndiga kakor",
    "endast n\xF6dv\xE4ndiga kakor",
    "till\xE5t endast n\xF6dv\xE4ndiga",
    "forts\xE4tt utan att acceptera",
    "godk\xE4nn endast n\xF6dv\xE4ndiga",
    "acceptera endast n\xF6dv\xE4ndiga",
    "avvisa cookies",
    "till\xE5t endast n\xF6dv\xE4ndiga kakor",
    "acceptera endast n\xF6dv\xE4ndiga cookies",
    "neka kakor",
    "bara n\xF6dv\xE4ndiga kakor",
    "neka alla cookies",
    "anv\xE4nd endast n\xF6dv\xE4ndiga",
    "avvisa alla utom n\xF6dv\xE4ndiga",
    "hantera eller avvisa",
    "neka alla utom n\xF6dv\xE4ndiga kakor",
    "neka och st\xE4ng",
    "till\xE5t bara n\xF6dv\xE4ndiga tj\xE4nster",
    "avvisa alla utom n\xF6dv\xE4ndiga kakor",
    "avvisa alla valfria",
    "godk\xE4nn bara n\xF6dv\xE4ndiga cookies",
    "acceptera endast n\xF6dv\xE4ndiga kakor",
    "anv\xE4nd endast n\xF6dv\xE4ndiga cookies",
    "avvisa alla kakor",
    "avvisa alla valm\xF6jligheter",
    "avvisa ej n\xF6dv\xE4ndiga",
    "avvisa icke-n\xF6dv\xE4ndiga",
    "f\xF6rneka",
    "godk\xE4nn bara n\xF6dv\xE4ndiga",
    "godk\xE4nn bara n\xF6dv\xE4ndiga kakor",
    "godk\xE4nn endast n\xF6dv\xE4ndiga cookies",
    "godk\xE4nn endast n\xF6dv\xE4ndiga kakor",
    "godta endast n\xF6dv\xE4ndiga",
    "jag godk\xE4nner bara n\xF6dv\xE4ndiga kakor",
    "nej, avvisa alla",
    "nej, bara n\xF6dv\xE4ndiga",
    "nej, bara n\xF6dv\xE4ndiga cookies",
    "neka alla utom n\xF6dv\xE4ndiga",
    "neka alla.",
    "neka cookies",
    "neka samtliga",
    "ok, endast n\xF6dv\xE4ndiga",
    "spara endast n\xF6dv\xE4ndiga",
    "st\xE4ng och avvisa",
    "till\xE5t bara n\xF6dv\xE4ndiga",
    "godk\xE4nn n\xF6dv\xE4ndiga kakor",
    "godk\xE4nn n\xF6dv\xE4ndiga",
    "acceptera n\xF6dv\xE4ndiga",
    "strikt n\xF6dv\xE4ndigt",
    "till\xE5t n\xF6dv\xE4ndiga",
    "n\xF6dv\xE4ndiga",
    "enbart n\xF6dv\xE4ndiga",
    "jag godk\xE4nner n\xF6dv\xE4ndiga kakor",
    "acceptera n\xF6dv\xE4ndiga kakor",
    "godk\xE4nn enbart n\xF6dv\xE4ndiga kakor",
    "godk\xE4nn n\xF6dv\xE4ndiga cookies",
    "om du inte vill acceptera andra cookies \xE4n de som \xE4r tekniskt n\xF6dv\xE4ndiga klickar du h\xE4r",
    "acceptera enbart n\xF6dv\xE4ndiga",
    "n\xF6dv\xE4ndiga cookies",
    "jag godk\xE4nner enbart att ni anv\xE4nder n\xF6dv\xE4ndiga cookies",
    "+ strikt n\xF6dv\xE4ndiga cookies",
    "anv\xE4nd enbart n\xF6dv\xE4ndiga cookies",
    "enbart n\xF6dv\xE4ndiga cookies",
    "godk\xE4nn n\xF6dv\xE4ndiga kakor st\xE4ng",
    "ok till n\xF6dv\xE4ndiga",
    "strikt n\xF6dv\xE4ndiga",
    "forts\xE4tt utan att godk\xE4nna",
    "avb\xF6j alla cookies",
    "jag accepterar endast grundl\xE4ggande kakor",
    "nej, jag avb\xF6jer",
    "till\xE5t inte cookies"
  ];
  var REJECT_PATTERNS = [
    ...REJECT_PATTERNS_ENGLISH,
    ...REJECT_PATTERNS_DUTCH,
    ...REJECT_PATTERNS_FRENCH,
    ...REJECT_PATTERNS_GERMAN,
    ...REJECT_PATTERNS_ITALIAN,
    ...REJECT_PATTERNS_BRAZILIAN_PORTUGUESE,
    ...REJECT_PATTERNS_SPANISH,
    ...REJECT_PATTERNS_SWEDISH
  ];
  var compactedRuleSteps = [
    ["exists", "e"],
    ["visible", "v"],
    ["waitForThenClick", "c"],
    ["click", "k"],
    ["waitFor", "w"],
    ["waitForVisible", "wv"],
    ["hide", "h"],
    ["cookieContains", "cc"]
  ];
  function clearUnusedStrings(ruleset, ignoreBeforeIndex = 0) {
    const { v, s, r } = ruleset;
    const usedStringIds = /* @__PURE__ */ new Set();
    function addStringIdsFromRuleSteps(steps) {
      steps.forEach((step) => {
        for (const [, shortKey] of compactedRuleSteps) {
          if (step[shortKey] !== void 0) {
            usedStringIds.add(step[shortKey]);
          }
        }
        if (step.if) {
          addStringIdsFromRuleSteps([step.if]);
        }
        if (step.then) {
          addStringIdsFromRuleSteps(step.then);
        }
        if (step.else) {
          addStringIdsFromRuleSteps(step.else);
        }
        if (step.any) {
          addStringIdsFromRuleSteps(step.any);
        }
      });
    }
    ruleset.r.forEach((rule) => {
      addStringIdsFromRuleSteps(rule[6]);
      addStringIdsFromRuleSteps(rule[7]);
      addStringIdsFromRuleSteps(rule[8]);
      addStringIdsFromRuleSteps(rule[9]);
      rule[5].forEach((id) => usedStringIds.add(id));
    });
    return {
      v,
      r,
      s: s.slice(0, Math.max(...usedStringIds) + 1).map((str, idx) => {
        if (idx < ignoreBeforeIndex || usedStringIds.has(idx)) {
          return str;
        }
        return "";
      })
    };
  }
  function shouldRunRuleInContext(rule, mainFrame, url) {
    const runContext = rule[4];
    if (mainFrame && runContext === 1) {
      return false;
    }
    if (!mainFrame && [20, 22, 10, 12].includes(runContext)) {
      return false;
    }
    const urlPattern = rule[3];
    if (urlPattern && urlPattern !== "" && url.match(urlPattern) === null) {
      return false;
    }
    return true;
  }
  function filterCompactRules(rules2, context) {
    const { v, s, r, index } = rules2;
    const { url, mainFrame } = context;
    const shouldRunInContext = (rule) => shouldRunRuleInContext(rule, mainFrame, url);
    if (!mainFrame) {
      const ruleset = {
        v,
        s: s.slice(0, index.frameStringEnd),
        r: r.slice(index.frameRuleRange[0], index.frameRuleRange[1]).filter(shouldRunInContext)
      };
      return clearUnusedStrings(ruleset);
    }
    const genericRules = r.slice(index.genericRuleRange[0], index.genericRuleRange[1]);
    const specificRules = r.slice(index.specificRuleRange[0], index.specificRuleRange[1]).filter(shouldRunInContext);
    if (specificRules.length > 0) {
      const ruleset = {
        v,
        s,
        r: [...genericRules, ...specificRules]
      };
      return clearUnusedStrings(ruleset);
    }
    return {
      v,
      s: s.slice(0, index.genericStringEnd),
      r: genericRules
    };
  }
  var _config;
  _config = /* @__PURE__ */ new WeakMap();

  // shared/js/background/components/cookie-prompt-management.js
  var import_webextension_polyfill3 = __toESM(require_browser_polyfill());
  init_wrapper();

  // shared/js/background/message-registry.js
  var messageHandlers = {};
  function registerMessageHandler(name, func) {
    messageHandlers[name] = func;
  }
  var message_registry_default = messageHandlers;

  // shared/js/background/components/mv3-content-script-injection.js
  var import_webextension_polyfill2 = __toESM(require_browser_polyfill());

  // shared/js/background/components/cookie-prompt-management.js
  var logsConfig = {
    lifecycle: false,
    detectionsteps: false,
    errors: false,
    evals: false,
    messages: false,
    rulesteps: false,
    waits: false
  };
  var CookiePromptManagement = class _CookiePromptManagement {
    static SUMMARY_ALARM_NAME = "cpm-summary";
    static SUMMARY_DELAY_MINUTES = 2;
    static CPM_CONTENT_SCRIPT_ID = "cookie-prompt-management-script";
    /**
     *
     * @param {{
     *  cpmMessaging: CPMMessagingBase
     * }} opts
     */
    constructor({ cpmMessaging: cpmMessaging2 }) {
      this.cpmMessaging = cpmMessaging2;
      this.scheduleConfigRefresh();
      if (false) {
        const remoteConfig = (
          /** @type {import('./cpm-standalone-messaging').CPMStandaloneMessaging} */
          cpmMessaging2.remoteConfig
        );
        remoteConfig.onUpdate(async () => {
          const enabled = remoteConfig.isFeatureEnabled("autoconsent");
          const existingScripts = await chrome.scripting.getRegisteredContentScripts({
            ids: [_CookiePromptManagement.CPM_CONTENT_SCRIPT_ID]
          });
          const cpmScriptExists = existingScripts.length > 0;
          if (enabled && !cpmScriptExists) {
            console.log("registering CPM content script");
            await registerContentScripts([
              {
                id: _CookiePromptManagement.CPM_CONTENT_SCRIPT_ID,
                allFrames: true,
                js: ["public/js/content-scripts/cpm.js"],
                runAt: "document_start",
                world: "ISOLATED",
                matches: ["*://*/*"],
                matchOriginAsFallback: true
              }
            ]);
          } else if (!enabled && cpmScriptExists) {
            console.log("unregistering CPM content script");
            await unregisterContentScripts([_CookiePromptManagement.CPM_CONTENT_SCRIPT_ID]);
          }
        });
      }
      this._tabUrlsCache = /* @__PURE__ */ new Map();
      this._lastHandledCMP = /* @__PURE__ */ new Map();
      this._reloadLoopDetected = /* @__PURE__ */ new Set();
      this._stateQueue = Promise.resolve();
      this.getCpmState();
      import_webextension_polyfill3.default.alarms.onAlarm.addListener(async (alarm) => {
        if (alarm.name === _CookiePromptManagement.SUMMARY_ALARM_NAME) {
          await import_webextension_polyfill3.default.alarms.clear(_CookiePromptManagement.SUMMARY_ALARM_NAME);
          await this.sendSummaryPixel();
        }
      });
      import_webextension_polyfill3.default.runtime.onSuspend?.addListener(() => {
        this.sendSummaryPixel();
      });
      registerMessageHandler("autoconsent", (options, sender, req) => {
        return this.handleAutoConsentMessage(req.autoconsentPayload, sender).then(() => {
        });
      });
    }
    scheduleConfigRefresh() {
      this.remoteConfigJson = this.cpmMessaging.refreshRemoteConfig().catch((e) => {
        return null;
      });
    }
    /**
     * @param {any} jsonCpmState
     * @returns {CpmState}
     */
    _deserializeCpmState(jsonCpmState) {
      return {
        detectionCache: {
          patterns: new Set(jsonCpmState.detectionCache?.patterns || []),
          both: new Set(jsonCpmState.detectionCache?.both || []),
          onlyRules: new Set(jsonCpmState.detectionCache?.onlyRules || [])
        },
        summaryEvents: structuredClone(jsonCpmState.summaryEvents || {})
      };
    }
    /**
     * @param {CpmState} cpmState
     * @returns {object}
     */
    _serializeCpmState(cpmState) {
      return {
        detectionCache: {
          patterns: Array.from(cpmState.detectionCache.patterns),
          both: Array.from(cpmState.detectionCache.both),
          onlyRules: Array.from(cpmState.detectionCache.onlyRules)
        },
        summaryEvents: structuredClone(cpmState.summaryEvents)
      };
    }
    /**
     * @returns {Promise<CpmState>}
     */
    async getCpmState() {
      if (!this._jsonCpmState) {
        this._jsonCpmState = await getFromSessionStorage("cpmState") || {
          detectionCache: {
            patterns: [],
            both: [],
            onlyRules: []
          },
          summaryEvents: {}
        };
      }
      return this._deserializeCpmState(this._jsonCpmState);
    }
    async checkHeuristicActionEnabled() {
      const settings3 = await this.cpmMessaging.checkAutoconsentSetting();
      const heuristicMode = this.settingsToHeuristicModeName(settings3);
      return heuristicMode !== "off" && heuristicMode !== "";
    }
    /**
     * @param {CpmState} newState
     */
    async updateCpmState(newState) {
      this._jsonCpmState = this._serializeCpmState(newState);
      try {
        await setToSessionStorage("cpmState", this._jsonCpmState);
      } catch (e) {
        this.cpmMessaging.logMessage(`error setting cpmState to session storage: ${e}`);
      }
    }
    /**
     * Atomically read-modify-write the CPM state.
     * All state mutations are serialized through this method to prevent race conditions
     * between parallel message handlers.
     *
     * IMPORTANT: The callback must NOT await other methods that call
     * modifyCpmState (e.g. firePixel), as that would deadlock the queue.
     * Non-awaited calls are fine -- they simply queue up after the current operation.
     *
     * @param {(state: CpmState) => void | Promise<void>} fn
     * @returns {Promise<void>}
     */
    modifyCpmState(fn) {
      const op = this._stateQueue.then(async () => {
        const state = await this.getCpmState();
        await fn(state);
        await this.updateCpmState(state);
      });
      this._stateQueue = op.catch((e) => {
        this.cpmMessaging.logMessage(`error in state queue: ${e}`);
      });
      return op;
    }
    /**
     * @param {number} tabId
     */
    clearReloadLoopState(tabId) {
      this._lastHandledCMP.delete(tabId);
      this._reloadLoopDetected.delete(tabId);
    }
    /**
     * @param {number} tabId
     * @param {string} url
     * @returns {URL}
     */
    updateTopUrl(tabId, url) {
      const oldTopUrl = this._tabUrlsCache.get(tabId) || new URL("about:blank");
      let newTopUrl = null;
      try {
        newTopUrl = new URL(url);
      } catch (e) {
        this.cpmMessaging.logMessage(`invalid top URL: ${url}: ${e}`);
        return oldTopUrl;
      }
      if (oldTopUrl.host !== newTopUrl.host || oldTopUrl.pathname !== newTopUrl.pathname || oldTopUrl.protocol !== newTopUrl.protocol) {
        this.clearReloadLoopState(tabId);
      }
      this._tabUrlsCache.set(tabId, newTopUrl);
      return newTopUrl;
    }
    /**
     * @param {number} tabId
     * @param {string} cmp
     * @param {boolean} isCosmetic
     */
    rememberLastHandledCMP(tabId, cmp, isCosmetic) {
      if (isCosmetic) {
        this.clearReloadLoopState(tabId);
        return;
      }
      const lastHandledCMP = this._lastHandledCMP.get(tabId);
      if (lastHandledCMP !== cmp) {
        this.clearReloadLoopState(tabId);
      }
      this._lastHandledCMP.set(tabId, cmp);
    }
    /**
     * @param {number} tabId
     * @param {string} cmp
     */
    detectReloadLoop(tabId, cmp) {
      const lastHandledCMP = this._lastHandledCMP.get(tabId);
      if (!this._reloadLoopDetected.has(tabId) && lastHandledCMP === cmp) {
        this.cpmMessaging.logMessage(`reload loop detected: ${cmp} on ${this._tabUrlsCache.get(tabId)} tabId: ${tabId}`);
        this._reloadLoopDetected.add(tabId);
        this.firePixel("error_reload-loop");
      }
    }
    /**
     *
     * @param {import('@duckduckgo/autoconsent').ContentScriptMessage} msg
     * @param {browser.Runtime.MessageSender} sender
     * @returns
     */
    async handleAutoConsentMessage(msg, sender) {
      const frameId = sender.frameId;
      if (!sender.tab || typeof frameId !== "number") {
        this.cpmMessaging.logMessage(`Invalid frameId ${frameId} or tab ${sender.tab}`);
        return;
      }
      const tabId = sender.tab.id;
      if (typeof tabId !== "number") {
        this.cpmMessaging.logMessage(`Invalid tabId ${tabId}`);
        return;
      }
      const isMainFrame = frameId === 0;
      const frameUrl = sender.url || sender.origin || "about:blank";
      const tabUrl = sender.tab.url || sender.tab.pendingUrl || "about:blank";
      const remoteConfig = await this.remoteConfigJson;
      if (!remoteConfig) {
        this.cpmMessaging.logMessage("Remote config not ready, scheduling retry");
        this.scheduleConfigRefresh();
        return;
      }
      const autoconsentRemoteConfig = remoteConfig.features?.autoconsent;
      const autoconsentSettings = autoconsentRemoteConfig?.settings;
      if (!autoconsentSettings) {
        this.cpmMessaging.logMessage(`autoconsentSettings not ready: ${autoconsentSettings}`);
        return;
      }
      switch (msg.type) {
        case "init": {
          const settings3 = await this.cpmMessaging.checkAutoconsentSetting();
          const heuristicMode = this.settingsToHeuristicModeName(settings3);
          const heuristicActionEnabled = heuristicMode !== "off";
          if (heuristicMode === "") {
            this.cpmMessaging.logMessage("autoconsent setting not enabled");
            return;
          }
          if (isMainFrame) {
            this.updateTopUrl(tabId, tabUrl);
            this.scheduleConfigRefresh();
          }
          const isEnabled = await this.cpmMessaging.checkAutoconsentEnabledForSite(tabUrl);
          if (!isEnabled) {
            this.cpmMessaging.logMessage(`autoconsent disabled for site: ${tabUrl}`);
            if (isMainFrame) {
              this.firePixel("disabled-for-site");
            }
            return;
          }
          const visualTest = false;
          let autoAction = "optOut";
          if (this._reloadLoopDetected.has(tabId)) {
            this.cpmMessaging.logMessage(`reload loop detected, disabling autoAction: ${tabId}`);
            autoAction = null;
          }
          if (isMainFrame) {
            this.cpmMessaging.refreshDashboardState(tabId, tabUrl, {
              consentManaged: false,
              cosmetic: null,
              optoutFailed: null,
              selftestFailed: null,
              consentReloadLoop: this._reloadLoopDetected.has(tabId),
              consentRule: this._lastHandledCMP.get(tabId) || null,
              consentHeuristicEnabled: heuristicActionEnabled
            });
            this.firePixel("init");
          }
          const autoconsentConfig = {
            enabled: isEnabled,
            autoAction,
            detectRetries: 20,
            isMainWorld: false,
            disabledCmps: autoconsentSettings.disabledCMPs || [],
            enablePrehide: true,
            prehideTimeout: 2e3,
            enableCosmeticRules: true,
            enableGeneratedRules: true,
            enableHeuristicDetection: true,
            heuristicMode,
            visualTest,
            logs: logsConfig
          };
          const compactRuleList = autoconsentSettings.compactRuleList;
          const rules2 = {
            autoconsent: []
          };
          if (compactRuleList) {
            if (compactRuleList.index) {
              rules2.compact = filterCompactRules(
                /** @type {import('@duckduckgo/autoconsent').IndexedCMPRuleset} */
                compactRuleList,
                {
                  // use the frame URL here because rules are filtered by frame context
                  url: frameUrl,
                  mainFrame: isMainFrame
                }
              );
            } else {
              rules2.compact = compactRuleList;
            }
          }
          chrome.tabs.sendMessage(
            tabId,
            {
              type: "initResp",
              rules: rules2,
              config: autoconsentConfig
            },
            {
              frameId
            }
          );
          break;
        }
        case "cmpDetected": {
          break;
        }
        case "popupFound": {
          this.firePixel("popup-found");
          this.detectReloadLoop(tabId, msg.cmp);
          break;
        }
        case "optOutResult": {
          if (!msg.result) {
            this.firePixel("error_optout");
            this.cpmMessaging.refreshDashboardState(tabId, tabUrl, {
              consentManaged: true,
              cosmetic: null,
              optoutFailed: true,
              selftestFailed: null,
              consentReloadLoop: this._reloadLoopDetected.has(tabId),
              consentRule: msg.cmp,
              consentHeuristicEnabled: await this.checkHeuristicActionEnabled()
            });
          } else {
          }
          break;
        }
        case "autoconsentDone": {
          this.rememberLastHandledCMP(tabId, msg.cmp, msg.isCosmetic);
          this.cpmMessaging.refreshDashboardState(tabId, tabUrl, {
            consentManaged: true,
            cosmetic: msg.isCosmetic,
            optoutFailed: false,
            selftestFailed: null,
            consentReloadLoop: this._reloadLoopDetected.has(tabId),
            consentRule: msg.cmp,
            consentHeuristicEnabled: await this.checkHeuristicActionEnabled()
          });
          if (msg.cmp === "HEURISTIC") {
            this.firePixel("done_heuristic");
          } else {
            this.firePixel(msg.isCosmetic ? "done_cosmetic" : "done");
          }
          this.cpmMessaging.showCpmAnimation(tabId, tabUrl, msg.isCosmetic);
          this.firePixel(msg.isCosmetic ? "animation-shown_cosmetic" : "animation-shown");
          this.cpmMessaging.notifyPopupHandled(tabId, msg);
          break;
        }
        case "report": {
          const state = msg.state || {};
          const detectedByPatterns = state.heuristicPatterns?.length > 0;
          const detectedBySnippets = state.heuristicSnippets?.length > 0;
          const detectedPopups = state.detectedPopups?.length > 0;
          const heuristicMatch = detectedByPatterns || detectedBySnippets;
          await this.modifyCpmState((cpmState) => {
            if (isMainFrame && heuristicMatch && !cpmState.detectionCache.patterns.has(msg.instanceId)) {
              cpmState.detectionCache.patterns.add(msg.instanceId);
              this.firePixel("detected-by-patterns");
            }
            if (isMainFrame && detectedPopups) {
              if (heuristicMatch && !cpmState.detectionCache.both.has(msg.instanceId)) {
                cpmState.detectionCache.both.add(msg.instanceId);
                this.firePixel("detected-by-both");
              } else if (!heuristicMatch && !cpmState.detectionCache.onlyRules.has(msg.instanceId)) {
                cpmState.detectionCache.onlyRules.add(msg.instanceId);
                this.firePixel("detected-only-rules");
              }
            }
          });
          break;
        }
        case "eval": {
          if (typeof msg.snippetId !== "undefined") {
            this.evalInTab(tabId, frameId, msg.snippetId).then(([result]) => {
              if (logsConfig.evals) {
                console.groupCollapsed(`eval result for ${frameUrl}`);
                console.log(msg.code, result.result);
                console.groupEnd();
              }
              chrome.tabs.sendMessage(
                tabId,
                {
                  id: msg.id,
                  type: "evalResp",
                  result: result.result
                },
                {
                  frameId
                }
              );
            });
          }
          break;
        }
        case "autoconsentError": {
          if (msg.details?.msg?.includes("Found multiple CMPs")) {
            this.firePixel("error_multiple-popups");
          }
          break;
        }
        case "visualDelay": {
          console.log("visualDelay", msg);
          break;
        }
        default:
          this.cpmMessaging.logMessage(`Unhandled autoconsent message type: ${msg.type}`);
          break;
      }
    }
    /**
     *
     * @param {number} tabId
     * @param {number} frameId
     * @param {keyof typeof evalSnippets} snippetId
     * @returns {Promise<chrome.scripting.InjectionResult<boolean>[]>}
     */
    async evalInTab(tabId, frameId, snippetId) {
      return chrome.scripting.executeScript({
        target: {
          tabId,
          frameIds: [frameId]
        },
        world: "MAIN",
        func: snippets[snippetId]
      });
    }
    /**
     * Determine the autoconsent operating mode from user settings and feature flags.
     *  - '' if autoconsent is disabled.
     *  - 'off' if heuristic action is disabled.
     *  - 'reject' if cookie popup preference setting is disabled (this is the old settings UI)
     *  - 'tier1' if user preference is 'default'.
     *  - 'tier2' if user preference is 'max'.
     *  - '' if the operating mode is not determined.
     * @param {AutoconsentUserSettings} settings
     * @returns {'' | 'off' | 'reject' | 'tier1' | 'tier2'}
     */
    settingsToHeuristicModeName(settings3) {
      const { enabled, userPreference, featureFlags } = settings3;
      if (!enabled || userPreference === "off") {
        return "";
      }
      if (!featureFlags.heuristicAction) {
        return "off";
      }
      if (!featureFlags.cookiePopupPreferenceSetting) {
        return "reject";
      }
      if (userPreference === "default") {
        return "tier1";
      }
      if (userPreference === "max") {
        return "tier2";
      }
      return "off";
    }
    async getPixelHeuristicParameter() {
      return this.settingsToHeuristicModeName(await this.cpmMessaging.checkAutoconsentSetting());
    }
    async firePixel(eventName) {
      this.modifyCpmState((cpmState) => {
        cpmState.summaryEvents[eventName] = (cpmState.summaryEvents[eventName] || 0) + 1;
      });
      createAlarm(_CookiePromptManagement.SUMMARY_ALARM_NAME, {
        delayInMinutes: _CookiePromptManagement.SUMMARY_DELAY_MINUTES
      });
      const pixelName = `autoconsent_${eventName}`;
      this.cpmMessaging.sendPixel(pixelName, "daily", {
        consentHeuristicEnabled: await this.getPixelHeuristicParameter(),
        fromExtension: "1"
      });
    }
    async sendSummaryPixel() {
      let summaryEvents = {};
      await this.modifyCpmState((cpmState) => {
        summaryEvents = structuredClone(cpmState.summaryEvents);
        cpmState.summaryEvents = {};
        cpmState.detectionCache.patterns.clear();
        cpmState.detectionCache.both.clear();
        cpmState.detectionCache.onlyRules.clear();
      });
      this.cpmMessaging.sendPixel("autoconsent_summary", "standard", {
        ...summaryEvents,
        consentHeuristicEnabled: await this.getPixelHeuristicParameter(),
        fromExtension: "1"
      });
    }
  };

  // shared/js/background/components/cpm-embedded-messaging.js
  init_wrapper();
  var SUBFEATURE_CHECK_TTL = 30 * 1e3;
  var SETTING_CHECK_TTL = 10 * 1e3;
  var SITE_CHECK_TTL = 3 * 1e3;
  var MAX_CACHE_SIZE = 100;
  var CPMEmbeddedMessaging = class {
    /**
     * @param {NativeMessagingInterface} nativeMessaging
     */
    constructor(nativeMessaging2) {
      this.nativeMessaging = nativeMessaging2;
      this._cache = /* @__PURE__ */ new Map();
      this._queue = Promise.resolve();
      this._cachedConfig = null;
    }
    /**
     * Enqueue a notification message to be sent to the native app.
     * @param {string} method
     * @param {Record<string, any>} params
     */
    async _notify(method2, params) {
      const result = this._queue.then(() => {
        return this.nativeMessaging.notify(method2, params);
      }).catch((e) => {
        console.error("error in notification queue", e);
      });
      this._queue = result;
      await result;
    }
    /**
     * Enqueue a request to the native app and wait for a response,
     * blocking subsequent callers until the request is complete.
     * If cacheKey and ttl are provided, the result is cached and
     * returned immediately on subsequent calls within the TTL.
     * @param {string} method
     * @param {Record<string, any>} params
     * @param {string} [cacheKey]
     * @param {number} [ttl]
     * @returns {Promise<any>}
     */
    _request(method2, params, cacheKey, ttl) {
      const job = this._queue.then(async () => {
        if (cacheKey && ttl) {
          const cached = this._cache.get(cacheKey);
          if (cached && Date.now() - cached.time < ttl) {
            return cached.value;
          }
        }
        const result = await this.nativeMessaging.request(method2, params);
        if (cacheKey && ttl) {
          if (this._cache.size >= MAX_CACHE_SIZE) {
            const oldest = this._cache.keys().next().value;
            if (oldest !== void 0) this._cache.delete(oldest);
          }
          this._cache.set(cacheKey, { time: Date.now(), value: result });
        }
        return result;
      }).catch((e) => {
        console.error(`error in request queue for ${method2}`, e);
      });
      this._queue = job;
      return job;
    }
    async logMessage(message) {
      console.log(message);
      await this._notify("extensionLog", {
        message
      });
    }
    async refreshDashboardState(tabId, url, dashboardState) {
      await this._notify("refreshCpmDashboardState", {
        tabId,
        url,
        consentStatus: dashboardState
      });
    }
    async showCpmAnimation(tabId, topUrl, isCosmetic) {
      await this._notify("showCpmAnimation", {
        tabId,
        topUrl,
        isCosmetic
      });
    }
    async notifyPopupHandled(tabId, msg) {
      await this._notify("cookiePopupHandled", {
        tabId,
        msg
      });
    }
    /**
     * Check autoconsent enabled state and user preference.
     * @returns {Promise<import('./cookie-prompt-management').AutoconsentUserSettings>}
     */
    async checkAutoconsentSetting() {
      const result = await this._request("isAutoconsentSettingEnabled", {}, "userSetting", SETTING_CHECK_TTL);
      return result ?? { enabled: false };
    }
    async checkAutoconsentEnabledForSite(url) {
      const result = await this._request("isFeatureEnabled", { featureName: "autoconsent", url }, `site:${url}`, SITE_CHECK_TTL);
      return result?.enabled ?? false;
    }
    async checkSubfeatureEnabled(subfeatureName) {
      const result = await this._request(
        "isSubFeatureEnabled",
        { featureName: "autoconsent", subfeatureName },
        `subfeature:${subfeatureName}`,
        SUBFEATURE_CHECK_TTL
      );
      return result?.enabled ?? false;
    }
    async sendPixel(pixelName, type, params) {
      await this._notify("sendPixel", {
        pixelName,
        type,
        params
      });
    }
    async refreshRemoteConfig() {
      const cachedConfig = this._cachedConfig || await getFromSessionStorage("config") || { version: "unknown" };
      const cachedConfigVersion = `${cachedConfig.version}`;
      try {
        console.log(`fetching config from native, cachedConfigVersion: ${cachedConfigVersion}`);
        const result = await this.nativeMessaging.request("getResourceIfNew", { name: "config", version: cachedConfigVersion });
        if (result.updated) {
          this._cachedConfig = result.data;
          try {
            await setToSessionStorage("config", this._cachedConfig);
          } catch (e) {
            this.logMessage(`error setting cached config to session storage: ${e}`);
          }
          return this._cachedConfig;
        }
        return cachedConfig;
      } catch (e) {
        this.logMessage(`error refreshing remote config: ${e}`);
        if (cachedConfigVersion !== "unknown") {
          return cachedConfig;
        }
        throw e;
      }
    }
  };

  // shared/js/background/components/message-router.js
  var import_webextension_polyfill5 = __toESM(require_browser_polyfill());
  init_wrapper();

  // shared/js/background/utils.js
  var import_webextension_polyfill4 = __toESM(require_browser_polyfill());
  init_wrapper();

  // shared/js/background/storage/tds.js
  var settings = require_settings();

  // shared/js/background/utils.js
  var import_settings = __toESM(require_settings());

  // node_modules/tldts-core/dist/es6/src/options.js
  function setDefaultsImpl({ allowIcannDomains = true, allowPrivateDomains = false, detectIp = true, detectSpecialUse = false, extractHostname: extractHostname2 = true, mixedInputs = true, validHosts = null, validateHostname = true }) {
    return {
      allowIcannDomains,
      allowPrivateDomains,
      detectIp,
      detectSpecialUse,
      extractHostname: extractHostname2,
      mixedInputs,
      validHosts,
      validateHostname
    };
  }
  var DEFAULT_OPTIONS = (
    /*@__INLINE__*/
    setDefaultsImpl({})
  );

  // node_modules/tldts-core/dist/es6/src/factory.js
  function getEmptyResult() {
    return {
      domain: null,
      domainWithoutSuffix: null,
      hostname: null,
      isIcann: null,
      isIp: null,
      isPrivate: null,
      isSpecialUse: null,
      publicSuffix: null,
      subdomain: null
    };
  }

  // node_modules/tldts/dist/es6/index.js
  var RESULT = getEmptyResult();

  // shared/js/background/utils.js
  var import_parse_user_agent_string = __toESM(require_parse_user_agent_string());
  var import_sha1 = __toESM(require_sha1());
  var browserInfo = (0, import_parse_user_agent_string.default)();
  function getBrowserName() {
    if (!browserInfo || !browserInfo.browser) return;
    let browserName = browserInfo.browser.toLowerCase();
    if (browserName === "firefox") browserName = "moz";
    return browserName;
  }
  var dayMultiplier = 24 * 60 * 60 * 1e3;

  // shared/js/background/popup-messaging.js
  var activePort = null;
  function getActivePort() {
    return activePort;
  }
  function setActivePort(port) {
    activePort = port;
  }

  // shared/js/background/components/message-router.js
  var MessageReceivedEvent = class extends CustomEvent {
    constructor(msg) {
      super("messageReceived", { detail: msg });
    }
    get messageType() {
      return this.detail.messageType;
    }
  };
  var MessageRouter = class extends EventTarget {
    constructor() {
      super();
      const browserName = getBrowserName();
      import_webextension_polyfill5.default.runtime.onConnect.addListener((port) => {
        if (port.name === "privacy-dashboard") {
          this.popupConnectionOpened(port);
        }
      });
      import_webextension_polyfill5.default.runtime.onMessage.addListener((req, sender) => {
        if (sender.id !== getExtensionId()) return;
        if (browserName === "chrome" && (req === "healthCheckRequest" || req === "rescheduleCounterMessagingRequest")) {
          req = { messageType: req };
        }
        const legacyMessageTypes = [
          "addUserData",
          "getUserData",
          "removeUserData",
          "getEmailProtectionCapabilities",
          "getAddresses",
          "refreshAlias",
          "debuggerMessage"
        ];
        for (const legacyMessageType of legacyMessageTypes) {
          if (legacyMessageType in req) {
            req.messageType = legacyMessageType;
            req.options = req[legacyMessageType];
          }
        }
        if (req.registeredTempAutofillContentScript) {
          req.messageType = "registeredContentScript";
        }
        if (req.messageType && req.messageType in message_registry_default) {
          this.dispatchEvent(new MessageReceivedEvent(req));
          return Promise.resolve(message_registry_default[req.messageType](req.options, sender, req));
        }
        console.error("Unrecognized message to background:", req, sender);
      });
    }
    /**
     * Set up the messaging connection with the popup UI.
     *
     * Note: If the ServiceWorker dies while there is an open connection, the popup
     *       will take care of re-opening the connection.
     *
     * @param {Port} port
     */
    popupConnectionOpened(port) {
      setActivePort(port);
      port.onDisconnect.addListener(() => {
        if (getActivePort() === port) {
          setActivePort(null);
        }
      });
      port.onMessage.addListener(async (message) => {
        const messageType = message?.messageType;
        if (!messageType || !(messageType in message_registry_default)) {
          console.error("Unrecognized message (privacy-dashboard -> background):", message);
          return;
        }
        this.dispatchEvent(new MessageReceivedEvent(message));
        const response = await message_registry_default[messageType](message?.options, port, message);
        if (typeof message?.id === "number") {
          port.postMessage({
            id: message.id,
            messageType: "response",
            options: response
          });
        }
      });
    }
  };

  // shared/js/background/devbuild-reloader.js
  var import_webextension_polyfill6 = __toESM(require_browser_polyfill());
  init_wrapper();

  // shared/js/background/components/native-messaging.js
  var import_webextension_polyfill7 = __toESM(require_browser_polyfill());
  var DEFAULT_NATIVE_APP_ID = "com.duckduckgo.macos.browser";
  var NativeMessaging = class {
    /**
     * @param {string} context
     * @param {string} featureName
     * @param {string} [appId]
     */
    constructor(context, featureName, appId = DEFAULT_NATIVE_APP_ID) {
      this._appId = appId;
      this._context = context;
      this._featureName = featureName;
    }
    /**
     * Send a fire-and-forget notification to the native app.
     *
     * @param {string} method - The method name to call on the native side
     * @param {Record<string, any>} [params] - Optional parameters to send
     */
    async notify(method2, params = {}) {
      const msg = (
        /** @type {NotificationMessage} */
        {
          context: this._context,
          featureName: this._featureName,
          method: method2,
          params
        }
      );
      await import_webextension_polyfill7.default.runtime.sendNativeMessage(this._appId, msg).catch((e) => {
        throw e;
      });
    }
    /**
     * Send a request to the native app and wait for a response.
     *
     * @param {string} method - The method name to call on the native side
     * @param {Record<string, any>} [params] - Optional parameters to send
     * @returns {Promise<any>}
     */
    async request(method2, params = {}) {
      const id = crypto.randomUUID();
      const msg = (
        /** @type {RequestMessage} */
        {
          context: this._context,
          featureName: this._featureName,
          id,
          method: method2,
          params
        }
      );
      const response = (
        /** @type {MessageResponse} */
        await import_webextension_polyfill7.default.runtime.sendNativeMessage(this._appId, msg).catch((e) => {
          return {
            id,
            context: this._context,
            featureName: this._featureName,
            error: {
              message: `NativeMessaging request-response error: ${e}`
            }
          };
        })
      );
      if (!response || typeof response !== "object") {
        throw new Error(`NativeMessaging: unexpected response type: ${typeof response}`);
      }
      if ("error" in response && response.error) {
        throw new Error(response.error.message || "Unknown error");
      }
      return response.result || {};
    }
    subscribe(_msg, _callback) {
      throw new Error("Subscriptions are not supported over Native Messaging API");
    }
  };

  // shared/js/background/background-embedded.js
  var nativeMessaging = new NativeMessaging("ddgInternalExtension", "autoconsent", "com.duckduckgo.macos.browser");
  globalThis.addEventListener("error", (event) => {
    nativeMessaging.notify("extensionException", {
      message: `Uncaught error: ${event.error?.message ?? event.message}`,
      stack: event.error?.stack
    }).catch((e) => {
    });
  });
  globalThis.addEventListener("unhandledrejection", (event) => {
    nativeMessaging.notify("extensionException", {
      message: `Unhandled promise rejection: ${event.reason}`,
      stack: event.reason?.stack
    }).catch((e) => {
    });
  });
  var cpmMessaging = new CPMEmbeddedMessaging(nativeMessaging);
  var messaging = new MessageRouter();
  var cpm = new CookiePromptManagement({
    cpmMessaging
  });
  var components = {
    messaging,
    cpm
  };
  Promise.all([
    import_webextension_polyfill8.default.scripting.getRegisteredContentScripts(),
    import_webextension_polyfill8.default.alarms.getAll(),
    // @ts-ignore - getBytesInUse is not available in the type
    import_webextension_polyfill8.default.storage.session.getBytesInUse(null)
  ]).then(([scripts, alarms, bytesInSessionStorage]) => {
    const quotaBytes = import_webextension_polyfill8.default.storage.session.QUOTA_BYTES;
    cpmMessaging.logMessage(
      `DuckDuckGo Embedded Extension loaded.
        Content scripts: ${JSON.stringify(scripts)}
        Alarms: ${JSON.stringify(alarms)}
        Current time: ${Date.now()}
        Bytes in session storage: ${bytesInSessionStorage} (Quota ${quotaBytes})
        `
    );
  });
  self.components = components;
})();
/*
 * [js-sha1]{@link https://github.com/emn178/js-sha1}
 *
 * @version 0.6.0
 * @author Chen, Yi-Cyuan [emn178@gmail.com]
 * @copyright Chen, Yi-Cyuan 2014-2017
 * @license MIT
 */
